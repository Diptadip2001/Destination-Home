if (typeof mouseflow === 'undefined' && typeof mouseflowPlayback === 'undefined') {
    (function() {
        var _493 = false;
        var _494 = false;
        var _472 = [];
        var _473 = [];
        var _54 = 'https://us.mouseflow.com';

        function _8(_131, _14) {
            _14 = (typeof _14 !== 'undefined' ? _14 : '');
            if (_4.debug) console.log('MF' + (_4.includeDebugTime ? ' - ' + _14 : '') + ': ' + _131)
        }
        var _29 = new _831(window);
        var _21 = new _774(window);
        var _10 = new _771(window, Math, JSON, _29);
        var _25 = new _963(_29, _10);
        var _58 = new _572('local', window, _10, _8);
        var _149 = new _572('session', window, _10, _8);
        var _301 = new _801(window);
        var _4 = new _992(window, _58, _493, _494);
        _4._352 = [];
        _4._353 = [];
        _4._193 = [];
        _4._1042 = [];
        _4._53 = '859dff4a-a2be-47c5-9d1f-d88c52663e18';
        _4._439 = true;
        _4._861 = '5242000';
        _4._298('appUrl', _54);

        function _676(_3, _128, _29, _4, _21, _10, _25, _189, _236, _58, _149, _148, _465, _8, _301) {
            var _909 = false;
            var _151 = 'https://n2.mouseflow.com/';
            var _221 = 100.00000;
            var _169 = [];
            var _977 = [];
            var _800 = [];
            var _263 = ["destinationhomes.com"];
            var _663 = false;
            var _913 = false;
            var _900 = '2023-12-11T08:53:49.0472604Z';
            var _252 = '17.97';
            var _167 = false;
            var _632 = false;
            var _92 = false;
            var _216 = false;
            var _375 = false;
            var _690 = /\[(\d+)\]_mf$/;
            var _11 = _3.document;
            var _73 = _3.location;
            _779();
            var _13 = _791();
            var _0 = _523();
            var _328 = _866();
            var _59 = {
                _607: 100,
                _850: 250,
                _974: 10000,
                _975: 300000,
                _518: 1336,
                _394: 1800000,
                _883: 3600000,
                _901: 7776000000,
                _986: 100,
                _873: 2000,
                _657: 8000,
                _314: 2048,
                _806: 200,
                _808: 5000
            };
            var _431, _430, _429, _428, _251, _249, _274, _403, _318, _102, _612 = [],
                _610 = [],
                _673 = [],
                _388 = [],
                _349 = new Map();
            var _6 = {
                _347: 0,
                _295: 1,
                _297: 2,
                _323: 3,
                _344: 4,
                _211: 5,
                _213: 6,
                _214: 7,
                _385: 8,
                _343: 9,
                _246: 10,
                _504: 11,
                _500: 12,
                _325: 13,
                _662: 14,
                _96: 15,
                _1053: 16,
                _1052: 17,
                _87: 18,
                _379: 19,
                _843: 20,
                _413: 21,
                _414: 22,
                _356: 23,
                _444: 24,
                _443: 25,
                _442: 26,
                _441: 27,
                _440: 28,
                _557: 29,
                _437: 30,
                _543: 31,
                _436: 32,
                _363: 33,
                _702: 34,
                _207: 35,
                _501: 36,
                _502: 37,
                _61: 38,
                _387: 39,
                _991: 40,
                _260: 41,
                _97: 42,
                _370: 43
            };
            var _111 = {
                _556: {
                    _22: 'bounce',
                    _5: 2,
                    _41: 1,
                    _150: 1000
                },
                _617: {
                    _22: 'click-rage',
                    _5: 5,
                    _41: 2,
                    _150: 2000
                },
                _412: {
                    _22: 'click-error',
                    _5: 2,
                    _41: 3,
                    _150: 20
                },
                _214: {
                    _22: 'mouse-out',
                    _5: 1,
                    _41: 5,
                    _150: 20
                },
                _547: {
                    _22: 'speed-browsing',
                    _5: 1,
                    _41: 6,
                    _150: 1000
                },
                _207: {
                    _22: 'submit-failure',
                    _5: 3,
                    _41: 7,
                    _150: 20
                }
            };
            var _776 = /[\x20\r\n]+/g;
            var _825 = /(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@/;
            var _830 = /^\d{12,19}$/;
            var _847 = /^(onbeforeunload|onblur|onchange|onclick|onfocus|oninput|onkeydown|onkeypress|onkeyup|onload|onmousedown|onmouseenter|onmouseleave|onmousemove|onmouseout|onmouseover|onmouseup|onresize|onsubmit|ontouchcancel|ontouchend|ontouchenter|ontouchleave|ontouchmove|ontouchstart|onunload)$/;
            var _834 = /checkbox|radio|button|submit|file|image|reset/;
            var _828 = [{
                name: 'VISA',
                patternRegex: /^4(\d{15}|\d{17,18})$/
            }, {
                name: 'Mastercard',
                patternRegex: /^(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720|5[1-5]\d\d)\d{12}$/
            }, {
                name: 'American Express',
                patternRegex: /^3[47]\d{13}$/
            }, {
                name: 'Diners Club',
                patternRegex: /^3(0[0-5]|[689]\d)(\d{11}|\d{13}|\d{16})$/
            }, {
                name: 'Discover',
                patternRegex: /^(6011|64[456789]\d|65\d{2})(\d{12}|\d{15})$/
            }, {
                name: 'JCB',
                patternRegex: /^(352[89]|35[3-8]\d|2131|1800)\d{12,15}$/
            }, {
                name: 'China UnionPay',
                patternRegex: /^(62[03456]\d{3}]|6210\d\d|621[1-7]\d\d|6218[0-2]\d|6218[4-9]\d|6219[0-7]\d|6220[0-579]\d|62201\d|6220[2-9]\d|622[1-9]\d{2}|622018|627[026]\d\d|62770\d|6277[1-7]\d|62778[1-9]|62779\d|628[2-9]\d\d|629[12]\d\d|810\d\d\d|811\d\d\d|81[2-6]\d\d\d|817[01]\d\d)\d{8,13}$/
            }, {
                name: 'Maestro',
                patternRegex: /^((493698|50000\d|5000[1-9]\d|500[1-9]\d{2}|50[1-3]\d{3}|5040\d{2}|5041[0-6]\d|50417[0-4]|50417[6-9]|5041[89]\d|504[2-9]\d{2}|505\d{3}|506[0-5]\d{2}|5066[0-8]\d|50669[0-8]|506779|5067[89]\d|506[89]\d{2}|50[78]\d{3})\d{6,13}|(5[6-9]|63|67|6\d)\d{10,17})$/
            }, {
                name: 'Elo',
                patternRegex: /^(40117[89]|438935|457631|457632|431274|451416|457393|504175|506699|5067[0-6]\d|50677[0-8]|50900\d|5090[1-9]\d|509[1-9]\d{2}|627780|636297|636368|65003[1-3]|65003[5-9]|65004\d|65005[01]|65040[5-9]|6504[1-3]\d|65048[5-9]|65049\d|6505[0-2]\d|65053[0-8]|65054[1-9]|6505[5-8]\d|65059[0-8]|65070\d|65071[0-8]|65072[0-7]|65090[1-9]|6509[1-6]\d|65097[0-8]|65165[2-9]|6516[67]\d|65500\d|65501\d|65502[1-9]|6550[34]\d|65505[0-8])\d{10}$/
            }, {
                name: 'Hiper',
                patternRegex: /^(637095|63737423|63743358|637568|637599|637609|637612)\d{10}$/
            }, {
                name: 'Hipercard',
                patternRegex: /^(606282)\d{10}$/
            }, {
                name: 'Dankort',
                patternRegex: /^5019\d{12}$/
            }, {
                name: 'VISA Dankort',
                patternRegex: /^4571\d{12}$/
            }];
            var _829 = (function(_759) {
                return function(_724) {
                    var _720 = _724.length,
                        _760 = 1,
                        _367 = 0,
                        _195;
                    while (_720) {
                        _195 = parseInt(_724.charAt(--_720), 10);
                        _367 += (_760 ^= 1) ? _759[_195] : _195
                    }
                    return _367 && _367 % 10 === 0
                }
            }([0, 2, 4, 6, 8, 1, 3, 5, 7, 9]));

            function _648() {
                _3._mfq = []
            }

            function _779() {
                if (!_3._mfq) _648();
                for (var _49 = 0; _49 < _3._mfq.length; _49++) {
                    var _52 = _3._mfq[_49];
                    if (_52 && _52.length) {
                        var _710 = true;
                        if (_52[0] === 'config') _4._298.apply(_4, _52.slice(1));
                        else if (_52[0] === 'newPageView') _4._484.apply(_4, _52.slice(1));
                        else _710 = false;
                        if (_710) delete _3._mfq[_49]
                    }
                }
            }

            function _641(_362) {
                if (!_362) _362 = [];
                var _47 = this;
                _3.setTimeout(function() {
                    for (var _49 = 0; _49 < _362.length; _49++) _47.push(_362[_49])
                }, 1)
            }
            _641.prototype.push = function(_52) {
                if (!_52) return;
                try {
                    if (typeof _52 === 'object' && _52.length) {
                        mouseflow[_52.slice(0, 1)].apply(mouseflow, _52.slice(1))
                    } else if (typeof _52 === 'function') {
                        _52(mouseflow)
                    }
                } catch (error) {
                    var _182 = 'Failed to execute item on action queue';
                    var _707 = _10._114(_52);
                    if (_707) _182 += '\n' + _707;
                    _182 += '\n' + error;
                    _8(_182, _14())
                }
            };
            // Copyright 2011 Google Inc.
            //
            // Licensed under the Apache License, Version 2.0 (the "License");
            // you may not use this file except in compliance with the License.
            // You may obtain a copy of the License at
            //
            //     http://www.apache.org/licenses/LICENSE-2.0
            //
            // Unless required by applicable law or agreed to in writing, software
            // distributed under the License is distributed on an "AS IS" BASIS,
            // WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
            // See the License for the specific language governing permissions and
            // limitations under the License.
            //
            // This component contains modifications carried out by Mouseflow ApS.
            var __extends = this.__extends || function(d, b) {
                for (var p in b)
                    if (b.hasOwnProperty(p)) d[p] = b[p];

                function __() {
                    this.constructor = d
                }
                __.prototype = b.prototype;
                d.prototype = new __()
            };
            var MutationObserverCtor;
            if (typeof WebKitMutationObserver !== 'undefined') MutationObserverCtor = WebKitMutationObserver;
            else if (typeof MutationObserver !== 'undefined') MutationObserverCtor = MutationObserver;
            if (MutationObserverCtor === undefined) {
                _8('DOM Mutation Observers not supported.', _14())
            }
            var NodeMap = (function() {
                function NodeMap() {
                    this.nodes = [];
                    this.values = []
                }
                NodeMap.prototype.isIndex = function(s) {
                    return +s === s >>> 0
                };
                NodeMap.prototype.nodeId = function(node) {
                    var id = node[NodeMap.ID_PROP];
                    if (!id) id = node[NodeMap.ID_PROP] = NodeMap.nextId_++;
                    return id
                };
                NodeMap.prototype.set = function(node, value) {
                    var id = this.nodeId(node);
                    this.nodes[id] = node;
                    this.values[id] = value
                };
                NodeMap.prototype.get = function(node) {
                    var id = this.nodeId(node);
                    return this.values[id]
                };
                NodeMap.prototype.has = function(node) {
                    return this.nodeId(node) in this.nodes
                };
                NodeMap.prototype.deleteNode = function(node) {
                    var id = this.nodeId(node);
                    delete this.nodes[id];
                    this.values[id] = undefined
                };
                NodeMap.prototype.keys = function() {
                    var nodes = [];
                    for (var id in this.nodes) {
                        if (!this.isIndex(id)) continue;
                        nodes.push(this.nodes[id])
                    }
                    return nodes
                };
                NodeMap.ID_PROP = '__mouseflow_node_map_id__';
                NodeMap.nextId_ = 1;
                return NodeMap
            })();
            var Movement;
            (function(Movement) {
                Movement[Movement['STAYED_OUT'] = 0] = 'STAYED_OUT';
                Movement[Movement['ENTERED'] = 1] = 'ENTERED';
                Movement[Movement['STAYED_IN'] = 2] = 'STAYED_IN';
                Movement[Movement['REPARENTED'] = 3] = 'REPARENTED';
                Movement[Movement['REORDERED'] = 4] = 'REORDERED';
                Movement[Movement['EXITED'] = 5] = 'EXITED'
            })(Movement || (Movement = {}));

            function enteredOrExited(changeType) {
                return changeType === Movement.ENTERED || changeType === Movement.EXITED
            }
            var NodeChange = (function() {
                function NodeChange(node, childList, attributes, characterData, oldParentNode, added, attributeOldValues, characterDataOldValue) {
                    if (childList === void 0) {
                        childList = false
                    }
                    if (attributes === void 0) {
                        attributes = false
                    }
                    if (characterData === void 0) {
                        characterData = false
                    }
                    if (oldParentNode === void 0) {
                        oldParentNode = null
                    }
                    if (added === void 0) {
                        added = false
                    }
                    if (attributeOldValues === void 0) {
                        attributeOldValues = null
                    }
                    if (characterDataOldValue === void 0) {
                        characterDataOldValue = null
                    }
                    this.node = node;
                    this.childList = childList;
                    this.attributes = attributes;
                    this.characterData = characterData;
                    this.oldParentNode = oldParentNode;
                    this.added = added;
                    this.attributeOldValues = attributeOldValues;
                    this.characterDataOldValue = characterDataOldValue;
                    this.isCaseInsensitive = this.node.nodeType === 1 && this.node instanceof HTMLElement && typeof(HTMLDocument) !== 'undefined' && this.node.ownerDocument instanceof HTMLDocument
                }
                NodeChange.prototype.getAttributeOldValue = function(name) {
                    if (!this.attributeOldValues) return undefined;
                    if (this.isCaseInsensitive) name = name.toLowerCase();
                    return this.attributeOldValues[name]
                };
                NodeChange.prototype.getAttributeNamesMutated = function() {
                    var names = [];
                    if (!this.attributeOldValues) return names;
                    for (var name in this.attributeOldValues) {
                        names.push(name)
                    }
                    return names
                };
                NodeChange.prototype.attributeMutated = function(name, oldValue) {
                    this.attributes = true;
                    this.attributeOldValues = this.attributeOldValues || {};
                    if (name in this.attributeOldValues) return;
                    this.attributeOldValues[name] = oldValue
                };
                NodeChange.prototype.characterDataMutated = function(oldValue) {
                    if (this.characterData) return;
                    this.characterData = true;
                    this.characterDataOldValue = oldValue
                };
                NodeChange.prototype.removedFromParent = function(parent) {
                    this.childList = true;
                    if (this.added || this.oldParentNode) this.added = false;
                    else this.oldParentNode = parent
                };
                NodeChange.prototype.insertedIntoParent = function() {
                    this.childList = true;
                    this.added = true
                };
                NodeChange.prototype.getOldParent = function() {
                    if (this.childList) {
                        if (this.oldParentNode) return this.oldParentNode;
                        if (this.added) return null
                    }
                    return _29._71(this.node)
                };
                return NodeChange
            })();
            var ChildListChange = (function() {
                function ChildListChange() {
                    this.added = new NodeMap();
                    this.removed = new NodeMap();
                    this.maybeMoved = new NodeMap();
                    this.oldPrevious = new NodeMap();
                    this.moved = undefined
                }
                return ChildListChange
            })();
            var TreeChanges = (function(_701) {
                __extends(TreeChanges, _701);

                function TreeChanges(rootNode, mutations) {
                    _701.call(this);
                    this.rootNode = rootNode;
                    this.reachableCache = undefined;
                    this.wasReachableCache = undefined;
                    this.anyParentsChanged = false;
                    this.anyAttributesChanged = false;
                    this.anyCharacterDataChanged = false;
                    for (var m = 0; m < mutations.length; m++) {
                        var mutation = mutations[m];
                        switch (mutation.type) {
                            case 'childList':
                                this.anyParentsChanged = true;
                                for (var i = 0; i < mutation.removedNodes.length; i++) {
                                    var node = mutation.removedNodes[i];
                                    this.getChange(node).removedFromParent(mutation.target)
                                }
                                for (var i = 0; i < mutation.addedNodes.length; i++) {
                                    var node = mutation.addedNodes[i];
                                    this.getChange(node).insertedIntoParent()
                                }
                                break;
                            case 'attributes':
                                this.anyAttributesChanged = true;
                                var change = this.getChange(mutation.target);
                                change.attributeMutated(mutation.attributeName, mutation.oldValue);
                                break;
                            case 'characterData':
                                this.anyCharacterDataChanged = true;
                                var change = this.getChange(mutation.target);
                                change.characterDataMutated(mutation.oldValue);
                                break
                        }
                    }
                }
                TreeChanges.prototype.getChange = function(node) {
                    var change = this.get(node);
                    if (!change) {
                        change = new NodeChange(node);
                        this.set(node, change)
                    }
                    return change
                };
                TreeChanges.prototype.getOldParent = function(node) {
                    var change = this.get(node);
                    return change ? change.getOldParent() : _29._71(node)
                };
                TreeChanges.prototype.getIsReachable = function(node) {
                    if (node === this.rootNode) return true;
                    if (!node) return false;
                    this.reachableCache = this.reachableCache || new NodeMap();
                    var isReachable = this.reachableCache.get(node);
                    if (isReachable === undefined) {
                        isReachable = this.getIsReachable(_29._71(node));
                        this.reachableCache.set(node, isReachable)
                    }
                    return isReachable
                };
                TreeChanges.prototype.getWasReachable = function(node) {
                    if (node === this.rootNode) return true;
                    if (!node) return false;
                    this.wasReachableCache = this.wasReachableCache || new NodeMap();
                    var wasReachable = this.wasReachableCache.get(node);
                    if (wasReachable === undefined) {
                        wasReachable = this.getWasReachable(this.getOldParent(node));
                        this.wasReachableCache.set(node, wasReachable)
                    }
                    return wasReachable
                };
                TreeChanges.prototype.reachabilityChange = function(node) {
                    if (this.getIsReachable(node)) {
                        return this.getWasReachable(node) ? Movement.STAYED_IN : Movement.ENTERED
                    }
                    return this.getWasReachable(node) ? Movement.EXITED : Movement.STAYED_OUT
                };
                return TreeChanges
            })(NodeMap);
            var MutationProjection = (function() {
                function MutationProjection(rootNode, mutations, selectors, calcReordered, calcOldPreviousSibling) {
                    this.rootNode = rootNode;
                    this.mutations = mutations;
                    this.selectors = selectors;
                    this.calcReordered = calcReordered;
                    this.calcOldPreviousSibling = calcOldPreviousSibling;
                    this.treeChanges = new TreeChanges(rootNode, mutations);
                    this.entered = [];
                    this.exited = [];
                    this.stayedIn = new NodeMap();
                    this.visited = new NodeMap();
                    this.childListChangeMap = undefined;
                    this.characterDataOnly = undefined;
                    this.matchCache = undefined;
                    this.processMutations()
                }
                MutationProjection.prototype.processMutations = function() {
                    if (!this.treeChanges.anyParentsChanged && !this.treeChanges.anyAttributesChanged) return;
                    var changedNodes = this.treeChanges.keys();
                    for (var i = 0; i < changedNodes.length; i++) {
                        this.visitNode(changedNodes[i], undefined)
                    }
                };
                MutationProjection.prototype.visitNode = function(node, parentReachable) {
                    if (this.visited.has(node)) return;
                    this.visited.set(node, true);
                    var change = this.treeChanges.get(node);
                    var reachable = parentReachable;
                    if ((change && change.childList) || reachable == undefined) reachable = this.treeChanges.reachabilityChange(node);
                    if (reachable === Movement.STAYED_OUT) return;
                    this.matchabilityChange(node);
                    if (reachable === Movement.ENTERED) {
                        this.entered.push(node)
                    } else if (reachable === Movement.EXITED) {
                        this.exited.push(node);
                        this.ensureHasOldPreviousSiblingIfNeeded(node)
                    } else if (reachable === Movement.STAYED_IN) {
                        var movement = Movement.STAYED_IN;
                        if (change && change.childList) {
                            if (change.oldParentNode !== _29._71(node)) {
                                movement = Movement.REPARENTED;
                                this.ensureHasOldPreviousSiblingIfNeeded(node)
                            } else if (this.calcReordered && this.wasReordered(node)) {
                                movement = Movement.REORDERED
                            }
                        }
                        this.stayedIn.set(node, movement)
                    }
                    if (reachable === Movement.STAYED_IN) return;
                    for (var child = _29._203(node); child; child = _29._166(child)) {
                        this.visitNode(child, reachable)
                    }
                };
                MutationProjection.prototype.ensureHasOldPreviousSiblingIfNeeded = function(node) {
                    if (!this.calcOldPreviousSibling) return;
                    this.processChildlistChanges();
                    var parentNode = _29._71(node);
                    var nodeChange = this.treeChanges.get(node);
                    if (nodeChange && nodeChange.oldParentNode) parentNode = nodeChange.oldParentNode;
                    var change = this.childListChangeMap.get(parentNode);
                    if (!change) {
                        change = new ChildListChange();
                        this.childListChangeMap.set(parentNode, change)
                    }
                    if (!change.oldPrevious.has(node)) {
                        change.oldPrevious.set(node, node.previousSibling)
                    }
                };
                MutationProjection.prototype.getChanged = function(summary, selectors, characterDataOnly) {
                    this.selectors = selectors;
                    this.characterDataOnly = characterDataOnly;
                    for (var i = 0; i < this.entered.length; i++) {
                        var node = this.entered[i];
                        var matchable = this.matchabilityChange(node);
                        if (matchable === Movement.ENTERED || matchable === Movement.STAYED_IN) summary.added.push(node)
                    }
                    var stayedInNodes = this.stayedIn.keys();
                    for (var i = 0; i < stayedInNodes.length; i++) {
                        var node = stayedInNodes[i];
                        var matchable = this.matchabilityChange(node);
                        if (matchable === Movement.ENTERED) {
                            summary.added.push(node)
                        } else if (matchable === Movement.EXITED) {
                            summary.removed.push(node)
                        } else if (matchable === Movement.STAYED_IN && (summary.reparented || summary.reordered)) {
                            var movement = this.stayedIn.get(node);
                            if (summary.reparented && movement === Movement.REPARENTED) summary.reparented.push(node);
                            else if (summary.reordered && movement === Movement.REORDERED) summary.reordered.push(node)
                        }
                    }
                    for (var i = 0; i < this.exited.length; i++) {
                        var node = this.exited[i];
                        var matchable = this.matchabilityChange(node);
                        if (matchable === Movement.EXITED || matchable === Movement.STAYED_IN) summary.removed.push(node)
                    }
                };
                MutationProjection.prototype.getOldParentNode = function(node) {
                    var change = this.treeChanges.get(node);
                    if (change && change.childList) return change.oldParentNode ? change.oldParentNode : null;
                    var reachabilityChange = this.treeChanges.reachabilityChange(node);
                    if (reachabilityChange === Movement.STAYED_OUT || reachabilityChange === Movement.ENTERED) throw Error('getOldParentNode requested on invalid node.');
                    return _29._71(node)
                };
                MutationProjection.prototype.getOldPreviousSibling = function(node) {
                    var parentNode = _29._71(node);
                    var nodeChange = this.treeChanges.get(node);
                    if (nodeChange && nodeChange.oldParentNode) parentNode = nodeChange.oldParentNode;
                    var change = this.childListChangeMap.get(parentNode);
                    if (!change) throw Error('getOldPreviousSibling requested on invalid node.');
                    return change.oldPrevious.get(node)
                };
                MutationProjection.prototype.getOldAttribute = function(element, attrName) {
                    var change = this.treeChanges.get(element);
                    if (!change || !change.attributes) throw Error('getOldAttribute requested on invalid node.');
                    var value = change.getAttributeOldValue(attrName);
                    if (value === undefined) throw Error('getOldAttribute requested for unchanged attribute name.');
                    return value
                };
                MutationProjection.prototype.attributeChangedNodes = function(includeAttributes) {
                    if (!this.treeChanges.anyAttributesChanged) return {};
                    var attributeFilter;
                    var caseInsensitiveFilter;
                    if (includeAttributes) {
                        attributeFilter = {};
                        caseInsensitiveFilter = {};
                        for (var i = 0; i < includeAttributes.length; i++) {
                            var attrName = includeAttributes[i];
                            attributeFilter[attrName] = true;
                            caseInsensitiveFilter[attrName.toLowerCase()] = attrName
                        }
                    }
                    var result = {};
                    var nodes = this.treeChanges.keys();
                    for (var i = 0; i < nodes.length; i++) {
                        var node = nodes[i];
                        var change = this.treeChanges.get(node);
                        if (!change.attributes) continue;
                        if (Movement.STAYED_IN !== this.treeChanges.reachabilityChange(node) || Movement.STAYED_IN !== this.matchabilityChange(node)) {
                            continue
                        }
                        var element = node;
                        var changedAttrNames = change.getAttributeNamesMutated();
                        for (var j = 0; j < changedAttrNames.length; j++) {
                            var attrName = changedAttrNames[j];
                            if (attributeFilter && !attributeFilter[attrName] && !(change.isCaseInsensitive && caseInsensitiveFilter[attrName])) {
                                continue
                            }
                            var oldValue = change.getAttributeOldValue(attrName);
                            if (oldValue === element.getAttribute(attrName)) continue;
                            if (caseInsensitiveFilter && change.isCaseInsensitive) attrName = caseInsensitiveFilter[attrName];
                            result[attrName] = result[attrName] || [];
                            result[attrName].push(element)
                        }
                    }
                    return result
                };
                MutationProjection.prototype.getOldCharacterData = function(node) {
                    var change = this.treeChanges.get(node);
                    if (!change || !change.characterData) throw Error('getOldCharacterData requested on invalid node.');
                    return change.characterDataOldValue
                };
                MutationProjection.prototype.getCharacterDataChanged = function() {
                    if (!this.treeChanges.anyCharacterDataChanged) return [];
                    var nodes = this.treeChanges.keys();
                    var result = [];
                    for (var i = 0; i < nodes.length; i++) {
                        var target = nodes[i];
                        if (Movement.STAYED_IN !== this.treeChanges.reachabilityChange(target)) continue;
                        var change = this.treeChanges.get(target);
                        if (!change.characterData || target.textContent == change.characterDataOldValue) continue;
                        result.push(target)
                    }
                    return result
                };
                MutationProjection.prototype.computeMatchabilityChange = function(selector, el) {
                    if (!this.matchCache) this.matchCache = [];
                    if (!this.matchCache[selector.uid]) this.matchCache[selector.uid] = new NodeMap();
                    var cache = this.matchCache[selector.uid];
                    var result = cache.get(el);
                    if (result === undefined) {
                        result = selector.matchabilityChange(el, this.treeChanges.get(el));
                        cache.set(el, result)
                    }
                    return result
                };
                MutationProjection.prototype.matchabilityChange = function(node) {
                    var _47 = this;
                    if (this.characterDataOnly) {
                        switch (node.nodeType) {
                            case 8:
                            case 3:
                                return Movement.STAYED_IN;
                            default:
                                return Movement.STAYED_OUT
                        }
                    }
                    if (!this.selectors) return Movement.STAYED_IN;
                    if (node.nodeType !== 1) return Movement.STAYED_OUT;
                    var el = node;
                    var matchChanges = this.selectors.map(function(selector) {
                        return _47.computeMatchabilityChange(selector, el)
                    });
                    var accum = Movement.STAYED_OUT;
                    var i = 0;
                    while (accum !== Movement.STAYED_IN && i < matchChanges.length) {
                        switch (matchChanges[i]) {
                            case Movement.STAYED_IN:
                                accum = Movement.STAYED_IN;
                                break;
                            case Movement.ENTERED:
                                if (accum === Movement.EXITED) accum = Movement.STAYED_IN;
                                else accum = Movement.ENTERED;
                                break;
                            case Movement.EXITED:
                                if (accum === Movement.ENTERED) accum = Movement.STAYED_IN;
                                else accum = Movement.EXITED;
                                break
                        }
                        i++
                    }
                    return accum
                };
                MutationProjection.prototype.getChildlistChange = function(el) {
                    var change = this.childListChangeMap.get(el);
                    if (!change) {
                        change = new ChildListChange();
                        this.childListChangeMap.set(el, change)
                    }
                    return change
                };
                MutationProjection.prototype.processChildlistChanges = function() {
                    if (this.childListChangeMap) return;
                    this.childListChangeMap = new NodeMap();
                    for (var i = 0; i < this.mutations.length; i++) {
                        var mutation = this.mutations[i];
                        if (mutation.type != 'childList') continue;
                        if (this.treeChanges.reachabilityChange(mutation.target) !== Movement.STAYED_IN && !this.calcOldPreviousSibling) continue;
                        var change = this.getChildlistChange(mutation.target);
                        var oldPrevious = mutation.previousSibling;

                        function recordOldPrevious(node, previous) {
                            if (!node || change.oldPrevious.has(node) || change.added.has(node) || change.maybeMoved.has(node)) return;
                            if (previous && (change.added.has(previous) || change.maybeMoved.has(previous))) return;
                            change.oldPrevious.set(node, previous)
                        }
                        for (var j = 0; j < mutation.removedNodes.length; j++) {
                            var node = mutation.removedNodes[j];
                            recordOldPrevious(node, oldPrevious);
                            if (change.added.has(node)) {
                                change.added.deleteNode(node)
                            } else {
                                change.removed.set(node, true);
                                change.maybeMoved.deleteNode(node)
                            }
                            oldPrevious = node
                        }
                        recordOldPrevious(mutation.nextSibling, oldPrevious);
                        for (var j = 0; j < mutation.addedNodes.length; j++) {
                            var node = mutation.addedNodes[j];
                            if (change.removed.has(node)) {
                                change.removed.deleteNode(node);
                                change.maybeMoved.set(node, true)
                            } else {
                                change.added.set(node, true)
                            }
                        }
                    }
                };
                MutationProjection.prototype.wasReordered = function(node) {
                    if (!this.treeChanges.anyParentsChanged) return false;
                    this.processChildlistChanges();
                    var parentNode = _29._71(node);
                    var nodeChange = this.treeChanges.get(node);
                    if (nodeChange && nodeChange.oldParentNode) parentNode = nodeChange.oldParentNode;
                    var change = this.childListChangeMap.get(parentNode);
                    if (!change) return false;
                    if (change.moved) return change.moved.get(node);
                    change.moved = new NodeMap();
                    var pendingMoveDecision = new NodeMap();

                    function isMoved(node) {
                        if (!node) return false;
                        if (!change.maybeMoved.has(node)) return false;
                        var didMove = change.moved.get(node);
                        if (didMove !== undefined) return didMove;
                        if (pendingMoveDecision.has(node)) {
                            didMove = true
                        } else {
                            pendingMoveDecision.set(node, true);
                            didMove = getPrevious(node) !== getOldPrevious(node)
                        }
                        if (pendingMoveDecision.has(node)) {
                            pendingMoveDecision.deleteNode(node);
                            change.moved.set(node, didMove)
                        } else {
                            didMove = change.moved.get(node)
                        }
                        return didMove
                    }
                    var oldPreviousCache = new NodeMap();

                    function getOldPrevious(node) {
                        var oldPrevious = oldPreviousCache.get(node);
                        if (oldPrevious !== undefined) return oldPrevious;
                        oldPrevious = change.oldPrevious.get(node);
                        while (oldPrevious && (change.removed.has(oldPrevious) || isMoved(oldPrevious))) {
                            oldPrevious = getOldPrevious(oldPrevious)
                        }
                        if (oldPrevious === undefined) oldPrevious = node.previousSibling;
                        oldPreviousCache.set(node, oldPrevious);
                        return oldPrevious
                    }
                    var previousCache = new NodeMap();

                    function getPrevious(node) {
                        if (previousCache.has(node)) return previousCache.get(node);
                        var previous = node.previousSibling;
                        while (previous && (change.added.has(previous) || isMoved(previous))) previous = previous.previousSibling;
                        previousCache.set(node, previous);
                        return previous
                    }
                    change.maybeMoved.keys().forEach(isMoved);
                    return change.moved.get(node)
                };
                return MutationProjection
            })();
            var Summary = (function() {
                function Summary(projection, query) {
                    var _47 = this;
                    this.projection = projection;
                    this.added = [];
                    this.removed = [];
                    this.reparented = query.all || query.element || query.characterData ? [] : undefined;
                    this.reordered = query.all ? [] : undefined;
                    projection.getChanged(this, query.elementFilter, query.characterData);
                    if (query.all || query.attribute || query.attributeList) {
                        var filter = query.attribute ? [query.attribute] : query.attributeList;
                        var attributeChanged = projection.attributeChangedNodes(filter);
                        if (query.attribute) {
                            this.valueChanged = attributeChanged[query.attribute] || []
                        } else {
                            this.attributeChanged = attributeChanged;
                            if (query.attributeList) {
                                query.attributeList.forEach(function(attrName) {
                                    if (!_47.attributeChanged.hasOwnProperty(attrName)) _47.attributeChanged[attrName] = []
                                })
                            }
                        }
                    }
                    if (query.all || query.characterData) {
                        var characterDataChanged = projection.getCharacterDataChanged();
                        if (query.characterData) this.valueChanged = characterDataChanged;
                        else this.characterDataChanged = characterDataChanged
                    }
                    if (this.reordered) this.getOldPreviousSibling = projection.getOldPreviousSibling.bind(projection)
                }
                Summary.prototype.getOldParentNode = function(node) {
                    return this.projection.getOldParentNode(node)
                };
                Summary.prototype.getOldAttribute = function(node, name) {
                    return this.projection.getOldAttribute(node, name)
                };
                Summary.prototype.getOldCharacterData = function(node) {
                    return this.projection.getOldCharacterData(node)
                };
                Summary.prototype.getOldPreviousSibling = function(node) {
                    return this.projection.getOldPreviousSibling(node)
                };
                return Summary
            })();
            var validNameInitialChar = /[a-zA-Z_]+/;
            var validNameNonInitialChar = /[a-zA-Z0-9_\-]+/;

            function escapeQuotes(value) {
                return '"' + value.replace(/"/, '\\\"') + '"'
            }
            var Qualifier = (function() {
                function Qualifier() {}
                Qualifier.prototype.matches = function(oldValue) {
                    if (oldValue === null) return false;
                    if (this.attrValue === undefined) return true;
                    if (!this.contains) return this.attrValue == oldValue;
                    var tokens = oldValue.split(' ');
                    for (var i = 0; i < tokens.length; i++) {
                        if (this.attrValue === tokens[i]) return true
                    }
                    return false
                };
                Qualifier.prototype.toString = function() {
                    if (this.attrName === 'class' && this.contains) return '.' + this.attrValue;
                    if (this.attrName === 'id' && !this.contains) return '#' + this.attrValue;
                    if (this.contains) return '[' + this.attrName + '~=' + escapeQuotes(this.attrValue) + ']';
                    if ('attrValue' in this) return '[' + this.attrName + '=' + escapeQuotes(this.attrValue) + ']';
                    return '[' + this.attrName + ']'
                };
                return Qualifier
            })();
            var Selector = (function() {
                function Selector() {
                    this.uid = Selector.nextUid++;
                    this.qualifiers = []
                }
                try {
                    Object.defineProperty(Selector.prototype, 'caseInsensitiveTagName', {
                        get: function() {
                            return this.tagName.toUpperCase()
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(Selector.prototype, 'selectorString', {
                        get: function() {
                            return this.tagName + this.qualifiers.join('')
                        },
                        enumerable: true,
                        configurable: true
                    })
                } catch (e) {};
                Selector.prototype.isMatching = function(el) {
                    return el[Selector.matchesSelector](this.selectorString)
                };
                Selector.prototype.wasMatching = function(el, change, isMatching) {
                    if (!change || !change.attributes) return isMatching;
                    var tagName = change.isCaseInsensitive ? this.caseInsensitiveTagName : this.tagName;
                    if (tagName !== '*' && tagName !== el.tagName) return false;
                    var attributeOldValues = [];
                    var anyChanged = false;
                    for (var i = 0; i < this.qualifiers.length; i++) {
                        var qualifier = this.qualifiers[i];
                        var oldValue = change.getAttributeOldValue(qualifier.attrName);
                        attributeOldValues.push(oldValue);
                        anyChanged = anyChanged || (oldValue !== undefined)
                    }
                    if (!anyChanged) return isMatching;
                    for (var i = 0; i < this.qualifiers.length; i++) {
                        var qualifier = this.qualifiers[i];
                        var oldValue = attributeOldValues[i];
                        if (oldValue === undefined) oldValue = el.getAttribute(qualifier.attrName);
                        if (!qualifier.matches(oldValue)) return false
                    }
                    return true
                };
                Selector.prototype.matchabilityChange = function(el, change) {
                    var isMatching = this.isMatching(el);
                    if (isMatching) return this.wasMatching(el, change, isMatching) ? Movement.STAYED_IN : Movement.ENTERED;
                    else return this.wasMatching(el, change, isMatching) ? Movement.EXITED : Movement.STAYED_OUT
                };
                Selector.parseSelectors = function(input) {
                    var selectors = [];
                    var currentSelector;
                    var currentQualifier;

                    function newSelector() {
                        if (currentSelector) {
                            if (currentQualifier) {
                                currentSelector.qualifiers.push(currentQualifier);
                                currentQualifier = undefined
                            }
                            selectors.push(currentSelector)
                        }
                        currentSelector = new Selector()
                    }

                    function newQualifier() {
                        if (currentQualifier) currentSelector.qualifiers.push(currentQualifier);
                        currentQualifier = new Qualifier()
                    }
                    var WHITESPACE = /\s/;
                    var valueQuoteChar;
                    var SYNTAX_ERROR = 'Invalid or unsupported selector syntax.';
                    var SELECTOR = 1;
                    var TAG_NAME = 2;
                    var QUALIFIER = 3;
                    var QUALIFIER_NAME_FIRST_CHAR = 4;
                    var QUALIFIER_NAME = 5;
                    var ATTR_NAME_FIRST_CHAR = 6;
                    var ATTR_NAME = 7;
                    var EQUIV_OR_ATTR_QUAL_END = 8;
                    var EQUAL = 9;
                    var ATTR_QUAL_END = 10;
                    var VALUE_FIRST_CHAR = 11;
                    var VALUE = 12;
                    var QUOTED_VALUE = 13;
                    var SELECTOR_SEPARATOR = 14;
                    var state = SELECTOR;
                    var i = 0;
                    while (i < input.length) {
                        var c = input[i++];
                        switch (state) {
                            case SELECTOR:
                                if (c.match(validNameInitialChar)) {
                                    newSelector();
                                    currentSelector.tagName = c;
                                    state = TAG_NAME;
                                    break
                                }
                                if (c == '*') {
                                    newSelector();
                                    currentSelector.tagName = '*';
                                    state = QUALIFIER;
                                    break
                                }
                                if (c == '.') {
                                    newSelector();
                                    newQualifier();
                                    currentSelector.tagName = '*';
                                    currentQualifier.attrName = 'class';
                                    currentQualifier.contains = true;
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '#') {
                                    newSelector();
                                    newQualifier();
                                    currentSelector.tagName = '*';
                                    currentQualifier.attrName = 'id';
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '[') {
                                    newSelector();
                                    newQualifier();
                                    currentSelector.tagName = '*';
                                    currentQualifier.attrName = '';
                                    state = ATTR_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c.match(WHITESPACE)) break;
                                throw Error(SYNTAX_ERROR);
                            case TAG_NAME:
                                if (c.match(validNameNonInitialChar)) {
                                    currentSelector.tagName += c;
                                    break
                                }
                                if (c == '.') {
                                    newQualifier();
                                    currentQualifier.attrName = 'class';
                                    currentQualifier.contains = true;
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '#') {
                                    newQualifier();
                                    currentQualifier.attrName = 'id';
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '[') {
                                    newQualifier();
                                    currentQualifier.attrName = '';
                                    state = ATTR_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c.match(WHITESPACE)) {
                                    state = SELECTOR_SEPARATOR;
                                    break
                                }
                                if (c == ',') {
                                    state = SELECTOR;
                                    break
                                }
                                throw Error(SYNTAX_ERROR);
                            case QUALIFIER:
                                if (c == '.') {
                                    newQualifier();
                                    currentQualifier.attrName = 'class';
                                    currentQualifier.contains = true;
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '#') {
                                    newQualifier();
                                    currentQualifier.attrName = 'id';
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '[') {
                                    newQualifier();
                                    currentQualifier.attrName = '';
                                    state = ATTR_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c.match(WHITESPACE)) {
                                    state = SELECTOR_SEPARATOR;
                                    break
                                }
                                if (c == ',') {
                                    state = SELECTOR;
                                    break
                                }
                                throw Error(SYNTAX_ERROR);
                            case QUALIFIER_NAME_FIRST_CHAR:
                                if (c.match(validNameInitialChar)) {
                                    currentQualifier.attrValue = c;
                                    state = QUALIFIER_NAME;
                                    break
                                }
                                throw Error(SYNTAX_ERROR);
                            case QUALIFIER_NAME:
                                if (c.match(validNameNonInitialChar)) {
                                    currentQualifier.attrValue += c;
                                    break
                                }
                                if (c == '.') {
                                    newQualifier();
                                    currentQualifier.attrName = 'class';
                                    currentQualifier.contains = true;
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '#') {
                                    newQualifier();
                                    currentQualifier.attrName = 'id';
                                    state = QUALIFIER_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c == '[') {
                                    newQualifier();
                                    state = ATTR_NAME_FIRST_CHAR;
                                    break
                                }
                                if (c.match(WHITESPACE)) {
                                    state = SELECTOR_SEPARATOR;
                                    break
                                }
                                if (c == ',') {
                                    state = SELECTOR;
                                    break
                                }
                                throw Error(SYNTAX_ERROR);
                            case ATTR_NAME_FIRST_CHAR:
                                if (c.match(validNameInitialChar)) {
                                    currentQualifier.attrName = c;
                                    state = ATTR_NAME;
                                    break
                                }
                                if (c.match(WHITESPACE)) break;
                                throw Error(SYNTAX_ERROR);
                            case ATTR_NAME:
                                if (c.match(validNameNonInitialChar)) {
                                    currentQualifier.attrName += c;
                                    break
                                }
                                if (c.match(WHITESPACE)) {
                                    state = EQUIV_OR_ATTR_QUAL_END;
                                    break
                                }
                                if (c == '~') {
                                    currentQualifier.contains = true;
                                    state = EQUAL;
                                    break
                                }
                                if (c == '=') {
                                    currentQualifier.attrValue = '';
                                    state = VALUE_FIRST_CHAR;
                                    break
                                }
                                if (c == ']') {
                                    state = QUALIFIER;
                                    break
                                }
                                throw Error(SYNTAX_ERROR);
                            case EQUIV_OR_ATTR_QUAL_END:
                                if (c == '~') {
                                    currentQualifier.contains = true;
                                    state = EQUAL;
                                    break
                                }
                                if (c == '=') {
                                    currentQualifier.attrValue = '';
                                    state = VALUE_FIRST_CHAR;
                                    break
                                }
                                if (c == ']') {
                                    state = QUALIFIER;
                                    break
                                }
                                if (c.match(WHITESPACE)) break;
                                throw Error(SYNTAX_ERROR);
                            case EQUAL:
                                if (c == '=') {
                                    currentQualifier.attrValue = '';
                                    state = VALUE_FIRST_CHAR;
                                    break
                                }
                                throw Error(SYNTAX_ERROR);
                            case ATTR_QUAL_END:
                                if (c == ']') {
                                    state = QUALIFIER;
                                    break
                                }
                                if (c.match(WHITESPACE)) break;
                                throw Error(SYNTAX_ERROR);
                            case VALUE_FIRST_CHAR:
                                if (c.match(WHITESPACE)) break;
                                if (c == '"' || c == "'") {
                                    valueQuoteChar = c;
                                    state = QUOTED_VALUE;
                                    break
                                }
                                currentQualifier.attrValue += c;
                                state = VALUE;
                                break;
                            case VALUE:
                                if (c.match(WHITESPACE)) {
                                    state = ATTR_QUAL_END;
                                    break
                                }
                                if (c == ']') {
                                    state = QUALIFIER;
                                    break
                                }
                                if (c == "'" || c == '"') throw Error(SYNTAX_ERROR);
                                currentQualifier.attrValue += c;
                                break;
                            case QUOTED_VALUE:
                                if (c == valueQuoteChar) {
                                    state = ATTR_QUAL_END;
                                    break
                                }
                                currentQualifier.attrValue += c;
                                break;
                            case SELECTOR_SEPARATOR:
                                if (c.match(WHITESPACE)) break;
                                if (c == ',') {
                                    state = SELECTOR;
                                    break
                                }
                                throw Error(SYNTAX_ERROR)
                        }
                    }
                    switch (state) {
                        case SELECTOR:
                        case TAG_NAME:
                        case QUALIFIER:
                        case QUALIFIER_NAME:
                        case SELECTOR_SEPARATOR:
                            newSelector();
                            break;
                        default:
                            throw Error(SYNTAX_ERROR)
                    }
                    if (!selectors.length) throw Error(SYNTAX_ERROR);
                    return selectors
                };
                Selector.nextUid = 1;
                Selector.matchesSelector = (function() {
                    var element = _11.createElement('div');
                    if (typeof element['webkitMatchesSelector'] === 'function') return 'webkitMatchesSelector';
                    if (typeof element['mozMatchesSelector'] === 'function') return 'mozMatchesSelector';
                    if (typeof element['msMatchesSelector'] === 'function') return 'msMatchesSelector';
                    return 'matchesSelector'
                })();
                return Selector
            })();
            var attributeFilterPattern = /^([a-zA-Z:_]+[a-zA-Z0-9_\-:\.]*)$/;

            function validateAttribute(attribute) {
                if (typeof attribute != 'string') throw Error('Invalid request opion. attribute must be a non-zero length string.');
                attribute = attribute.trim();
                if (!attribute) throw Error('Invalid request opion. attribute must be a non-zero length string.');
                if (!attribute.match(attributeFilterPattern)) throw Error('Invalid request option. invalid attribute name: ' + attribute);
                return attribute
            }

            function validateElementAttributes(attribs) {
                if (!attribs.trim().length) throw Error('Invalid request option: elementAttributes must contain at least one attribute.');
                var lowerAttributes = {};
                var attributes = {};
                var tokens = attribs.split(/\s+/);
                for (var i = 0; i < tokens.length; i++) {
                    var name = tokens[i];
                    if (!name) continue;
                    var name = validateAttribute(name);
                    var nameLower = name.toLowerCase();
                    if (lowerAttributes[nameLower]) throw Error('Invalid request option: observing multiple case variations of the same attribute is not supported.');
                    attributes[name] = true;
                    lowerAttributes[nameLower] = true
                }
                return Object.keys(attributes)
            }

            function elementFilterAttributes(selectors) {
                var attributes = {};
                selectors.forEach(function(selector) {
                    selector.qualifiers.forEach(function(qualifier) {
                        attributes[qualifier.attrName] = true
                    })
                });
                return Object.keys(attributes)
            }
            var MutationSummary = (function() {
                function MutationSummary(opts) {
                    var _47 = this;
                    this.connected = false;
                    this.options = MutationSummary.validateOptions(opts);
                    this.observerOptions = MutationSummary.createObserverOptions(this.options.queries);
                    this.root = this.options.rootNode;
                    this.callback = this.options.callback;
                    this.elementFilter = Array.prototype.concat.apply([], this.options.queries.map(function(query) {
                        return query.elementFilter ? query.elementFilter : []
                    }));
                    if (!this.elementFilter.length) this.elementFilter = undefined;
                    this.calcReordered = this.options.queries.some(function(query) {
                        return query.all
                    });
                    this.queryValidators = [];
                    if (MutationSummary.createQueryValidator) {
                        this.queryValidators = this.options.queries.map(function(query) {
                            return MutationSummary.createQueryValidator(_47.root, query)
                        })
                    }
                    this.observer = MutationObserverCtor ? new MutationObserverCtor(function(mutations) {
                        _47.observerCallback(mutations)
                    }) : {
                        observe: function() {}
                    };
                    this.reconnect()
                }
                MutationSummary.createObserverOptions = function(queries) {
                    var observerOptions = {
                        childList: true,
                        subtree: true
                    };
                    var attributeFilter;

                    function observeAttributes(attributes) {
                        if (observerOptions.attributes && !attributeFilter) return;
                        observerOptions.attributes = true;
                        observerOptions.attributeOldValue = true;
                        if (!attributes) {
                            attributeFilter = undefined;
                            return
                        }
                        attributeFilter = attributeFilter || {};
                        attributes.forEach(function(attribute) {
                            attributeFilter[attribute] = true;
                            attributeFilter[attribute.toLowerCase()] = true
                        })
                    }
                    queries.forEach(function(query) {
                        if (query.characterData) {
                            observerOptions.characterData = true;
                            observerOptions.characterDataOldValue = true;
                            return
                        }
                        if (query.all) {
                            observeAttributes();
                            observerOptions.characterData = true;
                            observerOptions.characterDataOldValue = true;
                            return
                        }
                        if (query.attribute) {
                            observeAttributes([query.attribute.trim()]);
                            return
                        }
                        var attributes = elementFilterAttributes(query.elementFilter).concat(query.attributeList || []);
                        if (attributes.length) observeAttributes(attributes)
                    });
                    if (attributeFilter) observerOptions.attributeFilter = Object.keys(attributeFilter);
                    return observerOptions
                };
                MutationSummary.validateOptions = function(options) {
                    for (var prop in options) {
                        if (!(prop in MutationSummary.optionKeys)) throw Error('Invalid option: ' + prop)
                    }
                    if (typeof options.callback !== 'function') throw Error('Invalid options: callback is required and must be a function');
                    if (!options.queries || !options.queries.length) throw Error('Invalid options: queries must contain at least one query request object.');
                    var opts = {
                        callback: options.callback,
                        rootNode: options.rootNode || _11,
                        observeOwnChanges: !!options.observeOwnChanges,
                        oldPreviousSibling: !!options.oldPreviousSibling,
                        queries: []
                    };
                    for (var i = 0; i < options.queries.length; i++) {
                        var request = options.queries[i];
                        if (request.all) {
                            if (Object.keys(request).length > 1) throw Error('Invalid request option. all has no options.');
                            opts.queries.push({
                                all: true
                            });
                            continue
                        }
                        if ('attribute' in request) {
                            var query = {
                                attribute: validateAttribute(request.attribute)
                            };
                            query.elementFilter = Selector.parseSelectors('*[' + query.attribute + ']');
                            if (Object.keys(request).length > 1) throw Error('Invalid request option. attribute has no options.');
                            opts.queries.push(query);
                            continue
                        }
                        if ('element' in request) {
                            var requestOptionCount = Object.keys(request).length;
                            var query = {
                                element: request.element,
                                elementFilter: Selector.parseSelectors(request.element)
                            };
                            if (request.hasOwnProperty('elementAttributes')) {
                                query.attributeList = validateElementAttributes(request.elementAttributes);
                                requestOptionCount--
                            }
                            if (requestOptionCount > 1) throw Error('Invalid request option. element only allows elementAttributes option.');
                            opts.queries.push(query);
                            continue
                        }
                        if (request.characterData) {
                            if (Object.keys(request).length > 1) throw Error('Invalid request option. characterData has no options.');
                            opts.queries.push({
                                characterData: true
                            });
                            continue
                        }
                        throw Error('Invalid request option. Unknown query request.')
                    }
                    return opts
                };
                MutationSummary.prototype.createSummaries = function(mutations) {
                    if (!mutations || !mutations.length) return [];
                    var projection = new MutationProjection(this.root, mutations, this.elementFilter, this.calcReordered, this.options.oldPreviousSibling);
                    var summaries = [];
                    for (var i = 0; i < this.options.queries.length; i++) {
                        summaries.push(new Summary(projection, this.options.queries[i]))
                    }
                    return summaries
                };
                MutationSummary.prototype.checkpointQueryValidators = function() {
                    this.queryValidators.forEach(function(validator) {
                        if (validator) validator.recordPreviousState()
                    })
                };
                MutationSummary.prototype.runQueryValidators = function(summaries) {
                    this.queryValidators.forEach(function(validator, index) {
                        if (validator) validator.validate(summaries[index])
                    })
                };
                MutationSummary.prototype.changesToReport = function(summaries) {
                    return summaries.some(function(summary) {
                        var summaryProps = ['added', 'removed', 'reordered', 'reparented', 'valueChanged', 'characterDataChanged'];
                        if (summaryProps.some(function(prop) {
                                return summary[prop] && summary[prop].length
                            })) return true;
                        if (summary.attributeChanged) {
                            var attrNames = Object.keys(summary.attributeChanged);
                            var attrsChanged = attrNames.some(function(attrName) {
                                return !!summary.attributeChanged[attrName].length
                            });
                            if (attrsChanged) return true
                        }
                        return false
                    })
                };
                MutationSummary.prototype.observerCallback = function(mutations) {
                    if (!this.options.observeOwnChanges) this.observer.disconnect();
                    var summaries = this.createSummaries(mutations);
                    this.runQueryValidators(summaries);
                    if (this.options.observeOwnChanges) this.checkpointQueryValidators();
                    if (this.changesToReport(summaries)) this.callback(summaries);
                    if (!this.options.observeOwnChanges && this.connected) {
                        this.checkpointQueryValidators();
                        this.observer.observe(this.root, this.observerOptions)
                    }
                };
                MutationSummary.prototype.reconnect = function() {
                    if (this.connected) throw Error('Already connected');
                    this.observer.observe(this.root, this.observerOptions);
                    this.connected = true;
                    this.checkpointQueryValidators()
                };
                MutationSummary.prototype.takeSummaries = function() {
                    if (!this.connected) throw Error('Not connected');
                    var summaries = this.createSummaries(this.observer.takeRecords());
                    return this.changesToReport(summaries) ? summaries : undefined
                };
                MutationSummary.prototype.disconnect = function() {
                    var summaries = this.takeSummaries();
                    this.observer.disconnect();
                    this.connected = false;
                    return summaries
                };
                MutationSummary.NodeMap = NodeMap;
                MutationSummary.parseElementFilter = Selector.parseSelectors;
                MutationSummary.optionKeys = {
                    'callback': true,
                    'queries': true,
                    'rootNode': true,
                    'oldPreviousSibling': true,
                    'observeOwnChanges': true
                };
                return MutationSummary
            })();
            var TreeMirrorClient = (function() {
                function TreeMirrorClient(target, mirror, testingQueries) {
                    var _47 = this;
                    this.target = target;
                    this.mirror = mirror;
                    this.nextId = 1;
                    this.knownNodes = new MutationSummary.NodeMap();
                    this.mutationSummaries = [];
                    _371();
                    var serializedRoot = this.serializeNode(target, true);
                    var rootId = serializedRoot.id;
                    this.mirror.initialize(rootId, [serializedRoot]);
                    var queries = [{
                        all: true
                    }];
                    if (testingQueries) queries = queries.concat(testingQueries);
                    this.mutationSummaries.push(new MutationSummary({
                        rootNode: target,
                        callback: function(summaries) {
                            _47.applyChanged(summaries)
                        },
                        queries: queries
                    }))
                }
                TreeMirrorClient.prototype.addShadowRoot = function(shadow) {
                    if (!this.isKnownNode(shadow)) {
                        var data = this.serializeNode(shadow, true);
                        if (data) {
                            data.parentNode = this.serializeNode(shadow.host);
                            this.mirror.applyChanged({
                                removed: [],
                                addedOrMoved: [data],
                                attributes: [],
                                text: []
                            })
                        }
                    }
                    var _47 = this;
                    this.mutationSummaries.push(new MutationSummary({
                        rootNode: shadow,
                        callback: function(summaries) {
                            _47.applyChanged(summaries)
                        },
                        queries: [{
                            all: true
                        }]
                    }))
                };
                TreeMirrorClient.prototype.disconnect = function() {
                    this.mutationSummaries.forEach(function(mutationSummary) {
                        mutationSummary.disconnect()
                    });
                    this.mutationSummaries = []
                };
                TreeMirrorClient.prototype.rememberNode = function(node) {
                    var id = this.nextId++;
                    this.knownNodes.set(node, id);
                    return id
                };
                TreeMirrorClient.prototype.forgetNode = function(node) {
                    this.knownNodes.deleteNode(node)
                };
                TreeMirrorClient.prototype.isKnownNode = function(node) {
                    return !!this.knownNodes.get(node)
                };
                TreeMirrorClient.prototype.serializeNode = function(node, isInitial) {
                    if (node === null || _206(node, 'no-mouseflow-dom')) return null;
                    if (_206(node, _336)) return null;
                    var id = this.knownNodes.get(node);
                    if (id !== undefined) {
                        if (isInitial) return _8('Found duplicated node during initial DOM: ' + id, _14());
                        return {
                            id: id
                        }
                    }
                    var data = {
                        nodeType: node.nodeType,
                        id: this.rememberNode(node)
                    };
                    var parent = _29._71(node);
                    if (_10._174(node, 'data-mf-replace') || _10._174(node, 'data-mf-replace-inner')) return null;
                    var _645 = _611(node),
                        _698 = !!_206(parent, _336);
                    if (_645 || _698) {
                        _8('CSS Blacklist blocked node. NodeType: ' + node.nodeType + '. ' + (node.nodeType === 1 ? 'Tag: ' + node.tagName : ''), _14());
                        _235(node, _336, true);
                        if (isInitial && node.childNodes.length) {
                            var _44;
                            for (_44 = _29._203(node); _44; _44 = _29._166(_44)) this.serializeNode(_44, true)
                        }
                        if (_698) return null
                    }
                    if (isInitial) {
                        if (_206(parent, 'no-mouseflow-dom') || _10._156(node, 'no-mouseflow-dom')) _235(node, 'no-mouseflow-dom', 'initial')
                    } else if (_206(parent, 'no-mouseflow-dom')) {
                        _235(node, 'no-mouseflow-dom', 'inherit');
                        return null
                    }
                    switch (data.nodeType) {
                        case 9:
                            this.serializeAdoptedStyleSheets(node, data);
                            if (isInitial) this.serializeChildNodes(node, data);
                            break;
                        case 11:
                            data.isShadowRoot = _29._794(node);
                            this.serializeAdoptedStyleSheets(node, data);
                            if (isInitial) this.serializeChildNodes(node, data);
                            break;
                        case 10:
                            data.name = node.name;
                            data.publicId = node.publicId;
                            data.systemId = node.systemId;
                            break;
                        case 8:
                        case 3:
                            if (node.nodeType === 8 && node.textContent.indexOf('[if') !== 0 && node.textContent.indexOf('<![endif]') !== 0) break;
                            data.textContent = _600(node);
                            if (!_920(parent)) data.textContent = data.textContent.replace(_776, ' ');
                            if (parent && parent.tagName === 'STYLE' && /^\s*$/.test(node.textContent)) {
                                data.textContent = _294(parent.sheet)
                            }
                            break;
                        case 1:
                            if (node.tagName === 'IFRAME' && parent && parent.tagName === 'HEAD') {
                                data.nodeType = 8;
                                data.textContent = '';
                                break
                            }
                            data.tagName = node.tagName;
                            if (node.attributes['data-mf-replace']) {
                                var _253 = node.attributes['data-mf-replace'].value;
                                data = _671.call(this, _253, function(_20) {
                                    var _12 = this.serializeNode(_20, true);
                                    _12.id = data.id;
                                    this.knownNodes.set(_20, _12.id);
                                    return _12
                                })[0];
                                break
                            }
                            if (node.tagName === 'SCRIPT') {
                                if (/\/?aura_prod\.js(\?.+)?$/.test(node.src)) {
                                    _8('Salesforce Aura script added');
                                    _958();
                                    _955()
                                }
                                break
                            }
                            data.attributes = {};
                            if (_645) {
                                var _644 = _635(node);
                                if (node.id) data.attributes.id = node.id;
                                if (node.name) data.attributes.name = node.name;
                                data.attributes.style = (node.style ? node.style.cssText + '; ' : '') + 'width: ' + _644.width + 'px; height: ' + _644.height + 'px;' + (_3.getComputedStyle(node).display === 'inline' ? ' display: inline-block;' : '');
                                data.attributes.class = node.className + ' mf-excluded';
                                break
                            }
                            for (var i = 0; i < node.attributes.length; i++) {
                                var attr = node.attributes[i];
                                if (_832(attr.name.toLowerCase())) continue;
                                if (attr.name.toLowerCase() === 'value' && node.tagName === 'INPUT') data.attributes.value = _231(node);
                                else data.attributes[attr.name] = attr.value
                            }
                            if (node === _328) data.attributes.class = (data.attributes.class || '') + ' mf-scroll-main';
                            if (_673.indexOf(node) !== -1) data.attributes.class = (data.attributes.class || '') + ' mf-listen';
                            if (node.tagName === 'IFRAME' && node.offsetWidth <= 1 && node.offsetHeight <= 1) data.attributes.src = '';
                            if (isInitial && node.tagName === 'INPUT') {
                                if (!data.attributes.value && node.value) data.attributes.value = _231(node);
                                if (!data.attributes.checked && node.checked) data.attributes.checked = node.checked
                            }
                            if (isInitial && node.tagName === 'OPTION' && !data.attributes.selected && node.selected) data.attributes.selected = node.selected;
                            if (node.tagName === 'INPUT' && node.type === 'hidden' && data.attributes.value) data.attributes.value = '';
                            if (node.attributes['data-mf-replace-inner']) {
                                var _253 = node.attributes['data-mf-replace-inner'].value;
                                data.childNodes = _671.call(this, _253, function(_20) {
                                    return this.serializeNode(_20, true)
                                });
                                break
                            }
                            if (isInitial) {
                                this.serializeChildNodes(node, data);
                                if (node.shadowRoot) {
                                    if (!data.childNodes) data.childNodes = [];
                                    data.childNodes.push(this.serializeNode(node.shadowRoot, true))
                                }
                                var cssDomain = node.tagName === 'LINK' ? node.href.split('/')[2] : '-1';
                                var cssGetAllowed = _11.domain.indexOf(cssDomain) !== -1;
                                var _766 = node.tagName === 'LINK' && node.href && cssGetAllowed && (node.href.indexOf('blob:') === 0 || _4.enableCssRecording);
                                var _770 = node.tagName === 'STYLE' && !node.textContent;
                                var cssRules = _766 || _770 ? _294(node.sheet) : null;
                                if (cssRules) {
                                    data.childNodes = [{
                                        nodeType: 3,
                                        textContent: cssRules
                                    }];
                                    data.tagName = 'STYLE';
                                    data.href = undefined;
                                    data.rel = undefined
                                }
                            }
                            break
                    }
                    return data
                };
                TreeMirrorClient.prototype.serializeAddedAndMoved = function(added, reparented, reordered) {
                    var _47 = this;
                    var all = added.concat(reparented).concat(reordered);
                    var parentMap = new MutationSummary.NodeMap();
                    all.forEach(function(node) {
                        var parent = _29._71(node);
                        var children = parentMap.get(parent);
                        if (!children) {
                            children = new MutationSummary.NodeMap();
                            parentMap.set(parent, children)
                        }
                        children.set(node, true)
                    });
                    var moved = [];
                    var noMouseflowDom = [];
                    parentMap.keys().forEach(function(parent) {
                        var children = parentMap.get(parent);
                        var keys = children.keys();
                        while (keys.length) {
                            var node = keys[0];
                            while (node.previousSibling && children.has(node.previousSibling)) node = node.previousSibling;
                            var _188 = false;
                            while (node && children.has(node)) {
                                if (_688(node)) _188 = true;
                                else if (_686(node.previousSibling)) _188 = false;
                                if (!_188) {
                                    var data = _47.serializeNode(node);
                                    if (data) {
                                        var _361 = node.previousSibling;
                                        while (_361 && !data.previousSibling) {
                                            data.previousSibling = _47.serializeNode(_361);
                                            _361 = _361.previousSibling
                                        }
                                        data.parentNode = _47.serializeNode(_29._71(node));
                                        if (data.parentNode) moved.push(data)
                                    }
                                    if (_10._156(node, 'no-mouseflow-dom')) noMouseflowDom.push(node)
                                }
                                children.deleteNode(node);
                                node = _29._166(node)
                            }
                            var keys = children.keys()
                        }
                    });
                    noMouseflowDom.forEach(function(node) {
                        _235(node, 'no-mouseflow-dom', 'initial', true)
                    });
                    return moved
                };
                TreeMirrorClient.prototype.serializeAttributeChanges = function(attributeChanged) {
                    var _47 = this;
                    var map = new MutationSummary.NodeMap();
                    Object.keys(attributeChanged).forEach(function(attrName) {
                        attributeChanged[attrName].forEach(function(element) {
                            if (element.hasAttribute && element.hasAttribute('data-mf-replace') || _10._174(element, 'data-mf-replace') || _10._174(element, 'data-mf-replace-inner')) {
                                return
                            }
                            if (_10._156(element, 'no-mouseflow-dom')) _235(element, 'no-mouseflow-dom', 'initial', true);
                            var record = map.get(element);
                            if (!record) {
                                record = _47.serializeNode(element);
                                if (record) {
                                    record.attributes = {};
                                    map.set(element, record)
                                }
                            }
                            if (record) {
                                if (attrName.toLowerCase() === 'value' && element.tagName === 'INPUT') record.attributes.value = _231(element);
                                else if (attrName === 'mf_adoptedStyleSheets') _47.serializeAdoptedStyleSheets(element, record);
                                else record.attributes[attrName] = element.getAttribute(attrName)
                            }
                        })
                    });
                    return map.keys().map(function(node) {
                        return map.get(node)
                    })
                };
                TreeMirrorClient.prototype.serializeTextChanges = function(textChanges) {
                    var _47 = this;
                    return textChanges.map(function(node) {
                        var data = _47.serializeNode(node);
                        if (data) {
                            if (node.tagName === 'STYLE' && /^\s*$/.test(node.textContent)) data.textContent = _294(node.sheet);
                            else data.textContent = _600(node)
                        }
                        return data
                    })
                };
                TreeMirrorClient.prototype.applyChanged = function(summaries) {
                    _371();
                    var summary = summaries[0];
                    ['removed', 'added', 'reparented', 'reordered', 'attributeChanged', 'characterDataChanged'].forEach(function(key) {
                        if (!summary[key]) summary[key] = []
                    });
                    var _47 = this;
                    var removed = summary.removed.map(function(node) {
                        return _47.serializeNode(node)
                    });
                    var moved = this.serializeAddedAndMoved(summary.added, summary.reparented, summary.reordered);
                    var attributes = this.serializeAttributeChanges(summary.attributeChanged);
                    var text = this.serializeTextChanges(summary.characterDataChanged);
                    this.mirror.applyChanged({
                        removed: _335(removed),
                        addedOrMoved: _335(moved),
                        attributes: _335(attributes),
                        text: _335(text)
                    });
                    summary.removed.forEach(function(node) {
                        _47.forgetNode(node)
                    });
                    summary.added.forEach(function(node) {
                        _322(node)
                    })
                };
                TreeMirrorClient.prototype.serializeChildNodes = function(node, data) {
                    if (!node.childNodes.length) return;
                    data.childNodes = [];
                    var _188 = false;
                    for (var child = _29._203(node); child; child = _29._166(child)) {
                        if (_688(child)) _188 = true;
                        else if (_686(child.previousSibling)) _188 = false;
                        if (_188) continue;
                        var serializedChild = this.serializeNode(child, true);
                        if (serializedChild) {
                            data.childNodes.push(serializedChild)
                        }
                    }
                };
                TreeMirrorClient.prototype.serializeAdoptedStyleSheets = function(_20, _12) {
                    if (!_20.adoptedStyleSheets) return;
                    var _47 = this;
                    _12.css = _20.adoptedStyleSheets.map(function(_125) {
                        var _340 = {
                            id: _47.knownNodes.get(_125)
                        };
                        if (!_340.id) {
                            _340.id = _47.rememberNode(_125);
                            _340.text = _294(_125)
                        }
                        return _340
                    })
                };
                return TreeMirrorClient
            })();

            function _335(_755) {
                return _755.filter(function(_85) {
                    return _85
                })
            }

            function _371() {
                _333(_612, _4._352);
                _333(_610, _4._353);
                _333(_673, _4._193);
                _333(_388, ['.mf-form']);
                _782()
            }

            function _333(_666, _730) {
                _666.length = 0;
                if (!_730.length) return;
                try {
                    var _255 = _173(_730.join(','), _11);
                    for (var i = 0; i < _255.length; i++) {
                        _666.push(_255[i])
                    }
                } catch (e) {}
            }

            function _782() {
                if (!_4.freezeElementIds) return;
                _4.freezeElementIds.forEach(function(_9) {
                    try {
                        var _255 = _173(_9, _11);
                        _255.forEach(function(_20) {
                            if (_349.has(_20)) return;
                            if (_255.length > 1) _9 = _60(_20);
                            _349.set(_20, _9)
                        })
                    } catch (e) {}
                })
            }

            function _173(_9, _31) {
                try {
                    var _63 = [];
                    _9.split(',').forEach(function(_9) {
                        var _45 = _9.split(' > :document-fragment: > ', 1);
                        _31.querySelectorAll(_45[0]).forEach(function(_1) {
                            if (_45[1] && _1.shadowRoot) {
                                _173(_45[1], _1.shadowRoot).forEach(function(_1) {
                                    _63.push(_1)
                                })
                            } else {
                                _63.push(_1)
                            }
                        })
                    });
                    return _63
                } catch (_55) {
                    _8('Could not get element from selector: ' + ex.message)
                }
            }

            function _671(_253, _822) {
                var _12 = [];
                var _376 = _11.createElement('div');
                _376.innerHTML = _253;
                for (var i = 0; i < _376.childNodes.length; i++) {
                    var _823 = _376.childNodes[i];
                    var _827 = _822.call(this, _823);
                    _12.push(_827)
                }
                return _12
            }

            function _688(_20) {
                return _20 && _20.nodeType === 8 && _20.textContent.trim().toLowerCase().indexOf('mouseflowexcludestart') === 0
            }

            function _686(_20) {
                return _20 && _20.nodeType === 8 && _20.textContent.trim().toLowerCase().indexOf('mouseflowexcludeend') === 0
            }

            function _832(_452) {
                return _847.test(_452)
            }

            function _294(_125) {
                var _205 = '';
                try {
                    if (!_125 || !_125.cssRules) return _205
                } catch (e) {
                    return _205
                }
                for (var _2 = 0; _2 < _125.cssRules.length; _2++) {
                    _205 += _125.cssRules[_2].cssText
                }
                return _205
            }

            function _912() {
                _115({
                    _18: _151 + 'install?websiteId=' + _4._53,
                    _164: function() {
                        _8('Website installed signal sent.', _14())
                    },
                    _96: function() {
                        _8('Error in transmitCrossDomain - could not signal that website was installed.', _14())
                    }
                })
            }

            function _910(_57) {
                _115({
                    _18: _151 + 'config?websiteId=' + _4._53,
                    _164: function(_84) {
                        var _835 = _10._296(_84._422);
                        _4.keyLogging = _835.enableKeystrokes;
                        _8('Fetched recording script configuration.');
                        _57()
                    },
                    _96: function() {
                        _8('Error in transmitCrossDomain - could not fetch recording script configuration.');
                        _57()
                    }
                })
            }

            function _38() {
                if (_92) {
                    _8('Recording script is already started', _14());
                    return
                }
                if (!_632) {
                    _8('Recording not started - recording script is not initialized', _14());
                    return
                }
                _8('Recording starting, version ' + _252 + (_4.gdprEnabled ? ', GDPR mode enabled' : '') + (_4._439 ? ', privacy enforced' : ''), _14());
                if (!_554()) return;
                _92 = true;
                _876();
                _371();
                _13._46 = _987(_0._506);
                if (_837()) _838();
                _0._208 = _252;
                _836(_13._46)
            }

            function _836(_46) {
                var _637 = _933();
                var _18 = _151 + 'init?v=' + _252 + '&p=' + _4._53 + '&s=' + _13._62 + '&page=' + _13._46 + '&ret=' + (_13._248 ? '1' : '0') + '&u=' + _13._163 + '&href={href}' + '&url=' + _80(_189._238()) + '&ref={referrer}' + '&title=' + _80(_11.title) + '&res=' + _3.screen.width + 'x' + _3.screen.height + '&tz=' + _989() + '&to=' + _13._606 + '&dnt=' + _13._507 + '&ori=' + (typeof _3.orientation != 'undefined' ? _3.orientation : '') + '&dw=' + _11.documentElement.clientWidth + '&dh=' + _11.documentElement.clientHeight + '&time=' + _1010() + '&pxr=' + (typeof _3.devicePixelRatio != 'undefined' ? _3.devicePixelRatio : 1) + (_637.length > 0 ? '&fw=' + _637.join(',') : '') + '&gdpr=' + (_4.gdprEnabled ? 1 : 0);
                var _201 = _4.location.href;
                var _638 = _59._314 - _18.length - 6;
                if (_80(_201).length > _638) _201 = _201.split('#')[0];
                if (_80(_201).length > _638) _201 = _201.split('?')[0];
                _18 = _18.replace('{href}', _80(_201));
                var _187 = _11.referrer;
                if (_18.replace('{referrer}', _80(_187)).length > _59._314) {
                    if (_187.indexOf('?') > -1) _187 = _187.split('?')[0];
                    if (_18.replace('{referrer}', _80(_187)).length > _59._314) _187 = ''
                }
                _18 = _18.replace('{referrer}', _80(_187));
                _950();
                var _640 = _785(_59._314 - _18.length - 6);
                _18 += _790(_640);
                _115({
                    _18: _18,
                    _164: function(_84) {
                        if (_84._422 === 'Recording blocked') {
                            _8('Recording not started - mf_block cookie set to 1', _14());
                            return
                        }
                        _640.forEach(function(_142) {
                            _750(_142.key, _142.value)
                        });
                        _216 = true;
                        _846(_46);
                        _148._38(_13, _0, _419);
                        _3._mfq = new _641(_3._mfq);
                        _813();
                        _796()
                    },
                    _860: true,
                    _96: function() {
                        _8('Error in transmitCrossDomain - recording not starting.', _14())
                    }
                });
                _715();
                _0._108 = null;
                _990();
                _0._86 = {
                    x: _3.pageXOffset,
                    y: _3.pageYOffset
                };
                if (_0._86.x !== 0 && _0._86.y !== 0) _550();
                _0._247 = 1;
                _423();
                _8('Recording started. Session: ' + _13._62 + ', Page: ' + _13._46 + ', Last page: ' + _13._392, _14())
            }

            function _837() {
                return !_13._62 || !_985() || (_0._208 && _0._208 !== '0' && _0._208 !== _252) || (+new Date() - _0._334) > _59._394
            }

            function _838() {
                _8('Starting new session');
                var _840 = _13._62;
                _13._62 = _374();
                _0._157 = [];
                _13._241 = 0;
                if (_13._62 === _840) throw Error('New session ID is identical to the old session ID. This might be because Math.random has been overwritten.')
            }

            function _78(_841) {
                if (!_92) return;
                _844();
                _167 = false;
                _539();
                _648();
                _21._154(_431);
                _21._154(_430);
                _21._154(_429);
                _21._154(_428);
                _21._132(_251);
                if (_274) {
                    _21._132(_274);
                    _737()
                }
                if (_249) {
                    _21._132(_249);
                    _748()
                }
                _803();
                if (!_841) _27(_6._843, {});
                _261();
                _216 = false;
                if (_102) _102.disconnect();
                _148._78();
                _423();
                _0 = _523();
                _8('Recording stopped', _14());
                _92 = false;
                _375 = false
            }

            function _491(_26, _73) {
                if (_92) _78();
                _4.htmlDelay = _4.newPageViewHtmlDelay;
                _4._484(_26, _73);
                _13._46 = '';
                _38();
                _487(0)
            }

            function _844() {
                if (_0._191) {
                    if (+new Date() - _0._191 < _4.registerSubmitTimeout) {
                        _8('Registering formSubmit', _14())
                    } else {
                        _8('Not registering formSubmit. Timeout exceeded.', _14());
                        _0._108 = null
                    }
                }
            }

            function _915() {
                _78();
                _946('mf_' + _4._53);
                if (_3.name && ((_3.name.length === 35 && _3.name.indexOf('mf_') === 0) || (_4.crossDomainSupport && _3.name.indexOf('mf_' + _4._53) === 0))) _3.name = ''
            }

            function _846(_46) {
                if (_4.htmlFetchMode === 'post') {
                    _21._65(function() {
                        _816(_46)
                    }, _4.htmlDelay)
                } else {
                    _8('Html not sent due to mouseflowHtmlFecthMode setting', _14())
                }
            }

            function _816(_46) {
                if (_102) _102.disconnect();
                _102 = new TreeMirrorClient(_11, {
                    initialize: function(rootId, children) {
                        if (_46 === _13._46) _167 = true;
                        _859({
                            data: {
                                f: 'initialize',
                                args: [rootId, children]
                            }
                        }, _11.documentElement.innerHTML.length, _46)
                    },
                    applyChanged: function(summary) {
                        if (_14() - _0._427 < 30000) {
                            if (summary.removed.length || summary.addedOrMoved.length || summary.attributes.length || summary.text.length) {
                                _865({
                                    data: {
                                        f: 'applyChanged',
                                        args: [summary.removed, summary.addedOrMoved, summary.attributes, summary.text]
                                    }
                                })
                            }
                        }
                    }
                })
            }

            function _911(_17, _5, _783, _743) {
                if (!_92 || !_17) return;
                _5 = _5 || '';
                if (_17.length > 100) {
                    _8('Variable key cannot be more than 100 characters', _14());
                    return
                }
                if (_5.length > 2000) {
                    _8('Variable value cannot be more than 2000 characters', _14());
                    return
                }
                if (!_750(_17, _5)) {
                    _8('Variable already set to same value, not triggering callback.', _14());
                    return
                }
                var _12 = {
                    key: _17.toString(),
                    value: _5.toString() || '',
                    scope: _783 || 'session',
                    overwrite: _743 === undefined ? true : _743
                };
                _0._138.push(_12);
                _21._132(_249);
                _249 = _21._65(_748, 1000)
            }

            function _785(limit) {
                if (!_3._mfq.length) return [];
                var _138 = [];
                var _745 = 0;
                for (var _49 = 0; _49 < _3._mfq.length; _49++) {
                    var _52 = _3._mfq[_49];
                    if (!_52 || !_52.length || _52[0] !== 'setVariable') continue;
                    if ((_52.length > 3 && _52[3] !== 'session') || (_52.length > 4 && _52[4] !== true)) continue;
                    var _17 = _52[1];
                    var _5 = _52[2];
                    if (!_17 || !_5) continue;
                    if (_740(_17) !== -1) continue;
                    var _787 = _80(_17) + '=' + _80(_5);
                    _745 += _787.length + 1;
                    if (_745 - 1 >= limit) break;
                    _138.push({
                        key: _17,
                        value: _5
                    });
                    _3._mfq.splice(_49, 1);
                    _49--
                }
                return _138
            }

            function _790(_138) {
                var _357 = _138.map(function(_142) {
                    return _80(_142.key) + '=' + _80(_142.value)
                }).join('&');
                return _357 ? '&vars=' + _80(_357) : ''
            }

            function _748() {
                _249 = 0;
                for (var _2 = 0; _2 < _0._138.length; _2++) {
                    var _142 = _0._138[_2];
                    _8('Setting custom variable: ' + _142.key + ' = ' + _142.value + ', overwrite: ' + (_142.overwrite === undefined ? true : _142.overwrite), _14())
                }
                _419('variable', _0._138);
                _0._138 = []
            }

            function _87(_793) {
                _27(_6._87, {
                    target: _793
                })
            }

            function _914() {
                _27(_6._87, {
                    target: '*'
                })
            }

            function _907(_795) {
                if (!_92) return;
                if (_4.gdprEnabled || _4._439) {
                    _8('User identification not allowed (privacy enforced in script)', _14());
                    return
                }
                _419('identify', {
                    userId: _13._163,
                    userName: _795
                })
            }

            function _906(_36) {
                if (!_92) return;
                _36 = _416(_36);
                _8('Registering form submit attempt on this page', _14());
                _404(_36)
            }

            function _461(_36) {
                if (!_92) return;
                _36 = _416(_36);
                var _445 = _14();
                if (_0._108 === _109(_4.path || _4.location.pathname) || _445 > 5000) {
                    _8('Registering form submit success on this page', _14());
                    if (!_0._108) _27(_6._325, {
                        target: _36
                    });
                    _27(_6._702, {});
                    _0._191 = undefined;
                    _0._108 = undefined
                } else {
                    _3.setTimeout(function() {
                        _8('Registering form submit success on previous page', _14());
                        _393([{
                            _19: _6._702
                        }])
                    }, _703())
                }
            }

            function _672(_36) {
                if (!_92) return;
                _36 = _416(_36);
                var _445 = _14();
                if (_0._108 === _109(_4.path || _4.location.pathname) || _445 > 5000) {
                    _8('Registering form submit failure on this page', _14());
                    if (!_0._108) _27(_6._325, {
                        target: _36
                    });
                    _27(_6._207, {});
                    _210(_111._207);
                    _0._191 = undefined;
                    _0._108 = undefined
                } else {
                    _3.setTimeout(function() {
                        _8('Registering form submit failure on previous page', _14());
                        _393([{
                            _19: _6._207
                        }, {
                            _19: _6._97,
                            _24: {
                                x: _111._207._5,
                                y: 0
                            }
                        }, {
                            _19: _6._87,
                            _24: {
                                target: _111._207._22
                            }
                        }])
                    }, _703())
                }
            }

            function _703() {
                var _704 = 1000;
                var _729 = new Date() - _0._191;
                return _729 > _704 ? 0 : _704 - _729
            }

            function _416(_36) {
                if (typeof(_36) === 'object') return _60(_36);
                var _28 = _800.filter(function(_417) {
                    return _417._56 === _36
                }).map(function(_417) {
                    return _417._28
                })[0];
                return _28 || _36
            }

            function _404(_56) {
                if (!_92 || !_56 || _329(_351(_56))) return;
                if ((+new Date()) - _0._503 < 20) return;
                _0._503 = +new Date();
                _27(_6._325, {
                    target: _56
                });
                if (!_0._426[_56]) {
                    _0._426[_56] = _386(_56)
                } else {
                    _817(_56, _386(_56), _0._426[_56])
                }
                _757(_56);
                _784(_56);
                _0._191 = +new Date();
                _0._108 = _109(_4.path || _4.location.pathname);
                _715()
            }

            function _715() {
                if (!_0._108) return;
                var _202 = _809();
                if (_202.length) {
                    _805(_202);
                    return
                }
                if (_0._108 !== _109(_4.path || _4.location.pathname)) {
                    _461()
                }
            }

            function _805(_202) {
                var _717 = _202.filter(function(_4) {
                    return !_4.target
                })[0];
                if (_717) {
                    _726(_717);
                    return
                }
                _848(function() {
                    var _718 = _202.filter(function(_4) {
                        return _4.target && _810(_4.target)
                    })[0];
                    if (!_718) return false;
                    _726(_718);
                    return true
                }, _59._806, _59._808)
            }

            function _809() {
                if (!_4.forms) return [];
                var _202 = _4.forms.filter(function(_306) {
                    if (_306.formPath && _109(_306.formPath) !== _0._108) return false;
                    if (_306.redirectPath && _306.redirectPath !== _4.location.pathname) return false;
                    return true
                });
                return _202
            }

            function _810(_28) {
                var _1 = _11.querySelector(_28.selector);
                if (!_1) return false;
                if (!_28.text) return true;
                return _1.textContent.toLowerCase().includes(_28.text.toLowerCase())
            }

            function _726(_4) {
                if (_4.result === 'success') {
                    _461()
                } else if (_4.result === 'failure') {
                    _672()
                }
            }

            function _848(_57, _535, _811) {
                var _83 = new Date();
                var _537 = function() {
                    var _812 = new Date() - _83;
                    if (_812 < _811 && !_57()) _3.setTimeout(_537, _535)
                };
                _3.setTimeout(_537, _535)
            }

            function _210(_97, _28) {
                if (!_92 || !_97) return;
                var _5 = +_97._5;
                if (!_5) return;
                var _22 = _97._22;
                if (_22) {
                    var _807 = _22 === _111._617 || _22 === _111._412;
                    var _421 = _0._317.filter(function(e) {
                        return e._22 === _22 && (!_807 || e._28 === _28)
                    })[0];
                    if (_421) {
                        var _804 = new Date() - _421._100;
                        if (_804 < _97._150) return;
                        _0._317.splice(_0._317.indexOf(_421));
                        _5 = 0
                    }
                    _0._317.push({
                        _22: _22,
                        _28: _28,
                        _100: new Date()
                    })
                } else {
                    _22 = 'custom-friction' + (_97._669 ? ('-' + _97._669) : '')
                }
                var _799 = {
                    value: _22,
                    target: _28 ? _28 : '',
                    x: _5 > 0 ? _5 : 0,
                    y: _5 < 0 ? _5 * -1 : 0
                };
                _27(_6._97, _799)
            }

            function _813() {
                if (_13._99.length < 2) return;
                var _209 = _13._99[_13._99.length - 2];
                var _287 = _13._99[_13._99.length - 1];
                var _190 = _109(_4.path || _4.location.pathname);
                if (_209._190 === _190 && _209._190 !== _287._190 && _0._83 - _287._83 < 10000) {
                    _393([{
                        _19: _6._97,
                        _24: {
                            x: _111._556._5,
                            y: 0
                        }
                    }, {
                        _19: _6._87,
                        _24: {
                            target: _111._556._22
                        }
                    }])
                }
            }

            function _796() {
                if (_13._99.length < 4) return;
                var _551 = _13._99[_13._99.length - 5];
                var _209 = _13._99[_13._99.length - 4];
                if (_0._83 - _209._83 < 30000) {
                    if (_551 && _209._83 - _551._83 < 30000) return;
                    _515(_209._41, [{
                        _19: _6._97,
                        _24: {
                            x: _111._547._5,
                            y: 0
                        }
                    }, {
                        _19: _6._87,
                        _24: {
                            target: _111._547._22
                        }
                    }])
                }
            }

            function _451() {
                if (!_92) return;
                _148._451.apply(_148, arguments)
            }

            function _791() {
                return {
                    _62: '',
                    _46: '',
                    _163: '',
                    _248: false,
                    _606: +('ontouchstart' in _3 && _4.touchEvents),
                    _507: (navigator.doNotTrack === 'yes' || navigator.doNotTrack == 1 || window.doNotTrack == 1 || navigator.msDoNotTrack == 1) ? 1 : 0,
                    _241: 0,
                    _392: '',
                    _99: [],
                    _272: [],
                    _309: _149._553(),
                    _159: null
                }
            }

            function _523() {
                return {
                    _506: new Date(),
                    _83: +new Date(),
                    _267: +new Date(),
                    _334: +new Date(),
                    _12: [],
                    _244: [],
                    _42: [],
                    _250: [],
                    _573: [],
                    _160: [],
                    _140: [],
                    _614: 0,
                    _629: 0,
                    _185: 0,
                    _616: '',
                    _503: 0,
                    _270: [],
                    _317: [],
                    _141: {
                        x: 0,
                        y: 0
                    },
                    _526: {
                        x: 0,
                        y: 0
                    },
                    _529: {
                        x: 0,
                        y: 0
                    },
                    _608: -100,
                    _86: {
                        x: 0,
                        y: 0
                    },
                    _243: {
                        x: 0,
                        y: 0
                    },
                    _230: {},
                    _434: -100,
                    _435: -100,
                    _168: {
                        x: 0,
                        y: 0
                    },
                    _383: [],
                    _867: 0,
                    _181: [],
                    _138: [],
                    _247: 1,
                    _427: 0,
                    _509: 0,
                    _426: {},
                    _157: [],
                    _722: 0,
                    _721: 0,
                    _719: 0,
                    _272: [],
                    _256: 0,
                    _179: 0,
                    _145: null,
                    _139: _815(),
                    _699: 0,
                    _425: false,
                    _208: 0,
                    _562: false,
                    _597: false
                }
            }

            function _499(_20, _43) {
                var _152 = [];
                if (!_20.childNodes || !_20.childNodes.length) return _152;
                for (var _44 = _29._203(_20); _44; _44 = _29._166(_44)) {
                    if (_43 && _43(_44)) _152.push(_44);
                    _152 = _152.concat(_499(_44, _43))
                }
                return _152
            }

            function _514(_36, _43) {
                return _36.elements ? Array.from(_36.elements).filter(_43) : _499(_36, _43)
            }

            function _386(_56) {
                var _36 = _351(_56);
                var _33 = {};
                if (!_36) {
                    _8('Form not found: ' + _56, _14());
                    return _33
                }
                var _152 = _514(_36, function(_7) {
                    return /input|select|textarea/i.test(_7.tagName) && !/hidden|submit|reset|image|button/i.test(_7.type)
                });
                _152.forEach(function(_7) {
                    var _5 = _232(_7);
                    var _41 = _60(_7);
                    if (!_33[_41]) _33[_41] = _5;
                    else if (_5) _33[_41] += ', ' + _5
                });
                return _33
            }

            function _784(_56) {
                var _36 = _351(_56);
                if (!_36 || !_13._309) return;
                var _152 = _514(_36, function(_7) {
                    return /input|textarea/i.test(_7.tagName) && !/hidden|submit|reset|image|file|button|password/i.test(_7.type)
                });
                _152.forEach(function(_7) {
                    var _5 = _232(_7);
                    if (!_5 || _5.length <= 3 || _254(_5) || _438(_7)) return;
                    var _110 = _516(_5);
                    if (_110.length === 0) return;
                    var _197 = [];
                    for (var _2 = 0; _2 < _110.length; _2++) {
                        _197.push(_110[_2]._117)
                    }
                    var _196 = false;
                    for (var _2 = 0; _2 < _0._139.length; _2++) {
                        var _240 = _0._139[_2];
                        _196 = _197.length === _240.length && _510(_240, _197) === 0;
                        if (_196) break
                    }
                    if (!_196) _0._139.push(_197)
                });
                if (_0._139.length) {
                    _0._139 = _0._139.slice(-100);
                    _797(_0._139)
                }
            }

            function _797(_42) {
                _58._257('mf_replaceHashes', _42)
            }

            function _815() {
                return _58._258('mf_replaceHashes') || []
            }

            function _839(_5) {
                if (_0._139.length === 0) return _5;
                var _110 = _516(_5);
                for (var _2 = 0; _2 < _0._139.length; _2++) {
                    var _240 = _0._139[_2];
                    var _199;
                    do {
                        var _129 = _199 !== undefined ? _199 + 1 : 0;
                        _199 = _510(_110, _240, _129);
                        if (_199 !== -1) {
                            var _38 = _110[_199]._38;
                            var _226 = _110[_199 + _240.length - 1]._226;
                            var _845 = _942('*', _226 - _38);
                            _5 = _5.slice(0, _38) + _845 + _5.slice(_226)
                        }
                    } while (_199 !== -1)
                }
                return _5
            }

            function _516(_5) {
                var _197 = [];
                var _38;

                function _512(_226) {
                    if (_38 === undefined) return;
                    var _513 = _5.slice(_38, _226);
                    _197.push({
                        _38: _38,
                        _226: _38 + _513.length,
                        _117: _109(_513)
                    });
                    _38 = undefined
                }
                for (var _2 = 0; _2 < _5.length; _2++) {
                    var _497 = _5[_2];
                    if (_849(_497)) {
                        if (_38 === undefined) {
                            _38 = _2
                        }
                    } else {
                        _512(_2)
                    }
                }
                _512();
                return _197
            }

            function _510(_228, _110, _129) {
                for (var _2 = _129 || 0; _2 < _228.length; _2++) {
                    if (_2 + _110.length > _228.length) break;
                    if (_842(_228, _110, _2)) return _2
                }
                return -1
            }

            function _842(_228, _110, _129) {
                var _196 = false;
                for (var _2 = _129 || 0, _130 = 0; _2 < _228.length && _130 < _110.length; _2++, _130++) {
                    _196 = _228[_2]._117 === _110[_130];
                    if (!_196) break
                }
                return _196
            }

            function _232(_1) {
                var _5 = '';
                if (_1.type && /radio|checkbox/.test(_1.type.toLowerCase())) _5 = _1.checked ? _1.value : '';
                else if (_1.tagName && /select/.test(_1.tagName.toLowerCase()) && _1.options)
                    for (var j = 0; j < _1.options.length; j++) {
                        var _195 = _1.options[j].selected ? _1.options[j].value : '';
                        if (_195 && _195 != '') _5 += (_5 && _5 != '' ? ',' : '') + _195
                    } else _5 = _1.value;
                return _5 || ''
            }

            function _231(_1) {
                if (_1.type === 'password') return '*';
                var _5 = _232(_1);
                if (_569(_1)) {
                    _5 = _5.replace(/./g, _564(_1.type))
                } else if (_570(_1) && !_438(_1)) {
                    _5 = _5.slice(0, 2) + _5.slice(2).replace(/./g, _564(_1.type))
                }
                return _5
            }

            function _600(_1) {
                var _222 = _1.textContent;
                if (_1.nodeType === 3 && _29._71(_1)) _1 = _29._71(_1);
                var _601 = _839(_222);
                if (_601 !== _222 && _4.replaceLastFormValues) _222 = _601;
                if (_833(_1)) _222 = _222.replace(/./g, '*');
                return _222
            }

            function _438(_1) {
                return _10._156(_1, 'mouseflow') || _610.indexOf(_1) !== -1
            }

            function _329(_1) {
                if (!_1) return false;
                if (_1[NodeMap.ID_PROP]) return !!_206(_1, _336);
                while (_1) {
                    if (_611(_1)) return true;
                    _1 = _29._71(_1)
                }
                return false
            }

            function _611(_1) {
                return _612.indexOf(_1) !== -1
            }

            function _622(_1) {
                return _10._156(_1, 'no-mouseflow') || (!_4.keyLogging && !_438(_1)) || _329(_1)
            }

            function _569(_1) {
                return (_622(_1) || _254(_232(_1)) || _781(_1)) && _563(_1) && !_834.test(_1.type)
            }

            function _833(_1) {
                return (_1.isContentEditable || _1.tagName === 'TEXTAREA') && _622(_1)
            }

            function _781(_1) {
                return (_4.gdprEnabled || _4._439) && (_826(_1) || _824(_1))
            }

            function _254(_5) {
                var _415 = _5.replace(/[-\s]+/g, '');
                if (!_830.test(_415) || !_829.call(this, _415)) return false;
                return !_828.every(function(_620) {
                    if (_620.patternRegex.test(_415)) {
                        _8("Identified credit card " + _620.name);
                        return false
                    }
                    return true
                })
            }

            function _826(_1) {
                return /email/i.test(_1.type) || _825.test(_1.value)
            }

            function _824(_1) {
                return /tel/i.test(_1.type)
            }

            function _570(_1) {
                return _563(_1) && /^\d{3}[^a-z]*$/i.test(_1.value)
            }

            function _563(_1) {
                return _1.tagName === 'INPUT' || _1.tagName === 'TEXTAREA'
            }

            function _564(_821) {
                return /number/i.test(_821) ? '0' : '*'
            }

            function _993(_35) {
                return _569(_35.target) || _570(_35.target) ? '191' : (_35.which && _35.which.toString()) || ''
            }

            function _994(_1) {
                var _574 = _60(_1);
                var _355 = _0._573[_574];
                var _364 = _231(_1);
                var _33 = _364;
                if (_355 && _355.length > 3 && _364.indexOf(_355) === 0) _33 = '+||' + _364.substring(_355.length);
                _0._573[_574] = _364;
                return _33
            }

            function _817(_56, _384, _397) {
                try {
                    var _271 = [];
                    for (var _69 in _384) {
                        if (typeof _397[_69] == 'undefined' || _384[_69] != _397[_69]) _271.push(_69)
                    }
                    for (var _69 in _397) {
                        if (typeof _384[_69] == 'undefined' && _271.indexOf(_69) === -1) _271.push(_69)
                    }
                    for (var i = 0; i < _271.length; i++) {
                        _27(_6._502, {
                            target: _271[i]
                        })
                    }
                } catch (_55) {
                    _8('Error in _addChangedFieldEvents: ' + _55.message, _14())
                }
            }

            function _757(_56) {
                try {
                    var _292 = _762(_56);
                    for (var i = 0; i < _292.length; i++) {
                        _27(_6._501, {
                            target: _292[i]
                        })
                    }
                } catch (_55) {
                    _8('Error in getBlankFields: ' + _55.message, _14())
                }
            }

            function _762(_56) {
                var _292 = [];
                var _42 = _386(_56);
                for (var _69 in _42)
                    if (_42[_69] == '') _292.push(_69);
                return _292
            }

            function _365(_1) {
                if (_388.includes(_1)) return null;
                return _1.form || _388.filter(function(_36) {
                    return _36.contains(_1)
                })[0] || null
            }

            function _976() {
                _769();
                _756()
            }

            function _423() {
                _780();
                _552()
            }

            function _769() {
                var _581 = _674('mf_user').split('|');
                for (var _2 = 0; _2 < _581.length; _2++) {
                    var _81 = _581[_2];
                    switch (_2) {
                        case 0:
                            _13._163 = _81;
                            break;
                        case 1:
                            _13._272 = _81 !== '' ? _81.split(/[$,]+/) : [];
                            break
                    }
                }
                _13._248 = _13._163 !== '';
                if (_13._163 === '' || _13._163 === '1') _13._163 = _374();
                _0._562 = true
            }

            function _780() {
                if (!_0._562) return;
                _675('mf_user', [_13._163, _13._272.join('$')].join('|'), 1, _372(_73))
            }

            function _756() {
                var _625 = _674('mf_' + _4._53).split('|');
                for (var _2 = 0; _2 < _625.length; _2++) {
                    var _81 = _625[_2];
                    switch (_2) {
                        case 0:
                            _13._62 = _81;
                            break;
                        case 1:
                            _13._99 = _765(_81, _13._46);
                            break;
                        case 2:
                            _0._334 = parseInt(_81, 10);
                            break;
                        case 3:
                            _0._157 = _81 !== '' ? _81.split('.') : [];
                            break;
                        case 4:
                            _13._241 = parseInt(_81, 10);
                            break;
                        case 5:
                            _0._108 = _81;
                            break;
                        case 6:
                            _0._191 = parseInt(_81, 10);
                            break;
                        case 7:
                            _0._272 = _81 !== '' ? _81.split(/[$,]+/) : [];
                            break;
                        case 8:
                            _13._248 = _81 === '1';
                            break;
                        case 9:
                            _0._208 = _81;
                            break;
                        case 10:
                            _13._159 = parseFloat(_81);
                            break
                    }
                }
                if (!_13._62) _13._62 = _4.sessionId || _763();
                if (!_13._159) _13._159 = _778();
                var _287 = _13._99[_13._99.length - 1];
                if (_287) _13._392 = _287._41;
                _0._597 = true
            }

            function _763() {
                var sessionId = _604();
                return sessionId && sessionId.length === 32 ? sessionId : null
            }

            function _778() {
                var recordingRate = _604();
                return /^\d+\.\d+$/.test(recordingRate) ? parseFloat(recordingRate) : null
            }

            function _604() {
                return _4.crossDomainSupport && _3.name && _3.name.indexOf('mf_' + _4._53) === 0 ? _3.name.split('=')[1] : null
            }

            function _552() {
                if (!_0._597) return;
                _675('mf_' + _4._53, [_13._62, _768(), _0._334, _0._157.join('.'), _13._241, _0._108 || '', _0._191 || '', _0._272.join('$'), _13._248 ? '1' : '0', _0._208, _13._159].join('|'), 0, _372(_73));
                if (_4.crossDomainSupport) _3.name = 'mf_' + _4._53 + '=' + (_13._62 || _13._159)
            }

            function _765(_5, _46) {
                return _5.split(/[$,]+/).map(function(_276) {
                    var _42 = _276.split('.');
                    return {
                        _41: _42[0],
                        _190: _42[1],
                        _83: +_42[2]
                    }
                }).filter(function(p) {
                    return p._41 !== _46
                }).slice(-5)
            }

            function _768() {
                var _391 = _13._99;
                if (_13._46) {
                    _391 = _391.concat([{
                        _41: _13._46,
                        _190: _109(_4.path || _4.location.pathname),
                        _83: _0._83
                    }]).slice(-6)
                }
                return _391.map(function(_276) {
                    return _276._41 + '.' + _276._190 + '.' + _276._83
                }).join('$')
            }
            var _339 = '__mouseflow_properties__';
            var _336 = 'is-blacklisted';

            function _206(_20, _17) {
                if (!_20) return null;
                var _219 = _20[_339];
                return _219 ? _219[_17] : null
            }

            function _235(_20, _17, _5, _761) {
                var _219 = _20[_339];
                if (!_219) _219 = _20[_339] = {};
                _219[_17] = _5;
                if (_761 && _20.childNodes && _20.childNodes.length) {
                    for (var _44 = _29._203(_20); _44; _44 = _29._166(_44)) {
                        _235(_44, _17, _5, true)
                    }
                }
            }

            function _631(_20) {
                delete _20[_339];
                if (_20.childNodes && _20.childNodes.length) {
                    for (var _44 = _29._203(_20); _44; _44 = _29._166(_44)) {
                        _631(_44)
                    }
                }
            }

            function _803() {
                _631(_3.document.body)
            }

            function _876() {
                _0._83 = +new Date();
                _0._267 = +new Date();
                _431 = _21._280(_550, _59._607);
                _430 = _21._280(_880, _59._850);
                _429 = _21._280(_379, _59._974);
                _428 = _21._280(_370, _59._975);
                _251 = _21._65(_150, _59._394)
            }

            function _908() {
                if (!_742(_4.location.hostname)) return false;
                if (_692()) {
                    _8('Recording not started - browser is IE8 or older');
                    return false
                }
                return _554()
            }

            function _554() {
                _976();
                if (_4.forceStart) return true;
                if (_983()) {
                    _8('Recording not started - session ID is invalid.', _14());
                    return false
                }
                if (_982()) {
                    _8('Recording not started - honored "do not track" browser setting.', _14());
                    return false
                }
                if (_984()) {
                    _8('Recording not started - the browser was identified as a bot.', _14());
                    return false
                }
                if (!_236._495(_169)) {
                    _8('Recording not started - page does not match page rules', _14());
                    return false
                }
                var _337 = _977.filter(function(_67) {
                    return _236._200(_67)
                }).sort(_978)[0];
                if (_337) {
                    _221 = _337._221;
                    _8('Recording rate set from page recording rule: ' + _337._19 + ', "' + _337._5 + '"', _14())
                }
                if (!_13._159) _13._159 = _981();
                var _524 = _13._62 || _13._159 <= _221;
                if (!_524) _8('Recording not started - recordingRate or blocked', _14());
                _552();
                return _524
            }

            function _978(_980, _979) {
                return _979._221 - _980._221
            }

            function _981() {
                return _128.round(_128.random() * 10000000) / 100000
            }

            function _982() {
                return _4.honorDoNotTrack && _13._507
            }

            function _983() {
                return _13._62 && _13._62.length != 32
            }

            function _984() {
                if (_4.enableBots) return false;
                return _3.navigator.webdriver || /ptst|headlesschrome|lighthouse/i.test(_3.navigator.userAgent)
            }

            function _985() {
                return (_13._241 < _59._986)
            }

            function _987(_100) {
                return _332(_100.getMonth() + 1, 2) + _332(_100.getDate(), 2) + _332(_100.getSeconds(), 2) + _332(_100.getMilliseconds(), 3).slice(1) + _374()
            }

            function _332(_988, _320) {
                return (new Array(_320 + 1).join('0') + _988).slice(-_320)
            }

            function _989() {
                var _594 = new Date();
                return _128.max(new Date(_594.getFullYear(), 0, 1).getTimezoneOffset(), new Date(_594.getFullYear(), 6, 1).getTimezoneOffset())
            }
            var _587 = false;

            function _990() {
                try {
                    _410(_11);
                    _90(_11, 'mousemove', function(_7) {
                        _0._141 = {
                            x: _7.pageX,
                            y: _7.pageY
                        }
                    });
                    _405(_11.documentElement, 'mouseleave', function() {
                        _27(_6._991, {});
                        _210(_111._214)
                    });
                    _90(_11, 'mousedown', function(_7) {
                        _1027(_7, _7.target)
                    });
                    _90(_11, 'mouseup', function(_7) {
                        _1028(_7, _7.target)
                    });
                    _583(_11, 'click', _1038(), function(_7) {
                        _1029(_7, _7.delegatedTarget || _7.target)
                    });
                    try {
                        var _399 = _1040();
                        if (_399) {
                            _405(_11, 'mouseenter', _399, function(_7) {
                                var _177 = _338(_6._213).filter(function(_85) {
                                    return _7.delegatedTarget && _7.delegatedTarget.matches(_85._9)
                                })[0];
                                if (_177) _87(_177._87);
                                _27(_6._213, {
                                    x: _7.pageX,
                                    y: _7.pageY,
                                    target: _60(_7.target)
                                })
                            });
                            _405(_11, 'mouseleave', _399, function(_7) {
                                _27(_6._214, {
                                    x: _7.pageX,
                                    y: _7.pageY,
                                    target: _60(_7.target)
                                })
                            })
                        }
                    } catch (_55) {
                        _8('Error in getHoverSelectors: ' + _55.message, _14())
                    }
                    _90(_11, 'focus', 'input,textarea,select,button', function(_7) {
                        _27(_6._504, {
                            target: _60(_7.target)
                        })
                    });
                    _90(_11, 'blur', 'input,textarea,select,button', function(_7) {
                        _27(_6._500, {
                            target: _60(_7.target)
                        })
                    });
                    _90(_11, 'keypress', 'input,textarea,select', function(_7) {
                        if (_7.target && _7.target.type !== 'password') {
                            _27(_6._385, {
                                target: _60(_7.target)
                            })
                        }
                    });
                    _90(_11, 'keydown', 'input,textarea,select', function(_7) {
                        if (_7.target && _7.target.type !== 'password') {
                            _27(_6._363, {
                                target: _60(_7.target),
                                value: _993(_7)
                            })
                        }
                    });
                    _90(_11, 'keyup', 'input,textarea,select', function(_7) {
                        if (_7.target && _7.target.type !== 'password') {
                            _27(_6._343, {
                                target: _60(_7.target),
                                value: _994(_7.target)
                            });
                            if (_254(_232(_7.target)) && _4.autoTagPayments) _87('payment')
                        }
                    });
                    _90(_11, 'change', 'input,textarea,select', function(_7) {
                        _27(_6._246, {
                            target: _60(_7.target),
                            value: _231(_7.target)
                        });
                        if (_7.target && ['password', 'file'].indexOf(_7.target.type) === -1 && _254(_232(_7.target)) && _4.autoTagPayments) _87('payment')
                    });
                    _382(_11);
                    if (_13._606) {
                        _90(_11, 'touchstart', function(_7) {
                            var _88 = _7.touches;
                            if (_88.length > 0) {
                                _27(_6._413, {
                                    x: _88[0].pageX,
                                    y: _88[0].pageY
                                })
                            }
                            if (_88.length > 1) {
                                _27(_6._443, {
                                    x: _88[1].pageX,
                                    y: _88[1].pageY
                                })
                            }
                        });
                        _90(_11, 'touchmove', function(_7) {
                            var _88 = _7.touches;
                            var _321 = _14();
                            var _400 = _321 - _59._607;
                            if (_88.length > 0 && _0._608 < _400) {
                                _27(_6._414, {
                                    x: _88[0].pageX,
                                    y: _88[0].pageY
                                });
                                if (_88.length > 1) {
                                    _27(_6._442, {
                                        x: _88[1].pageX,
                                        y: _88[1].pageY
                                    })
                                }
                                _0._608 = _321;
                                var _973 = !_223(_312(), _0._168);
                                if (_973) {
                                    _0._168 = _312();
                                    _27(_6._347, _0._168);
                                    if (_0._435 < _400) {
                                        _27(_6._347, _0._168);
                                        _0._435 = _321
                                    }
                                }
                                _0._86 = {
                                    x: _3.pageXOffset,
                                    y: _3.pageYOffset
                                };
                                if (_0._434 < _400 && !_223(_0._86, _0._243)) {
                                    _0._243 = _0._86;
                                    _27(_6._295, _0._86);
                                    _0._434 = _321
                                }
                            }
                        });
                        _90(_11, 'touchend', function(_7) {
                            var _88 = _7.touches;
                            if (_88.length === 0) _27(_6._356, {
                                x: 0,
                                y: 0
                            });
                            if (_88.length > 1) _27(_6._441, {
                                x: 0,
                                y: 0
                            })
                        });
                        if (_3.screen.orientation) {
                            _90(_3.screen.orientation, 'change', function() {
                                _27(_6._444, {
                                    x: _3.screen.orientation.angle,
                                    y: 0
                                })
                            })
                        }
                    }
                    _90(_3, _917(), function() {
                        _78()
                    });
                    var _575 = _3.onerror;
                    _3.onerror = function(_131, _18, _407, _406, _402) {
                        var _971 = new Date() - _0._179;
                        if (_971 > 1000 && _0._256 < 50) {
                            _0._179 = +new Date();
                            var _401 = 'Malformed error';
                            if (_131 && _131.message) _401 = _131.message;
                            else if (typeof _131 === 'string') _401 = _131;
                            _0._145 = {
                                _131: _401,
                                _18: typeof _18 === 'string' ? _18 : 'Malformed URL',
                                _407: '' + _407,
                                _406: '' + _406,
                                _965: _402 && _402.stack && _402.stack.substring(0, 800),
                                _1051: _0._179
                            };
                            if (_0._185 !== 0 && _0._179 - _0._185 < 100) {
                                _210(_111._412, _0._616);
                                _148._454('clickError');
                                _621()
                            }
                        }
                        if (_575) _575.apply(this, arguments)
                    };
                    if (!_587) {
                        if (_4.proxyAttachShadow) _360();
                        _588();
                        _952();
                        if (_4.enableSpa) {
                            _301.proxyPushState(_491)
                        }
                        if (_4.proxyValueSetter) _590();
                        _587 = true
                    }
                    if (_4.keyLogging) _969()
                } catch (_55) {
                    _8('Error in bindDomEvents: ' + _55.message, _14())
                }
            }

            function _410(_31) {
                _583(_31, 'scroll', 'body,div,section,main,article,ul,.mf-scroll-listen', function(_7) {
                    if (_7.target === _11) {
                        _0._86 = {
                            x: _3.pageXOffset,
                            y: _3.pageYOffset
                        }
                    } else if (_7.target === _328) {
                        _0._86 = {
                            x: _7.target.scrollLeft,
                            y: _7.target.scrollTop
                        }
                    } else {
                        _1033(_60(_7.target), _7.target.scrollLeft, _7.target.scrollTop)
                    }
                })
            }

            function _382(_31) {
                _90(_31, 'click', '.mf-form-button', function(_7) {
                    _404(_60(_365(_7.target)))
                });
                _90(_31, 'submit', 'form', function(_7) {
                    _404(_60(_7.target))
                })
            }

            function _90(_28, _6, _43, _57) {
                _25._40(_28, _6, _43, _57, {
                    _77: true
                })
            }

            function _405(_28, _6, _43, _57) {
                _25._40(_28, _6, _43, _57, {
                    _77: true,
                    _303: true
                })
            }

            function _583(_28, _6, _43, _57) {
                _25._40(_28, _6, _43, _57, {
                    _77: true,
                    _962: true
                })
            }

            function _952() {
                var _953 = CSSStyleSheet.prototype.insertRule;
                var _598;
                var _229 = [];
                CSSStyleSheet.prototype.insertRule = function() {
                    _953.apply(this, arguments);
                    if (!_167) return;
                    var _20 = this.ownerNode;
                    if (_229.indexOf(_20) < 0) _229.push(_20);
                    _21._132(_598);
                    _598 = _21._65(function() {
                        _229 = _229.filter(function(_20) {
                            return _20 && _102.isKnownNode(_20)
                        });
                        _102.applyChanged([{
                            characterDataChanged: _229
                        }]);
                        _229 = []
                    }, 200)
                }
            }
            var _409 = HTMLElement.prototype.attachShadow;
            var _348 = false;

            function _955() {
                var _83 = new Date();
                var _957 = _3.setInterval(function() {
                    var _956 = new Date() - _83;
                    if (HTMLElement.prototype.attachShadow !== _409 || _956 > 10000) {
                        _3.clearInterval(_957);
                        _360()
                    }
                }, 200)
            }

            function _958() {
                if (!_348 || HTMLElement.prototype.attachShadow !== _580) return;
                _8('Resetting "attach shadow" proxy');
                delete HTMLElement.prototype.attachShadow;
                _348 = false
            }

            function _360() {
                if (_348) return;
                if (!_167) {
                    _3.setTimeout(_360, 200);
                    return
                }
                _8('Setting up "attach shadow" proxy');
                _322(_11.body);
                _409 = HTMLElement.prototype.attachShadow;
                HTMLElement.prototype.attachShadow = _580;
                _348 = true
            }

            function _580() {
                var _107 = _409.apply(this, arguments);
                if (_167 && _102.isKnownNode(this)) {
                    _410(_107);
                    _382(_107);
                    _102.addShadowRoot(_107)
                }
                return _107
            }

            function _322(_1) {
                for (; _1; _1 = _1.nextElementSibling) {
                    if (_1.shadowRoot) {
                        _410(_1.shadowRoot);
                        _382(_1.shadowRoot);
                        _102.addShadowRoot(_1.shadowRoot);
                        _322(_1.shadowRoot.firstElementChild)
                    }
                    _322(_1.firstElementChild)
                }
            }

            function _588() {
                if (!_167) {
                    _3.setTimeout(_588, 200);
                    return
                }
                _278(Document.prototype, 'adoptedStyleSheets', {
                    _143: _589
                });
                _278(ShadowRoot.prototype, 'adoptedStyleSheets', {
                    _143: _589
                })
            }

            function _589() {
                if (!_167) return;
                _102.applyChanged([{
                    attributeChanged: {
                        'mf_adoptedStyleSheets': [this]
                    }
                }])
            }

            function _590() {
                if (!_167) {
                    _3.setTimeout(_590, 200);
                    return
                }
                _278(HTMLInputElement.prototype, 'value', {
                    _143: _411
                });
                _278(HTMLTextAreaElement.prototype, 'value', {
                    _143: _411
                });
                _278(HTMLSelectElement.prototype, 'value', {
                    _143: _411
                })
            }

            function _411() {
                if (!_102.isKnownNode(this)) return;
                _102.applyChanged([{
                    attributeChanged: {
                        'value': [this]
                    }
                }])
            }

            function _278(_20, _578, _264) {
                var _408 = Object.getOwnPropertyDescriptor(_20, _578);
                if (!_264 || !_408) return;
                Object.defineProperty(_20, _578, {
                    get: function() {
                        var _5 = _408.get.apply(this, arguments);
                        if (_264._233) _264._233.apply(this, arguments);
                        return _5
                    },
                    set: function() {
                        _408.set.apply(this, arguments);
                        if (_264._143) _264._143.apply(this, arguments)
                    }
                })
            }

            function _621() {
                if (_0._145) {
                    _0._256++;
                    var _967 = 'website=' + _4._53 + '&session=' + _13._62 + '&page=' + _13._46 + '&type=error&data=' + _80(_10._114({
                        seq: _0._256,
                        errorMsg: _0._145._131,
                        url: _0._145._18,
                        line: _0._145._407,
                        col: _0._145._406,
                        stack: _0._145._965,
                        errorTime: _0._179
                    }));
                    _27(_6._96, {
                        x: _0._256,
                        y: 0
                    });
                    _8('JS error ' + _0._256 + ', msg: ' + _0._145._131, _14());
                    _115({
                        _18: _151 + 'data',
                        _12: _967
                    });
                    _0._145 = null
                }
            }

            function _539() {
                _25._584();
                if (_403) _21._154(_403)
            }

            function _969() {
                _0._250 = _568();
                _403 = _21._280(function() {
                    _1025(_1024(_568(), _0._250))
                }, 200)
            }

            function _568() {
                var _567 = _11.querySelectorAll('input,textarea,select');
                var _565 = {};
                for (var i = 0; i < _567.length; i++) {
                    var _69 = _567[i];
                    if (_10._156(_69, 'no-mouseflow')) continue;
                    if (!_996(_69, ['text', 'textarea', 'select-one'])) continue;
                    _565[_60(_69)] = _231(_69)
                }
                return _565
            }

            function _996(_69, _997) {
                return _69.type && new RegExp(_997.join('|'), 'i').test(_69.type)
            }

            function _1024(_250, _595) {
                var _288 = [];
                for (var _17 in _250) {
                    var _5 = _250[_17];
                    var _585 = _595[_17];
                    if (_585 !== undefined && _585 !== _5) _288.push({
                        id: _17,
                        value: _5
                    });
                    _595[_17] = _5
                }
                return _288
            }

            function _1025(_288) {
                if (_14() - _0._509 > 100) {
                    for (var i = 0; i < _288.length; i++) {
                        var _37 = _288[i];
                        _27(_6._246, {
                            target: _37.id,
                            value: _37.value
                        })
                    }
                }
            }

            function _1027(_7, _1) {
                if ((+new Date()) - _0._614 < 20) return;
                _0._614 = +new Date();
                _27(_6._323, {
                    x: _7.pageX,
                    y: _7.pageY,
                    target: _60(_1)
                })
            }

            function _1028(_7, _1) {
                if ((+new Date()) - _0._629 < 20) return;
                _0._629 = +new Date();
                var _155 = _433(_1, _7.pageX, _7.pageY);
                if (!_155 && _1.firstElementChild) _155 = _433(_1.firstElementChild, _7.pageX, _7.pageY);
                if (_155) _27(_6._344, {
                    x: _155.x,
                    y: _155.y,
                    target: _60(_1)
                })
            }

            function _1029(_7, _1) {
                if ((+new Date()) - _0._185 < 20) return;
                var _28 = _60(_1);
                _0._185 = +new Date();
                _0._616 = _28;
                _27(_6._211, {
                    x: _7.pageX,
                    y: _7.pageY,
                    target: _28
                });
                _0._270.push(_0._185);
                _0._270 = _0._270.slice(-5);
                if (_0._270[4] - _0._270[0] < 1000) {
                    _210(_111._617, _28);
                    _148._454('clickRage')
                }
                if (_0._185 !== 0 && _0._179 !== 0 && _0._185 - _0._179 < 100) {
                    _210(_111._412, _28);
                    _148._454('clickError');
                    _621()
                }
                var _177 = _338(_6._211).filter(function(_85) {
                    return _1.matches(_85._9)
                })[0];
                if (_177) {
                    _87(_177._87);
                    if (_177._1032) _491(_177._1032)
                }
            }

            function _1033(_41, _1034, _1035) {
                _0._230[_41] = {
                    x: _1034,
                    y: _1035
                };
                if (_318) return;
                _318 = _21._65(_627, 100);

                function _627() {
                    _318 = null;
                    var _623 = true;
                    for (var _28 in _0._230) {
                        if (_0._230.hasOwnProperty(_28)) {
                            _27(_6._387, {
                                x: _0._230[_28].x,
                                y: _0._230[_28].y,
                                target: _28
                            });
                            _623 = false
                        }
                    }
                    if (!_623) {
                        _0._230 = {};
                        _318 = _21._65(_627, 100)
                    }
                }
            }

            function _433(_20, _1036, _1037) {
                var _48 = _635(_20);
                if (_48 == null || !_48.height || !_48.width) return null;
                return {
                    x: parseInt((_1036 - _0._86.x - _48.x) / parseFloat(_48.width) * 65535),
                    y: parseInt((_1037 - _0._86.y - _48.y) / parseFloat(_48.height) * 65535)
                }
            }

            function _1038() {
                var _398 = ['a', 'input', 'select', 'button', '.mf-listen-click'];
                _398.push.apply(_398, _560(_338(_6._211)));
                return _398.slice(0, 1000).join(',')
            }

            function _1040() {
                var _602 = {};
                var _603 = /[^(]:hover/;
                if (_4.useAllHoverSelectors) {
                    for (var _2 = 0; _2 < _11.styleSheets.length; _2++) {
                        var _137 = _11.styleSheets[_2];
                        try {
                            var _205 = _137.cssRules ? _137.cssRules : _137.rules;
                            for (var _130 = 0; _130 < _205.length; _130++) {
                                var _605 = _137.cssRules[_130];
                                if (!_603.test(_605.selectorText)) continue;
                                var _34 = _605.selectorText.split(',');
                                var _9;
                                for (var _396 = 0; _396 < _34.length; _396++) {
                                    _9 = _34[_396].replace(/^\s+|\s+$/g, '');
                                    if (_603.test(_9)) {
                                        _9 = _9.substring(0, _9.indexOf(':hover'));
                                        _9 = _1045(_9);
                                        _602[_9] = true
                                    }
                                }
                            }
                        } catch (_55) {
                            _8('Cannot inspect external css file, :hover support may fail: ' + _137.href)
                        }
                    }
                }
                var _34 = ['a', 'input', 'select', 'button', 'textarea', 'li', 'canvas', '.mf-listen'];
                for (_9 in _602) {
                    _9 = _9.replace(/^\s+|\s+$/g, '');
                    if (_9 != '' && _9 != 'a' && !_283(_9, ' a') && !_283(_9, ' select') && !_283(_9, ' submit') && !_283(_9, ' textarea') && !_283(_9, ' li')) _34.push(_9)
                }
                _34.push.apply(_34, _4._193);
                _34.push.apply(_34, _560(_338(_6._213)));
                return _34.slice(0, 1000).join(',')
            }

            function _338(_1044) {
                var _1043 = {
                    5: 'Click',
                    6: 'Mouseover'
                };
                var _395 = _4._1042.filter(function(_85) {
                    return _85._35 === _1043[_1044] && (!_85._1023 || _85._1023 === _4.location.href)
                });
                return _395
            }

            function _560(_395) {
                return _395.map(function(_85) {
                    return _85._9
                })
            }

            function _1045(_37) {
                var _559 = [/:active/g, /:visited/g, /::before/g, /:before/g, /::after/g, /:after/g, /::first-letter/g, /::first-line/g, /::selection/g];
                for (var _2 = 0; _2 < _559.length; _2++) _37 = _37.replace(_559[_2], '');
                return _37
            }

            function _80(_1022) {
                try {
                    return _3.encodeURIComponent(_1022)
                } catch (_55) {
                    _8('Encode error: ' + _55.message, _14());
                    return ''
                }
            }

            function _896(_5) {
                return _5.replace(/%/g, '%25').replace(/\|{3}/g, '%7C%7C%7C')
            }

            function _27(_19, _24) {
                if (!_92) return;
                if (_0._12.length === 0) _0._267 = +new Date();
                var _50 = _517(_19, _24, _0._160, _0._42);
                if (!_50) return;
                if (_1018(_19)) {
                    _21._132(_251);
                    _251 = _21._65(_150, _59._394);
                    _0._427 = _14();
                    _0._334 = +new Date()
                }
                if (_546(_19)) _0._509 = _14();
                var _999 = _678(_0._140) + (_50._121 ? _327.encode(_50._121).length : 0),
                    _1000 = _678(_0._42) + (_50._5 ? _327.encode(_50._5).length : 0);
                var totalDataSize = _0._12.length + _50._12.length + _999 + _1000;
                if (totalDataSize > _59._518) {
                    _261();
                    if (_50._5 !== undefined) _50._12[_50._12.length - 1] = 0;
                    _0._12 = _50._12;
                    _0._12[0] = 0;
                    _0._12[1] = 0;
                    if (_50._121 !== undefined) _0._140.push(_50._121);
                    if (_50._5 !== undefined) _0._42.push(_50._5)
                } else {
                    _0._12 = _0._12.concat(_50._12);
                    if (_50._121 !== undefined) _0._140.push(_50._121);
                    if (_50._5 !== undefined) _0._42.push(_50._5);
                    if (_19 === _6._356) {
                        _261()
                    }
                }
            }

            function _393(_390) {
                _515(_13._392, _390)
            }

            function _515(_46, _390) {
                var _12 = [],
                    _160 = [],
                    _140 = [],
                    _42 = [];
                _390.forEach(function(_35) {
                    if (!_35._24) _35._24 = {};
                    var _50 = _517(_35._19, _35._24, _160, _42);
                    if (!_50) return;
                    _12 = _12.concat(_50._12);
                    if (_50._121 !== undefined) _140.push(_50._121);
                    if (_50._5 !== undefined) _42.push(_50._5)
                });
                var _237 = 0;
                var _432 = _665(_237, _12, _140, _42);
                _115({
                    _18: _151 + 'events?w=' + _4._53 + '&s=' + _13._62 + '&p=' + _46 + '&li=0&lh=0&ls=0&d=' + _432
                })
            }

            function _517(_19, _24, _160, _42) {
                var _121;
                var _5 = _24.value;
                var _389 = -1;
                var _12 = [];
                _12._695 = false;
                if (_1011(_19) && !_1012(_24)) return null;
                if (_24.value && _24.value.length > _59._518) {
                    _8('Event, type: ' + _19 + ', skipping due to large value, details: ' + _10._114(_24), _14());
                    return null
                }
                _133(2, _381(), _12);
                _133(1, _19, _12);
                if (_24.x < 0) _24.x = 0;
                if (_24.y < 0) _24.y = 0;
                if (_24.x > 65534) _24.x = 65534;
                if (_24.y > 65534) _24.y = 65534;
                if (_24.x != undefined) _133(2, _24.x, _12);
                if (_24.y != undefined) _133(2, _24.y, _12);
                if (_24.target != undefined) {
                    if (typeof _24.target == 'object' && _24.target.id != undefined) _24.target = _24.target.id;
                    if (_19 !== _6._87 && _24.target && _24.target.indexOf('||') === -1) {
                        var _1 = _351(_24.target);
                        if (_1) {
                            if (_329(_1)) return null;
                            var _36 = _365(_1);
                            if (_36 && !_329(_36)) _24.target = _60(_36) + '||' + _24.target
                        }
                    }
                    for (var _2 = 0; _2 < _160.length; _2++) {
                        if (_160[_2] === _24.target) {
                            _389 = _2;
                            break
                        }
                    }
                }
                if (_1014(_19)) {
                    if (!_24.target) {
                        _133(2, 65535, _12)
                    } else if (_389 === -1) {
                        var _520 = _160.length;
                        _133(2, _520, _12);
                        _121 = _520 + ':' + _24.target;
                        _160.push(_24.target)
                    } else {
                        _133(2, _389, _12)
                    }
                }
                if (_19 !== _6._297 && _19 !== _6._260) _8('Event, type: ' + _19 + ', time: ' + _14() + ', details: ' + _10._114(_24), _14());
                if (_1016(_19)) {
                    if (_5 instanceof Array) _5 = _5.join(', ');
                    _133(1, _42.length, _12)
                }
                if (_12._695) {
                    _8('Event, type: ' + _19 + ', skipping due to overflow in temp data, details: ' + _10._114(_24), _14());
                    return null
                }
                return {
                    _12: _12,
                    _121: _121,
                    _5: _5
                }
            }

            function _381() {
                return +new Date() - _0._267
            }

            function _1010() {
                return _3.performance && _3.performance.timing.domLoading > 0 ? _0._506 - _3.performance.timing.domLoading : 0
            }

            function _654() {
                return _3.performance && _3.performance.timing.loadEventStart > 0 && _3.performance.timing.fetchStart > 0 ? _3.performance.timing.loadEventStart - _3.performance.timing.fetchStart : 0
            }

            function _1011(_19) {
                return [_6._347, _6._295, _6._297, _6._323, _6._344, _6._211, _6._213, _6._214, _6._662, _6._96, _6._413, _6._414, _6._356, _6._444, _6._443, _6._442, _6._441, _6._440, _6._557, _6._437, _6._543, _6._436, _6._61, _6._387, _6._260, _6._97].indexOf(_19) !== -1
            }

            function _1012(_24) {
                return _24.x !== undefined && _24.y !== undefined && !isNaN(_24.x) && !isNaN(_24.y)
            }

            function _1014(_19) {
                return [_6._323, _6._344, _6._211, _6._213, _6._214, _6._385, _6._343, _6._246, _6._504, _6._500, _6._325, _6._87, _6._440, _6._437, _6._436, _6._363, _6._501, _6._502, _6._387, _6._260, _6._97].indexOf(_19) !== -1
            }

            function _1016(_19) {
                return [_6._343, _6._246, _6._363, _6._97].indexOf(_19) !== -1
            }

            function _1018(_19) {
                return _1019(_19) || _546(_19) || _922(_19)
            }

            function _1019(_19) {
                return [_6._297, _6._323, _6._344, _6._211, _6._295, _6._213, _6._214, _6._260].indexOf(_19) !== -1
            }

            function _546(_19) {
                return [_6._385, _6._343, _6._246, _6._363].indexOf(_19) !== -1
            }

            function _922(_19) {
                return [_6._413, _6._414, _6._356, _6._444, _6._443, _6._442, _6._441, _6._440, _6._557, _6._437, _6._543, _6._436].indexOf(_19) !== -1
            }

            function _550() {
                if (!_223(_312(), _0._168)) {
                    _0._168 = _312();
                    _27(_6._347, _0._168);
                    _0._435 = _14()
                }
                if (!_223(_0._141, _0._526)) {
                    _0._526 = _0._141;
                    _27(_6._297, _0._141)
                }
                if (!_223(_0._86, _0._243)) {
                    _0._243 = _0._86;
                    _27(_6._295, _0._86);
                    _0._434 = _14()
                }
            }

            function _880() {
                if (!_223(_0._141, _0._529)) {
                    _0._529 = _0._141;
                    var _534 = _11.elementFromPoint(_0._141.x - _0._86.x, _0._141.y - _0._86.y);
                    var _155 = _433(_534, _0._141.x, _0._141.y);
                    if (_155) {
                        _27(_6._260, {
                            x: _155.x,
                            y: _155.y,
                            target: _60(_534)
                        })
                    }
                }
            }

            function _261() {
                var _237 = _0._267 - _0._83;
                var _432 = _665(_237, _0._12, _0._140, _0._42);
                _0._244.push(_432);
                _0._12 = [];
                _0._42 = [];
                _0._140 = [];
                _0._267 = +new Date();
                if (_14() > _59._883) {
                    _8('Pageview over max.time, stopping.', _14());
                    _539();
                    _21._154(_431);
                    _21._154(_430);
                    _21._154(_429);
                    _21._154(_428);
                    _21._132(_251);
                    _216 = false
                } else {
                    _890()
                }
            }

            function _665(_237, _12, _140, _42) {
                var _239 = [];
                _133(3, _237, _239);
                _133(2, _12.length, _239);
                _239 = _239.concat(_12);
                return _904.e(_239) + '.' + _679(_140 || []) + '.' + _679(_42 || [])
            }

            function _890() {
                if (_216 && _0._244.length > 0) {
                    if (_0._247 == 1) {
                        _13._241++
                    }
                    var _98 = _13._309 ? _424() : [];
                    for (var _2 = 0; _2 < _0._244.length; _2++) {
                        _98.push({
                            _18: _151 + 'events?w=' + _4._53 + '&s=' + _13._62 + '&p=' + _13._46 + '&q=' + _0._247 + '&li=' + _0._722 + '&lh=' + _0._721 + '&ls=' + _0._719 + '&d=' + _0._244[_2]
                        });
                        _0._247++;
                        _0._722 = _0._427;
                        _0._721 = _0._168.y;
                        _0._719 = _0._243.y
                    }
                    _0._244 = [];
                    if (_13._309) {
                        _712(_98.slice(-10));
                        _714()
                    } else {
                        for (var _2 = 0; _2 < _98.length; _2++) {
                            _115(_98[_2])
                        }
                    }
                    if (_0._247 > _59._873) _78()
                }
            }

            function _714() {
                if (_0._425) return;
                var _16 = _424().slice(0, 1)[0];
                if (_16) {
                    _0._425 = true;
                    _16._164 = _16._96 = function() {
                        _712(_424().slice(1));
                        _0._425 = false;
                        _21._65(_714, 1)
                    };
                    _115(_16)
                }
            }

            function _424() {
                return _149._258('mf_transmitQueue') || []
            }

            function _712(_98) {
                _149._257('mf_transmitQueue', _98)
            }

            function _115(_16) {
                if (!_16 || !_16._18) return;
                _423();
                if (_736() && _3.XDomainRequest) {
                    try {
                        _16._18 = _858(_420(_16._18, '0'));
                        var _120 = new _3.XDomainRequest();
                        _120.open(_16._12 ? 'POST' : 'GET', _16._18);
                        _120.onload = function() {
                            if (_16._164) _16._164(_708(_120))
                        };
                        _120.onerror = function() {
                            if (_16._96) _16._96(_708(_120))
                        };
                        _120.onprogress = function() {
                            _8('XDR progress:' + _16._18, _14())
                        };
                        _120.ontimeout = function() {
                            _8('XDR timeout:' + _16._18, _14())
                        };
                        _120.timeout = 20000;
                        _21._65(function() {
                            _120.send(_16._12)
                        }, 500)
                    } catch (_55) {
                        _8('Error in transmitCrossDomain (XDomainRequest): ' + _55.message, _14());
                        if (_16._96) _16._96({})
                    }
                } else if (_3.XMLHttpRequest) {
                    try {
                        var _84 = new _3.XMLHttpRequest();
                        _84.onreadystatechange = function() {
                            if (_84.readyState !== 4 || !_84.status) return;
                            if (_856(_84.status)) {
                                if (_16._164) _16._164(_706(_84))
                            } else {
                                if (_16._96) _16._96(_706(_84))
                            }
                        };
                        if (_16._12, _16._660) {
                            _16._12 = pako.gzip(_16._12);
                            _16._18 = _420(_16._18, '1')
                        } else {
                            _16._18 = _420(_16._18, '0')
                        }
                        _84.open(_16._12 ? 'POST' : 'GET', _16._18, true);
                        _84.setRequestHeader('Content-type', 'text/plain');
                        if (_16._860) _84.withCredentials = true;
                        _84.send(_16._12)
                    } catch (_55) {
                        _8('Error in transmitCrossDomain (XMLHttpRequest): ' + _55.message, _14());
                        if (_16._96) _16._96({})
                    }
                }
            }

            function _708(_120) {
                return {
                    _422: _120.responseText
                }
            }

            function _706(_84) {
                return {
                    _418: _84.status,
                    _422: _84.response
                }
            }

            function _420(_18, _5) {
                return /\/(html|dom)/.test(_18) ? _18 + (_18.indexOf('?') === -1 ? '?' : '&') + 'gz=' + _5 : _18
            }

            function _419(_19, _12) {
                _115({
                    _18: _151 + 'data',
                    _12: 'website=' + _4._53 + '&session=' + _13._62 + '&page=' + _13._46 + '&type=' + _19 + '&data=' + _80(_10._114(_12))
                })
            }

            function _856(_418) {
                return _418 >= 200 && _418 < 300
            }

            function _736() {
                return _11.all && !_3.atob;
            }

            function _692() {
                return _11.all && !_11.addEventListener;
            }

            function _858(_18) {
                return _18.replace(/^https?:/i, _4.location.protocol)
            }

            function _859(_61, _871, _46) {
                var _311 = _10._114(_61.data);
                if (_311 && _311.length > _4._861) {
                    _8('DOM size too big, not sending, size: ' + _10._225(_311.length), _14());
                    _87('mf_secret_html-too-big');
                    return
                }
                var _165 = _80(_311);
                var _751 = 5242000;
                var _16 = {
                    _18: _151 + 'html' + '?website=' + _4._53 + '&session=' + _13._62 + '&page=' + (_46 || _13._46),
                    _12: 'size=' + _871 + '&html=' + _165,
                    _660: _4.compress
                };
                if (_13._309 && _165.length <= _751) {
                    var _98 = _741();
                    if (_165 !== '') {
                        _8('Adding initial DOM to queue, size: ' + _10._225(_165.length), _14());
                        _98.push(_16)
                    } else _8('Initial DOM empty, not sending', _14());
                    _738(_98.slice(-10));
                    _744()
                } else {
                    if (_165 == '') {
                        _8('Initial DOM empty, not sending', _14());
                        return
                    }
                    if (_165.length <= _751) {
                        _8('Transmitting initial DOM without queue due to no sessionstorage, size: ' + _10._225(_165.length), _14());
                        _115(_16)
                    } else {
                        _8('Transmitting initial DOM without queue due to big html, size: ' + _10._225(_165.length), _14());
                        _115(_16)
                    }
                }
            }

            function _744() {
                var _98 = _741();
                var _16 = _98.splice(0, 1)[0];
                if (_16) {
                    _8('Sending initial DOM mutations. Size: ' + _16._12.length, _14());
                    _16._164 = _16._96 = function() {
                        _738(_98);
                        _21._65(_744, 1)
                    };
                    _115(_16)
                }
            }

            function _741() {
                return _149._258('mf_initialDomQueue') || []
            }

            function _738(_98) {
                _149._257('mf_initialDomQueue', _98)
            }

            function _865(_61) {
                var _162 = _61.data.args[1].some(function(_116) {
                    return _465._162(_116)
                });
                if (_162) {
                    _8('DOM mutation is a duplicate and has not been added.', _14());
                    return
                }
                var _735 = _898(_61, _0._181);
                if (_735 > -1) {
                    _0._181[_735].data = _61.data;
                    _8('Deduplicating DOM mutation', _14());
                    return
                }
                if (_4.domReuse) {
                    var _302 = _869(_61);
                    var _731 = _868(_302);
                    if (_731 > -1) {
                        _61.sequence = _731;
                        _8('Reusing already sent DOM mutation, sequence ' + _61.sequence, _14());
                        _27(_6._61, {
                            x: _61.sequence,
                            y: 0
                        });
                        return
                    } else _0._383.push(_302)
                }
                _61.sequence = ++_0._867;
                _27(_6._61, {
                    x: _61.sequence,
                    y: 0
                });
                _0._181.push(_61);
                if (!_274) _274 = _21._65(_737, 1500)
            }

            function _868(_302) {
                for (var i = 0; i < _0._383.length; i++)
                    if (_0._383[i] == _302) return i + 1;
                return -1
            }

            function _869(_61) {
                return _109(_10._114(_61.data))
            }

            function _737() {
                _274 = 0;
                if (_216 && _0._181.length > 0) {
                    var _659 = _0._181.length;
                    var _12 = _0._181.map(function(_61) {
                        return _61.sequence + '.' + _896(_10._114(_61.data))
                    }).join('|||');
                    _0._181 = [];
                    if (_12 !== '') {
                        _12 = 'website=' + _4._53 + '&session=' + _13._62 + '&page=' + _13._46 + '&data=' + _80(_12);
                        _115({
                            _18: _151 + 'dom',
                            _12: _12,
                            _660: _4.compress
                        });
                        _8('Sending DOM mutations: ' + _659 + ', size: ' + _12.length, _14());
                        _0._699 += _659;
                        if (_0._699 > _59._657) {
                            _8('DOM mutation limit of ' + _59._657 + ' reached. Stopping recording.', _14());
                            _78()
                        }
                    }
                }
            }

            function _898(_74, _656) {
                if (!_4.domDeduplicator) return -1;
                var _91 = _74.data.args;
                var _655 = _651(_91);
                var _653 = _650(_91);
                if (!_655 && !_653) return -1;
                for (var i = 0; i < _656.length; i++) {
                    var _380 = _656[i].data.args;
                    if (_655 && _651(_380) && _927(_91[2], _380[2])) {
                        return i
                    } else if (_653 && _650(_380)) {
                        return i
                    }
                }
                return -1
            }

            function _651(_91) {
                return _649(_91) && _91[2].filter(_899).length === _91[2].length
            }

            function _650(_91) {
                return _649(_91) && _91[2].filter(_925).length === _91[2].length
            }

            function _649(_91) {
                return _91[0].length === 0 && _91[1].length === 0 && _91[2].length > 0 && _91[3].length === 0
            }

            function _899(_284) {
                return _284.attributes.style && _647(_284.attributes) === 1
            }

            function _925(_284) {
                return _284.attributes.d && _647(_284.attributes) === 1
            }

            function _647(obj) {
                var count = 0;
                for (var prop in obj)
                    if (obj.hasOwnProperty(prop)) count++;
                return count
            }

            function _927(_378, _642) {
                if (_378.length !== _642.length) return false;
                for (var i = 0; i < _378.length; i++) {
                    var _929 = _378[i],
                        _930 = _642[i];
                    if (_929.id !== _930.id) return false
                }
                return true
            }

            function _379() {
                if (_0._12.length > 0 && _381() >= 5000) {
                    _27(_6._379, {});
                    _261()
                }
            }

            function _370() {
                if (_381() >= 5000) {
                    _27(_6._370, {});
                    _261()
                }
            }

            function _150() {
                _8('Inactivity timeout.', _14());
                _78(true)
            }

            function _223(_123, _636) {
                return _123.x == _636.x && _123.y == _636.y
            }

            function _312() {
                return {
                    x: _3.innerWidth,
                    y: _3.innerHeight
                }
            }

            function _635(_183) {
                if (!_183 || !_183.getBoundingClientRect) return null;
                var _161 = _183.getBoundingClientRect();
                var _268;
                if (!_183.childElementCount && !_161.height && !_161.width) _268 = _937(_183);
                if (!_268) {
                    return {
                        x: _161.left,
                        y: _161.top,
                        width: _161.width,
                        height: _161.height
                    }
                } else {
                    _268.x += _161.left - _183.offsetLeft;
                    _268.y += _161.top - _183.offsetTop;
                    return _268
                }
            }

            function _937(_1) {
                var _224 = window.getComputedStyle(_1, [':after']);
                if (!_224) return _224;
                return {
                    x: +_224.left.slice(0, -2),
                    y: +_224.top.slice(0, -2),
                    width: +_224.width.slice(0, -2),
                    height: +_224.height.slice(0, -2)
                }
            }

            function _60(_1) {
                var _262 = _349.get(_1);
                if (_262) return _262;
                try {
                    var _41 = [];
                    while (_1) {
                        var _31 = _1.getRootNode ? _1.getRootNode() : _11;
                        _41.unshift(_939(_1, _31) || _940(_1, _31));
                        _1 = _31.host
                    }
                    return _41.join(' > :document-fragment: > ')
                } catch (_55) {
                    _8('Error in getElementPath: ' + _55.message, _14())
                }
                return ''
            }

            function _939(_1) {
                var name = _1.attributes['name'] ? _1.attributes['name'].value : null;
                if (name && _365(_1) && /button|input|select|textarea/.test(_1.tagName.toLowerCase())) {
                    var _346 = _11.getElementsByName(name);
                    if (_346.length === 1) return name;
                    if (_346.length > 1) {
                        for (var _2 = 0; _2 < _346.length; _2++)
                            if (_1 === _346[_2]) return name + '[' + _2 + ']_mf'
                    }
                }
                return null
            }

            function _940(_79, _31) {
                var _26 = [];
                try {
                    while (_79 && _79.nodeType === 1) {
                        var _9 = '';
                        var _64 = _29._71(_79);
                        var _262 = _349.get(_79);
                        if (_262) {
                            _26.unshift(_262);
                            break
                        }
                        if (_79.tagName === 'TABLE' && _26.indexOf('tbody') === -1 && _26.indexOf('thead') === -1) _26.unshift('tbody');
                        if (_79.getAttribute('id') && !_10._174(_79, 'data-mf-ignore-child-ids') && _4.useIdSelectors) {
                            _9 += '#' + _79.getAttribute('id');
                            _26.unshift(_9);
                            break
                        } else {
                            _9 += _79.tagName.toLowerCase();
                            var _350 = '',
                                _447 = _79,
                                _220 = 1;
                            if (_64 && _64.tagName && _64.tagName.toLowerCase() == 'body') {
                                var _101 = _10._194(_79);
                                _350 = _101.length ? '.' + _101.join('.') : ''
                            }
                            if (_350 !== '' && _31.querySelectorAll(_697('body > ' + _9 + _350)).length === 1) _9 += _350;
                            else {
                                while ((_447 = _447.previousElementSibling)) {
                                    if (_447.tagName.toLowerCase() === _9) _220++
                                }
                                if (_220 !== 1) _9 += ':[' + _220 + ']'
                            }
                        }
                        _26.unshift(_9);
                        if (!_64) return '';
                        _79 = _64
                    }
                } catch (_55) {
                    _8('Error in _getCssPath: ' + _55.message, _14())
                }
                return _26.join(' > ').replace('html > body > ', '> ')
            }

            function _351(_41) {
                if (!_41) return null;
                var _1 = _943(_41);
                if (!_1) {
                    try {
                        var _31 = _11;
                        _697(_41).split(' > :document-fragment: > ').forEach(function(_9) {
                            _1 = _31.querySelector(_9);
                            _31 = _1.shadowRoot
                        })
                    } catch (_55) {
                        _8('Error in _getElementById: ' + _55.message, _14())
                    }
                }
                return _1
            }

            function _943(_22) {
                if (!_22) return null;
                var _68 = _690.exec(_22);
                if (_68 && _68[1]) {
                    try {
                        var _49 = _3.parseInt(_68[1]);
                        return _11.getElementsByName(_22.replace(_690, ''))[_49]
                    } catch (_55) {}
                }
                var _63 = _11.getElementsByName(_22);
                if (_63 && _63.length === 1) return _63[0];
                return null
            }

            function _697(_26) {
                if (!_26) return null;
                if (_26.substr(0, 1) === '>') _26 = 'html > body ' + _26;
                _26 = _26.replace(/^#(\d)/, '#\\3$1 ');
                _26 = _26.replace(/^#(-\d)/, '#\\$1');
                _26 = _26.replace(/:([^\[])/g, '\\:$1');
                _26 = _26.replace(/\\:document-fragment\\:/g, ':document-fragment:');
                _26 = _26.replace(/^#[^\s]+/, function(id) {
                    return '#' + id.slice(1).replace(/([^a-zA-Z\d\s:\\])/g, '\\$1')
                });
                _26 = _26.replace(/:\[([^\]]+)\]/g, ':nth-of-type($1)');
                return _26
            }

            function _133(_944, _5, _265) {
                for (var _2 = _944 - 1; _2 > 0; _2--) {
                    var _693 = _128.pow(256, _2);
                    _694(_128.floor(_5 / _693), _265);
                    _5 = _5 % _693
                }
                _694(_5, _265)
            }

            function _694(_680, _265) {
                if (_680 > 255) {
                    _265._695 = true;
                    return
                }
                _265.push(_680)
            }

            function _679(_1) {
                var _33 = '';
                for (var _2 = 0; _2 < _1.length; _2++) {
                    _33 += (_2 > 0 ? ',' : '') + _327.encode('' + _1[_2])
                }
                return _33
            }

            function _678(_1) {
                var _192 = 0;
                for (var _2 = 0; _2 < _1.length; _2++) _192 += _327.encode('' + _1[_2]).length + 1;
                return _192 > 0 ? _192 - 1 : _192
            }

            function _372(_37) {
                if (_924(_37.hostname) || !_4.includeSubDomains) return _37.hostname;
                var _30 = _37.href;
                var _945 = /\.co\.|\.com\.|\.ac\.|\.org\.|\.gov\.|\.edu\.|\.net\./;
                _30 = _30.replace(/^http(s)?\:\/\/?/i, '').replace(/^([^\/]+)\/.*/i, '$1').replace(/:[\d]*$/, '');
                if (_945.test(_30)) _30 = _30.replace(/^([^\.]+\.){1,}([^\.]+\.[^\.]+\.[^\.]+)$/i, '$2');
                else _30 = _30.replace(/^([^\.]+\.){1,}([^\.]+\.[^\.]+)$/i, '$2');
                return '.' + _30
            }

            function _924(ipaddress) {
                if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress)) {
                    return (true)
                }
                return (false)
            }

            function _675(_22, _5, _377, _30) {
                if (_4.preferStorageApi) _58._143(_22, _5);
                else _921(_22, _5, _377, _30)
            }

            function _674(_22) {
                if (_4.preferStorageApi) return _58._233(_22) || '';
                else return _903(_22)
            }

            function _946(_22) {
                if (_4.preferStorageApi) {
                    _149._319(_22);
                    _58._319(_22)
                } else {
                    _11.cookie = _22 + '=; expires=Thu, 01-Jan-70 00:00:01 GMT; path=/; domain=' + _372(_73) + ';'
                }
            }

            function _921(_22, _5, _377, _30) {
                var _667 = '';
                if (_377 == 1) {
                    var _100 = new Date();
                    _100.setTime(_100.getTime() + _59._901);
                    _667 = '; expires=' + _100.toGMTString()
                }
                var _902 = _4.secureCookie ? 'secure;' : '';
                _11.cookie = _22 + '=' + _5 + _667 + '; path=/; domain=' + _30 + ';' + _902 + 'SameSite=Strict;'
            }

            function _903(_22) {
                var _668 = _22 + '=';
                var _658 = _11.cookie.split(';');
                for (var i = 0; i < _658.length; i++) {
                    var c = _658[i];
                    while (c.charAt(0) === ' ') {
                        c = c.substring(1)
                    }
                    if (c.indexOf(_668) === 0) {
                        return c.substring(_668.length, c.length)
                    }
                }
                return ''
            }
            var _904 = new function() {
                for (var d = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'.split(''), c = 64; c;) --c;
                this.e = function(e) {
                    for (var a = [], f = 0, b = 0, g, c = e.length, h = c % 3; f < c;) a[b++] = d[(g = e[f++] << 16 | e[f++] << 8 | e[f++]) >> 18 & 63] + d[g >> 12 & 63] + d[g >> 6 & 63] + d[g & 63];
                    if (h)
                        for (a[--b] = a[b].substr(0, a[b].length - (h = 3 - h)); h--;) a[b] += '*';
                    return a.join('')
                }
            };
            var _327 = {
                _331: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
                encode: function(c) {
                    for (var a = '', d, b, e, i, h, f, g = 0, c = this._905(c); g < c.length;) d = c.charCodeAt(g++), b = c.charCodeAt(g++), e = c.charCodeAt(g++), i = d >> 2, d = (d & 3) << 4 | b >> 4, h = (b & 15) << 2 | e >> 6, f = e & 63, isNaN(b) ? h = f = 64 : isNaN(e) && (f = 64), a = a + this._331.charAt(i) + this._331.charAt(d) + this._331.charAt(h) + this._331.charAt(f);
                    return a
                },
                _905: function(c) {
                    for (var c = c.replace(/\r\n/g, '\n'), a = '', d = 0; d < c.length; d++) {
                        var b = c.charCodeAt(d);
                        128 > b ? a += String.fromCharCode(b) : (127 < b && 2048 > b ? a += String.fromCharCode(b >> 6 | 192) : (a += String.fromCharCode(b >> 12 | 224), a += String.fromCharCode(b >> 6 & 63 | 128)), a += String.fromCharCode(b & 63 | 128))
                    }
                    return a
                }
            };

            function _374() {
                var _123 = function() {
                    return ((1 + _128.random()) * 65536 | 0).toString(16).substring(1)
                };
                return _123() + _123() + _123() + _123() + _123() + _123() + _123() + _123()
            }
            var _369 = 0;

            function _733() {
                if (_11.body) {
                    _8('Initializing recorder');
                    if (!_908()) return;
                    if (_909) _910(_696);
                    else _696();
                    return
                }
                _369++;
                if (_369 === 1) {
                    _8('Retrying to initialize recorder - document.body is not set', _14())
                } else if (_369 === 25) {
                    _8('Failed to initialize recorder', _14());
                    return
                };
                _21._65(_733, 200)
            }

            function _696() {
                _8('Initializing recorder', _14());
                if (!_742(_4.location.hostname)) return;
                if (_692()) {
                    _8('Recording not started - browser is IE8 or older', _14());
                    return
                }
                if (_663) _912();
                if (_663 || _913) return;
                _632 = true;

                function _643() {
                    if (!_92 && _4.autoStart && _11.readyState !== 'loading') _38();
                    _487(_654())
                }
                _25._40(_11, 'readystatechange', _643);
                _643()
            }

            function _487(_916) {
                if (_375 || !_92 || _11.readyState !== 'complete') return;
                _27(_6._662, {
                    x: _916,
                    y: _328 ? _328.scrollHeight : _10._483()
                });
                _375 = true
            }

            function _917() {
                return _4.useUnload ? 'unload' : 'beforeunload'
            }

            function _283(_700, _749) {
                return _700.indexOf(_749, _700.length - _749.length) !== -1
            }

            function _109(_37) {
                var _117 = 0,
                    _747;
                for (var _2 = 0; _2 < _37.length; _2++) {
                    _747 = _37.charCodeAt(_2);
                    _117 = ((_117 << 5) - _117) + _747
                }
                return _117.toString()
            }

            function _740(_17) {
                for (var _2 = 0; _2 < _0._157.length; _2++)
                    if (_0._157[_2].split('_')[0] === _109(_17)) {
                        return _2
                    }
                return -1
            }

            function _750(_17, _5) {
                var _366 = _740(_17);
                var _373 = _109('' + _5);
                if (_366 > -1) {
                    if (_0._157[_366].split('_')[1] === _373) {
                        return false
                    }
                    _0._157[_366] = _109(_17) + '_' + _373
                } else if (_0._157.length < 20) {
                    _0._157.push(_109(_17) + '_' + _373)
                }
                return true
            }

            function _742(_30) {
                var _918 = _30;
                _30 = _368(_30);
                var _746 = false;
                for (var _2 = 0; _2 < _263.length; _2++) {
                    if (_30 == _368(_263[_2])) {
                        _746 = true;
                        break
                    }
                }
                _30 = _947(_30);
                var _713 = false;
                for (var _2 = 0; _2 < _263.length; _2++) {
                    if (_30 == _368(_263[_2])) {
                        _713 = true;
                        break
                    }
                }
                var _33 = _746 || _713;
                if (!_33) _8('Domain was blocked: ' + _918 + ' - domain list: ' + _263, _14());
                return _33
            }

            function _368(_30) {
                if (_30 == null) return '';
                _30 = _30.toLowerCase();
                _30 = _30.replace(/^\s+|\s+$/g, '');
                if (_30.substring(0, 4) == 'www.') {
                    _30 = _30.substring(4, _30.length)
                }
                return _30
            }

            function _947(_30) {
                if (_4.includeSubDomains) {
                    _30 = _1046(_30)
                }
                return _30
            }

            function _1046(_30) {
                var _124 = _30.split('.');
                if (_124.length <= 2) return _30;
                if (_30.indexOf('.co.') > -1 || _30.indexOf('.com.') > -1 || _30.indexOf('.org.') > -1) {
                    _124 = _124.slice(_124.length - 3, _124.length);
                    return _124.join('.')
                }
                _124 = _124.slice(_124.length - 2, _124.length);
                return _124.join('.')
            }

            function _933() {
                var _33 = [];
                if (typeof Ember != 'undefined') _33.push('em');
                if (typeof angular != 'undefined') _33.push('an');
                if (typeof Backbone != 'undefined') _33.push('bb');
                return _33
            }

            function _961() {
                var scrollingEl = null;
                var bodyScrollHeight = _3.document.body.scrollHeight;
                document.querySelectorAll('body *').forEach(function(el) {
                    if (el.tagName === 'LINKBAR-CONTAINER') return;
                    if (!scrollingEl) scrollingEl = el;
                    if (scrollingEl.scrollHeight < el.scrollHeight) scrollingEl = el
                });
                return scrollingEl.scrollHeight > bodyScrollHeight ? scrollingEl : null
            }

            function _866() {
                if (!_4.autoScrollSelector) return _11.querySelector(_4.scrollSelector);
                return _961()
            }

            function _950() {
                if (_4.autoTagging) {
                    _8('Autotagging session', _14());
                    var _725 = ['utm_source', 'utm_medium', 'utm_term', 'utm_content', 'utm_campaign', 'gclid'];
                    for (var _2 = 0; _2 < _725.length; _2++) {
                        var _446 = _725[_2];
                        var _5 = _615(_4.location.href, _446);
                        if (!_5) _5 = _615(_11.referrer, _446);
                        if (_5) _3._mfq.push(['setVariable', _446, _5])
                    }
                }
            }

            function _615(_18, _22) {
                _22 = _22.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
                var regex = new RegExp('[\\?&]' + _22 + '=([^&#]*)'),
                    results = regex.exec(_18);
                return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '))
            }

            function _849(_497) {
                switch (_497) {
                    case ' ':
                    case '"':
                    case "'":
                    case '.':
                    case ',':
                    case '_':
                    case '-':
                    case '+':
                    case '/':
                    case '*':
                    case ':':
                    case '=':
                    case '!':
                    case '?':
                    case '@':
                    case '#':
                    case '%':
                    case '&':
                    case '{':
                    case '}':
                    case '[':
                    case ']':
                    case '\\':
                    case '|':
                        return false;
                    default:
                        return true
                }
            }

            function _942(_5, _453) {
                var _33 = '';
                for (var _2 = 0; _2 < _453; _2++) {
                    _33 += _5
                }
                return _33
            }

            function _14() {
                return +new Date() - _0._83
            }

            function _920(_20) {
                var _919 = _20 instanceof Element;
                if (!_919) return false;
                var _739 = _3.getComputedStyle(_20);
                var _489 = _739 ? _739['white-space'] : '';
                if (_489 && (_489.indexOf('pre') > -1 || _489 === 'break-spaces')) return true;
                return false
            }
            if (!_736()) {
                var pako = function() {
                    function t() {
                        this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0
                    }

                    function e(t, e, a, n) {
                        for (var r = 65535 & t | 0, i = t >>> 16 & 65535 | 0, s = 0; 0 !== a;) {
                            s = a > 2e3 ? 2e3 : a, a -= s;
                            do r = r + e[n++] | 0, i = i + r | 0; while (--s);
                            r %= 65521, i %= 65521
                        }
                        return r | i << 16 | 0
                    }
                    var a = {
                            2: "need dictionary",
                            1: "stream end",
                            0: "",
                            "-1": "file error",
                            "-2": "stream error",
                            "-3": "data error",
                            "-4": "insufficient memory",
                            "-5": "buffer error",
                            "-6": "incompatible version"
                        },
                        n = function() {
                            function t() {
                                for (var t, e = [], a = 0; a < 256; a++) {
                                    t = a;
                                    for (var n = 0; n < 8; n++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
                                    e[a] = t
                                }
                                return e
                            }

                            function e(t, e, n, r) {
                                var i = a,
                                    s = r + n;
                                t ^= -1;
                                for (var h = r; h < s; h++) t = t >>> 8 ^ i[255 & (t ^ e[h])];
                                return t ^ -1
                            }
                            var a = t();
                            return e
                        }(),
                        r = {
                            Buf8: Uint8Array,
                            Buf16: Uint16Array,
                            assign: function(t) {
                                for (var e = Array.prototype.slice.call(arguments, 1); e.length;) {
                                    var a = e.shift();
                                    if (a) {
                                        if ("object" != typeof a) throw new TypeError(a + "must be non-object");
                                        for (var n in a) a.hasOwnProperty(n) && (t[n] = a[n])
                                    }
                                }
                                return t
                            },
                            shrinkBuf: function(t, e) {
                                return t.length === e ? t : t.subarray ? t.subarray(0, e) : (t.length = e, t)
                            },
                            arraySet: function(t, e, a, n, r) {
                                if (e.subarray && t.subarray) return void t.set(e.subarray(a, a + n), r);
                                for (var i = 0; i < n; i++) t[r + i] = e[a + i]
                            },
                            flattenChunks: function(t) {
                                var e, a, n, r, i, s;
                                for (n = 0, e = 0, a = t.length; e < a; e++) n += t[e].length;
                                for (s = new Uint8Array(n), r = 0, e = 0, a = t.length; e < a; e++) i = t[e], s.set(i, r), r += i.length;
                                return s
                            }
                        },
                        i = function() {
                            function t(t) {
                                var e, a, n, i, s, h = t.length,
                                    _ = 0;
                                for (i = 0; i < h; i++) a = t.charCodeAt(i), 55296 === (64512 & a) && i + 1 < h && (n = t.charCodeAt(i + 1), 56320 === (64512 & n) && (a = 65536 + (a - 55296 << 10) + (n - 56320), i++)), _ += a < 128 ? 1 : a < 2048 ? 2 : a < 65536 ? 3 : 4;
                                for (e = new r.Buf8(_), s = 0, i = 0; s < _; i++) a = t.charCodeAt(i), 55296 === (64512 & a) && i + 1 < h && (n = t.charCodeAt(i + 1), 56320 === (64512 & n) && (a = 65536 + (a - 55296 << 10) + (n - 56320), i++)), a < 128 ? e[s++] = a : a < 2048 ? (e[s++] = 192 | a >>> 6, e[s++] = 128 | 63 & a) : a < 65536 ? (e[s++] = 224 | a >>> 12, e[s++] = 128 | a >>> 6 & 63, e[s++] = 128 | 63 & a) : (e[s++] = 240 | a >>> 18, e[s++] = 128 | a >>> 12 & 63, e[s++] = 128 | a >>> 6 & 63, e[s++] = 128 | 63 & a);
                                return e
                            }

                            function e(t) {
                                var e = t.length;
                                if (e < 65537 && (t.subarray && n || !t.subarray && a)) return String.fromCharCode.apply(null, r.shrinkBuf(t, e));
                                for (var i = "", s = 0; s < e; s++) i += String.fromCharCode(t[s]);
                                return i
                            }
                            var a = !0,
                                n = !0;
                            try {
                                String.fromCharCode.apply(null, [0])
                            } catch (t) {
                                a = !1
                            }
                            try {
                                String.fromCharCode.apply(null, new Uint8Array(1))
                            } catch (t) {
                                n = !1
                            }
                            return {
                                string2buf: t,
                                buf2binstring: e
                            }
                        }(),
                        s = function() {
                            function t(t) {
                                for (var e = t.length; --e >= 0;) t[e] = 0
                            }

                            function e(t, e, a, n, r) {
                                this.static_tree = t, this.extra_bits = e, this.extra_base = a, this.elems = n, this.max_length = r, this.has_stree = t && t.length
                            }

                            function a(t, e) {
                                this.dyn_tree = t, this.max_code = 0, this.stat_desc = e
                            }

                            function n(t) {
                                return t < 256 ? it[t] : it[256 + (t >>> 7)]
                            }

                            function i(t, e) {
                                t.pending_buf[t.pending++] = 255 & e, t.pending_buf[t.pending++] = e >>> 8 & 255
                            }

                            function s(t, e, a) {
                                t.bi_valid > Q - a ? (t.bi_buf |= e << t.bi_valid & 65535, i(t, t.bi_buf), t.bi_buf = e >> Q - t.bi_valid, t.bi_valid += a - Q) : (t.bi_buf |= e << t.bi_valid & 65535, t.bi_valid += a)
                            }

                            function h(t, e, a) {
                                s(t, a[2 * e], a[2 * e + 1])
                            }

                            function _(t, e) {
                                var a = 0;
                                do a |= 1 & t, t >>>= 1, a <<= 1; while (--e > 0);
                                return a >>> 1
                            }

                            function l(t) {
                                16 === t.bi_valid ? (i(t, t.bi_buf), t.bi_buf = 0, t.bi_valid = 0) : t.bi_valid >= 8 && (t.pending_buf[t.pending++] = 255 & t.bi_buf, t.bi_buf >>= 8, t.bi_valid -= 8)
                            }

                            function o(t, e) {
                                var a, n, r, i, s, h, _ = e.dyn_tree,
                                    l = e.max_code,
                                    o = e.stat_desc.static_tree,
                                    d = e.stat_desc.has_stree,
                                    u = e.stat_desc.extra_bits,
                                    f = e.stat_desc.extra_base,
                                    c = e.stat_desc.max_length,
                                    g = 0;
                                for (i = 0; i <= N; i++) t.bl_count[i] = 0;
                                for (_[2 * t.heap[t.heap_max] + 1] = 0, a = t.heap_max + 1; a < M; a++) n = t.heap[a], i = _[2 * _[2 * n + 1] + 1] + 1, i > c && (i = c, g++), _[2 * n + 1] = i, n > l || (t.bl_count[i]++, s = 0, n >= f && (s = u[n - f]), h = _[2 * n], t.opt_len += h * (i + s), d && (t.static_len += h * (o[2 * n + 1] + s)));
                                if (0 !== g) {
                                    do {
                                        for (i = c - 1; 0 === t.bl_count[i];) i--;
                                        t.bl_count[i]--, t.bl_count[i + 1] += 2, t.bl_count[c]--, g -= 2
                                    } while (g > 0);
                                    for (i = c; 0 !== i; i--)
                                        for (n = t.bl_count[i]; 0 !== n;) r = t.heap[--a], r > l || (_[2 * r + 1] !== i && (t.opt_len += (i - _[2 * r + 1]) * _[2 * r], _[2 * r + 1] = i), n--)
                                }
                            }

                            function d(t, e, a) {
                                var n, r, i = new Array(N + 1),
                                    s = 0;
                                for (n = 1; n <= N; n++) i[n] = s = s + a[n - 1] << 1;
                                for (r = 0; r <= e; r++) {
                                    var h = t[2 * r + 1];
                                    0 !== h && (t[2 * r] = _(i[h]++, h))
                                }
                            }

                            function u() {
                                var t, a, n, r, i, s = new Array(N + 1);
                                for (n = 0, r = 0; r < q - 1; r++)
                                    for (ht[r] = n, t = 0; t < 1 << Z[r]; t++) st[n++] = r;
                                for (st[n - 1] = r, i = 0, r = 0; r < 16; r++)
                                    for (_t[r] = i, t = 0; t < 1 << $[r]; t++) it[i++] = r;
                                for (i >>= 7; r < J; r++)
                                    for (_t[r] = i << 7, t = 0; t < 1 << $[r] - 7; t++) it[256 + i++] = r;
                                for (a = 0; a <= N; a++) s[a] = 0;
                                for (t = 0; t <= 143;) nt[2 * t + 1] = 8, t++, s[8]++;
                                for (; t <= 255;) nt[2 * t + 1] = 9, t++, s[9]++;
                                for (; t <= 279;) nt[2 * t + 1] = 7, t++, s[7]++;
                                for (; t <= 287;) nt[2 * t + 1] = 8, t++, s[8]++;
                                for (d(nt, G + 1, s), t = 0; t < J; t++) rt[2 * t + 1] = 5, rt[2 * t] = _(t, 5);
                                lt = new e(nt, Z, F + 1, G, N), ot = new e(rt, $, 0, J, N), dt = new e(new Array(0), tt, 0, K, R)
                            }

                            function f(t) {
                                var e;
                                for (e = 0; e < G; e++) t.dyn_ltree[2 * e] = 0;
                                for (e = 0; e < J; e++) t.dyn_dtree[2 * e] = 0;
                                for (e = 0; e < K; e++) t.bl_tree[2 * e] = 0;
                                t.dyn_ltree[2 * V] = 1, t.opt_len = t.static_len = 0, t.last_lit = t.matches = 0
                            }

                            function c(t) {
                                t.bi_valid > 8 ? i(t, t.bi_buf) : t.bi_valid > 0 && (t.pending_buf[t.pending++] = t.bi_buf), t.bi_buf = 0, t.bi_valid = 0
                            }

                            function g(t, e, a, n) {
                                c(t), n && (i(t, a), i(t, ~a)), r.arraySet(t.pending_buf, t.window, e, a, t.pending), t.pending += a
                            }

                            function p(t, e, a, n) {
                                var r = 2 * e,
                                    i = 2 * a;
                                return t[r] < t[i] || t[r] === t[i] && n[e] <= n[a]
                            }

                            function b(t, e, a) {
                                for (var n = t.heap[a], r = a << 1; r <= t.heap_len && (r < t.heap_len && p(e, t.heap[r + 1], t.heap[r], t.depth) && r++, !p(e, n, t.heap[r], t.depth));) t.heap[a] = t.heap[r], a = r, r <<= 1;
                                t.heap[a] = n
                            }

                            function w(t, e, a) {
                                var r, i, _, l, o = 0;
                                if (0 !== t.last_lit)
                                    do r = t.pending_buf[t.d_buf + 2 * o] << 8 | t.pending_buf[t.d_buf + 2 * o + 1], i = t.pending_buf[t.l_buf + o], o++, 0 === r ? h(t, i, e) : (_ = st[i], h(t, _ + F + 1, e), l = Z[_], 0 !== l && (i -= ht[_], s(t, i, l)), r--, _ = n(r), h(t, _, a), l = $[_], 0 !== l && (r -= _t[_], s(t, r, l))); while (o < t.last_lit);
                                h(t, V, e)
                            }

                            function v(t, e) {
                                var a, n, r, i = e.dyn_tree,
                                    s = e.stat_desc.static_tree,
                                    h = e.stat_desc.has_stree,
                                    _ = e.stat_desc.elems,
                                    l = -1;
                                for (t.heap_len = 0, t.heap_max = M, a = 0; a < _; a++) 0 !== i[2 * a] ? (t.heap[++t.heap_len] = l = a, t.depth[a] = 0) : i[2 * a + 1] = 0;
                                for (; t.heap_len < 2;) r = t.heap[++t.heap_len] = l < 2 ? ++l : 0, i[2 * r] = 1, t.depth[r] = 0, t.opt_len--, h && (t.static_len -= s[2 * r + 1]);
                                for (e.max_code = l, a = t.heap_len >> 1; a >= 1; a--) b(t, i, a);
                                r = _;
                                do a = t.heap[1], t.heap[1] = t.heap[t.heap_len--], b(t, i, 1), n = t.heap[1], t.heap[--t.heap_max] = a, t.heap[--t.heap_max] = n, i[2 * r] = i[2 * a] + i[2 * n], t.depth[r] = (t.depth[a] >= t.depth[n] ? t.depth[a] : t.depth[n]) + 1, i[2 * a + 1] = i[2 * n + 1] = r, t.heap[1] = r++, b(t, i, 1); while (t.heap_len >= 2);
                                t.heap[--t.heap_max] = t.heap[1], o(t, e), d(i, l, t.bl_count)
                            }

                            function m(t, e, a) {
                                var n, r, i = -1,
                                    s = e[1],
                                    h = 0,
                                    _ = 7,
                                    l = 4;
                                for (0 === s && (_ = 138, l = 3), e[2 * (a + 1) + 1] = 65535, n = 0; n <= a; n++) r = s, s = e[2 * (n + 1) + 1], ++h < _ && r === s || (h < l ? t.bl_tree[2 * r] += h : 0 !== r ? (r !== i && t.bl_tree[2 * r]++, t.bl_tree[2 * W]++) : h <= 10 ? t.bl_tree[2 * X]++ : t.bl_tree[2 * Y]++, h = 0, i = r, 0 === s ? (_ = 138, l = 3) : r === s ? (_ = 6, l = 3) : (_ = 7, l = 4))
                            }

                            function k(t, e, a) {
                                var n, r, i = -1,
                                    _ = e[1],
                                    l = 0,
                                    o = 7,
                                    d = 4;
                                for (0 === _ && (o = 138, d = 3), n = 0; n <= a; n++)
                                    if (r = _, _ = e[2 * (n + 1) + 1], !(++l < o && r === _)) {
                                        if (l < d) {
                                            do h(t, r, t.bl_tree); while (0 !== --l)
                                        } else 0 !== r ? (r !== i && (h(t, r, t.bl_tree), l--), h(t, W, t.bl_tree), s(t, l - 3, 2)) : l <= 10 ? (h(t, X, t.bl_tree), s(t, l - 3, 3)) : (h(t, Y, t.bl_tree), s(t, l - 11, 7));
                                        l = 0, i = r, 0 === _ ? (o = 138, d = 3) : r === _ ? (o = 6, d = 3) : (o = 7, d = 4)
                                    }
                            }

                            function y(t) {
                                var e;
                                for (m(t, t.dyn_ltree, t.l_desc.max_code), m(t, t.dyn_dtree, t.d_desc.max_code), v(t, t.bl_desc), e = K - 1; e >= 3 && 0 === t.bl_tree[2 * et[e] + 1]; e--);
                                return t.opt_len += 3 * (e + 1) + 5 + 5 + 4, e
                            }

                            function z(t, e, a, n) {
                                var r;
                                for (s(t, e - 257, 5), s(t, a - 1, 5), s(t, n - 4, 4), r = 0; r < n; r++) s(t, t.bl_tree[2 * et[r] + 1], 3);
                                k(t, t.dyn_ltree, e - 1), k(t, t.dyn_dtree, a - 1)
                            }

                            function x(t) {
                                var e, a = 4093624447;
                                for (e = 0; e <= 31; e++, a >>>= 1)
                                    if (1 & a && 0 !== t.dyn_ltree[2 * e]) return U;
                                if (0 !== t.dyn_ltree[18] || 0 !== t.dyn_ltree[20] || 0 !== t.dyn_ltree[26]) return D;
                                for (e = 32; e < F; e++)
                                    if (0 !== t.dyn_ltree[2 * e]) return D;
                                return U
                            }

                            function B(t) {
                                ut || (u(), ut = !0), t.l_desc = new a(t.dyn_ltree, lt), t.d_desc = new a(t.dyn_dtree, ot), t.bl_desc = new a(t.bl_tree, dt), t.bi_buf = 0, t.bi_valid = 0, f(t)
                            }

                            function A(t, e, a, n) {
                                s(t, (I << 1) + (n ? 1 : 0), 3), g(t, e, a, !0)
                            }

                            function S(t) {
                                s(t, L << 1, 3), h(t, V, nt), l(t)
                            }

                            function C(t, e, a, n) {
                                var r, i, h = 0;
                                t.level > 0 ? (t.strm.data_type === H && (t.strm.data_type = x(t)), v(t, t.l_desc), v(t, t.d_desc), h = y(t), r = t.opt_len + 3 + 7 >>> 3, i = t.static_len + 3 + 7 >>> 3, i <= r && (r = i)) : r = i = a + 5, a + 4 <= r && e !== -1 ? A(t, e, a, n) : t.strategy === j || i === r ? (s(t, (L << 1) + (n ? 1 : 0), 3), w(t, nt, rt)) : (s(t, (O << 1) + (n ? 1 : 0), 3), z(t, t.l_desc.max_code + 1, t.d_desc.max_code + 1, h + 1), w(t, t.dyn_ltree, t.dyn_dtree)), f(t), n && c(t)
                            }

                            function E(t, e, a) {
                                return t.pending_buf[t.d_buf + 2 * t.last_lit] = e >>> 8 & 255, t.pending_buf[t.d_buf + 2 * t.last_lit + 1] = 255 & e, t.pending_buf[t.l_buf + t.last_lit] = 255 & a, t.last_lit++, 0 === e ? t.dyn_ltree[2 * a]++ : (t.matches++, e--, t.dyn_ltree[2 * (st[a] + F + 1)]++, t.dyn_dtree[2 * n(e)]++), t.last_lit === t.lit_bufsize - 1
                            }
                            var j = 4,
                                U = 0,
                                D = 1,
                                H = 2,
                                I = 0,
                                L = 1,
                                O = 2,
                                P = 3,
                                T = 258,
                                q = 29,
                                F = 256,
                                G = F + 1 + q,
                                J = 30,
                                K = 19,
                                M = 2 * G + 1,
                                N = 15,
                                Q = 16,
                                R = 7,
                                V = 256,
                                W = 16,
                                X = 17,
                                Y = 18,
                                Z = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0],
                                $ = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13],
                                tt = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7],
                                et = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15],
                                at = 512,
                                nt = new Array(2 * (G + 2));
                            t(nt);
                            var rt = new Array(2 * J);
                            t(rt);
                            var it = new Array(at);
                            t(it);
                            var st = new Array(T - P + 1);
                            t(st);
                            var ht = new Array(q);
                            t(ht);
                            var _t = new Array(J);
                            t(_t);
                            var lt, ot, dt, ut = !1;
                            return {
                                _tr_init: B,
                                _tr_stored_block: A,
                                _tr_align: S,
                                _tr_flush_block: C,
                                _tr_tally: E
                            }
                        }(),
                        h = function() {
                            function t(t, e) {
                                return t.msg = a[e], e
                            }

                            function i(t) {
                                return (t << 1) - (t > 4 ? 9 : 0)
                            }

                            function h(t) {
                                for (var e = t.length; --e >= 0;) t[e] = 0
                            }

                            function _(t) {
                                var e = t.state,
                                    a = e.pending;
                                a > t.avail_out && (a = t.avail_out), 0 !== a && (r.arraySet(t.output, e.pending_buf, e.pending_out, a, t.next_out), t.next_out += a, e.pending_out += a, t.total_out += a, t.avail_out -= a, e.pending -= a, 0 === e.pending && (e.pending_out = 0))
                            }

                            function l(t, e) {
                                s._tr_flush_block(t, t.block_start >= 0 ? t.block_start : -1, t.strstart - t.block_start, e), t.block_start = t.strstart, _(t.strm)
                            }

                            function o(t, e) {
                                t.pending_buf[t.pending++] = e
                            }

                            function d(t, e) {
                                t.pending_buf[t.pending++] = e >>> 8 & 255, t.pending_buf[t.pending++] = 255 & e
                            }

                            function u(t, a, i, s) {
                                var h = t.avail_in;
                                return h > s && (h = s), 0 === h ? 0 : (t.avail_in -= h, r.arraySet(a, t.input, t.next_in, h, i), 1 === t.state.wrap ? t.adler = e(t.adler, a, h, i) : 2 === t.state.wrap && (t.adler = n(t.adler, a, h, i)), t.next_in += h, t.total_in += h, h)
                            }

                            function f(t, e) {
                                var a, n, r = t.max_chain_length,
                                    i = t.strstart,
                                    s = t.prev_length,
                                    h = t.nice_match,
                                    _ = t.strstart > t.w_size - rt ? t.strstart - (t.w_size - rt) : 0,
                                    l = t.window,
                                    o = t.w_mask,
                                    d = t.prev,
                                    u = t.strstart + nt,
                                    f = l[i + s - 1],
                                    c = l[i + s];
                                t.prev_length >= t.good_match && (r >>= 2), h > t.lookahead && (h = t.lookahead);
                                do
                                    if (a = e, l[a + s] === c && l[a + s - 1] === f && l[a] === l[i] && l[++a] === l[i + 1]) {
                                        i += 2, a++;
                                        do; while (l[++i] === l[++a] && l[++i] === l[++a] && l[++i] === l[++a] && l[++i] === l[++a] && l[++i] === l[++a] && l[++i] === l[++a] && l[++i] === l[++a] && l[++i] === l[++a] && i < u);
                                        if (n = nt - (u - i), i = u - nt, n > s) {
                                            if (t.match_start = e, s = n, n >= h) break;
                                            f = l[i + s - 1], c = l[i + s]
                                        }
                                    }
                                while ((e = d[e & o]) > _ && 0 !== --r);
                                return s <= t.lookahead ? s : t.lookahead
                            }

                            function c(t) {
                                var e, a, n, i, s, h = t.w_size;
                                do {
                                    if (i = t.window_size - t.lookahead - t.strstart, t.strstart >= h + (h - rt)) {
                                        r.arraySet(t.window, t.window, h, h, 0), t.match_start -= h, t.strstart -= h, t.block_start -= h, a = t.hash_size, e = a;
                                        do n = t.head[--e], t.head[e] = n >= h ? n - h : 0; while (--a);
                                        a = h, e = a;
                                        do n = t.prev[--e], t.prev[e] = n >= h ? n - h : 0; while (--a);
                                        i += h
                                    }
                                    if (0 === t.strm.avail_in) break;
                                    if (a = u(t.strm, t.window, t.strstart + t.lookahead, i), t.lookahead += a, t.lookahead + t.insert >= at)
                                        for (s = t.strstart - t.insert, t.ins_h = t.window[s], t.ins_h = (t.ins_h << t.hash_shift ^ t.window[s + 1]) & t.hash_mask; t.insert && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[s + at - 1]) & t.hash_mask, t.prev[s & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = s, s++, t.insert--, !(t.lookahead + t.insert < at)););
                                } while (t.lookahead < rt && 0 !== t.strm.avail_in)
                            }

                            function g(t, e) {
                                var a = 65535;
                                for (a > t.pending_buf_size - 5 && (a = t.pending_buf_size - 5);;) {
                                    if (t.lookahead <= 1) {
                                        if (c(t), 0 === t.lookahead && e === U) return ft;
                                        if (0 === t.lookahead) break
                                    }
                                    t.strstart += t.lookahead, t.lookahead = 0;
                                    var n = t.block_start + a;
                                    if ((0 === t.strstart || t.strstart >= n) && (t.lookahead = t.strstart - n, t.strstart = n, l(t, !1), 0 === t.strm.avail_out)) return ft;
                                    if (t.strstart - t.block_start >= t.w_size - rt && (l(t, !1), 0 === t.strm.avail_out)) return ft
                                }
                                return t.insert = 0, e === I ? (l(t, !0), 0 === t.strm.avail_out ? gt : pt) : t.strstart > t.block_start && (l(t, !1), 0 === t.strm.avail_out) ? ft : ft
                            }

                            function p(t, e) {
                                for (var a, n;;) {
                                    if (t.lookahead < rt) {
                                        if (c(t), t.lookahead < rt && e === U) return ft;
                                        if (0 === t.lookahead) break
                                    }
                                    if (a = 0, t.lookahead >= at && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + at - 1]) & t.hash_mask, a = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart), 0 !== a && t.strstart - a <= t.w_size - rt && (t.match_length = f(t, a)), t.match_length >= at)
                                        if (n = s._tr_tally(t, t.strstart - t.match_start, t.match_length - at), t.lookahead -= t.match_length, t.match_length <= t.max_lazy_match && t.lookahead >= at) {
                                            t.match_length--;
                                            do t.strstart++, t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + at - 1]) & t.hash_mask, a = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart; while (0 !== --t.match_length);
                                            t.strstart++
                                        } else t.strstart += t.match_length, t.match_length = 0, t.ins_h = t.window[t.strstart], t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + 1]) & t.hash_mask;
                                    else n = s._tr_tally(t, 0, t.window[t.strstart]), t.lookahead--, t.strstart++;
                                    if (n && (l(t, !1), 0 === t.strm.avail_out)) return ft
                                }
                                return t.insert = t.strstart < at - 1 ? t.strstart : at - 1, e === I ? (l(t, !0), 0 === t.strm.avail_out ? gt : pt) : t.last_lit && (l(t, !1), 0 === t.strm.avail_out) ? ft : ct
                            }

                            function b(t, e) {
                                for (var a, n, r;;) {
                                    if (t.lookahead < rt) {
                                        if (c(t), t.lookahead < rt && e === U) return ft;
                                        if (0 === t.lookahead) break
                                    }
                                    if (a = 0, t.lookahead >= at && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + at - 1]) & t.hash_mask, a = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart), t.prev_length = t.match_length, t.prev_match = t.match_start, t.match_length = at - 1, 0 !== a && t.prev_length < t.max_lazy_match && t.strstart - a <= t.w_size - rt && (t.match_length = f(t, a), t.match_length <= 5 && (t.strategy === J || t.match_length === at && t.strstart - t.match_start > 4096) && (t.match_length = at - 1)), t.prev_length >= at && t.match_length <= t.prev_length) {
                                        r = t.strstart + t.lookahead - at, n = s._tr_tally(t, t.strstart - 1 - t.prev_match, t.prev_length - at), t.lookahead -= t.prev_length - 1, t.prev_length -= 2;
                                        do ++t.strstart <= r && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + at - 1]) & t.hash_mask, a = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart); while (0 !== --t.prev_length);
                                        if (t.match_available = 0, t.match_length = at - 1, t.strstart++, n && (l(t, !1), 0 === t.strm.avail_out)) return ft
                                    } else if (t.match_available) {
                                        if (n = s._tr_tally(t, 0, t.window[t.strstart - 1]), n && l(t, !1), t.strstart++, t.lookahead--, 0 === t.strm.avail_out) return ft
                                    } else t.match_available = 1, t.strstart++, t.lookahead--
                                }
                                return t.match_available && (n = s._tr_tally(t, 0, t.window[t.strstart - 1]), t.match_available = 0), t.insert = t.strstart < at - 1 ? t.strstart : at - 1, e === I ? (l(t, !0), 0 === t.strm.avail_out ? gt : pt) : t.last_lit && (l(t, !1), 0 === t.strm.avail_out) ? ft : ct
                            }

                            function w(t, e) {
                                for (var a, n, r, i, h = t.window;;) {
                                    if (t.lookahead <= nt) {
                                        if (c(t), t.lookahead <= nt && e === U) return ft;
                                        if (0 === t.lookahead) break
                                    }
                                    if (t.match_length = 0, t.lookahead >= at && t.strstart > 0 && (r = t.strstart - 1, n = h[r], n === h[++r] && n === h[++r] && n === h[++r])) {
                                        i = t.strstart + nt;
                                        do; while (n === h[++r] && n === h[++r] && n === h[++r] && n === h[++r] && n === h[++r] && n === h[++r] && n === h[++r] && n === h[++r] && r < i);
                                        t.match_length = nt - (i - r), t.match_length > t.lookahead && (t.match_length = t.lookahead)
                                    }
                                    if (t.match_length >= at ? (a = s._tr_tally(t, 1, t.match_length - at), t.lookahead -= t.match_length, t.strstart += t.match_length, t.match_length = 0) : (a = s._tr_tally(t, 0, t.window[t.strstart]), t.lookahead--, t.strstart++), a && (l(t, !1), 0 === t.strm.avail_out)) return ft
                                }
                                return t.insert = 0, e === I ? (l(t, !0), 0 === t.strm.avail_out ? gt : pt) : t.last_lit && (l(t, !1), 0 === t.strm.avail_out) ? ft : ct
                            }

                            function v(t, e) {
                                for (var a;;) {
                                    if (0 === t.lookahead && (c(t), 0 === t.lookahead)) {
                                        if (e === U) return ft;
                                        break
                                    }
                                    if (t.match_length = 0, a = s._tr_tally(t, 0, t.window[t.strstart]), t.lookahead--, t.strstart++, a && (l(t, !1), 0 === t.strm.avail_out)) return ft
                                }
                                return t.insert = 0, e === I ? (l(t, !0), 0 === t.strm.avail_out ? gt : pt) : t.last_lit && (l(t, !1), 0 === t.strm.avail_out) ? ft : ct
                            }

                            function m(t, e, a, n, r) {
                                this.good_length = t, this.max_lazy = e, this.nice_length = a, this.max_chain = n, this.func = r
                            }

                            function k(t) {
                                t.window_size = 2 * t.w_size, h(t.head), t.max_lazy_match = j[t.level].max_lazy, t.good_match = j[t.level].good_length, t.nice_match = j[t.level].nice_length, t.max_chain_length = j[t.level].max_chain, t.strstart = 0, t.block_start = 0, t.lookahead = 0, t.insert = 0, t.match_length = t.prev_length = at - 1, t.match_available = 0, t.ins_h = 0
                            }

                            function y() {
                                this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = R, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new r.Buf16(2 * tt), this.dyn_dtree = new r.Buf16(2 * (2 * Z + 1)), this.bl_tree = new r.Buf16(2 * (2 * $ + 1)), h(this.dyn_ltree), h(this.dyn_dtree), h(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new r.Buf16(et + 1), this.heap = new r.Buf16(2 * Y + 1), h(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new r.Buf16(2 * Y + 1), h(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0
                            }

                            function z(e) {
                                var a;
                                return e && e.state ? (e.total_in = e.total_out = 0, e.data_type = Q, a = e.state, a.pending = 0, a.pending_out = 0, a.wrap < 0 && (a.wrap = -a.wrap), a.status = a.wrap ? st : dt, e.adler = 2 === a.wrap ? 0 : 1, a.last_flush = U, s._tr_init(a), O) : t(e, T)
                            }

                            function x(t) {
                                var e = z(t);
                                return e === O && k(t.state), e
                            }

                            function B(t, e) {
                                return t && t.state ? 2 !== t.state.wrap ? T : (t.state.gzhead = e, O) : T
                            }

                            function A(e, a, n, i, s, h) {
                                if (!e) return T;
                                var _ = 1;
                                if (a === G && (a = 6), i < 0 ? (_ = 0, i = -i) : i > 15 && (_ = 2, i -= 16), s < 1 || s > V || n !== R || i < 8 || i > 15 || a < 0 || a > 9 || h < 0 || h > N) return t(e, T);
                                8 === i && (i = 9);
                                var l = new y;
                                return e.state = l, l.strm = e, l.wrap = _, l.gzhead = null, l.w_bits = i, l.w_size = 1 << l.w_bits, l.w_mask = l.w_size - 1, l.hash_bits = s + 7, l.hash_size = 1 << l.hash_bits, l.hash_mask = l.hash_size - 1, l.hash_shift = ~~((l.hash_bits + at - 1) / at), l.window = new r.Buf8(2 * l.w_size), l.head = new r.Buf16(l.hash_size), l.prev = new r.Buf16(l.w_size), l.lit_bufsize = 1 << s + 6, l.pending_buf_size = 4 * l.lit_bufsize, l.pending_buf = new r.Buf8(l.pending_buf_size), l.d_buf = 1 * l.lit_bufsize, l.l_buf = 3 * l.lit_bufsize, l.level = a, l.strategy = h, l.method = n, x(e)
                            }

                            function S(e, a) {
                                var r, l, u, f;
                                if (!e || !e.state || a > L || a < 0) return e ? t(e, T) : T;
                                if (l = e.state, !e.output || !e.input && 0 !== e.avail_in || l.status === ut && a !== I) return t(e, 0 === e.avail_out ? F : T);
                                if (l.strm = e, r = l.last_flush, l.last_flush = a, l.status === st)
                                    if (2 === l.wrap) e.adler = 0, o(l, 31), o(l, 139), o(l, 8), l.gzhead ? (o(l, (l.gzhead.text ? 1 : 0) + (l.gzhead.hcrc ? 2 : 0) + (l.gzhead.extra ? 4 : 0) + (l.gzhead.name ? 8 : 0) + (l.gzhead.comment ? 16 : 0)), o(l, 255 & l.gzhead.time), o(l, l.gzhead.time >> 8 & 255), o(l, l.gzhead.time >> 16 & 255), o(l, l.gzhead.time >> 24 & 255), o(l, 9 === l.level ? 2 : l.strategy >= K || l.level < 2 ? 4 : 0), o(l, 255 & l.gzhead.os), l.gzhead.extra && l.gzhead.extra.length && (o(l, 255 & l.gzhead.extra.length), o(l, l.gzhead.extra.length >> 8 & 255)), l.gzhead.hcrc && (e.adler = n(e.adler, l.pending_buf, l.pending, 0)), l.gzindex = 0, l.status = ht) : (o(l, 0), o(l, 0), o(l, 0), o(l, 0), o(l, 0), o(l, 9 === l.level ? 2 : l.strategy >= K || l.level < 2 ? 4 : 0), o(l, bt), l.status = dt);
                                    else {
                                        var c = R + (l.w_bits - 8 << 4) << 8,
                                            g = -1;
                                        g = l.strategy >= K || l.level < 2 ? 0 : l.level < 6 ? 1 : 6 === l.level ? 2 : 3, c |= g << 6, 0 !== l.strstart && (c |= it), c += 31 - c % 31, l.status = dt, d(l, c), 0 !== l.strstart && (d(l, e.adler >>> 16), d(l, 65535 & e.adler)), e.adler = 1
                                    }
                                if (l.status === ht)
                                    if (l.gzhead.extra) {
                                        for (u = l.pending; l.gzindex < (65535 & l.gzhead.extra.length) && (l.pending !== l.pending_buf_size || (l.gzhead.hcrc && l.pending > u && (e.adler = n(e.adler, l.pending_buf, l.pending - u, u)), _(e), u = l.pending, l.pending !== l.pending_buf_size));) o(l, 255 & l.gzhead.extra[l.gzindex]), l.gzindex++;
                                        l.gzhead.hcrc && l.pending > u && (e.adler = n(e.adler, l.pending_buf, l.pending - u, u)), l.gzindex === l.gzhead.extra.length && (l.gzindex = 0, l.status = _t)
                                    } else l.status = _t;
                                if (l.status === _t)
                                    if (l.gzhead.name) {
                                        u = l.pending;
                                        do {
                                            if (l.pending === l.pending_buf_size && (l.gzhead.hcrc && l.pending > u && (e.adler = n(e.adler, l.pending_buf, l.pending - u, u)), _(e), u = l.pending, l.pending === l.pending_buf_size)) {
                                                f = 1;
                                                break
                                            }
                                            f = l.gzindex < l.gzhead.name.length ? 255 & l.gzhead.name.charCodeAt(l.gzindex++) : 0, o(l, f)
                                        } while (0 !== f);
                                        l.gzhead.hcrc && l.pending > u && (e.adler = n(e.adler, l.pending_buf, l.pending - u, u)), 0 === f && (l.gzindex = 0, l.status = lt)
                                    } else l.status = lt;
                                if (l.status === lt)
                                    if (l.gzhead.comment) {
                                        u = l.pending;
                                        do {
                                            if (l.pending === l.pending_buf_size && (l.gzhead.hcrc && l.pending > u && (e.adler = n(e.adler, l.pending_buf, l.pending - u, u)), _(e), u = l.pending, l.pending === l.pending_buf_size)) {
                                                f = 1;
                                                break
                                            }
                                            f = l.gzindex < l.gzhead.comment.length ? 255 & l.gzhead.comment.charCodeAt(l.gzindex++) : 0, o(l, f)
                                        } while (0 !== f);
                                        l.gzhead.hcrc && l.pending > u && (e.adler = n(e.adler, l.pending_buf, l.pending - u, u)), 0 === f && (l.status = ot)
                                    } else l.status = ot;
                                if (l.status === ot && (l.gzhead.hcrc ? (l.pending + 2 > l.pending_buf_size && _(e), l.pending + 2 <= l.pending_buf_size && (o(l, 255 & e.adler), o(l, e.adler >> 8 & 255), e.adler = 0, l.status = dt)) : l.status = dt), 0 !== l.pending) {
                                    if (_(e), 0 === e.avail_out) return l.last_flush = -1, O
                                } else if (0 === e.avail_in && i(a) <= i(r) && a !== I) return t(e, F);
                                if (l.status === ut && 0 !== e.avail_in) return t(e, F);
                                if (0 !== e.avail_in || 0 !== l.lookahead || a !== U && l.status !== ut) {
                                    var p = l.strategy === K ? v(l, a) : l.strategy === M ? w(l, a) : j[l.level].func(l, a);
                                    if (p !== gt && p !== pt || (l.status = ut), p === ft || p === gt) return 0 === e.avail_out && (l.last_flush = -1), O;
                                    if (p === ct && (a === D ? s._tr_align(l) : a !== L && (s._tr_stored_block(l, 0, 0, !1), a === H && (h(l.head), 0 === l.lookahead && (l.strstart = 0, l.block_start = 0, l.insert = 0))), _(e), 0 === e.avail_out)) return l.last_flush = -1, O
                                }
                                return a !== I ? O : l.wrap <= 0 ? P : (2 === l.wrap ? (o(l, 255 & e.adler), o(l, e.adler >> 8 & 255), o(l, e.adler >> 16 & 255), o(l, e.adler >> 24 & 255), o(l, 255 & e.total_in), o(l, e.total_in >> 8 & 255), o(l, e.total_in >> 16 & 255), o(l, e.total_in >> 24 & 255)) : (d(l, e.adler >>> 16), d(l, 65535 & e.adler)), _(e), l.wrap > 0 && (l.wrap = -l.wrap), 0 !== l.pending ? O : P)
                            }

                            function C(e) {
                                var a;
                                return e && e.state ? (a = e.state.status, a !== st && a !== ht && a !== _t && a !== lt && a !== ot && a !== dt && a !== ut ? t(e, T) : (e.state = null, a === dt ? t(e, q) : O)) : T
                            }

                            function E(t, a) {
                                var n, i, s, _, l, o, d, u, f = a.length;
                                if (!t || !t.state) return T;
                                if (n = t.state, _ = n.wrap, 2 === _ || 1 === _ && n.status !== st || n.lookahead) return T;
                                for (1 === _ && (t.adler = e(t.adler, a, f, 0)), n.wrap = 0, f >= n.w_size && (0 === _ && (h(n.head), n.strstart = 0, n.block_start = 0, n.insert = 0), u = new r.Buf8(n.w_size), r.arraySet(u, a, f - n.w_size, n.w_size, 0), a = u, f = n.w_size), l = t.avail_in, o = t.next_in, d = t.input, t.avail_in = f, t.next_in = 0, t.input = a, c(n); n.lookahead >= at;) {
                                    i = n.strstart, s = n.lookahead - (at - 1);
                                    do n.ins_h = (n.ins_h << n.hash_shift ^ n.window[i + at - 1]) & n.hash_mask, n.prev[i & n.w_mask] = n.head[n.ins_h], n.head[n.ins_h] = i, i++; while (--s);
                                    n.strstart = i, n.lookahead = at - 1, c(n)
                                }
                                return n.strstart += n.lookahead, n.block_start = n.strstart, n.insert = n.lookahead, n.lookahead = 0, n.match_length = n.prev_length = at - 1, n.match_available = 0, t.next_in = o, t.input = d, t.avail_in = l, n.wrap = _, O
                            }
                            var j, U = 0,
                                D = 1,
                                H = 3,
                                I = 4,
                                L = 5,
                                O = 0,
                                P = 1,
                                T = -2,
                                q = -3,
                                F = -5,
                                G = -1,
                                J = 1,
                                K = 2,
                                M = 3,
                                N = 4,
                                Q = 2,
                                R = 8,
                                V = 9,
                                W = 29,
                                X = 256,
                                Y = X + 1 + W,
                                Z = 30,
                                $ = 19,
                                tt = 2 * Y + 1,
                                et = 15,
                                at = 3,
                                nt = 258,
                                rt = nt + at + 1,
                                it = 32,
                                st = 42,
                                ht = 69,
                                _t = 73,
                                lt = 91,
                                ot = 103,
                                dt = 113,
                                ut = 666,
                                ft = 1,
                                ct = 2,
                                gt = 3,
                                pt = 4,
                                bt = 3;
                            return j = [new m(0, 0, 0, 0, g), new m(4, 4, 8, 4, p), new m(4, 5, 16, 8, p), new m(4, 6, 32, 32, p), new m(4, 4, 16, 16, b), new m(8, 16, 32, 32, b), new m(8, 16, 128, 128, b), new m(8, 32, 128, 256, b), new m(32, 128, 258, 1024, b), new m(32, 258, 258, 4096, b)], {
                                deflateInit2: A,
                                deflateSetHeader: B,
                                deflate: S,
                                deflateEnd: C,
                                deflateSetDictionary: E
                            }
                        }(),
                        _ = function() {
                            function e(n) {
                                if (!(this instanceof e)) return new e(n);
                                this.options = r.assign({
                                    level: c,
                                    method: p,
                                    chunkSize: 16384,
                                    windowBits: 15,
                                    memLevel: 8,
                                    strategy: g,
                                    to: ""
                                }, n || {});
                                var s = this.options;
                                s.raw && s.windowBits > 0 ? s.windowBits = -s.windowBits : s.gzip && s.windowBits > 0 && s.windowBits < 16 && (s.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new t, this.strm.avail_out = 0;
                                var l = h.deflateInit2(this.strm, s.level, s.method, s.windowBits, s.memLevel, s.strategy);
                                if (l !== d) throw new Error(a[l]);
                                if (s.header && h.deflateSetHeader(this.strm, s.header), s.dictionary) {
                                    var o;
                                    if (o = "string" == typeof s.dictionary ? i.string2buf(s.dictionary) : "[object ArrayBuffer]" === _.call(s.dictionary) ? new Uint8Array(s.dictionary) : s.dictionary, l = h.deflateSetDictionary(this.strm, o), l !== d) throw new Error(a[l]);
                                    this._dict_set = !0
                                }
                            }

                            function n(t, n) {
                                var r = new e(n);
                                if (r.push(t, !0), r.err) throw r.msg || a[r.err];
                                return r.result
                            }

                            function s(t, e) {
                                return e = e || {}, e.gzip = !0, n(t, e)
                            }
                            var _ = Object.prototype.toString,
                                l = 0,
                                o = 4,
                                d = 0,
                                u = 1,
                                f = 2,
                                c = -1,
                                g = 0,
                                p = 8;
                            return e.prototype.push = function(t, e) {
                                var a, n, s = this.strm,
                                    c = this.options.chunkSize;
                                if (this.ended) return !1;
                                n = e === ~~e ? e : e === !0 ? o : l, "string" == typeof t ? s.input = i.string2buf(t) : "[object ArrayBuffer]" === _.call(t) ? s.input = new Uint8Array(t) : s.input = t, s.next_in = 0, s.avail_in = s.input.length;
                                do {
                                    if (0 === s.avail_out && (s.output = new r.Buf8(c), s.next_out = 0, s.avail_out = c), a = h.deflate(s, n), a !== u && a !== d) return this.onEnd(a), this.ended = !0, !1;
                                    0 !== s.avail_out && (0 !== s.avail_in || n !== o && n !== f) || ("string" === this.options.to ? this.onData(i.buf2binstring(r.shrinkBuf(s.output, s.next_out))) : this.onData(r.shrinkBuf(s.output, s.next_out)))
                                } while ((s.avail_in > 0 || 0 === s.avail_out) && a !== u);
                                return n === o ? (a = h.deflateEnd(this.strm), this.onEnd(a), this.ended = !0, a === d) : n !== f || (this.onEnd(d), s.avail_out = 0, !0)
                            }, e.prototype.onData = function(t) {
                                this.chunks.push(t)
                            }, e.prototype.onEnd = function(t) {
                                t === d && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = r.flattenChunks(this.chunks)), this.chunks = [], this.err = t, this.msg = this.strm.msg
                            }, {
                                gzip: s
                            }
                        }();
                    return _
                }();
            }
            _733();
            this.start = function() {
                _38();
                _487(_654())
            };
            this.stop = _78;
            this.newPageView = _491;
            this.stopSession = _915;
            this.getSessionId = function() {
                return _13._62
            };
            this.getPageViewId = function() {
                return _13._46
            };
            this.tag = _87;
            this.star = _914;
            this.setVariable = _911;
            this.identify = _907;
            this.formSubmitAttempt = _906;
            this.formSubmitSuccess = _461;
            this.formSubmitFailure = _672;
            this.addFriction = function(_5, _22) {
                _210({
                    _5: _5,
                    _669: _22
                })
            };
            this.isRecording = function() {
                return _216
            };
            this.isReturningUser = function() {
                return _13._248
            };
            this.activateFeedback = _451;
            this.proxyAttachShadow = _360;
            this.recordingRate = _221;
            this.version = _252;
            this.lastUpdate = _900;
            this.isCreditCard = _254
        }

        function _646(_29, _4) {
            var _664 = [];

            function _162(_116) {
                if (!_4.domMutationDetectorEnable || !_116 || _116.nodeType !== 1) return false;
                var _64 = _29._71(_116);
                var _681 = _64 ? _64.id : undefined;
                var _691 = _116.previousSibling ? _116.previousSibling.id : undefined;
                var _923 = _116.tagName;
                var _687 = _116.attributes ? _116.attributes.id : undefined;
                var _685 = _116.attributes ? _116.attributes.class : undefined;
                var _17 = _923;
                if (_4.domMutationUseParentNode && _681) _17 += '_' + _681;
                if (_4.domMutationUsePreviousSibling && _691) _17 += '_' + _691;
                if (_687) _17 += '_' + _687;
                if (_685) _17 += '_' + _685.replace(/\s/g, "_");
                var _633 = +new Date();
                var _74 = _664[_17];
                var _448 = _74 ? _74._453 : 0;
                var _941 = _74 ? ((_633 - _74._938) / 1000) : 0;
                var _684 = _448 < _4.domMutationCountThreshold;
                var _683 = _941 < _4.domMutationTimeThresholdInSeconds;
                var _162 = _74 ? (_684 && _683) : false;
                if (!_684 || !_683) _448 = 0;
                _664[_17] = {
                    _938: _633,
                    _453: _448 + 1
                };
                return _162
            }
            this._162 = _162
        }

        function _819(_3, _4, _103, _10, _25, _189, _58) {
            var _54, _53, _8, _119;
            var _464 = 'mf_liveHeatmaps';
            var _39;
            var _279 = [];
            var _176;
            var _300 = false;

            function _38(_474, _273, _450, _290) {
                _53 = _474;
                _54 = _450;
                _8 = _273;
                _300 = window.location.search.indexOf('mf_legacy=1') !== -1 ? true : false;
                _8('Live heatmaps starting');
                _119 = _103._275();
                if (!_119) {
                    _8('Live heatmaps not initiated - could not create root HTML element');
                    return
                }
                if (!_3.opener) {
                    _8('Live heatmaps not initiated - window.opener is missing');
                    return
                }
                if (typeof _290 === 'function') {
                    _290(function() {
                        _341()
                    })
                } else {
                    _341()
                }
            }

            function _78() {
                _330()
            }

            function _341() {
                _25._40(_3, 'message', function(_35) {
                    if (_35.origin !== _54) return;
                    _458(_35.data);
                    switch (_35.data.message) {
                        case 'MouseflowLiveHeatmaps_Init_Received':
                            _3.clearInterval(_176);
                            break;
                        case 'MouseflowLiveHeatmaps_Init_Success':
                        case 'MouseflowLiveHeatmaps_Hello':
                            _936(_35.data.minDate, _35.data.filters, _35.data.filteredViews, _35.data.user, _35.data.websiteSettings.cssSelectorTracked);
                            _456(_35.data.scripts, function() {
                                var message;
                                if (_300) {
                                    message = {
                                        mfCommand: 'settings',
                                        value: {
                                            websiteSettings: _35.data.websiteSettings
                                        }
                                    }
                                } else {
                                    _732();
                                    message = {
                                        mfCommand: 'settings_liveheatmap',
                                        value: _39
                                    }
                                }
                                _477(JSON.stringify(message))
                            });
                            break;
                        case 'MouseflowLiveHeatmaps_StreamData_Chunk':
                            _285(_35.data.requestUrl, true)._476(_35.data.dataChunk);
                            break;
                        case 'MouseflowLiveHeatmaps_StreamData_Success':
                            _285(_35.data.requestUrl)._136();
                            break;
                        case 'MouseflowLiveHeatmaps_StreamData_Error':
                            _285(_35.data.requestUrl)._180();
                            break;
                        case 'MouseflowLiveHeatmaps_RequestData_Success':
                            _285(_35.data.requestUrl)._136(_35.data.responseText);
                            break;
                        case 'MouseflowLiveHeatmaps_RequestData_Error':
                            _285(_35.data.requestUrl)._180();
                            break
                    }
                });
                _176 = _3.setInterval(_634, 500);
                _3.setTimeout(function() {
                    _3.clearInterval(_176)
                }, 10000);
                _634()
            }

            function _634() {
                _291({
                    message: 'MouseflowLiveHeatmaps_Init',
                    websiteId: _53,
                    legacy: _300
                })
            }

            function _936(_934, _135, _932, _931, _193) {
                _39 = _652();
                var _277 = _661();
                var _305 = _4.location.search.match(/mf_liveHeatmaps=([^&]+)/);
                var _449 = typeof _3.name === 'string' && _3.name.indexOf('mf_liveHeatmaps') === 0 ? _3.name.slice(15).split('_') : [];
                var _935 = _305 || _449[1] === 'init';
                if (_39 && !_935) {
                    _39.filters.url = _277.url;
                    _94(_39);
                    return
                }
                _39 = {
                    isMinimized: false,
                    appUrlBase: _54,
                    websiteId: _53,
                    filters: _277,
                    minDate: _934,
                    filteredViews: _932,
                    user: _931,
                    cssSelectorTracked: _193
                };
                if (_135 && _135.view) {
                    _39.selectedFilteredView = _135.view;
                    delete _135.view
                }
                if (_135) {
                    Object.keys(_135).forEach(function(_17) {
                        var _5 = _135[_17];
                        if (_5 instanceof Date) _5 = _313(_5);
                        _39.filters[_17] = _5
                    })
                }
                if (_305 && _305[1] !== '1') _39.filters.maptype = _305[1];
                else if (_449[2]) _39.filters.maptype = _449[2];
                _94(_39);
                _3.name = 'mf_liveHeatmaps'
            }

            function _732() {
                _39.devices = _39.filters ? .device ? [_39.filters.device] : [];
                _39.mapType = _39.filters.maptype;
                _39.url = _189._238()
            }

            function _456(_178, _57) {
                if (!_178) return;
                var _186 = 0;

                function _282() {
                    if (_186 >= _178.length) {
                        _57();
                        return
                    }
                    var _106 = _178[_186];
                    _457(_106);
                    _186++;
                    var _144 = document.createElement('script');
                    if (_106.startsWith('/')) _144.src = _54 + _106;
                    else _144.src = _54 + '/' + _106;
                    _144.onload = _282;
                    _119.appendChild(_144)
                }
                _282()
            }

            function _652() {
                return _58._258(_464)
            }

            function _94(_39) {
                if (_8) _8('Live heatmaps saving settings');
                _58._257(_464, _39)
            }

            function _330() {
                if (_8) _8('Live heatmaps removing settings');
                _58._319(_464)
            }

            function _285(_18, _926) {
                var _467 = _279.filter(function(_928) {
                    return _928._18 === _18
                })[0];
                if (!_926 && _467) _279.splice(_279.indexOf(_467), 1);
                return _467
            }

            function _870(_16) {
                if (typeof _16 !== 'object') return;
                _39 = _652();
                var _277 = _661();
                Object.keys(_16).forEach(function(_17) {
                    var _5 = _16[_17];
                    if (_5 instanceof Date) _5 = _313(_5);
                    _39.filters[_17] = _5 || undefined
                });
                Object.keys(_277).forEach(function(_17) {
                    if (!_39.filters[_17]) _39.filters[_17] = _277[_17]
                });
                if (_39.filters.view) {
                    _39.selectedFilteredView = _39.filters.view;
                    delete _39.filters.view
                }
                _94(_39)
            }

            function _661() {
                var _217 = new Date();
                _217 = new Date(_217.getFullYear(), _217.getMonth(), _217.getDate());
                var _479 = new Date(_217);
                _479.setDate(_479.getDate() - 29);
                return {
                    maptype: 'click',
                    url: _189._238(),
                    fromdate: _313(_479),
                    todate: _313(_217)
                }
            }

            function _291(_12) {
                _3.opener.postMessage(_12, _54);
                _8('Sent ' + _12.message + (_12.requestUrl ? ', request URL: ' + _12.requestUrl : ''))
            }

            function _477(_12) {
                _3.postMessage(_12, _3.location.origin);
                _8('Sent ' + _12.message + (_12.requestUrl ? ', request URL: ' + _12.requestUrl : ''))
            }

            function _458(_12) {
                if (_12.message && _12.message.indexOf('MouseflowLiveHeatmaps_') === 0) _8('Received ' + _12.message + (_12.requestUrl ? ', request URL: ' + _12.requestUrl : ''))
            }

            function _457(_106) {
                _8('Live heatmaps loading script: ' + _106)
            }

            function _313(_100) {
                return _100.getFullYear() + '-' + _689(_100.getMonth() + 1, '00') + '-' + _689(_100.getDate(), '00')
            }

            function _689(_897, _705) {
                return (_705 + _897).slice(-_705.length)
            }
            this._38 = _38;
            this._78 = _78;
            this._716 = function(_16) {
                _870(_16);
                if (_300) {
                    _477('{"mfCommand":"MouseflowHeatmap_UpdateHeatmap"}')
                } else {
                    _732();
                    var message = {
                        mfCommand: 'settings_change',
                        value: {
                            settings: _39,
                            reloadData: _16 && _16.maptype ? false : true
                        }
                    };
                    _477(JSON.stringify(message))
                }
                _8('Sent postmessage updateheatmap')
            };
            _3.mouseflowHeatmap = {
                streamData: function(_18, _476, _136, _180) {
                    _279.push({
                        _18: _18,
                        _476: _476 || function() {},
                        _136: _136 || function() {},
                        _180: _180 || function() {}
                    });
                    _291({
                        message: 'MouseflowLiveHeatmaps_StreamData',
                        requestUrl: _18
                    })
                },
                getData: function(_18, _136, _180) {
                    _279.push({
                        _18: _18,
                        _136: _136 || function() {},
                        _180: _180 || function() {}
                    });
                    _291({
                        message: 'MouseflowLiveHeatmaps_RequestData',
                        requestUrl: _18
                    })
                }
            }
        }

        function _820(_3, _103, _29, _21, _10, _25, _58, _4) {
            var _11 = _3.document,
                _54, _53, _8, _15, _119, _23, _544, _525, _541, _158, _113, _324, _153, _536, _184, _293, _269, _146, _126, _137;

            function _38(_864, _474, _352, _353, _193, _273) {
                _54 = _864;
                _53 = _474;
                _8 = _273;
                _15 = _1021() || {
                    _134: false,
                    _95: 'exclude',
                    _76: _352 || [],
                    _72: _353 || [],
                    _93: _193 || []
                };
                _8('Starting privacy tool');
                _119 = _103._275();
                if (!_119) {
                    _8('Privacy tool not initiated - could not create root HTML element');
                    return
                }
                _863();
                _21._65(function() {
                    _862();
                    _94(_15)
                }, 1000);
            }

            function _78() {
                _872();
                _103._490()
            }

            function _863() {
                _25._40(_3, 'message', function(event) {
                    if (event.origin !== _54) return;
                    switch (event.data.message) {
                        case 'MouseflowPrivacyTool_Hello':
                            _8('Privacy tool API ready');
                            _269 = event.source;
                            if (event.data.cssSelectorBlacklist) {
                                _15._76 = event.data.cssSelectorBlacklist;
                                _15._72 = event.data.cssSelectorWhitelist;
                                _15._93 = event.data.cssSelectorTracked
                            }
                            _734();
                            break;
                        case 'MouseflowPrivacyTool_Save_Success':
                            _8('Successfully saved CSS lists');
                            if (_146) _146();
                            _146 = undefined;
                            _126 = undefined;
                            break;
                        case 'MouseflowPrivacyTool_Save_Failed':
                            _8('Failed saving CSS lists');
                            if (_126) _126();
                            _146 = undefined;
                            _126 = undefined;
                            _475('Uh oh! We couldn\'t save your changes.<br><br>' + 'Please refresh the page and try again.');
                            break;
                        case 'MouseflowPrivacyTool_Unauthorized':
                            _8('Privacy tool API logged out - cannot save');
                            if (_126) _126();
                            _146 = undefined;
                            _126 = undefined;
                            _475('Uh oh! We couldn\'t save your changes.<br><br>' + 'Please log into Mouseflow and try again.');
                            break
                    }
                });
                if (_3.opener) {
                    _8('Loading privacy tool API using window.opener');
                    _3.opener.postMessage({
                        message: 'MouseflowPrivacyTool_Hello'
                    }, _54)
                }
                _21._65(function() {
                    if (!_269) {
                        _8('Loading privacy tool API using iframe');
                        var _281 = _11.createElement('iframe');
                        _281.style.width = '0px';
                        _281.style.height = '0px';
                        _281.style.display = 'none';
                        _281.src = _54 + '/websites/' + _53 + '/privacytool';
                        _119.appendChild(_281);
                        _21._65(function() {
                            if (!_269) {
                                _8('Loading privacy tool API timed out');
                                _1017('We\'re having trouble loading the Privacy Tool on this page. Please try ' + 'refreshing the page or logging in to Mouseflow and reloading the Privacy Tool from there.<br><br>' + 'If you need help, please don\'t hesitate to reach out to us at:  <a class="green" href="mailto:support@mouseflow.com">support@mouseflow.com</a>')
                            }
                        }, 5000)
                    }
                }, 2000)
            }

            function _862() {
                _23 = _1013(_15);
                _544 = _23.querySelector('.tool-exclude output');
                _525 = _23.querySelector('.tool-whitelist output');
                _541 = _23.querySelector('.tool-track output');
                _158 = _23.querySelector('.tool-status-text');
                _113 = _23.querySelector('.btn-widget');
                _324 = _23.querySelector('.tool-loading h2');
                _15._76.forEach(_531);
                _15._72.forEach(_530);
                _15._93.forEach(_533);
                _119.appendChild(_23);
                _153 = _1009();
                _23.appendChild(_153);
                _10._259(_11.body, 'mf-privacy-tool-opened', !_15._134);
                _857();
                _734()
            }

            function _734() {
                if (_23 && _269) {
                    _10._51(_23, 'is-loading');
                    _122();
                    _855();
                    _299()
                }
            }

            function _485() {
                _330();
                _78();
                _3.close()
            }

            function _857() {
                _25._40(_23, 'click', '.mf-tool-close', _485, {
                    _105: true
                })
            }

            function _855() {
                _25._40(_23, 'click', '.mf-tool-toggle', _874, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-tool-close', _485, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-tool-exclude', _895, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-tool-whitelist', _894, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-tool-track', _893, {
                    _105: true
                });
                _25._40(_23, 'click', '.highlight-excluded', _892, {
                    _105: true
                });
                _25._40(_23, 'click', '.highlight-whitelisted', _891, {
                    _105: true
                });
                _25._40(_23, 'click', '.highlight-tracked', _889, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-remove-excluded', _888, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-remove-whitelisted', _887, {
                    _105: true
                });
                _25._40(_23, 'click', '.mf-remove-tracked', _886, {
                    _105: true
                });
                _25._40(_23, 'submit', _885, {
                    _105: true
                });
                _25._40(_11, 'mouseover', _884, {
                    _77: true
                });
                _25._40(_11, 'mouseleave', _882, {
                    _77: true
                });
                _25._40(_11, 'mouseup', _881, {
                    _77: true
                });
                _25._40(_11, 'mouseenter', _170, {
                    _77: true
                });
                _25._40(_11, 'mousemove', _170, {
                    _77: true
                });
                _25._40(_11, 'mousedown', _170, {
                    _77: true
                });
                _25._40(_11, 'click', _170, {
                    _77: true
                });
                _25._40(_11, 'mouseout', _170, {
                    _77: true
                });
                _25._40(_11, 'scroll', _122, {
                    _77: true,
                    _303: true
                });
                _25._40(_3, 'resize', _122, {
                    _77: true,
                    _303: true
                });
                var MutationObserver = _3.MutationObserver || _3.WebKitMutationObserver || _3.MozMutationObserver;
                if (MutationObserver) {
                    _293 = new MutationObserver(function(_711) {
                        var _851 = _711.some(function(_74) {
                            if (_74.target.nodeType !== 1 || _10._82(_74.target, '#mouseflow *')) return false;
                            var _854 = _74.oldValue && _74.oldValue.indexOf('mf-highlight') !== -1;
                            var _853 = _74.target.className && _74.target.className.indexOf('mf-highlight') !== -1;
                            var _852 = _854 || _853;
                            if (_74.type === 'attributes' && _74.attributeName === 'class' && _852) return false;
                            return true
                        });
                        if (_851) _122();
                        _711.forEach(function(_74) {
                            _74.addedNodes.forEach(function(_20) {
                                if (!_20.shadowRoot) return;
                                _293.observe(_20.shadowRoot, {
                                    childList: true,
                                    subtree: true
                                });
                                _299(_20)
                            })
                        })
                    });
                    _293.observe(_11, {
                        attributes: true,
                        childList: true,
                        characterData: true,
                        subtree: true,
                        attributeOldValue: true
                    })
                }
            }

            function _872() {
                _25._584();
                if (_293) _293.disconnect()
            }

            function _299(_64) {
                if (!_137) _137 = _1041();
                if (!_64) _64 = _11;
                for (var _44 = _29._203(_64); _44; _44 = _29._166(_44)) {
                    _299(_44);
                    var _107 = _44.shadowRoot;
                    if (!_107) continue;
                    _299(_107);
                    if (_107.adoptedStyleSheets) {
                        if (_107.adoptedStyleSheets.indexOf(_137) > -1) continue;
                        var _727 = Array.prototype.slice.call(_107.adoptedStyleSheets);
                        _727.push(_137);
                        _107.adoptedStyleSheets = _727
                    } else {
                        if (_107.querySelector('.mf-privacy-tool-style')) continue;
                        var _112 = _11.createElement('style');
                        _112.type = 'text/css';
                        _112.innerHTML = _466();
                        _112.className = 'mf-privacy-tool-style';
                        _107.appendChild(_112)
                    }
                }
            }

            function _874() {
                _15._134 = !_15._134;
                _94(_15);
                _10._259(_23, 'tool-closed', _15._134);
                _10._259(_11.body, 'mf-privacy-tool-opened', !_15._134);
                var _304 = _23.getElementsByClassName('step')[0];
                var _308 = _23.getElementsByClassName('tool-container')[0];
                if (_15._134) {
                    _10._51(_304, 'fade-out');
                    _10._70(_304, 'fade-in');
                    _10._51(_308, 'fade-in');
                    _10._70(_308, 'fade-out')
                } else {
                    _10._51(_304, 'fade-in');
                    _10._70(_304, 'fade-out');
                    _10._51(_308, 'fade-out');
                    _10._70(_308, 'fade-in')
                }
            }

            function _895() {
                _15._95 = 'exclude';
                _94(_15);
                _10._51(_23.getElementsByClassName('mf-tool-whitelist')[0], 'active');
                _10._51(_23.getElementsByClassName('tool-whitelist')[0], 'active');
                _10._51(_23.getElementsByClassName('mf-tool-track')[0], 'active');
                _10._51(_23.getElementsByClassName('tool-track')[0], 'active');
                _10._70(_23.getElementsByClassName('mf-tool-exclude')[0], 'active');
                _10._70(_23.getElementsByClassName('tool-exclude')[0], 'active')
            }

            function _894() {
                _15._95 = 'whitelist';
                _94(_15);
                _10._51(_23.getElementsByClassName('mf-tool-exclude')[0], 'active');
                _10._51(_23.getElementsByClassName('tool-exclude')[0], 'active');
                _10._51(_23.getElementsByClassName('mf-tool-track')[0], 'active');
                _10._51(_23.getElementsByClassName('tool-track')[0], 'active');
                _10._70(_23.getElementsByClassName('mf-tool-whitelist')[0], 'active');
                _10._70(_23.getElementsByClassName('tool-whitelist')[0], 'active')
            }

            function _893() {
                _15._95 = 'track';
                _94(_15);
                _10._51(_23.getElementsByClassName('mf-tool-exclude')[0], 'active');
                _10._51(_23.getElementsByClassName('tool-exclude')[0], 'active');
                _10._51(_23.getElementsByClassName('mf-tool-whitelist')[0], 'active');
                _10._51(_23.getElementsByClassName('tool-whitelist')[0], 'active');
                _10._70(_23.getElementsByClassName('mf-tool-track')[0], 'active');
                _10._70(_23.getElementsByClassName('tool-track')[0], 'active')
            }

            function _892(_7) {
                if (_15._95 === 'exclude') {
                    _630(_7.target.getAttribute('data-target'));
                    _122()
                }
            }

            function _891(_7) {
                if (_15._95 === 'whitelist') {
                    _528(_7.target.getAttribute('data-target'));
                    _122()
                }
            }

            function _889(_7) {
                if (_15._95 === 'track') {
                    _527(_7.target.getAttribute('data-target'));
                    _122()
                }
            }

            function _888(_7) {
                _630(_7.target.parentNode.getAttribute('data-target'));
                _122()
            }

            function _887(_7) {
                _528(_7.target.parentNode.getAttribute('data-target'));
                _122()
            }

            function _886(_7) {
                _527(_7.target.parentNode.getAttribute('data-target'));
                _122()
            }

            function _885() {
                _949();
                _879(_15._76, _15._72, _15._93, function() {
                    _545();
                    _113.innerHTML = 'Saved';
                    _330();
                    _21._65(_485, 500)
                }, function() {
                    _545()
                })
            }

            function _884(_7) {
                _21._132(_536);
                var _626 = _11.getElementsByClassName('mf-highlight');
                for (var _2 = 0; _2 < _626.length; _2++) {
                    _10._51(_626[_2], 'mf-highlight')
                }
                _10._70(_153, 'hidden');
                if (_170(_7) || _540(_7.target)) return;
                _10._70(_7.target, 'mf-highlight');
                _536 = _21._65(function() {
                    var _48 = _7.target.getBoundingClientRect();
                    _153.style.left = _48.left + _3.pageXOffset + 'px';
                    _153.style.top = _48.top + _3.pageYOffset + 'px';
                    _153.style.width = _48.width + 'px';
                    _153.style.height = _48.height + 'px';
                    _10._51(_153, 'hidden')
                }, 75)
            }

            function _882(_7) {
                if (_170(_7)) return;
                if (_7.target === _11) {
                    _10._70(_153, 'hidden')
                }
            }

            function _881(_7) {
                if (_170(_7)) return;
                if (_7.button !== 0 || _540(_7.target)) return;
                _10._51(_7.target, 'mf-highlight');
                var _9 = _877(_7.target);
                if (_15._95 === 'exclude') {
                    _531(_9)
                } else if (_15._95 === 'whitelist') {
                    _530(_9)
                } else {
                    _533(_9)
                }
                _122()
            }

            function _170(_7) {
                if (_15._134 || _7.target.nodeType !== 1 || _10._82(_7.target, '#mouseflow *')) return true;
                _7.preventDefault();
                _7.stopPropagation();
                return false
            }

            function _540(_1) {
                return _1 === _11.body || _10._82(_1, 'html') || (_15._95 === 'whitelist' && (!/INPUT|TEXTAREA/.test(_1.tagName) || /checkbox|radio|button|submit/.test(_1.type)))
            }

            function _533(_9) {
                if (_9 && _15._93.indexOf(_9) === -1) {
                    _15._93.unshift(_9);
                    _94(_15)
                }
                _212()
            }

            function _531(_9) {
                if (_9 && _15._76.indexOf(_9) === -1) {
                    _15._76.unshift(_9);
                    _94(_15)
                }
                _212()
            }

            function _530(_9) {
                if (_9 && _15._72.indexOf(_9) === -1) {
                    _15._72.unshift(_9);
                    _94(_15)
                }
                _212()
            }

            function _630(_9) {
                if (_9 && _15._76.indexOf(_9) !== -1) {
                    _15._76 = _15._76.filter(function(_85) {
                        return _85 !== _9
                    });
                    _94(_15)
                }
                _212()
            }

            function _528(_9) {
                if (_9 && _15._72.indexOf(_9) !== -1) {
                    _15._72 = _15._72.filter(function(_85) {
                        return _85 !== _9
                    });
                    _94(_15)
                }
                _212()
            }

            function _527(_9) {
                if (_9 && _15._93.indexOf(_9) !== -1) {
                    _15._93 = _15._93.filter(function(_85) {
                        return _85 !== _9
                    });
                    _94(_15)
                }
                _212()
            }

            function _122() {
                _21._132(_184);
                if (!_184) {
                    _21._65(function() {
                        if (_184) {
                            _21._132(_184);
                            _532();
                            _184 = undefined
                        }
                    }, 200)
                }
                _184 = _21._65(function() {
                    _532();
                    _184 = undefined
                }, 100)
            }

            function _532() {
                var _542 = _23.querySelectorAll('.highlight-excluded,.highlight-whitelisted,.highlight-tracked'),
                    _2;
                for (_2 = 0; _2 < _542.length; _2++) {
                    _23.removeChild(_542[_2])
                }
                _15._76.forEach(function(_9) {
                    var _63 = _173(_9, _11);
                    for (_2 = 0; _2 < _63.length; _2++) {
                        _23.appendChild(_1008(_9, _63[_2].getBoundingClientRect()))
                    }
                });
                _15._72.forEach(function(_9) {
                    var _63 = _173(_9, _11);
                    for (_2 = 0; _2 < _63.length; _2++) {
                        _23.appendChild(_1007(_9, _63[_2].getBoundingClientRect()))
                    }
                });
                _15._93.forEach(function(_9) {
                    var _63 = _173(_9, _11);
                    for (_2 = 0; _2 < _63.length; _2++) {
                        _23.appendChild(_1006(_9, _63[_2].getBoundingClientRect()))
                    }
                })
            }

            function _173(_9, _31) {
                try {
                    var _63 = [];
                    _9.split(',').forEach(function(_9) {
                        var _45 = _9.split(' > :document-fragment: > ', 1);
                        _31.querySelectorAll(_45[0]).forEach(function(_1) {
                            if (_45[1] && _1.shadowRoot) {
                                _173(_45[1], _1.shadowRoot).forEach(function(_1) {
                                    _63.push(_1)
                                })
                            } else {
                                _63.push(_1)
                            }
                        })
                    });
                    return _63
                } catch (_55) {
                    _8('Could not get element from selector: ' + ex.message)
                }
            }

            function _879(_76, _72, _93, _136, _878) {
                if (_146) {
                    _8('Attempted to save CSS lists while previous save was in progress');
                    return
                }
                _146 = _136;
                _126 = _878;
                _1015();
                _269.postMessage({
                    message: 'MouseflowPrivacyTool_Save',
                    blacklist: _76,
                    whitelist: _72,
                    tracked: _93
                }, _54);
                _21._65(function() {
                    if (_146 === _136) {
                        _8('Saving CSS lists timed out');
                        if (_126) _126();
                        _146 = undefined;
                        _126 = undefined;
                        _475('Uh oh! We couldn\'t save your changes.<br><br>' + 'Please log into Mouseflow and try again.')
                    }
                }, 7500)
            }

            function _877(_1) {
                if (_1 == null) return null;
                try {
                    var _41 = [];
                    while (_1) {
                        var _31 = _1.getRootNode ? _1.getRootNode() : _11;
                        var _9 = _555(_1, _31);
                        _41.unshift(_9);
                        _1 = _31.host
                    }
                    return _41.join(' > :document-fragment: > ')
                } catch (ex) {
                    _8('Could not get element selector: ' + ex.message);
                    return null
                }
            }

            function _1047(_1, _31) {
                var _266 = _875(_1, _31);
                if (!_266) return null;
                if (_10._82(_1, _266)) return _266;
                var _103 = _31.querySelector(_266);
                var _127 = _1;
                var _45 = [];
                while (_127 && _127 !== _103) {
                    var _34 = _471(_127, _31);
                    if (_34.length === 0) _34.push(_558(_127));
                    _45.unshift(_34);
                    _127 = _127.parentNode
                }
                _45.unshift(_266);
                return _469(_45, _31)
            }

            function _555(_1, _31, _45) {
                if (!_45) _45 = [];
                var _34 = _471(_1, _31);
                _45.unshift(_34);
                var _9 = _469(_45, _31);
                if (_9) return _9;
                if (_34.length === 0) {
                    _34.push(_558(_1));
                    _9 = _469(_45, _31);
                    if (_9) return _9
                }
                return _555(_1.parentNode, _31, _45)
            }

            function _469(_45, _31) {
                var _470 = _45.length > 1 ? _948.apply(this, _45) : _45[0];
                for (var _2 = 0; _2 < _470.length; _2++) {
                    if (_31.querySelectorAll(_470[_2]).length === 1) return _470[_2]
                }
                return null
            }

            function _875(_1, _31) {
                var _127 = _1;
                while (_127) {
                    var _34 = _471(_127, _31);
                    for (var _2 = 0; _2 < _34.length; _2++) {
                        if (_31.querySelectorAll(_34[_2]).length === 1) return _34[_2]
                    }
                    _127 = _127.parentNode
                }
                return null
            }

            function _471(_1, _31) {
                if (_1 === _11.body) return ['body'];
                var _34 = [];
                var _64 = _1.parentNode;
                var _2;
                var _41 = _1.getAttribute('id');
                var _9 = '#' + _10._171(_41);
                if (_41 && _31.querySelectorAll(_9).length === 1 && !_10._174(_1, 'data-mf-ignore-child-ids') && _4.useIdSelectors) return [_9];
                var _22 = _1.getAttribute('name');
                _9 = '[name="' + _10._171(_22) + '"]';
                if (_22) {
                    if (_31.querySelectorAll(_9).length === 1) return [_9];
                    if (_64.querySelectorAll(_9).length === 1) _34.push(_9)
                }
                var _101 = _10._194(_1);
                for (_2 = 0; _2 < _101.length; _2++) {
                    _9 = '.' + _10._171(_101[_2]);
                    if (_31.querySelectorAll(_9).length === 1) return [_9];
                    if (_64.querySelectorAll(_9).length === 1) _34.push(_9)
                }
                for (_2 = 0; _2 < _101.length; _2++) {
                    _9 = _10._171(_1.tagName.toLowerCase()) + '.' + _10._171(_101[_2]);
                    if (_31.querySelectorAll(_9).length === 1) return [_9];
                    if (_64.querySelectorAll(_9).length === 1) _34.push(_9)
                }
                return _34
            }

            function _558(_1) {
                var _9 = _10._171(_1.tagName.toLowerCase());
                if (_1.parentNode.querySelectorAll(_9).length === 1) return _9;
                var _220 = 0;
                var _358 = _1;
                while (_358) {
                    if (_358.tagName === _1.tagName) _220++;
                    _358 = _358.previousElementSibling
                }
                _9 += ':nth-of-type(' + _220 + ')';
                return _9
            }

            function _948() {
                var _34, _227, _218, _2;
                var _129 = 0;
                var _175 = arguments.length - 1;
                var _359 = false;
                var _245 = true;
                while (_129 < _175) {
                    _227 = undefined;
                    for (_2 = 0; _2 <= _129; _2++) {
                        _227 = _227 ? _345(_227, arguments[_2], ' > ') : arguments[_2]
                    }
                    _218 = undefined;
                    for (_2 = arguments.length - 1; _2 >= _175; _2--) {
                        _218 = _218 ? _345(arguments[_2], _218, ' > ') : arguments[_2]
                    }
                    var _354 = (_129 + 1) == _175 ? ' > ' : ' ';
                    _34 = _34 ? _34.concat(_345(_227, _218, _354)) : _345(_227, _218, _354);
                    if (_245 && _359) {
                        _175--;
                        _359 = false;
                        _245 = true
                    } else if (_245) {
                        _175--;
                        _359 = true;
                        _245 = false
                    } else {
                        _129++;
                        if (_129 != _175) _175++;
                        _359 = true;
                        _245 = true
                    }
                }
                return _34
            }

            function _345(_549, _548, _354) {
                var _34 = [];
                for (var _2 = 0; _2 < _549.length; _2++) {
                    for (var _130 = 0; _130 < _548.length; _130++) {
                        _34.push(_549[_2] + _354 + _548[_130])
                    }
                }
                return _34
            }

            function _1021() {
                return _58._258('mf_privacyTool') || null
            }

            function _94(_39) {
                _58._257('mf_privacyTool', _39)
            }

            function _330() {
                _58._319('mf_privacyTool')
            }

            function _949() {
                _113.setAttribute('disabled', '');
                _113.setAttribute('original-html', _113.innerHTML);
                _113.innerHTML = '<i>&bull;</i> <i>&bull;</i> <i>&bull;</i> <i>&bull;</i>';
                _10._70(_113, 'loading')
            }

            function _545() {
                _10._51(_113, 'loading');
                _113.innerHTML = _113.getAttribute('original-html');
                _113.removeAttribute('original-html');
                _113.removeAttribute('disabled')
            }

            function _212() {
                _544.innerHTML = _1002(_15._76);
                _525.innerHTML = _1001(_15._72);
                _541.innerHTML = _1020(_15._93);
                _158.innerHTML = _480(_15._76, _15._72, _15._93);
                _10._51(_158, 'red')
            }

            function _1017(_182) {
                if (!_324) return;
                _324.innerHTML = _182;
                _10._70(_324, 'red')
            }

            function _475(_182) {
                if (!_158) return;
                _158.innerHTML = _182;
                _10._70(_158, 'red')
            }

            function _1015() {
                if (!_158) return;
                _158.innerHTML = _480(_15._76, _15._72, _15._93);
                _10._51(_158, 'red')
            }

            function _1013(_15) {
                var _32 = _11.createElement('div');
                _32.className = 'privacy-tool is-loading';
                _32.innerHTML = _1005(_15);
                if (_15._134) _32.className += ' tool-closed';
                var _112 = _11.createElement('style');
                _112.type = 'text/css';
                _112.innerHTML = _466();
                _32.appendChild(_112);
                return _32
            }

            function _1009() {
                var _32 = _11.createElement('div');
                _32.className = 'highlight-box';
                return _32
            }

            function _1008(_9, _48) {
                var _32 = _11.createElement('div');
                _32.className = 'highlight-box highlight-excluded';
                _32.setAttribute('data-target', _9);
                _32.style.left = _48.left + _3.pageXOffset + 'px';
                _32.style.top = _48.top + _3.pageYOffset + 'px';
                _32.style.width = _48.width + 'px';
                _32.style.height = _48.height + 'px';
                return _32
            }

            function _1007(_9, _48) {
                var _32 = _11.createElement('div');
                _32.className = 'highlight-box highlight-whitelisted';
                _32.setAttribute('data-target', _9);
                _32.style.left = _48.left + _3.pageXOffset + 'px';
                _32.style.top = _48.top + _3.pageYOffset + 'px';
                _32.style.width = _48.width + 'px';
                _32.style.height = _48.height + 'px';
                return _32
            }

            function _1006(_9, _48) {
                var _32 = _11.createElement('div');
                _32.className = 'highlight-box highlight-tracked';
                _32.setAttribute('data-target', _9);
                _32.style.left = _48.left + _3.pageXOffset + 'px';
                _32.style.top = _48.top + _3.pageYOffset + 'px';
                _32.style.width = _48.width + 'px';
                _32.style.height = _48.height + 'px';
                return _32
            }

            function _1005(_15) {
                return ('<form action="#" id="mf_privacy_tool">' + '<link rel="stylesheet" href="https://use.typekit.net/eum4oaj.css" integrity="sha512-Kf9N7GyqTToDCLsU3mY5/S89bDwQub88vOG9wLAKvk89imOPLp+6gyjkeDdDXARvHuyUJrzAWYhvdJnzOOmSEQ==" crossorigin="anonymous">' + _1004(_15) + _1003(_15) + '</form>')
            }

            function _1004(_15) {
                return ('<div class="step step-block' + (_15._134 ? ' fade-in' : '') + '">' + '<div class="widget-header">' + '<div class="widget-text">Open privacy tool</div>' + '<div class="widget-toggle">' + '<a href="#" class="btn-arrow btn-arrow--up mf-tool-toggle"></a>' + '</div>' + '</div>' + '</div>')
            }

            function _1003() {
                return ('<div class="tool-container' + (_15._134 ? '' : ' fade-in') + '">' + '<div class="tool-header">' + '<svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 168.56 32" class=""><defs></defs><g data-name="Layer 2"><g data-name="Layer 1"><path class="logo-path" d="M35.31,16c0-2.75-2.2-5.18-5.77-6.86.33-3.92-.67-7-3.06-8.43S20.88,0,17.65,2.28l-.31-.21C14.09-.1,11.07-.58,8.83.71S5.44,5.22,5.77,9.14C2.21,10.82,0,13.25,0,16s2.21,5.19,5.78,6.87a2.43,2.43,0,0,0,0,.38c-.26,3.89.84,6.75,3.08,8a5.4,5.4,0,0,0,2.75.71,11,11,0,0,0,6.08-2.28A11,11,0,0,0,23.73,32a5.37,5.37,0,0,0,2.75-.71c2.25-1.29,3.34-4.15,3.09-8l0-.38C33.1,21.19,35.31,18.76,35.31,16ZM23.75,1.94a3.49,3.49,0,0,1,1.77.44c1.48.85,2.27,3,2.14,6a27.56,27.56,0,0,0-4.91-1.2,27.61,27.61,0,0,0-3.49-3.64A8.7,8.7,0,0,1,23.75,1.94ZM7.86,10.36a24,24,0,0,1,3-.9c-.41.62-.82,1.27-1.2,1.94s-.76,1.36-1.09,2A22.4,22.4,0,0,1,7.86,10.36ZM21.71,23a32.55,32.55,0,0,1-4.05.24A32.6,32.6,0,0,1,13.6,23c-.95-.12-1.85-.28-2.7-.47a22.61,22.61,0,0,1-3-.91,23.19,23.19,0,0,1,.73-3.08c.26-.85.58-1.71.94-2.57a33.42,33.42,0,0,1,1.81-3.65A31.45,31.45,0,0,1,13.59,9a26.92,26.92,0,0,1,1.76-2.11,23.13,23.13,0,0,1,2.3-2.18A22.26,22.26,0,0,1,20,6.87c.61.66,1.2,1.36,1.77,2.11A33,33,0,0,1,24,12.36,33.42,33.42,0,0,1,25.77,16c.36.86.68,1.72.94,2.57a21.79,21.79,0,0,1,.74,3.08,23.22,23.22,0,0,1-3,.91C23.56,22.76,22.66,22.92,21.71,23Zm-4.05,2.17c.78,0,1.55,0,2.3-.08a22,22,0,0,1-2.3,2.18,21.08,21.08,0,0,1-2.31-2.18C16.1,25.18,16.87,25.21,17.66,25.21Zm9.05-11.77q-.5-1-1.08-2c-.39-.67-.79-1.31-1.21-1.94a24,24,0,0,1,3,.9A22.4,22.4,0,0,1,26.71,13.44ZM9.79,2.38a3.53,3.53,0,0,1,1.8-.44,8.61,8.61,0,0,1,4.46,1.59,27.07,27.07,0,0,0-3.49,3.64A26.32,26.32,0,0,0,7.65,8.38C7.52,5.42,8.31,3.23,9.79,2.38ZM1.93,16c0-1.84,1.57-3.55,4.12-4.85A26.55,26.55,0,0,0,7.46,16a26.91,26.91,0,0,0-1.41,4.85C3.43,19.49,1.93,17.72,1.93,16Zm9.64,14.06a3.55,3.55,0,0,1-1.78-.43c-1.51-.87-2.28-3.05-2.13-6a26.22,26.22,0,0,0,4.9,1.2,27.17,27.17,0,0,0,3.49,3.65A8.68,8.68,0,0,1,11.57,30.06Zm14-.43c-1.48.85-3.76.44-6.26-1.15a26.56,26.56,0,0,0,3.49-3.65,26.33,26.33,0,0,0,4.91-1.2C27.8,26.58,27,28.76,25.52,29.63Zm3.74-8.77A27.14,27.14,0,0,0,27.85,16a26.55,26.55,0,0,0,1.41-4.86c2.55,1.3,4.13,3,4.13,4.85S31.89,19.49,29.26,20.86Z"></path><path class="logo-path" d="M17.66,10.22a28,28,0,0,0-4.78,10l4.78-2.61,4.78,2.61a29,29,0,0,0-2-5.32A29,29,0,0,0,17.66,10.22Z"></path><path class="logo-path" d="M22.44,20.19l-4.78-2.61-4.78,2.61a28,28,0,0,1,4.78-10,29,29,0,0,1,2.81,4.65A29,29,0,0,1,22.44,20.19Z"></path><path class="logo-path" d="M47.62,22.09V9.91H50l.36,1.53a7.07,7.07,0,0,1,4.17-1.53,3.45,3.45,0,0,1,3.26,1.67,7.58,7.58,0,0,1,4.37-1.67Q66,9.91,66,14.54v7.55H62.94V14.42c0-1.35-.57-2-1.72-2A4.14,4.14,0,0,0,58.36,14v8.12H55.28V14.46c0-1.38-.57-2.07-1.69-2.07A4,4,0,0,0,50.69,14v8.12Z"></path><path class="logo-path" d="M67.93,16q0-6.21,6.15-6.21T80.23,16q0,6.2-6.15,6.2T67.93,16Zm6.15,3.77q3.08,0,3.08-3.82t-3.08-3.72Q71,12.23,71,16T74.08,19.77Z"></path><path class="logo-path" d="M93.58,9.91V22.09H91.17l-.37-1.55a7.65,7.65,0,0,1-4.45,1.55q-4.21,0-4.21-4.53V9.91h3.08v7.68a1.78,1.78,0,0,0,2,2,4.91,4.91,0,0,0,3.28-1.54V9.91Z"></path><path class="logo-path" d="M96.79,21.51V19a12.63,12.63,0,0,0,4.69.81c1.33,0,2-.42,2-1.27s-.45-1.17-1.34-1.17h-2.2c-2.48,0-3.72-1.23-3.72-3.71S98,9.79,101.63,9.79a13.06,13.06,0,0,1,4.33.7V13a11.77,11.77,0,0,0-4.41-.81c-1.66,0-2.49.42-2.49,1.27s.48,1.17,1.45,1.17h2c2.71,0,4.07,1.23,4.07,3.71s-1.73,3.83-5.18,3.83A13.94,13.94,0,0,1,96.79,21.51Z"></path><path class="logo-path" d="M119.58,17.2h-8q0,2.46,4,2.46a20,20,0,0,0,3.69-.35v2.44a20.57,20.57,0,0,1-4.16.34q-6.62,0-6.62-6.23,0-6,6.07-5.95T119.58,17.2Zm-8-2.26h5.09c.1-1.75-.71-2.62-2.44-2.62S111.74,13.19,111.6,14.94Z"></path><path class="logo-path" d="M122.2,22.15V9.31q0-4.43,5.48-4.42a7.84,7.84,0,0,1,2.72.46V7.79a7.29,7.29,0,0,0-2.73-.46c-1.6,0-2.39.86-2.39,2.58h3.65v2.43h-3.65v9.77Z"></path><path class="logo-path" d="M135.07,5.49v16.6H132V5.49Z"></path><path class="logo-path" d="M137.25,16q0-6.21,6.16-6.21T149.56,16q0,6.2-6.15,6.2T137.25,16Zm6.16,3.77q3.08,0,3.07-3.82t-3.07-3.72c-2.06,0-3.08,1.24-3.08,3.72S141.35,19.77,143.41,19.77Z"></path><path class="logo-path" d="M150.58,9.91h3.1l1.81,8.25,2.71-8.25h2.63l2.93,8.25,1.6-8.25h3.2l-3.29,12.18h-2.89l-2.87-8.41-2.9,8.41h-2.94Z"></path></g></g></svg>' + '<div class="tool-toggle">' + '<div class="tool-toggle-text">' + 'Hide to navigate' + '</div>' + '<div class="tool-toggle-icon">' + '<a href="#" class="btn-arrow btn-arrow--down mf-tool-toggle"></a>' + '</div>' + '</div>' + '<div class="tool-close">' + '<div class="tool-toggle-text">' + 'Close' + '</div>' + '<div class="tool-toggle-icon">' + '<a href="#" class="btn-cross mf-tool-close"></a>' + '</div>' + '</div>' + '</div>' + '<div class="tool-content">' + '<ul class="tool-menu">' + '<li class="tool-menu-item mf-tool-exclude' + (_15._95 === 'exclude' ? ' active' : '') + '">' + 'Excluded content' + '</li>' + '<li class="tool-menu-item mf-tool-whitelist' + (_15._95 === 'whitelist' ? ' active' : '') + '">' + 'Whitelisted fields' + '</li>' + '<li class="tool-menu-item mf-tool-track' + (_15._95 === 'track' ? ' active' : '') + '">' + 'Tracked elements' + '</li>' + '</ul>' + '<div class="tool-exclude' + (_15._95 === 'exclude' ? ' active' : '') + '">' + '<h2>Exclude content from appearing in Mouseflow</h2>' + '<p>' + 'To get started, just click the element(s) or content you wish to exclude. ' + 'This will add the necessary CSS selectors to be blocked in the list below.' + '</p>' + '<p>' + 'When you\'re finished, click "Hide to navigate" to browse to another page to exclude additional content, or click "Save and close" to keep your changes.' + '</p>' + '<p>' + 'For more details and best practices, read our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a>.' + '</p>' + '<h3>Excluded content</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-whitelist' + (_15._95 === 'whitelist' ? ' active' : '') + '">' + '<h2>Whitelist input fields</h2>' + '<p>' + 'You can whitelist any input field or text area, simply by clicking the field(s) on the page. ' + 'This will let Mouseflow record input in that field.' + '</p>' + '<p>' + 'When you\'re finished, click "Hide to navigate" to browse to another page to exclude additional content, or click "Save and close" to keep your changes.' + '</p>' + '<p>' + 'For more details and best practices, read our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a>.' + '</p>' + '<h3>Whitelisted fields</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-track' + (_15._95 === 'track' ? ' active' : '') + '">' + '<h2>Tracked elements</h2>' + '<p>' + 'When viewing a heatmap, most of your links will include a box that shows additional metrics(clicks, hovers, etc.).In some cases, these boxes will not appear.' + '</p>' + '<p>' + 'If you\'ve found such an element, you can select it here. That will ensure the additional metrics are shown in your heatmaps.' + '</p>' + '<p>' + 'When you\'re finished, click "Hide to navigate" to browse to another page to exclude additional content, or click "Save and close" to keep your changes.' + '</p>' + '<p>' + 'For more details and best practices, read our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a>.' + '</p>' + '<h3>Tracked elements</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-status">' + '<div class="tool-status-text">' + _480(_15._76, _15._72, _15._93) + '</div>' + '<div class="tool-status-buttons">' + '<button type="submit" class="btn-widget">Save and close</button>' + '<a href="#" class="green bold mf-tool-close">Close Privacy Tool</a>' + '</div>' + '</div>' + '<div class="tool-loading">' + '<h2 class="loading">Loading the Privacy Tool<i>.</i><i>.</i><i>.</i></h2>' + '</div>' + '<div class="tool-message">' + '<h3>Browser window is to small to load the Privacy Tool</h3>' + '<p>To use Mouseflow\'s Privacy Tool, you need to view the page in a larger browser window.</p>' + '</div>' + '</div>' + '</div>')
            }

            function _1002(_45) {
                return _45.map(function(_9) {
                    return ('<div class="tm-tag" data-target="' + _10._172(_9) + '">' + _10._172(_9) + '<a href="#" class="btn-cross mf-remove-excluded"></a>' + '</div>')
                }).join('')
            }

            function _1001(_45) {
                return _45.map(function(_9) {
                    return ('<div class="tm-tag" data-target="' + _10._172(_9) + '">' + _10._172(_9) + '<a href="#" class="btn-cross mf-remove-whitelisted"></a>' + '</div>')
                }).join('')
            }

            function _1020(_45) {
                return _45.map(function(_9) {
                    return ('<div class="tm-tag" data-target="' + _10._172(_9) + '">' + _10._172(_9) + '<a href="#" class="btn-cross mf-remove-tracked"></a>' + '</div>')
                }).join('')
            }

            function _480(_76, _72, _561) {
                return '<p>You have:</p>' + '<p>' + '&nbsp;&bull; excluded <i class="emphasis"> ' + _76.length + '</i> ' + (_76.length === 1 ? 'element' : 'elements') + '<br>' + '&nbsp;&bull; whitelisted <i class="emphasis">' + _72.length + '</i> input ' + (_72.length === 1 ? 'field' : 'fields') + '<br>' + '&nbsp;&bull; tracked <i class="emphasis">' + _561.length + '</i> input ' + (_561.length === 1 ? 'element' : 'elements') + '</p>'
            }

            function _1041() {
                var _125 = new CSSStyleSheet();
                _125.replace(_466());
                return _125
            }

            function _466() {
                return (':root {' + '--deep-ocean: #08163c;' + '--dusty-cloud: #f7f9fc;' + '--dark-border: #bbc8e0;' + '--lighter-navy: #d4dbe3;' + '--dark-mode: #10172D;' + '--serious-business: #0b65e3;' + '--light-blue: #66A7FD;' + '--subtle-warmth: #7162e3;' + '--lighter-aqua: #ebf2fa;' + '--dusty-cloud-darker: #E4E9F2;' + '--deep-ocean-light: #A1B2D3;' + '--redwine-vibes: #cd575f;' + '}' + '.mf-highlight {' + 'cursor: pointer !important;' + '}' + '.mf-privacy-tool-opened iframe {' + 'pointer-events: none;' + '}' + '#mouseflow {' + 'font-weight: 300;' + 'font-family: \'museo-sans\';' + '}' + '#mouseflow .highlight-box {' + 'background-color: #add8e6;' + 'border: 2px dotted #808080;' + 'position: absolute;' + 'border-radius: 2px;' + 'z-index: 2147483646;' + 'cursor: pointer;' + 'pointer-events: none;' + 'opacity: 0.5;' + '-webkit-transition: opacity .075s linear;' + 'transition: opacity .075s linear;' + '}' + '#mouseflow .highlight-box.hidden,' + '#mouseflow .tool-closed .highlight-box {' + 'opacity: 0;' + '}' + '#mouseflow .highlight-box.highlight-excluded {' + 'background-color: #ffb6c1;' + 'pointer-events: initial;' + '}' + '#mouseflow .highlight-box.highlight-whitelisted {' + 'background-color: #90ee90;' + 'pointer-events: initial;' + '}' + '#mouseflow .highlight-box.highlight-tracked {' + 'background-color: orange;' + 'pointer-events: initial;' + '}' + '#mouseflow .tool-closed .highlight-box.highlight-excluded,' + '#mouseflow .tool-closed .highlight-box.highlight-whitelisted,' + '#mouseflow .tool-closed .highlight-box.highlight-tracked {' + 'pointer-events: none;' + '}' + '#mouseflow .btn-widget {' + 'background: var(--serious-business);' + '}' + '#mouseflow .widget-header {' + 'background: var(--dusty-cloud);' + '}' + '#mouseflow .widget-text,' + '#mouseflow .btn-arrow,' + '#mouseflow .btn-cross {' + 'color: var(--deep-ocean);' + '}' + '#mouseflow .btn-widget {' + 'color: white;' + '}' + '#mouseflow .tm-tag {' + 'margin: 7px 7px 0 0;' + 'padding: 7px;' + 'display: inline-block;' + 'border-radius: 8px;' + 'border: 1px solid var(--dark-border);' + 'background-color: var(--dusty-cloud);' + 'color: var(--deep-ocean);' + 'font-size: 13px;' + '}' + '#mouseflow .step {' + 'visibility: hidden;' + 'opacity: 0;' + 'position: fixed;' + 'bottom: 30px;' + 'right: 30px;' + 'z-index: 2147483647;' + 'width: 300px;' + 'border-radius: 8px;' + 'border: 1px solid var(--deep-ocean);' + 'overflow: hidden;' + '}' + '#mouseflow a:hover {' + 'text-decoration: underline;' + '}' + '#mouseflow h2 {' + 'font-size: 21px;' + 'font-weight: 700;' + 'line-height: 1.4em;' + 'margin-bottom: 6px;' + '}' + '#mouseflow h3 {' + 'font-size: 16px;' + 'font-weight: 700;' + 'line-height: 1.4em;' + '}' + '#mouseflow p {' + 'margin-bottom: 8px;' + 'line-height: 1.4em;' + '}' + '#mouseflow .green {' + 'color: var(--deep-ocean);' + '}' + '#mouseflow .red {' + 'color: var(--redwine-vibes);' + '}' + '#mouseflow .emphasis {' + 'color: var(--subtle-warmth);' + 'font-weight: 700;' + '}' + '#mouseflow .bold {' + 'font-weight: 700;' + '}' + '#mouseflow .tool-container {' + 'visibility: visible;' + 'opacity: 0;' + 'position: fixed;' + 'bottom: 0;' + 'left: 0;' + 'width: 100%;' + 'height: 350px;' + 'max-height: 40%;' + 'overflow: hidden;' + 'background-color: white;' + 'box-shadow: 0 0 6px var(--deep-ocean-light);' + 'z-index: 2147483647;' + '}' + '#mouseflow .tool-header {' + 'background-color: var(--dusty-cloud);' + 'height: 58px;' + 'border: 1px solid var(--dusty-cloud-darker);' + '}' + '#mouseflow .logo {' + 'display: inline;' + 'height: 30px;' + 'margin: 14px 10px;' + 'fill: black;' + '}' + '#mouseflow .tool-toggle,' + '#mouseflow .tool-close {' + 'float: right;' + 'padding: 18px 24px;' + '}' + '#mouseflow .is-loading .tool-close {' + 'display: block;' + '}' + '#mouseflow .is-loading .tool-toggle,' + '#mouseflow .tool-close {' + 'display: none;' + '}' + '#mouseflow .tool-toggle-text {' + 'display: inline-block;' + 'color: var(--deep-ocean);' + 'font-size: 16px;' + '}' + '#mouseflow .tool-toggle-icon {' + 'width: 23px;' + 'display: inline-block;' + 'position: relative;' + 'top: 0px;' + '}' + '#mouseflow .tool-close .tool-toggle-icon {' + 'top: 4px;' + '}' + '#mouseflow .tool-content {' + 'height: calc(100% - 58px);' + '}' + '#mouseflow .tool-menu {' + 'width: 15%;' + 'height: 100%;' + 'float: left;' + '}' + '#mouseflow .tool-menu-item {' + 'background-color: var(--dusty-cloud);' + 'color: var(--deep-ocean);' + 'cursor: pointer;' + 'height: 40px;' + 'padding: 12px;' + '}' + '#mouseflow .tool-menu-item.active {' + 'position: relative;' + 'background-color: var(--lighter-navy);' + 'color: var(--deep-ocean);' + 'cursor: default;' + '}' + '#mouseflow .tool-exclude,' + '#mouseflow .tool-whitelist,' + '#mouseflow .tool-track {' + 'display: none;' + 'width: 70%;' + 'height: 100%;' + 'float: left;' + 'color: var(--deep-ocean);' + 'overflow-y: auto;' + 'overflow-x: hidden;' + 'padding: 10px 20px;' + '}' + '#mouseflow .tool-exclude p, #mouseflow .tool-whitelist p, #mouseflow .tool-track p {' + 'color: black;' + '}' + '#mouseflow .tool-exclude.active,' + '#mouseflow .tool-whitelist.active,' + '#mouseflow .tool-track.active {' + 'display: block;' + '}' + '#mouseflow .tool-exclude::-webkit-scrollbar,' + '#mouseflow .tool-whitelist::-webkit-scrollbar,' + '#mouseflow .tool-track::-webkit-scrollbar {' + 'width: 8px;' + '}' + '#mouseflow .tool-exclude::-webkit-scrollbar-track,' + '#mouseflow .tool-whitelist::-webkit-scrollbar-track,' + '#mouseflow .tool-track::-webkit-scrollbar-track {' + 'border-radius: 10px;' + 'background-color: #F5F5F5;' + '-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);' + '}' + '#mouseflow .tool-exclude::-webkit-scrollbar-thumb,' + '#mouseflow .tool-whitelist::-webkit-scrollbar-thumb,' + '#mouseflow .tool-track::-webkit-scrollbar-thumb {' + 'border-radius: 10px;' + 'background-color: #a7a7a7;' + '-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);' + '}' + '#mouseflow .tool-status {' + 'width: 15%;' + 'background-color: var(--dusty-cloud);' + 'color: var(--deep-ocean);' + 'height: 100%;' + 'float: left;' + 'position: relative;' + '}' + '#mouseflow .tool-status-text {' + 'font-size: 16px;' + 'font-weight: 300;' + 'text-align: left;' + 'padding: 0 15px;' + 'position: absolute;' + 'top: 40px;' + '}' + '#mouseflow .tool-status-buttons {' + 'width: 100%;' + 'text-align: center;' + 'position: absolute;' + 'padding: 0 30px;' + 'bottom: 40px;' + '}' + '#mouseflow .tool-loading {' + 'width: 100%;' + 'height: calc(100% - 58px);' + 'background-color: white;' + 'color: rgb(71, 64, 62);' + 'position: absolute;' + 'top: 58px;' + 'z-index: 2;' + 'visibility: hidden;' + 'opacity: 0;' + '-webkit-animation: fadeOut .3s linear;' + 'animation: fadeOut .3s linear;' + '}' + '#mouseflow .is-loading .tool-loading {' + 'visibility: visible;' + 'opacity: 1;' + '-webkit-animation: fadeIn .3s linear;' + 'animation: fadeIn .3s linear;' + '}' + '#mouseflow .tool-loading h2 {' + 'position: absolute;' + 'left: 50%;' + 'top: 50%;' + '-webkit-transform: translate(-50%, -50%);' + '-ms-transform: translate(-50%, -50%);' + 'transform: translate(-50%, -50%);' + '}' + '#mouseflow .widget-header {' + 'color: #fff;' + 'padding: 12px 15px;' + 'vertical-align: middle;' + 'overflow: hidden;' + 'position: relative;' + 'z-index: 1;' + '-webkit-transition: opacity .3s linear;' + 'transition: opacity .3s linear;' + '}' + '#mouseflow .widget-header:hover {' + 'background-color: var(--lighter-aqua);' + '}' + '#mouseflow .widget-text {' + 'font-size: 16px;' + 'line-height: 20px;' + 'width: 245px;' + 'display: inline-block;' + 'vertical-align: middle;' + '}' + '#mouseflow .widget-toggle {' + 'width: 20px;' + 'display: inline-block;' + 'vertical-align: middle;' + 'margin: 0;' + '}' + '#mouseflow .btn-arrow,' + '#mouseflow .btn-cross {' + 'float: right;' + 'z-index: 10;' + 'line-height: .5;' + '}' + '#mouseflow .tool-toggle-icon .btn-arrow,' + '#mouseflow .tool-toggle-icon .btn-cross {' + 'font-size: 23px;' + '}' + '#mouseflow .widget-toggle .btn-arrow {' + 'font-size: 23px;' + '}' + '#mouseflow .tm-tag .btn-cross {' + 'margin: 3px 0 0 7px;' + 'font-weight: 700;' + 'font-size: 16px;' + '}' + '#mouseflow .btn-arrow--up {' + '-webkit-transform: rotate(-90deg) scale(1.5, 1.5);' + '-ms-transform: rotate(-90deg) scale(1.5, 1.5);' + 'transform: rotate(-90deg) scale(1.5, 1.5);' + '}' + '#mouseflow .btn-arrow--down {' + '-webkit-transform: rotate(+90deg) scale(1.5, 1.5);' + '-ms-transform: rotate(+90deg) scale(1.5, 1.5);' + 'transform: rotate(+90deg) scale(1.5, 1.5);' + '}' + '#mouseflow .widget-toggle .btn-arrow:before {' + 'content: "";' + 'display: inline;' + 'position: absolute;' + 'top: -185px;' + 'left: -15px;' + 'right: -15px;' + 'bottom: -15px;' + 'display: block;' + '}' + '#mouseflow .tool-toggle-icon .btn-arrow:before {' + 'content: "";' + 'display: inline;' + 'position: absolute;' + 'top: -10px;' + 'left: -15px;' + 'right: -15px;' + 'bottom: -100px;' + 'display: block;' + '}' + '#mouseflow .tool-toggle-icon .btn-cross:before {' + 'content: "";' + 'display: inline;' + 'position: absolute;' + 'top: -25px;' + 'left: -150px;' + 'right: -20px;' + 'bottom: -20px;' + 'display: block;' + '}' + '#mouseflow .btn-arrow:after {' + 'content: "\\203a";' + 'display: inline;' + '}' + '#mouseflow .btn-cross:after {' + 'content: "\\00d7";' + 'display: inline;' + 'top: -4px;' + 'position: relative;' + '}' + '#mouseflow .tm-tag .btn-cross:after {' + 'top: 0px;' + '}' + '#mouseflow .btn-arrow:hover,' + '#mouseflow .btn-cross:hover {' + 'text-decoration: none;' + '}' + '#mouseflow .btn-widget {' + 'width: 100%;' + 'height: 38px;' + 'border: none;' + 'border-radius: 8px;' + 'overflow: hidden;' + 'position: relative;' + 'z-index: 1;' + 'cursor: pointer;' + 'display: block;' + 'padding: 10px;' + 'font-size: 16px;' + 'font-family: inherit;' + 'font-weight: bold;' + 'text-align: center;' + 'outline: none;' + 'color: var(--dusty-cloud);' + 'margin-bottom: 10px;' + '-webkit-transition: background-color .3s linear;' + 'transition: background-color .3s linear;' + '}' + '#mouseflow .btn-widget:hover {' + 'text-decoration: none;' + 'background-color: var(--light-blue);' + '}' + '#mouseflow .privacy-tool {' + 'height: 350px;' + 'max-height: 40%;' + '-webkit-transition: height .5s ease-out;' + 'transition: height .5s ease-out;' + '}' + '#mouseflow .privacy-tool.tool-closed {' + 'height: 0;' + '}' + '#mouseflow .tool-closed .step {' + 'visibility: visible;' + '}' + '#mouseflow .tool-closed .tool-container {' + 'visibility: hidden;' + '}' + '#mouseflow .step.fade-in,' + '#mouseflow .tool-container.fade-in {' + '-webkit-animation: fadeUpIn .8s cubic-bezier(0, 0, 0, 1) both;' + 'animation: fadeUpIn .8s cubic-bezier(0, 0, 0, 1) both;' + '}' + '#mouseflow .step.fade-out,' + '#mouseflow .tool-container.fade-out {' + '-webkit-animation: fadeDownOut .8s cubic-bezier(0, 0, 0, 1);' + 'animation: fadeDownOut .8s cubic-bezier(0, 0, 0, 1);' + '}' + '#mouseflow .btn-widget.loading {' + 'cursor: default;' + '}' + '#mouseflow .btn-widget.loading:before {' + 'display: none;' + '}' + '#mouseflow .loading i {' + 'animation-name: blink;' + 'animation-duration: 1.4s;' + 'animation-iteration-count: infinite;' + 'animation-fill-mode: both;' + '}' + '#mouseflow .loading i:nth-child(2) {' + 'animation-delay: .2s;' + '}' + '#mouseflow .loading i:nth-child(3) {' + 'animation-delay: .4s;' + '}' + '#mouseflow .loading i:nth-child(4) {' + 'animation-delay: .6s;' + '}' + '#mouseflow .tool-message {' + 'width: 100%;' + 'height: calc(100% - 58px);' + 'background-color: white;' + 'color: rgb(71, 64, 62);' + 'position: absolute;' + 'top: 58px;' + 'z-index: 3;' + 'padding: 20px;' + 'overflow-y: auto;' + 'overflow-x: hidden;' + 'visibility: hidden;' + 'opacity: 0;' + '-webkit-animation: fadeOut .3s linear;' + 'animation: fadeOut .3s linear;' + '}' + '#mouseflow .tool-message h3 {' + 'margin-bottom: 20px;' + '}' + '@media (max-width: 1300px) {' + '#mouseflow .tool-exclude,' + '#mouseflow .tool-whitelist,' + '#mouseflow .tool-track {' + 'width: 60%;' + '}' + '#mouseflow .tool-status {' + 'width: 25%;' + '}' + '#mouseflow .tool-status-buttons {' + 'bottom: 10px;' + '}' + '}' + '@media (max-width: 850px) {' + '#mouseflow .tool-menu-item {' + 'height: 56px;' + '}' + '#mouseflow .tool-status-text {' + 'font-size: 14px;' + '}' + '#mouseflow .btn-widget {' + 'font-size: 12px;' + '}' + '#mouseflow a.mf-tool-close {' + 'font-size: 12px;' + '}' + '}' + '@media (max-height: 800px) {' + '#mouseflow .tool-status-text {' + 'top: 20px;' + '}' + '#mouseflow .tool-status-buttons {' + 'bottom: 20px;' + '}' + '}' + '@media (max-height: 650px) {' + '#mouseflow .tool-status-text {' + 'font-size: 14px;' + '}' + '}' + '@media (max-width: 650px), (max-height: 600px) {' + '#mouseflow .tool-message {' + 'visibility: visible;' + 'opacity: 1;' + '-webkit-animation: fadeIn .3s linear;' + 'animation: fadeIn .3s linear;' + '}' + '}' + '@-webkit-keyframes fadeUpIn {' + '0% {' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '100% {' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '}' + '@keyframes fadeUpIn {' + '0% {' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '100% {' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '}' + '@-webkit-keyframes fadeDownOut {' + '0% {' + 'visibility: visible;' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '}' + '@keyframes fadeDownOut {' + '0% {' + 'visibility: visible;' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '}' + '@-webkit-keyframes fadeIn {' + '0% {' + 'visibility: visible;' + 'opacity: 0;' + '}' + '100% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '}' + '@keyframes fadeIn {' + '0% {' + 'visibility: visible;' + 'opacity: 0;' + '}' + '100% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '}' + '@-webkit-keyframes fadeOut {' + '0% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + 'opacity: 0;' + '}' + '}' + '@keyframes fadeOut {' + '0% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + 'opacity: 0;' + '}' + '}' + '@keyframes blink {' + '0% {' + 'opacity: .2;' + '}' + '20% {' + 'opacity: 1;' + '}' + '100% {' + 'opacity: .2;' + '}' + '}')
            }
            this._38 = _38;
            this._78 = _78
        }

        function _818(_3, _103, _21, _10, _25, _4) {
            var _8, _119, _176, _54, _628, _455;

            function _38(_273, _450, _1039, _57) {
                _54 = _450;
                _8 = _273;
                _455 = _57;
                _628 = !!_1039;
                _8('Tagger tool starting');
                _119 = _103._275();
                if (!_119) {
                    _8('Tagger tool not initiated - could not create root HTML element');
                    return
                }
                if (!_3.opener) {
                    _8('Tagger tool not initiated - window.opener is missing');
                    return
                }
                _341()
            }

            function _341() {
                _25._40(_3, 'message', function(_35) {
                    if (_35.origin !== _54) return;
                    _458(_35.data);
                    switch (_35.data.message) {
                        case 'MouseflowTaggerTool_Init_Received':
                            _3.clearInterval(_176);
                            break;
                        case 'MouseflowTaggerTool_Init_Success':
                            _456(_35.data.scripts, function() {
                                if (typeof _455 === 'function') _455();
                                _8('Tagger tool scripts loaded')
                            });
                            break
                    }
                });
                _176 = _3.setInterval(_624, 500);
                _3.setTimeout(function() {
                    _3.clearInterval(_176)
                }, 10000);
                _624()
            }

            function _624() {
                _291({
                    message: 'MouseflowTaggerTool_Init',
                    startWithHeatMap: _628
                })
            }

            function _456(_178, _57) {
                if (!_178) return;
                var _186 = 0;

                function _282() {
                    if (_186 >= _178.length) {
                        _57();
                        return
                    }
                    var _106 = _178[_186];
                    _457(_106);
                    _186++;
                    var _144 = document.createElement('script');
                    if (_106.startsWith('/')) _144.src = _54 + _106;
                    else _144.src = _54 + '/' + _106;
                    _144.onload = _282;
                    _119.appendChild(_144)
                }
                _282()
            }

            function _457(_106) {
                _8('Tagger tool loading script: ' + _106)
            }

            function _458(_12) {
                if (_12.message && _12.message.indexOf('MouseflowTaggerTool_') === 0) _8('Received ' + _12.message + (_12.requestUrl ? ', request URL: ' + _12.requestUrl : ''))
            }

            function _291(_12) {
                _3.opener.postMessage(_12, _54);
                _8('Sent ' + _12.message + (_12.requestUrl ? ', request URL: ' + _12.requestUrl : ''))
            }
            this._38 = _38
        }

        function _798(_4, _472, _473) {
            function _238() {
                var _66 = (_4.crossDomainSupport ? _4.location.hostname : '') + (_4.path || (_4.decodePathName ? decodeURIComponent(_4.location.pathname) : _4.location.pathname)).toLowerCase();
                var _117 = (_4.includeHashInPath ? _4.location.hash : '').toLowerCase();
                var _104 = _4.location.search.toLowerCase();
                if (_66 !== '/' && _66.slice(-1) === '/' && (!_4.includeQueryStringInPath && !_4.includeHashInPath)) _66 = _66.slice(0, -1);
                return _1031(_66 + (_4.includeQueryStringInPath ? _104 : '') + _117) || _66 + _1030(_104) + _117
            }

            function _1031(_66) {
                return _472.filter(function(_75) {
                    return _998(_66, _75)
                }).map(function(_75) {
                    return _995(_66, _75)
                })[0]
            }

            function _1030(_104) {
                if (_104[0] === '?') _104 = _104.slice(1);
                var _68;
                var _459 = [];
                var _1026 = /([^&=]+)=?([^&]*)/g;
                while (_68 = _1026.exec(_104)) {
                    var _49 = _473.indexOf(_68[1]);
                    if (_68[2] && _49 > -1) _459[_49] = _68[0]
                }
                return _459.length ? '?' + _459.filter(hasValue).join('&') : (_4.includeQueryStringInPath && _104 ? '?' + _104 : '')
            }

            function _998(_66, _75) {
                var _566 = _66.indexOf('?');
                if (!_4.includeQueryStringInPath && _566 > -1) _66 = _66.slice(0, _566);
                switch (_75._19) {
                    case 'equals':
                        return _66 === _75._5.toLowerCase();
                    case 'startsWith':
                        return _66.substr(0, _75._5.length) === _75._5;
                    case 'endsWith':
                        return _66.substr(-_75._5.length) === _75._5;
                    case 'regex':
                        return new RegExp(_75._5).test(_66);
                    default:
                        return false
                }
            }

            function _995(_66, _75) {
                if (_75._968) return _75._968;
                switch (_75._19) {
                    case 'startsWith':
                        return _75._5 + '*';
                    case 'endsWith':
                        return '*' + _75._5;
                    default:
                        return _75._5
                }
            }

            function hasValue(value) {
                return value
            }
            this._238 = _238
        }

        function _572(_19, _3, _10, _8) {
            var _234 = _964(_19);
            this._233 = function(_17) {
                try {
                    return _234.getItem(_17) || null
                } catch (e) {
                    _8(e);
                    return null
                }
            };
            this._258 = function(_17) {
                try {
                    return _10._296(this._233(_17)) || null
                } catch (e) {
                    _8(e);
                    return null
                }
            };
            this._143 = function(_17, _5) {
                try {
                    _234.setItem(_17, _5)
                } catch (e) {
                    _8(e)
                }
            };
            this._257 = function(_17, _5) {
                try {
                    this._143(_17, _10._114(_5))
                } catch (e) {
                    _8(e)
                }
            };
            this._319 = function(_17) {
                try {
                    _234.removeItem(_17)
                } catch (e) {
                    _8(e)
                }
            };
            this._553 = function() {
                try {
                    var _17 = 'mf_supportsSessionStorage';
                    var _5 = '1';
                    _234.setItem(_17, _5);
                    var _966 = _234.getItem(_17) === _5;
                    _234.removeItem(_17);
                    return _966
                } catch (e) {
                    _8(e);
                    return false
                }
            };

            function _964(_19) {
                switch (_19) {
                    case 'local':
                        return _3.localStorage;
                    case 'session':
                        return _3.sessionStorage;
                    default:
                        throw Error('Unknown storage type: ' + (_19 || 'null'))
                }
            }
        }

        function _963(_29, _10) {
            var _463 = [];
            var _960 = ['target', 'button', 'pageX', 'pageY', 'which', 'data', 'origin', 'source', 'touches'];

            function _954(_28, _6, _43, _462, _16) {
                var _77 = !!_16._77;
                var _592 = function(_7) {
                    var _242 = [];
                    if (_7.composedPath && (_7.target.shadowRoot || _43)) _242 = _7.composedPath();
                    var _576 = _7;
                    _7 = _970(_7);
                    _7.preventDefault = function() {
                        _576.preventDefault()
                    };
                    _7.stopPropagation = function() {
                        _576.stopPropagation()
                    };
                    if (_7.target.shadowRoot && _242.length) _7.target = _242[0];
                    if (_43) {
                        _7.delegatedTarget = _582(function(_79, _2) {
                            return _242.length ? _242[_2] : (_79 ? _29._71(_79) : _7.target)
                        }, _43);
                        if (!_7.delegatedTarget && !_16._962) return;
                        if (_16._303 && _7.target !== _7.delegatedTarget) return
                    } else if (_16._303 && _7.target !== _28) {
                        return
                    }
                    if (_16._105) _7.preventDefault();
                    if (_16._1050) _7.stopPropagation();
                    _462.apply(this, arguments)
                };
                _28.addEventListener(_6, _592, {
                    capture: _77
                });
                _463.push({
                    _28: _28,
                    _6: _6,
                    _462: _592,
                    _77: _77
                })
            }

            function _970(_7) {
                var _593 = {};
                _960.forEach(function(_17) {
                    if (_7[_17] != undefined) _593[_17] = _7[_17]
                });
                return _593
            }

            function _951() {
                _463.forEach(function(_25) {
                    _25._28.removeEventListener(_25._6, _25._462, {
                        capture: _25._77
                    })
                });
                _463 = []
            }

            function _582(_579, _43, _28, _49) {
                if (!_49) _49 = 0;
                _28 = _579(_28, _49);
                if (!_28 || !_43) return null;
                if (_10._82(_28, _43)) return _28;
                return _582(_579, _43, _28, ++_49)
            }
            this._40 = function(_28, _6, _43, _57, _16) {
                if (typeof _43 === 'function') {
                    _16 = _57;
                    _57 = _43;
                    _43 = null
                }
                _954(_28, _6, _43, _57, _16 || {})
            };
            this._584 = _951
        }

        function _728(_4, _10) {
            function _495(_169) {
                if (!_169 || !_169.length) return true;
                _169 = _169.filter(function(_67) {
                    return _67 && _67._19 && _67._5
                });
                var _586 = _169.filter(function(_67) {
                    return _67._19.indexOf('not') !== 0
                });
                var _972 = _586.length === 0 || _586.some(function(_67) {
                    return _200(_67)
                });
                var _619 = _169.filter(function(_67) {
                    return _67._19.indexOf('not') === 0
                });
                var _959 = _619.length === 0 || _619.every(function(_67) {
                    return _200(_67)
                });
                return _959 && _972
            }

            function _200(_67) {
                var _66 = (_4.path || _4.location.pathname).toLowerCase();
                var _117 = (_4.includeHashInPath ? _4.location.hash : '').toLowerCase();
                var _104 = (_4.includeQueryStringInPath ? _4.location.search : '').toLowerCase();
                var _26 = _66 + _104 + _117;
                var _486 = _609(_67, _26);
                if (!_486 && _4.crossDomainSupport) _486 = _609(_67, _4.location.hostname + _26);
                return _486
            }

            function _609(_67, _26) {
                var _19 = _67._19 || '';
                var _5 = _67._5 || '';
                switch (_19.toLowerCase()) {
                    case 'equals':
                        _26 = _10._204(_26, '/').toLowerCase();
                        _5 = _10._204(_5, '/').toLowerCase();
                        return _26 === _5;
                    case 'startswith':
                        _26 = _26.toLowerCase();
                        _5 = _5.toLowerCase();
                        return _26.substr(0, _5.length) === _5;
                    case 'endswith':
                        _26 = _10._204(_26, '/').toLowerCase();
                        _5 = _10._204(_5, '/').toLowerCase();
                        return _26.substr(-_5.length) === _5;
                    case 'regex':
                        return new RegExp(_5).test(_26);
                    case 'notequals':
                    case 'notstartswith':
                    case 'notendswith':
                        return !_200({
                            _19: _19.slice(3),
                            _5: _5
                        });
                    default:
                        return true
                }
            }
            this._495 = _495;
            this._200 = _200
        }

        function _992(_3, _58, _493, _494) {
            var _73 = _3.location;

            function _538(_18) {
                var _82 = (_18 || '').match(/^(([^:]+:)?\/?\/?(([^:\/\?#]+)?:?(\d+)?))(\/.*?)?(\?.*?)?(#.*)?$/);
                return {
                    href: _82[0] || '',
                    origin: _82[1] || '',
                    protocol: _82[2] || '',
                    host: _82[3] || '',
                    hostname: _82[4] || '',
                    port: _82[5] || '',
                    pathname: _82[6] || '',
                    search: _82[7] || '',
                    hash: _82[8] || ''
                }
            }
            this.debug = _3.mouseflowDebug || _73.search.indexOf('mf_debug=1') !== -1;
            this.includeDebugTime = false;
            this.forceStart = _73.search.indexOf('mf_force=1') !== -1;
            this.autoStart = _3.mouseflowAutoStart !== false && _73.search.indexOf('mf_autostart=0') === -1;
            this.enableBots = false;
            this.touchEvents = !_3.mouseflowDisableTouch;
            this.htmlDelay = _3.mouseflowHtmlDelay || 1000;
            this.newPageViewHtmlDelay = _3.mouseflowNewPageViewHtmlDelay || 500;
            this.compress = _3.mouseflowCompress !== false && _73.search.indexOf('mf_compress=0') === -1;
            this.autoTagging = _3.mouseflowAutoTagging !== false;
            this.path = _3.mouseflowPath;
            this.crossDomainSupport = !!_3.mouseflowCrossDomainSupport;
            this.location = _538(_3.mouseflowHref || _73.href);
            this.htmlFetchMode = _3.mouseflowHtmlFetchMode || 'post';
            this.sessionId = _3.mouseflowSessionId;
            this.honorDoNotTrack = _3.mouseflowHonorDoNotTrack || _494;
            this.gdprEnabled = _3.mouseflowForceGdpr || _493;
            this.keyLogging = !_3.mouseflowDisableKeyLogging && !this.gdprEnabled;
            this.domReuse = !_3.mouseflowDisableDomReuse;
            this.domDeduplicator = !_3.mouseflowDisableDomDeduplicator;
            this.includeSubDomains = !_3.mouseflowExcludeSubDomains;
            this.registerSubmitTimeout = _3.mouseflowRegisterSubmitTimeout || 2000;
            this.useUnload = !!_3.mouseflowUseUnload;
            this.replaceLastFormValues = _3.mouseflowReplaceLastFormValues || !this.keyLogging || this.gdprEnabled;
            this.useAllHoverSelectors = !!_3.mouseflowUseAllHoverSelectors;
            this.enableCssRecording = !!_3.mouseflowEnableCssRecording;
            this.secureCookie = !!_3.mouseflowSecureCookie;
            this.enableSpa = true;
            this.includeHashInPath = false;
            this.includeQueryStringInPath = false;
            this.autoTagPayments = true;
            this.preferStorageApi = !!_3.mouseflowPreferStorageApi;
            this.domMutationDetectorEnable = _3.domMutationDetectorEnable !== undefined ? _3.domMutationDetectorEnable : false;
            this.domMutationUseParentNode = _3.domMutationUseParentNode !== undefined ? _3.domMutationUseParentNode : true;
            this.domMutationUsePreviousSibling = _3.domMutationUsePreviousSibling !== undefined ? _3.domMutationUsePreviousSibling : false;
            this.domMutationCountThreshold = _3.domMutationCountThreshold !== undefined ? _3.domMutationCountThreshold : 20;
            this.domMutationTimeThresholdInSeconds = _3.domMutationTimeThresholdInSeconds !== undefined ? _3.domMutationTimeThresholdInSeconds : 10;
            this.liveHeatmapsEnabled = false;
            this.privacyToolEnabled = false;
            this.taggerToolEnabled = false;
            this.useIdSelectors = _3.mouseflowUseIdSelectors !== undefined ? _3.mouseflowUseIdSelectors : true;
            this.proxyAttachShadow = true;
            this.scrollSelector = _3.mouseflowScrollSelector;
            this.autoScrollSelector = _3.mouseflowAutoScrollSelector || false;
            this.freezeElementIds = [];
            this.proxyValueSetter = false;
            this.decodePathName = false;
            this.forms = _3.mouseflowFormsConfiguration || null;
            this._753 = function() {
                if (!!_3.opener && _73.search.indexOf('mf_liveHeatmaps') !== -1) {
                    this.liveHeatmapsEnabled = true;
                    this.taggerToolEnabled = true;
                    return
                }
                if (_73.search.indexOf('mf_inspect') !== -1) {
                    this.privacyToolEnabled = true;
                    return
                }
                if (!!_3.opener && (typeof _3.name === 'string' && _3.name.indexOf('mf_liveHeatmaps') === 0)) {
                    this.liveHeatmapsEnabled = true;
                    this.taggerToolEnabled = true;
                    return
                }
                if (_3.name === 'mf_privacyTool') {
                    this.privacyToolEnabled = true;
                    return
                }
                if (_3.name.indexOf('mf_tagger_tool') > -1) {
                    this.taggerToolEnabled = true;
                    return
                }
                if (!_58._553()) return;
                if (_3.opener) {
                    if (_58._233('mf_privacyTool')) this.privacyToolEnabled = true;
                    else if (_58._233('mf_liveHeatmaps')) {
                        this.liveHeatmapsEnabled = true;
                        this.taggerToolEnabled = true
                    }
                }
            };
            this._753();
            this._484 = function(_26, _73) {
                this._298('href', window.location.href);
                this.path = undefined;
                if (_26) this.path = _26.toString();
                if (_73) this.location = _73
            };
            this._298 = function(_17, _5) {
                switch (_17) {
                    case 'href':
                        this.location = _538(_5);
                        break;
                    case 'keyLogging':
                        this.keyLogging = this.keyLogging && _5;
                        break;
                    case 'gdprEnabled':
                        this.gdprEnabled = this.gdprEnabled || _5;
                        break;
                    case 'freezeElementIds':
                        this.freezeElementIds = Array.isArray(_5) ? _5 : ['' + _5];
                        break;
                    case '_cssSelectorBlackList':
                    case '_cssSelectorWhiteList':
                    case '_cssSelectorTracked':
                    case '_websiteId':
                    case '_enforcePrivacy':
                    case '_initialDomLimit':
                        break;
                    default:
                        this[_17] = _5;
                        break
                }
            }
        }

        function _802(_3) {
            var _11 = _3.document,
                _198;

            function _275() {
                if (_11.body && !_198) {
                    _198 = _758();
                    _11.body.appendChild(_198)
                }
                return _198
            }

            function _490() {
                if (_198) {
                    _11.body.removeChild(_198);
                    _198 = undefined
                }
            }

            function _758() {
                var _32 = _11.createElement('div');
                _32.id = 'mouseflow';
                var _112 = _11.createElement('style');
                _112.type = 'text/css';
                _112.innerHTML = _777();
                var _488 = _11.createElement('div');
                _488.className = 'load-font';
                _488.innerHTML = 'load font';
                _32.appendChild(_112);
                _32.appendChild(_488);
                return _32
            }

            function _777() {
                return ('@font-face {' + 'font-family: "Droid Sans";' + 'font-style: normal;' + 'font-weight: 400;' + 'src: local("Droid Sans Regular"), local("DroidSans-Regular"), url(https://cdn.mouseflow.com/fonts/gstatic_droidsans.woff2) format("woff2");' + 'unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2212, U+2215;' + '}' + '#mouseflow :before, #mouseflow :after {' + 'display: none;' + '}' + '#mouseflow,' + '#mouseflow * {' + 'background: transparent;' + 'border: 0;' + 'border-image-outset: 0s;' + 'border-image-repeat: stretch;' + 'border-image-slice: 100%;' + 'border-image-source: none;' + 'border-image-width: 1;' + 'border-color: #000;' + 'border-radius: 0;' + 'border-width: 0;' + 'border-style: none;' + 'box-sizing: border-box;' + 'clip: auto;' + 'float: none;' + 'color: inherit;' + 'font-family: inherit;' + 'font-size: inherit;' + 'font-style: inherit;' + 'font-weight: inherit;' + 'width: auto;' + 'height: auto;' + 'min-width: auto;' + 'min-height: auto;' + 'max-width: auto;' + 'max-height: auto;' + 'letter-spacing: normal;' + 'line-height: normal;' + 'margin: 0;' + 'padding: 0;' + 'text-decoration: none;' + 'text-indent: 0;' + 'text-transform: none;' + 'vertical-align: baseline;' + 'text-align: left;' + 'overflow: visible;' + 'top: auto;' + 'right: auto;' + 'bottom: auto;' + 'left: auto;' + '-webkit-transition: none;' + 'transition: none;' + '}' + '#mouseflow {' + 'font: 400 14px/1.4 "Droid Sans", Helvetica, Arial, sans-serif;' + 'color: #666;' + '}' + '#mouseflow .load-font {' + 'position: absolute;' + 'visibility: hidden;' + 'width: 0px;' + 'height: 0px;' + 'overflow: hidden;' + '}')
            }
            this._275 = _275;
            this._490 = _490
        }

        function _774(_3) {
            this._65 = function() {
                return _342('setTimeout').apply(_3, arguments)
            };
            this._280 = function() {
                return _342('setInterval').apply(_3, arguments)
            };
            this._132 = function() {
                _342('clearTimeout').apply(_3, arguments)
            };
            this._154 = function() {
                _342('clearInterval').apply(_3, arguments)
            };

            function _342(_22) {
                var _498;
                if (_3.Zone && _3.Zone.__symbol__) _498 = _3[_3.Zone.__symbol__(_22)];
                return _498 || _3[_22]
            }
        }

        function _771(_3, _128, _492, _29) {
            var _11 = _3.document;

            function _156(_1, _89) {
                var _101 = _1.classList;
                if (_101 && _89) return _101.contains(_89);
                var _147 = _194(_1);
                return _147.indexOf(_89) !== -1
            }

            function _70(_1, _89) {
                var _101 = _1.classList;
                if (_101 && _89) {
                    _1.classList.add(_89);
                    return
                }
                var _147 = _194(_1);
                if (_147.indexOf(_89) === -1) _147.push(_89);
                _1.className = _147.join(' ')
            }

            function _51(_1, _89) {
                var _101 = _1.classList;
                if (_101 && _89) {
                    _1.classList.remove(_89);
                    return
                }
                var _147 = _194(_1);
                var _49 = _147.indexOf(_89);
                if (_49 !== -1) _147.splice(_49, 1);
                _1.className = _147.join(' ')
            }

            function _259(_1, _89, _496) {
                if (_496 === undefined) _496 = !_156(_1, _89);
                if (_496) {
                    _70(_1, _89)
                } else {
                    _51(_1, _89)
                }
            }

            function _194(_1) {
                var _508 = typeof _1.className === 'string' ? _1.className.replace(/\s+/g, ' ').trim() : '';
                return _508 !== '' ? _508.split(' ') : []
            }

            function _483() {
                return _128.max((_11.body || {}).scrollHeight || 0, (_11.body || {}).offsetHeight || 0, _11.documentElement.scrollHeight || 0, _11.documentElement.offsetHeight || 0, _11.documentElement.clientHeight || 0)
            }

            function _43(_42, _764) {
                var _33 = [];
                if (!_42) return _33;
                for (var _2 = 0; _2 < _42.length; _2++) {
                    if (_764(_42[_2], _2)) _33.push(_42[_2])
                }
                return _33
            }

            function _225(_192) {
                var _2 = Math.floor(Math.log(_192) / Math.log(1024));
                return (_192 / Math.pow(1024, _2)).toFixed(2) * 1 + ' ' + ['B', 'KB', 'MB', 'GB', 'TB'][_2]
            }

            function _599(_286) {
                var _326 = _286.length;
                while (_326) {
                    var _2 = _128.floor(_128.random() * _326--);
                    var _767 = _286[_326];
                    _286[_326] = _286[_2];
                    _286[_2] = _767
                }
            }

            function _172(_37) {
                if (!_37) return _37;
                return _37.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            }

            function _482(_37) {
                if (!_37) return _37;
                return _37.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
            }

            function _481(url) {
                return /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)$/.test(url.trim())
            }

            function _511(_37) {
                return _37.replace(/\[([^\]]+)\]\(([^\)]+)\)/g, function(_68, _752, _18) {
                    _18 = _482(_18);
                    return _481(_18) ? '<a href="' + _18 + '" target="_blank">' + _752 + '</a>' : _68
                })
            }

            function _171(_5) {
                if (!_5) return _5;
                return _5.replace(/([^a-zA-Z\d-_])/g, '\\$1').replace(/^(-)?(\d)/, '$1\\3$2 ')
            }

            function _296(_5) {
                return _5 ? _492.parse(_5) : undefined
            }

            function _114(_5) {
                var _33;
                if (Array.prototype.toJSON) {
                    var _754 = Array.prototype.toJSON;
                    delete Array.prototype.toJSON;
                    _33 = _492.stringify(_5);
                    Array.prototype.toJSON = _754
                } else if (_5) {
                    _33 = _492.stringify(_5)
                }
                return _33
            }

            function _522(_772, _773) {
                var _215 = _316(_772);
                var _37 = _316(_773);
                var _320 = _128.max(_215.length, _37.length);
                if (_37 == 'NaN' || _215 == 'NaN') {
                    return false
                }
                for (var _2 = 0; _2 < _320; _2++) {
                    _215[_2] = _215[_2] || 0;
                    _37[_2] = _37[_2] || 0;
                    if (_215[_2] == _37[_2]) {
                        continue
                    }
                    return _215[_2] > _37[_2]
                }
                return true
            }

            function _316(_775) {
                var _505 = _775.split('.');
                var _591 = [];
                for (var _2 = 0; _2 < _505.length; _2++) {
                    _591.push(parseInt(_505[_2]))
                }
                return _591
            }

            function _204(_37, _814) {
                var _33 = _37;
                while (_33[_33.length - 1] === (_814 || ' ')) _33 = _33.slice(0, -1);
                return _33
            }

            function _519(_357) {
                var _68;
                var _104 = /([^?&=]+)(?:=([^&]*))?/g;
                var _135 = {};
                while (_68 = _104.exec(_357)) {
                    var _17 = _68[1];
                    var _5 = !!_68[2] ? window.decodeURIComponent(_68[2].replace(/\+/g, ' ')) : null;
                    _135[_17] = _5
                }
                return _135
            }
            const platformRegexes = [{
                family: 'windows',
                regex: [/microsoft (windows) (vista|xp)/i, /(windows) nt 6\.2; (arm)/i, /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i, /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i, /(win(?=3|9|n)|win 9x )([nt\d\.]+)/i]
            }, {
                family: 'ios',
                regex: [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, /cfnetwork\/.+darwin/i]
            }, {
                family: 'macos',
                regex: [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i]
            }, {
                family: 'android',
                regex: [/droid ([\w\.]+)\b.+android[- ]x86/i, /(android)[-\/ ]?([\w\.]*)/i]
            }, {
                family: 'linux',
                regex: [/\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i]
            }];
            const browserRegexes = [{
                browser: 'chrome',
                regex: [/\b(?:crmo|crios)\/([\w\.]+)/i]
            }, {
                browser: 'edge',
                regex: [/edg(?:e|ios|a)?\/([\w\.]+)/i]
            }, {
                browser: 'opera',
                regex: [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i, /opios[\/ ]+([\w\.]+)/i, /\bopr\/([\w\.]+)/i]
            }, {
                browser: 'ie',
                regex: [/(?:ms|\()(ie) ([\w\.]+)/i, /trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i]
            }, {
                browser: 'firefox',
                regex: [/\bfocus\/([\w\.]+)/i, /fxios\/([\w\.-]+)/i, /(?:mobile|tablet);.*(firefox)\/([\w\.-]+)/i, /mobile vr; rv:([\w\.]+)\).+firefox/i, /(firefox)\/([\w\.]+)/i]
            }, {
                browser: 'opera',
                regex: [/\bopt\/([\w\.]+)/i, /coast\/([\w\.]+)/i]
            }, {
                browser: 'samsung',
                regex: [/(samsung)browser\/([\w\.]+)/i]
            }, {
                browser: 'chrome',
                regex: [/ wv\).+(chrome)\/([\w\.]+)/i, /chrome\/([\w\.]+) mobile/i, /(chrome)\/v?([\w\.]+)/i]
            }, {
                browser: 'android',
                regex: [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i]
            }, {
                browser: 'safari',
                regex: [/version\/([\w\.\,]+) .*mobile(?:\/\w+ | ?)safari/i, /iphone .*mobile(?:\/\w+ | ?)safari/i, /version\/([\w\.\,]+) .*(safari)/i, /webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i]
            }];

            function _521(_571) {
                var _618;
                var _613;
                for (var _2 = 0; _2 < platformRegexes.length; _2++) {
                    var _577 = platformRegexes[_2];
                    var _68 = _577.regex.find(function(_460) {
                        return _460.test(_571)
                    });
                    if (_68) {
                        _613 = _577.family;
                        break
                    }
                }
                for (var _2 = 0; _2 < browserRegexes.length; _2++) {
                    var _596 = browserRegexes[_2];
                    var _68 = _596.regex.find(function(_460) {
                        return _460.test(_571)
                    });
                    if (_68) {
                        _618 = _596.browser;
                        break
                    }
                }
                return {
                    browser: _618,
                    os: _613
                }
            }

            function _82(_1, _9) {
                if (_1.nodeType !== 1) return false;
                if (_1.msMatchesSelector) return _1.msMatchesSelector(_9);
                if (_1.matches) return _1.matches(_9);
                return false
            }

            function _174(_79, _452) {
                var _64 = _29._71(_79);
                return _64 && _64.hasAttribute && _64.hasAttribute(_452)
            }
            this._156 = _156;
            this._70 = _70;
            this._51 = _51;
            this._259 = _259;
            this._194 = _194;
            this._483 = _483;
            this._43 = _43;
            this._225 = _225;
            this._599 = _599;
            this._172 = _172;
            this._482 = _482;
            this._481 = _481;
            this._511 = _511;
            this._171 = _171;
            this._296 = _296;
            this._114 = _114;
            this._522 = _522;
            this._316 = _316;
            this._204 = _204;
            this._82 = _82;
            this._174 = _174;
            this._519 = _519;
            this._521 = _521
        }

        function _831(_3) {
            var _310 = _3.Object;
            var _478 = _3.Node;
            var _315;
            var _786 = _310.getOwnPropertyDescriptor(_478.prototype, 'parentNode');
            var _788 = _310.getOwnPropertyDescriptor(_478.prototype, 'nextSibling');
            var _789 = _310.getOwnPropertyDescriptor(_478.prototype, 'firstChild');
            this._71 = function(_1) {
                return _1 ? _786.get.apply(_1) : null
            };
            this._166 = function(_1) {
                return _1 ? _788.get.apply(_1) : null
            };
            this._203 = function(_1) {
                return _1 ? _789.get.apply(_1) : null
            };
            this._794 = function(_1) {
                if (!_1) return false;
                if (_315 === undefined) {
                    try {
                        _315 = _3.document.createElement('div').attachShadow({
                            mode: 'open'
                        }).constructor
                    } catch (e) {
                        _315 = _3.ShadowRoot
                    }
                }
                var _289 = _1;
                while (true) {
                    _289 = _310.getPrototypeOf(_289);
                    if (!_289 || _289.constructor === _3.DocumentFragment) return false;
                    if (_289.constructor === _315) return true
                }
            }
        }

        function _801(_3) {
            var _723;
            this.proxyPushState = function(callback) {
                var _468 = _3.history;
                _723 = _468.pushState;
                _468.pushState = function() {
                    _3.setTimeout(callback, 100);
                    return _723.apply(_468, arguments)
                };
                _3.addEventListener('popstate', function() {
                    _3.setTimeout(callback, 100)
                })
            }
        }
        var _103 = new _802(window);
        var _189 = new _798(_4, _472, _473);
        var _236 = (typeof _728 === 'function') ? new _728(_4, _10) : {
            _200: function() {}
        };
        var _792 = /[?&]mf_feedback=old(&|#|$)/.test(window.location.search);
        if (_792) _639 = _1049;
        var _148 = (typeof _639 === 'function') ? new _639(window, _4, _103, _21, _10, _236, _25, _149, _8) : {
            _38: function() {},
            _78: function() {},
            _451: function() {},
            _1048: function() {},
            _454: function() {}
        };
        var _465 = (typeof _646 === 'function') ? new _646(_29, _4) : {
            _162: function() {}
        };
        var _677 = new _820(window, _103, _29, _21, _10, _25, _58, _4);
        var _307 = new _819(window, _4, _103, _10, _25, _189, _58);
        var _670 = new _818(window, _103, _21, _10, _25, _4);

        function _118() {
            return undefined
        }

        function _682() {
            return null
        }

        function _709() {
            return false
        }
        var shouldRecord = false;
        if (_4.privacyToolEnabled) {
            _677._38(_54, _4._53, _4._352, _4._353, _4._193, _8)
        } else if (_4.liveHeatmapsEnabled) {
            var _290;
            if (_4.taggerToolEnabled) {
                _290 = function(_57) {
                    _670._38(_8, _54, true, _57)
                }
            }
            _307._38(_4._53, _8, _54, _290)
        } else if (_4.taggerToolEnabled) {
            _670._38(_8, _54)
        } else if (typeof _676 === 'function') {
            window.mouseflow = new _676(window, Math, _29, _4, _21, _10, _25, _189, _236, _58, _149, _148, _465, _8, _301);
            shouldRecord = true
        }
        if (!shouldRecord) {
            window.mouseflow = {
                start: _118,
                stop: function() {
                    if (_4.privacyToolEnabled) _677._78();
                    else if (_4.liveHeatmapsEnabled) _307._78()
                },
                newPageView: function(_26, _73) {
                    _4._484(_26, _73);
                    if (_4.liveHeatmapsEnabled) _307._716()
                },
                stopSession: _118,
                getSessionId: _682,
                getPageViewId: _682,
                tag: _118,
                star: _118,
                setVariable: _118,
                identify: _118,
                formSubmitAttempt: _118,
                formSubmitSuccess: _118,
                formSubmitFailure: _118,
                addFriction: _118,
                isRecording: _709,
                isReturningUser: _709,
                activateFeedback: _118,
                proxyAttachShadow: _118,
                recordingRate: null,
                version: null
            };
            _301.proxyPushState(window.mouseflow.newPageView)
        }
        window.mouseflow.websiteId = _4._53;
        window.mouseflow.gdprEnabled = _4.gdprEnabled;
        window.mouseflow.updateHeatmap = _307._716;
        window.mouseflow.config = function() {
            return arguments.length === 1 ? _4[arguments[0]] : _4._298.apply(_4, arguments)
        };
        window.mouseflow.debug = function() {
            _4.debug = !_4.debug;
            console.log('MF: Debugging ' + (_4.debug ? 'enabled' : 'disabled'))
        }
    })()
}