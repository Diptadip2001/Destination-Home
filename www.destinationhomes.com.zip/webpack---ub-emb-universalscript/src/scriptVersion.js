// @flow

// _VERSION is a global defined in our webpack config using DefinePlugin
export default _VERSION;