// @flow
// eslint-disable-next-line no-unused-vars
export default Object.freeze((...args: Array < * > ) => {});