import { preparePathObjects } from './prepare-path-objects';
import { searchElementByPathObject } from './search-element-by-path-object';
import { splitXpathParams } from './split-xpath-params';

export const recursiveXpathSearch = (xpathStr: string) => {
  const { xpath, params } = splitXpathParams(xpathStr);
  const pathObjects = preparePathObjects(xpath, params);

  return searchElementByPathObject(pathObjects);
};
