import { splitXpathParams } from './split-xpath-params';
import { checkHash } from './check-hash';

export const getElementByXpath = (xpathStr: string) => {
  const { xpath, params } = splitXpathParams(xpathStr);

  const element = document.evaluate(
    xpath,
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null,
  ).singleNodeValue;

  if (checkHash(element as HTMLElement, params)) {
    return element;
  }
  return null;
};
