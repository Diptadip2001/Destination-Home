import { originalQueryNotStrict } from './original-query-not-strict';
import { executeQuery } from './execute-query';

import { PathObject, QueryMode } from './types';

import { BODY_INDEX } from './constants';

// minTailLength specifies minimum elements count which should prepend last element
// (html and body not counted as far as they always exists)

export const searchElementByPathObject = (
  pathObjects: PathObject[],
  minTailLength = 4,
): HTMLElement | null => {
  // count number of elements between body and tail elements
  let shrunkLength = pathObjects.length - BODY_INDEX - minTailLength;
  const lastEl = pathObjects[pathObjects.length - 1];
  let query;
  const hashObj = lastEl.params;

  // in case when we cant remove any elements from xpath
  if (shrunkLength < 0) {
    // strict query with - nth-child
    query = originalQueryNotStrict(pathObjects, 0, true);
    const qResult = executeQuery(query, hashObj, lastEl);

    if (qResult) {
      return qResult;
    }

    // loose query
    query = originalQueryNotStrict(pathObjects, 0);
    return executeQuery(query, hashObj, lastEl);
  }

  const tryToFindElement = (mode: QueryMode) => {
    shrunkLength = pathObjects.length - BODY_INDEX - minTailLength;
    for (; shrunkLength >= 0; shrunkLength--) {
      query =
        mode === QueryMode.Loose
          ? // Use two first elements and rest of tail
            originalQueryNotStrict(
              pathObjects
                .slice(0, 2)
                .concat(...pathObjects.slice(-shrunkLength - minTailLength)),
              pathObjects.length - minTailLength,
            )
          : originalQueryNotStrict(
              pathObjects,
              pathObjects.length - minTailLength - shrunkLength - 1,
              mode === QueryMode.Strict,
            );
      const result = executeQuery(query, hashObj, lastEl);

      if (result) {
        return result;
      }
    }
  };

  // TODO: combine next two loops to iterate floating path (from whole to tail only)
  // with floating depth of strict comparison (from strict to loose)

  const modeList = [
    // find element with strict query - full path of elements + nth-child
    QueryMode.Strict,
    // find element - full path of elements but without nth-child
    QueryMode.Medium,
    // use two first elements in query and rest of tail
    QueryMode.Loose,
  ];

  for (let i = 0; i < modeList.length; i++) {
    const result = tryToFindElement(modeList[i]);
    if (result) {
      return result;
    }
  }

  return null;
};
