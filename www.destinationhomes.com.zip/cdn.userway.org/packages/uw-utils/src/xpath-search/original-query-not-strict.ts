import { PathObject } from './types';

// prepare query selector based on path object
export const originalQueryNotStrict = (
  pathObject: PathObject[],
  tailIdxStart: number,
  useOrderInSelector = false,
): string =>
  pathObject
    .reduce((res, current) => {
      // using tag and its serial number to create query string
      // if idx of current operated element greater then tailIdxStart then prevent inserting other elements between tail elements
      const position =
        useOrderInSelector && current.position
          ? ':nth-of-type(' + current.position + ')'
          : '';
      res += current.tag + position + (current.idx >= tailIdxStart ? '>' : ' ');
      return res;
    }, '')
    .slice(0, -1);
