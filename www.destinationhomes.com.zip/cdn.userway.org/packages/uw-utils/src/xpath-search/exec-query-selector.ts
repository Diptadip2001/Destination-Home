// exec query selector
export const execQuerySelector = (queryStr: string): Array<HTMLElement> => {
  return [].slice.call(document.querySelectorAll(queryStr));
};
