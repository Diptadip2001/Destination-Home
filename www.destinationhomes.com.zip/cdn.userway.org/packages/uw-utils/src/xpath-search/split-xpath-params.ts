import { HashedParams } from './types';
import { paramMap, SEPARATOR } from './constants';

export const splitXpathParams = (
  xpathStr: string,
): { xpath: string; params: HashedParams } => {
  const [xpath, elementParams] = xpathStr.split(SEPARATOR);
  let params: HashedParams = { innerText: '' };
  if (elementParams) {
    const [innerText, ...restParams] = elementParams.split(';');
    params.innerText = innerText;
    restParams.forEach((paramString) => {
      const [key, value] = paramString.split(':');
      const paramsKey = paramMap[key as keyof typeof paramMap];
      params[paramsKey as keyof HashedParams] = value;
    });
  }

  return { xpath, params };
};
