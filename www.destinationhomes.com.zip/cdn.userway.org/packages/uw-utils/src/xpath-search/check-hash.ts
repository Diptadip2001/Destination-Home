import { hashString } from '../hash-string';

import { HashedParams } from './types';

export const checkHash = (
  element: HTMLElement,
  params: HashedParams | null,
) => {
  if (params === null) {
    return true;
  }

  const innerTextHash = element.innerText
    ? hashString(element.innerText).toString()
    : '';
  if (params.innerText.toString() !== innerTextHash) {
    return false;
  }

  const hrefHash = element.hasAttribute('href')
    ? hashString(element.getAttribute('href') as string).toString()
    : '';
  if (params.href && params.href !== hrefHash) {
    return false;
  }

  const srcHash = element.hasAttribute('src')
    ? hashString(element.getAttribute('src') as string).toString()
    : '';
  if (params.src && params.src !== srcHash) {
    return false;
  }

  return true;
};
