import { HashedParams, PathObject } from './types';

export const preparePathObjects = (
  xpath: string,
  params?: HashedParams,
): PathObject[] => {
  const xpathWithoutFirstSlash = xpath[0] === '/' ? xpath.slice(1) : xpath;
  const xpathItems: string[] = xpathWithoutFirstSlash.split('/');

  return xpathItems.map((partOfPath: string, index: number) => {
    const pathParams = partOfPath.toLowerCase();
    const [, tag, position] = pathParams.match(/(\S+)\[(\S+)?\]/) || [
      ,
      pathParams,
    ];
    const isLastItem = xpathItems.length - 1 === index;

    const result: PathObject = { idx: index, tag };

    if (position) {
      result.position = +position;
    }

    if (isLastItem && params) {
      result.params = params;
    }

    return result;
  });
};
