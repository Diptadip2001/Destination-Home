import { execQuerySelector } from './exec-query-selector';
import { checkHash } from './check-hash';

import { HashedParams, PathObject } from './types';

// NEW: hashObject: HashedParams | null
export const executeQuery = (
  query: string,
  hashObject: HashedParams | null = null,
  lastEl: PathObject,
) => {
  const foundElementsList = execQuerySelector(query);

  if (foundElementsList.length === 1) {
    // element found
    if (lastEl.params == null) {
      return foundElementsList[0];
    }

    if (checkHash(foundElementsList[0], hashObject)) {
      return foundElementsList[0];
    }
  }

  if (foundElementsList.length > 1) {
    // more than one found
    if (lastEl.params == null) {
      return null; // more than one found
    }
    const verifiedElements = foundElementsList.filter((element) =>
      checkHash(element, hashObject),
    );
    if (verifiedElements.length === 1) {
      return verifiedElements[0];
    }
  }

  return null; // nothing found
};
