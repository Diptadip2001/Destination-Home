export const BODY_INDEX = 2;
export const SEPARATOR = '|';
export const paramMap = {
  i: 'innerText',
  s: 'src',
  h: 'href',
};
