interface PostMessageData {
  action: string;
  type?: string;
  isUserWay?: boolean;
  data?: { [key: string]: any };
  state?: string;
  config?: { [key: string]: any };
  [key: string]: any;
}

export const postMessage = (
  data: PostMessageData,
  iframes: string[] = ['userway'],
): void => {
  const newData = { ...data, isUserWay: true };

  iframes.forEach((name: string) => {
    let iframe = (window.frames as any)[name];

    if (!iframe || typeof iframe.postMessage !== 'function') {
      try {
        iframe = document.querySelector(`iframe[name=${name}]`);
        iframe = iframe ? iframe.contentWindow : null;
      } catch (e) {
        console.error(e);
      }
    }

    iframe && iframe.postMessage(newData, '*');
  });
};
