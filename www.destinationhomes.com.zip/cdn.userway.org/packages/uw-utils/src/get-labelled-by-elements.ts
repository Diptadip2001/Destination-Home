// getLabelledByElements function retrieves elements
// based on the provided IDs in the aria-labelledby attribute
// and generates a concatenated text taken from children elements

const isHidden = (element: Element): boolean => {
  let style = window.getComputedStyle(element);
  return style.display === 'none';
};

export const isElementNode = (node: Node): boolean => {
  return !['#text', '#comment'].includes(node.nodeName);
};

const isHideFromReaders = (element: Element): boolean => {
  if (!isElementNode(element)) {
    return false;
  }
  let ariaHiddenAttribute = element.getAttribute('aria-hidden');
  let hiddenAttribute = element.getAttribute('hidden');

  return (
    isHidden(element) ||
    ariaHiddenAttribute === 'true' ||
    (hiddenAttribute !== null && hiddenAttribute !== '')
  );
};

const invalidTags = ['NOSCRIPT', 'SCRIPT', 'style'];

const compose = (
  children: NodeListOf<ChildNode>,
  textAppendTo: string,
): string => {
  //this function will be reviewed and probably changed
  for (let i = 0; i < children.length; i++) {
    let childNode = children[i];
    switch (childNode.nodeType) {
      case Node.TEXT_NODE:
        textAppendTo +=
          ' ' + childNode.textContent?.trim().replace(/(\n|\r\n)/g, '');
        break;

      case Node.ELEMENT_NODE:
        if (
          invalidTags.includes((childNode as Element).tagName) ||
          isHideFromReaders(childNode as Element)
        ) {
          break;
        }

        const ariaHidden = (childNode as Element).getAttribute('aria-hidden'),
          alt = (childNode as Element).getAttribute('alt'),
          ariaLabel = (childNode as Element).getAttribute('aria-label');

        if (!ariaHidden || ariaHidden === 'false') {
          if (ariaLabel) {
            textAppendTo += ' ' + ariaLabel;
            break;
          } else if (alt) {
            textAppendTo += alt + ' ';
          }
          if ((childNode as Element).tagName !== 'IMG') {
            textAppendTo = compose(
              (childNode as ChildNode).childNodes,
              textAppendTo,
            );
          }
        }
        break;
    }
  }
  return textAppendTo;
};

export const composeElementTextRepresentation = (
  element: Element,
  textAppendTo: string = '',
): string => {
  //this function will be reviewed and probably changed
  let modifiedText = textAppendTo;
  textAppendTo = compose(element.childNodes, modifiedText);

  return textAppendTo.replace(/\s+/g, ' ').trim();
};

export const getLabelledByElements = (ariaLabelledBy: string): string => {
  let ids = ariaLabelledBy.split(' '),
    textToRead = '';
  for (let i = 0; i < ids.length; i++) {
    let labelEl = document.getElementById(ids[i]);
    if (labelEl) {
      textToRead = ' ' + composeElementTextRepresentation(labelEl, textToRead);
    }
  }
  return textToRead;
};
