/**
 * Function creates invisible element that contain some text
 * for some tags (e.g. label) existence of content is necessary,
 * but we can't just attach text content to host site, because it changes rendering
 * that is why we create invisible element, invisible - for users, available - for screen readers
 */
export const createScreenRearedElement = (content: string, className = '') => {
  const span = document.createElement('span');
  span.textContent = content;
  span.setAttribute(
    'style',
    'color: #ffffff!important;background: #000000!important;clip: rect(1px, 1px, 1px, 1px)!important;clip-path: inset(50%)!important;height: 1px!important;width: 1px!important;margin: -1px!important;overflow: hidden!important;padding: 0!important;position: absolute!important;',
  );
  span.setAttribute('class', className);
  span.setAttribute('data-uw-reader-element', '');
  span.setAttribute('data-uw-rm-ignore', '');

  return span;
};
