const base64RE = new RegExp('^(data:)');
const includesImgExtensionRegex = new RegExp(
  '(.)(gif|jpe?g|tiff?|png|webp|bmp)',
  'i',
);

export const normalizeSrc = (originalSrc: string) => {
  if (base64RE.test(originalSrc)) {
    return originalSrc;
  }

  if (!!originalSrc) {
    originalSrc = originalSrc
      .replace(/^(http|https)(:\/\/)/, '')
      .replace(/^(www\.)/, '');
  }

  const matches = originalSrc.match(includesImgExtensionRegex);

  if (matches?.index && matches?.length) {
    return originalSrc.substring(0, matches.index + matches[0].length);
  }

  return originalSrc.split('?')[0];
};
