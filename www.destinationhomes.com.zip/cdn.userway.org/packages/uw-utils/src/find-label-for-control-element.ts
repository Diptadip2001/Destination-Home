import {
  getLabelledByElements,
  composeElementTextRepresentation,
} from './get-labelled-by-elements';

const findLabelByForAttr = (id: string): Element | null => {
  const labels = document.querySelectorAll('LABEL');

  for (let i = 0; i < labels.length; i++) {
    if ((labels[i] as HTMLLabelElement).htmlFor === id) {
      return labels[i];
    }
  }

  return null;
};

export const findLabelForControlElement = (element: HTMLElement): string => {
  // 1. Parent 'label' element
  let parentLabel = element.closest('label');
  let labelText = '';
  if (parentLabel) {
    for (let node of parentLabel.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        labelText += node.textContent;
      }
    }
    if (labelText.trim()) {
      return labelText.trim();
    }
  }

  // 2. 'label' element with for attr
  if (element.id) {
    let labelByFor = findLabelByForAttr(element.id);
    if (labelByFor) {
      return composeElementTextRepresentation(labelByFor, '');
    }
  }

  // 3. 'aria-label' or  'aria-labelledby' attribute
  const ariaLabel = element.getAttribute('aria-label');
  const ariaLabelledBy = element.getAttribute('aria-labelledby');
  if (ariaLabel) {
    return ariaLabel;
  } else if (ariaLabelledBy) {
    return getLabelledByElements(ariaLabelledBy);
  }

  // 4. 'title' attribute
  const title = element.getAttribute('title');
  if (title) {
    return title;
  }

  // 6. Inner content
  const innerContent = composeElementTextRepresentation(element, '');
  return innerContent || '';
};
