export const onElementVisible = (
  element: HTMLElement,
  callback: Function,
): void => {
  new IntersectionObserver((entries, observer) => {
    for (const entry of entries) {
      if (entry.intersectionRatio > 0) {
        callback(element);
        observer.disconnect();
      }
    }
  }).observe(element);
};
