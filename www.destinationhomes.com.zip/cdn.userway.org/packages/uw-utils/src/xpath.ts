import { hashString } from './hash-string';

export const xpath = (element: HTMLElement, isParentEl = false): string => {
  if (element.nodeName.toLowerCase() === 'html') {
    return '/HTML';
  }

  if (element.nodeName.toLowerCase() === 'body') {
    return '/HTML/BODY';
  }

  if (element.nodeName.toLowerCase() === 'head') {
    return '/HTML/HEAD';
  }

  let siblingIndex = 0;
  const siblings = element.parentElement?.children;

  if (!siblings) {
    return '';
  }

  for (let i = 0; i < siblings.length; i++) {
    let sibling = siblings[i];

    if (sibling === element) {
      return (
        xpath(element.parentElement as HTMLElement, true) +
        `/${element.tagName}[${siblingIndex + 1}]` +
        (isParentEl ? '' : getHashedParams(element as HTMLElement))
      );
    }

    if (sibling.tagName === element.tagName) {
      siblingIndex++;
    }
  }

  return '';
};

function getHashedParams(element: HTMLElement): string {
  const attributes = {
    s: 'src',
    h: 'href',
  };

  type AttributesKeys = keyof typeof attributes;

  const textHash = element.innerText ? hashString(element.innerText) : '';

  return (Object.keys(attributes) as AttributesKeys[]).reduce((result, key) => {
    const attribute = attributes[key];
    const attrValue = element.getAttribute(attribute) || '';

    if (
      !element.hasAttribute ||
      !element.hasAttribute(attribute) ||
      attrValue === ''
    ) {
      return result;
    }

    return result + ';' + key + ':' + hashString(attrValue);
  }, '|' + textHash);
}
