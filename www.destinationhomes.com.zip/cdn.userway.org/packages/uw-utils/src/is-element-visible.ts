interface VisibilityOptions {
  skipParentCheck?: boolean;
  shouldBeInViewport?: boolean;
}

const isInViewPort = (rect: DOMRect): boolean => {
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <=
      (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
};

const checkVisibility = (
  element: Element | Document,
  options: VisibilityOptions,
): boolean => {
  if (element === document) {
    return true;
  }
  const htmlElement = element as HTMLElement;

  const computedStyle = getComputedStyle(htmlElement);
  const rect = htmlElement.getBoundingClientRect();
  const inViewPort = isInViewPort(rect);
  const isScaledToZero = rect.width === 0 || rect.height === 0;
  const stylesRule =
    computedStyle.opacity !== '0' &&
    computedStyle.visibility !== 'hidden' &&
    computedStyle.display !== 'none' &&
    computedStyle.visibility !== 'collapse';

  return (
    (htmlElement.offsetWidth > 0 ||
      htmlElement.offsetHeight > 0 ||
      htmlElement.getClientRects().length > 0) &&
    (!options.shouldBeInViewport || inViewPort) &&
    !isScaledToZero &&
    stylesRule
  );
};

export const isElementVisible = (
  element: Element | Document,
  options: VisibilityOptions = {},
): boolean => {
  const modifiedOptions: VisibilityOptions = {
    skipParentCheck: options.skipParentCheck ?? false,
    shouldBeInViewport: options.shouldBeInViewport ?? true,
  };

  let modifiedElement = element;

  let isVisible = checkVisibility(modifiedElement, modifiedOptions);

  if (!modifiedOptions.skipParentCheck) {
    while (
      isVisible &&
      modifiedElement.parentNode &&
      modifiedElement.parentNode !== document
    ) {
      if (
        checkVisibility(modifiedElement.parentNode as Element, {
          shouldBeInViewport: false,
        })
      ) {
        modifiedElement = modifiedElement.parentNode as Element;
      } else {
        isVisible = false;
      }
    }
  }

  return isVisible;
};
