export const getElementAccessibleName = (
  element: HTMLElement,
): string | null => {
  let elementText = element.getAttribute('aria-label')?.trim() ?? '';

  const ariaDescribedBy = element.getAttribute('aria-describedby');
  elementText += ariaDescribedBy
    ? getContentOfAriaReferences(ariaDescribedBy)
    : '';

  if (elementText) {
    return elementText.toLowerCase();
  }

  const ariaLabelledBy = element.getAttribute('aria-labelledby');
  if (ariaLabelledBy) {
    elementText += getContentOfAriaReferences(ariaLabelledBy);
  }

  if (elementText.trim()) {
    return elementText.toLowerCase();
  }

  elementText = element.textContent ?? '';

  if (elementText.trim()) {
    return elementText.toLowerCase();
  }

  const inputElement = element as HTMLInputElement;
  elementText = inputElement.value || '';

  if (
    elementText.trim() &&
    inputElement.type &&
    ['button', 'submit', 'reset'].includes(inputElement.type.toLowerCase())
  ) {
    return elementText.toLowerCase();
  }

  /**
   * Check before img step for improving performance. querySelector is quite expensive,
   * so first need to check does element have children at all.
   * Benchmark test shows that hasChildNodes check before querySelector is twice faster
   * than just simple using of querySelector.
   */
  if (!element.hasChildNodes()) {
    return null;
  }

  let img = element.querySelector('img, *[role="img"]') as HTMLImageElement;
  if (img) {
    elementText = getImageAccessibleName(img) || '';
    if (elementText.trim()) {
      return elementText.toLowerCase();
    }
  }

  return null;
};

const getImageAccessibleName = (img: HTMLImageElement): string | null => {
  const alt = img.alt;
  if (alt && alt.trim()) {
    return alt.trim();
  }

  const ariaLabel = img.getAttribute('aria-label');
  if (ariaLabel && ariaLabel.trim()) {
    return ariaLabel.trim();
  }

  const ariaDescription = img.getAttribute('aria-describedby');
  if (ariaDescription) {
    const content = getContentOfAriaReferences(ariaDescription);
    if (content) {
      return content;
    }
  }

  const ariaLabelledBy = img.getAttribute('aria-labelledby');
  if (ariaLabelledBy) {
    let content = getContentOfAriaReferences(ariaLabelledBy);
    if (content) {
      return content;
    }
  }

  return null;
};

const getContentOfAriaReferences = (ariaRefValue: string): string => {
  const refs = ariaRefValue.split(' ');
  return refs.reduce((content, ref) => {
    const el = document.getElementById(ref.trim());
    return content + (el?.textContent ?? '');
  }, '');
};
