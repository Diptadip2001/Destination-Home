export const AUTO_STRATEGY_VALUE: string = 'AUTO';
