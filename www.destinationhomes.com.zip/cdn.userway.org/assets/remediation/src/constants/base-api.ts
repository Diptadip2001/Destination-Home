export const BASE_API = '__BASE_API__';
export const ENDPOINT_CDN = '__ENDPOINT_CDN__';

export const USERWAY_ADDR: string = '__USERWAY_ADDR__';

export enum PostMessageAction {
  Remediation = 'remediation',
  AriaEditor = 'aria-editor',
}

export enum PostMessageType {
  KeyboardNavEnabled = 'app-key-nav-enabled',
}
