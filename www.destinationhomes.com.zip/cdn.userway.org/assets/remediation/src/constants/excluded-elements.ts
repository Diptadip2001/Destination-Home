export const EXCLUDED_TAG_NAMES = [
  'script',
  'noscript',
  'style',
  'meta',
  'link',
  // svg elements:
  'path',
  'circle',
  'rect',
  'ellipse',
  'line',
  'polygon',
  'polyline',
  'g',
];

export const EXCLUDED_CLASS_NAMES = [
  // widget elements
  '.uwy',
  '.uwy *',
  '.uw-sl *',
];

export const DATA_UW_IGNORE = 'data-uw-ignore';
export const DATA_UW_ELEMENT = 'data-uw-rm-ignore';

export const EXCLUDED_ATTRIBUTES = [DATA_UW_IGNORE, DATA_UW_ELEMENT];
