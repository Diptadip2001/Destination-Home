import { IMAGE_ALT_HELPER_ID } from '../../common/rules/image-alt/constants';
import { ARIA_EDITOR_HELPER_ID } from '../../common/rules/aria-editor/constants';
import { EMPTY_CONTROLS_RULE_ID } from '../../common/rules/empty-controls/constants';
import { FORM_RULE_ID } from '../../common/rules/form-label/constants';

const configFields = ['alt', 'ariaEditor', 'emptyControls', 'forms'] as const;
export type RuleFiled = typeof configFields[number];

/**
 * Function returns config name used in remediation config (tunings) for rule.
 * @param ruleId
 */
export const getRuleConfigName = (ruleId: string): RuleFiled | null => {
  switch (ruleId) {
    case IMAGE_ALT_HELPER_ID:
      return 'alt';
    case ARIA_EDITOR_HELPER_ID:
      return 'ariaEditor';
    case EMPTY_CONTROLS_RULE_ID:
      return 'emptyControls';
    case FORM_RULE_ID:
      return 'forms';
    default:
      return null;
  }
};
