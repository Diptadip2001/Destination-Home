export const getDomainNameFromHref = (element: HTMLElement): string | null => {
  if (!element.hasAttribute('href')) return null;

  const httpUrlPattern = /^https?:\/\/(?:www\.)?([^/?#]+)/;
  const href = element.getAttribute('href') as string;
  const matchResult = href.toLowerCase().match(httpUrlPattern);
  const domainName = matchResult ? matchResult[1] : null;

  return domainName;
};
