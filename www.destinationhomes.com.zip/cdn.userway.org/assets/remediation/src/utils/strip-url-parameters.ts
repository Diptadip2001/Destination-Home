import { IMAGE_EXTENSIONS } from '../common/rules/image-alt/constants';

/* 
Function removes URL parameters, ONLY if they go after the image extension:
Example 1: http://example.com/image.jpg?id=25 ->  http://example.com/image.jpg
Example 2: http://site.us/i.php?t=jpg&w=100 -> http://site.us/i.php?t=jpg&w=100
*/

export const stripUrlParameters = (url: string): string => {
  const imageUrlRegPattern = `(.*\\.(${IMAGE_EXTENSIONS.join('|')}))\\?.*$`;
  const imageUrlRegRule = new RegExp(imageUrlRegPattern);

  const result = url.match(imageUrlRegRule);

  if (result && result[1]) {
    return result[1].toLowerCase();
  }

  return url;
};
