import {
  EXCLUDED_ATTRIBUTES,
  EXCLUDED_TAG_NAMES,
} from '../../constants/excluded-elements';

export const getAllElements = (): NodeListOf<HTMLElement> => {
  const tagNamesList = EXCLUDED_TAG_NAMES.join(',');
  const attrList = EXCLUDED_ATTRIBUTES.map((attr) => `[${attr}]`).join(',');
  const query = `${tagNamesList},${attrList}`;
  return document.body.querySelectorAll(`*:not(${query})`);
};
