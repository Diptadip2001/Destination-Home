export const getTitleFromPageUrl = (): string => {
  const cutName = (stringsList: string[]): string[] =>
    stringsList.length > 1 ? stringsList.slice(0, -1) : stringsList;

  const { hostname, pathname } = window.location;
  const websiteName = hostname.replace('www.', '').split('.');

  const currentName = cutName(websiteName).join('-');

  const path = pathname.split('/');

  const currentPage = path
    .filter((pathItem) => pathItem)
    .join(' ')
    .replace(/^\d+|\s\d+/g, '') // remove numbers
    .trim();

  return (currentPage + (currentPage ? ' - ' : ' ') + currentName).trim();
};
