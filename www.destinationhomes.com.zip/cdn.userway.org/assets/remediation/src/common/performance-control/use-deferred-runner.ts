import { throttle, debounce } from 'lodash-es';
import {
  REMEDIATION_DEBOUNCE_DELAY,
  REMEDIATION_THROTTLE_DELAY,
  REMEDIATION_DEBOUNCE_MAX_WAIT,
  REMEDIATION_MODE_SWITCH,
} from '../../constants';

interface DeferredRunner {
  run: (elements: HTMLElement[]) => void;
}

let isActivePhase = true;

export const useDeferredRunner = (
  runCallback: (elements: HTMLElement[]) => void,
): DeferredRunner => {
  setTimeout(() => {
    isActivePhase = false;
  }, REMEDIATION_MODE_SWITCH);

  const throttleRemediationRun = throttle(
    (elements): void => runCallback(elements),
    REMEDIATION_THROTTLE_DELAY,
    {
      leading: true,
      trailing: true,
    },
  );

  const debounceRemediationRun = debounce(
    (elements): void => runCallback(elements),
    REMEDIATION_DEBOUNCE_DELAY,
    {
      maxWait: REMEDIATION_DEBOUNCE_MAX_WAIT,
      leading: true,
      trailing: true,
    },
  );

  const run = (elements: HTMLElement[]): void =>
    isActivePhase
      ? throttleRemediationRun(elements)
      : debounceRemediationRun(elements);

  return { run };
};
