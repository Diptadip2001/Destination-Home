export const saveRemediationResults = <T>(
  name: string,
  corrections: T[],
  fixedCount: number,
  toDoCount: number,
): void => {
  const legacyRemediationManager = UserWayWidgetApp.getLib(
    'remediation_manager',
  );
  const legacyHelperOutcome = UserWayWidgetApp.getLib(
    'remediation_helper_outcome',
  );

  if (!legacyHelperOutcome.of) {
    return;
  }

  const result = legacyHelperOutcome.of(
    name,
    { items: corrections },
    null,
    fixedCount,
    toDoCount,
  );

  legacyRemediationManager.HelperCallbackAggregator.onHelperRemediationCompleted(
    result,
  );
};
