import { nodesFilter } from './nodes-filter';
import { TuningsConfig } from '../config/config';
import { onPostMessage } from '../api/on-post-message';
import { PostMessageType } from '../../constants/base-api';

// TODO FILL THE LIST WITH ATTRIBUTES ALLOWED TO OBSERVE
const allowed: string[] = ['aria-label', 'alt'];
const element: HTMLElement = document.documentElement;
const options = {
  attributes: true,
  attributeFilter: allowed,
  childList: true,
  subtree: true,
};

const callbacksSet: Set<(nodes: HTMLElement[]) => void> = new Set();

export const subscribeOnDomUpdates = (
  callback: (nodes: HTMLElement[]) => void,
): void => {
  callbacksSet.add(callback);
};

export const unsubscribeFromDomUpdates = (
  callback: (nodes: HTMLElement[]) => void,
): void => {
  callbacksSet.delete(callback);
};

const observer: MutationObserver = new MutationObserver((domMutations) => {
  const filteredNodes = nodesFilter(domMutations);
  if (filteredNodes.length) {
    callbacksSet.forEach((callbackFn) => callbackFn(filteredNodes));
  }
});

export const initDomObserver = (
  target: HTMLElement | Node = element,
  config = options,
): void => {
  if (!TuningsConfig.tech_rem_on_tab) {
    observer.observe(target, config);
  }

  const unsubscribe = onPostMessage(PostMessageType.KeyboardNavEnabled, () => {
    observer.observe(target, config);
    unsubscribe();
  });
};

export const disableDomObserver = (): void => {
  observer.disconnect();
};
