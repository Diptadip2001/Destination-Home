import {
  EXCLUDED_ATTRIBUTES,
  EXCLUDED_CLASS_NAMES,
  EXCLUDED_TAG_NAMES,
} from '../../constants';

// MUTATED NODES FILTER
const isNodeExcluded = (node: Node): boolean =>
  !(node instanceof HTMLElement) ||
  EXCLUDED_ATTRIBUTES.some((attr) => node.hasAttribute(attr)) ||
  EXCLUDED_CLASS_NAMES.some((cssClass) => node.classList.contains(cssClass)) ||
  EXCLUDED_TAG_NAMES.includes(node.nodeName.toLowerCase());

// MAIN DOM MUTATION FILTER
const mutationFilter = (
  mutation: MutationRecord,
  type: string,
): HTMLElement[] => {
  if (type === 'childList') {
    // get all children elements of added nodes
    const newChildrenElements: HTMLElement[] = [...mutation.addedNodes].reduce(
      (acc, current) => {
        if (current instanceof HTMLElement) {
          const newChildren = [
            ...current.getElementsByTagName('*'),
          ] as HTMLElement[];
          return [...acc, ...newChildren];
        }

        return acc;
      },
      [] as HTMLElement[],
    );

    return [].filter.call(
      [...mutation.addedNodes, ...newChildrenElements],
      (node: Node) => !isNodeExcluded(node),
    );
  }
  if (type === 'attributes')
    return isNodeExcluded(mutation.target)
      ? []
      : ([mutation.target] as HTMLElement[]);

  return [];
};

export const nodesFilter = (mutations: MutationRecord[]): HTMLElement[] => {
  const sorted: HTMLElement[] = [];
  for (const mutation of mutations) {
    sorted.push(...mutationFilter(mutation, mutation.type));
  }
  return sorted;
};
