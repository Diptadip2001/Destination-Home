import { postMessage } from '@uw/utils';
import { buildAccessibilityTreeNode } from './build-accessibility-tree-node/build-accessibility-tree-node';
import { TREE_OBSERVER_ACTION } from './constants';
import { AccessibilityTreeNode, AccessibilityTreeWalkerNode } from './types';

const accessibilityTreeWalker = UserWayWidgetApp.getLib(
  // TODO: tmp using of legacy accessibilityTreeWalker until implementation a new one in new remediation workspace
  'accessibility_tree_walker',
);

const ariaEditorIframeName = 'uwAccessibilityEditor';

let nodes: AccessibilityTreeNode[] = [];

export const generateAccessibilityTree = (): void => {
  let cursor: Node | null = null;
  nodes = [];
  do {
    const treeWalkerItem: AccessibilityTreeWalkerNode = accessibilityTreeWalker.getNextAccessibilityTreeNode(
      cursor,
    );
    if (!treeWalkerItem) {
      break;
    }

    const treeItem = buildAccessibilityTreeNode(treeWalkerItem.node);

    if (treeItem) {
      nodes.push(treeItem);
    }

    cursor = treeWalkerItem.node;
  } while (cursor);

  nodes = nodes.map((node) => {
    const { el, ...tail } = node;
    return tail;
  });

  postMessage(
    {
      action: TREE_OBSERVER_ACTION,
      type: 'userway:ato-output:get',
      data: {
        nodes,
        version: Date.now(),
      },
    },
    [ariaEditorIframeName],
  );
};

export const getNodes = (): AccessibilityTreeNode[] => nodes;
