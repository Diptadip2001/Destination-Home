import { NodeSemanticType } from '../../types/element';

export enum AccessibilityTreeNodeAttributeName {
  TABINDEX = 'tabindex',
  ROLE = 'role',
  TYPE = 'type',
  SRC = 'src',
  ARIA_LEVEL = 'ariaLevel',
  ORIGINAL_ALT = 'originalAlt',
}

export interface Element extends HTMLElement {
  uwAtoId?: number;
}

export interface AccessibilityTreeNodeAttribute {
  name: AccessibilityTreeNodeAttributeName;
  value: string;
}

export interface AccessibilityTreeNode {
  id: number;
  xpath: string;
  label: string;
  tagName: string;
  type: NodeSemanticType;
  hidden: boolean;
  attributes: AccessibilityTreeNodeAttribute[];
  el?: HTMLElement;
  parentXpath?: string;
}

export enum AccessibilityTreeWalkerNodeType {
  UNKNOWN = 'UNKNOWN',
  NOT_ALLOWED = 'NOT_ALLOWED',
  TEXT_NODE = 'TEXT_NODE',
  LANDMARK = 'LANDMARK',
  CONTROL = 'CONTROL',
  HEADING = 'HEADING',
  HAS_ALT_DESCRIPTION = 'HAS_ALT_DESCRIPTION',
  COMPOSED_TEXT_NODES = 'COMPOSED_TEXT_NODES',
  IFRAME = 'IFRAME',
  HIDDEN_FOR_READER = 'HIDDEN_FOR_READER',
}

export interface AccessibilityTreeWalkerNode {
  node: HTMLElement;
  type: AccessibilityTreeWalkerNodeType;
}

export interface IElementAdditionalParams {
  parentXpath?: string;
}

export interface ElementAttributes {
  tagName?: string;
  tabindex?: string;
  role?: string;
  ariaLevel?: string;
  ariaLabel?: string;
  ariaLabelledBy?: string;
  type?: string;
  uwAtoId?: number;
}
