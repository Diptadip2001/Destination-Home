import { getLabelledByElements } from '@uw/utils';
import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';
import { ElementAttributes } from '../types';

export const processLandmarkNode = (
  attributes: ElementAttributes,
): ProcessedElement => {
  let textToRead = '';
  let semanticType;

  if (attributes.ariaLabel) {
    textToRead = attributes.ariaLabel;
  } else if (attributes.ariaLabelledBy) {
    textToRead = getLabelledByElements(attributes.ariaLabelledBy);
  }

  const { tagName } = attributes;
  const { role } = attributes;

  if (tagName === 'FOOTER' || role === 'contentinfo') {
    semanticType = NodeSemanticType.FOOTER;
  } else if (tagName === 'HEADER' || role === 'banner') {
    semanticType = NodeSemanticType.HEADER;
  } else if (tagName === 'FORM' || role === 'form') {
    semanticType = NodeSemanticType.FORM;
  } else if (tagName === 'MAIN' || role === 'main') {
    semanticType = NodeSemanticType.MAIN;
  } else if (tagName === 'NAV' || role === 'navigation') {
    semanticType = NodeSemanticType.NAV;
  } else {
    semanticType = NodeSemanticType.LANDMARK;
  }

  return { semanticType, textToRead };
};
