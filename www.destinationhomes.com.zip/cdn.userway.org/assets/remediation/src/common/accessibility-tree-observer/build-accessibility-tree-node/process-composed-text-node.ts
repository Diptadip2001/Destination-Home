import { composeElementTextRepresentation } from '@uw/utils';
import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';
import { ElementAttributes } from '../types';

export const processComposedTextNode = (
  element: HTMLElement,
  attributes: ElementAttributes,
): ProcessedElement => {
  const semanticType =
    attributes.tagName === 'LI'
      ? NodeSemanticType.LIST_ITEM
      : NodeSemanticType.TEXT;
  const textToRead =
    attributes.ariaLabel || composeElementTextRepresentation(element, '');

  return { semanticType, textToRead };
};
