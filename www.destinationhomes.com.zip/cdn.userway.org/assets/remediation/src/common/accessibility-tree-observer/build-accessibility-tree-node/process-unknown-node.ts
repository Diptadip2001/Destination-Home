import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';
import { ElementAttributes } from '../types';

export const processUnknownNode = (
  element: HTMLElement,
  attributes: ElementAttributes,
): ProcessedElement => {
  let semanticType = NodeSemanticType.TEXT;
  const textToRead = '';

  if (attributes.tagName === 'DIV' && !element.innerHTML) {
    semanticType = NodeSemanticType.LANDMARK;
  }

  return { semanticType, textToRead };
};
