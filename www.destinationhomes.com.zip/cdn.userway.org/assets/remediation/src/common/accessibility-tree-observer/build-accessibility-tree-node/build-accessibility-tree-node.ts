import { xpath } from '@uw/utils';
import {
  AccessibilityTreeNode,
  AccessibilityTreeWalkerNodeType,
  IElementAdditionalParams,
  AccessibilityTreeWalkerNode,
  AccessibilityTreeNodeAttribute,
  ElementAttributes,
  AccessibilityTreeNodeAttributeName,
  Element,
} from '../types';
import { NodeSemanticType } from '../../../types/element';
import { UW_ELEMENTS_CLASSES, UW_IGNORE_ATTR } from '../constants';
import { ProcessedElement } from './types';
import { processTextNode } from './process-text-node';
import { processComposedTextNode } from './process-composed-text-node';
import { processHiddenNode } from './process-hidden-node';
import { processHeadingNode } from './process-heading-node';
import { processLandmarkNode } from './process-landmark-node';
import { processControlNode } from './process-control-node';
import { processNodeWithAlt } from './process-node-with-alt';
import { processUnknownNode } from './process-unknown-node';

const additionalParams: IElementAdditionalParams = {};

const accessibilityTreeWalker = UserWayWidgetApp.getLib(
  'accessibility_tree_walker',
);

let attributesToReturn: AccessibilityTreeNodeAttribute[] = [];
let treeWalkerNodeType;
let identifierInc = 1;

export const isUwElement = (element: HTMLElement): boolean => {
  const isTextNode = element.nodeType === 3;
  return (
    UW_ELEMENTS_CLASSES.some((cl) =>
      element.closest ? element.closest(`.${cl}`) : false,
    ) ||
    (!isTextNode && element.hasAttribute(UW_IGNORE_ATTR))
  );
};

export const checkHidden = (
  element: HTMLElement,
  attributes: ElementAttributes,
): void => {
  const clone = element.cloneNode(true);
  (clone as HTMLElement).removeAttribute('aria-hidden');
  treeWalkerNodeType = accessibilityTreeWalker.identifyElementType(clone);

  const isUnknownType =
    treeWalkerNodeType === AccessibilityTreeWalkerNodeType.UNKNOWN;
  // separate check for images cause identifyElementType method determine element type as unknown
  // for images that don't have alt attribute, but it is possible case for images with aria-hidden true
  if (
    isUnknownType &&
    (attributes.tagName === 'IMG' || attributes.role === 'img')
  ) {
    treeWalkerNodeType = AccessibilityTreeWalkerNodeType.HAS_ALT_DESCRIPTION;
  }
};

const getElementAttributes = (
  element: AccessibilityTreeWalkerNode,
): ElementAttributes => {
  if (!element || !element.type) {
    return {};
  }

  const { node } = element;

  if (
    [
      AccessibilityTreeWalkerNodeType.UNKNOWN,
      AccessibilityTreeWalkerNodeType.NOT_ALLOWED,
      AccessibilityTreeWalkerNodeType.TEXT_NODE,
    ].includes(element.type)
  ) {
    return {
      uwAtoId: (node as Element).uwAtoId,
    };
  }

  return {
    tagName: node.tagName,
    tabindex: node.getAttribute('tabindex') || '',
    role: node.getAttribute('role') || '',
    ariaLevel: node.getAttribute('aria-level') || '',
    ariaLabel: node.getAttribute('aria-label') || '',
    ariaLabelledBy: node.getAttribute('aria-labelledby') || '',
    type: node.getAttribute('type') || '',
    uwAtoId: (node as Element).uwAtoId,
  };
};

const getAttributesToReturn = (
  elementAttributes: ElementAttributes,
): AccessibilityTreeNodeAttribute[] => {
  if (elementAttributes.tabindex) {
    attributesToReturn.push({
      name: AccessibilityTreeNodeAttributeName.TABINDEX,
      value: elementAttributes.tabindex,
    });
  }
  if (elementAttributes.role) {
    attributesToReturn.push({
      name: AccessibilityTreeNodeAttributeName.ROLE,
      value: elementAttributes.role,
    });
  }
  if (elementAttributes.type) {
    attributesToReturn.push({
      name: AccessibilityTreeNodeAttributeName.TYPE,
      value: elementAttributes.type,
    });
  }
  if (elementAttributes.ariaLevel) {
    attributesToReturn.push({
      name: AccessibilityTreeNodeAttributeName.ARIA_LEVEL,
      value: elementAttributes.ariaLevel,
    });
  }
  return attributesToReturn;
};

export const buildAccessibilityTreeNode = (
  element: HTMLElement,
  isTreeBuilding?: boolean,
): AccessibilityTreeNode | null => {
  attributesToReturn = [];

  // to avoid including uw widget elements to element tree
  if (isUwElement(element) && !isTreeBuilding) {
    return null;
  }

  const node: AccessibilityTreeWalkerNode = {
    node: element,
    type: accessibilityTreeWalker.identifyElementType(element),
  };

  const elementAttributes = getElementAttributes(node);

  treeWalkerNodeType = accessibilityTreeWalker.identifyElementType(element);

  const hidden =
    treeWalkerNodeType === AccessibilityTreeWalkerNodeType.HIDDEN_FOR_READER;

  attributesToReturn = getAttributesToReturn(elementAttributes);

  if (hidden) {
    checkHidden(element, elementAttributes); // check what is the element type if element would not be hidden
  }

  let processedElement: ProcessedElement;

  switch (treeWalkerNodeType) {
    case AccessibilityTreeWalkerNodeType.TEXT_NODE:
      processedElement = processTextNode(element);
      additionalParams.parentXpath =
        processedElement.additionalParams?.parentXpath;
      break;
    case AccessibilityTreeWalkerNodeType.COMPOSED_TEXT_NODES:
      processedElement = processComposedTextNode(element, elementAttributes);
      break;
    case AccessibilityTreeWalkerNodeType.HIDDEN_FOR_READER:
      processedElement = processHiddenNode();
      break;
    case AccessibilityTreeWalkerNodeType.HEADING:
      processedElement = processHeadingNode(element, elementAttributes);
      break;
    case AccessibilityTreeWalkerNodeType.LANDMARK:
      processedElement = processLandmarkNode(elementAttributes);
      break;
    case AccessibilityTreeWalkerNodeType.CONTROL:
      processedElement = processControlNode(element, elementAttributes);
      break;
    case AccessibilityTreeWalkerNodeType.HAS_ALT_DESCRIPTION:
      processedElement = processNodeWithAlt(
        element,
        elementAttributes,
        attributesToReturn,
      );
      if (processedElement.attributesToReturn) {
        attributesToReturn = processedElement.attributesToReturn;
      }
      break;
    case AccessibilityTreeWalkerNodeType.UNKNOWN:
      processedElement = processUnknownNode(element, elementAttributes);
      break;
    default:
      processedElement = {
        textToRead: '',
        semanticType: NodeSemanticType.TEXT,
      };
  }

  let id;
  if (elementAttributes.uwAtoId) {
    id = elementAttributes.uwAtoId;
  } else {
    id = identifierInc;
    identifierInc += 1;
    (node.node as Element).uwAtoId = id;
  }

  return {
    id,
    xpath: xpath(element),
    label: processedElement.textToRead.replace(/\|/g, '').trim(),
    tagName: elementAttributes.tagName || '',
    type: processedElement.semanticType,
    hidden,
    attributes: attributesToReturn,
    el: node.node,
    ...additionalParams,
  };
};
