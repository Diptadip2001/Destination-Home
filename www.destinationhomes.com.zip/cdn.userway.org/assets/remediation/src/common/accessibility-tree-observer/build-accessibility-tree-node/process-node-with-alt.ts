import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';
import {
  ElementAttributes,
  AccessibilityTreeNodeAttributeName,
  AccessibilityTreeNodeAttribute,
} from '../types';

export const processNodeWithAlt = (
  element: HTMLElement,
  attributes: ElementAttributes,
  attributesToReturn: AccessibilityTreeNodeAttribute[],
): ProcessedElement => {
  const { tagName, role, ariaLabel } = attributes;
  const alt = element.getAttribute('alt') || '';
  const title = element.getAttribute('title') || '';
  const remediationAltOriginal =
    element.getAttribute('data-uw-rm-ima-original') || '';
  let textToRead = '';
  let semanticType = NodeSemanticType.TEXT;
  const attributesToReturnCopy = attributesToReturn;

  if (tagName === 'IMG' || role === 'img') {
    semanticType = NodeSemanticType.IMAGE;
    attributesToReturnCopy.push({
      name: AccessibilityTreeNodeAttributeName.SRC,
      value: (element as HTMLImageElement).src,
    });
    attributesToReturnCopy.push({
      name: AccessibilityTreeNodeAttributeName.ORIGINAL_ALT,
      value: remediationAltOriginal,
    });
    textToRead = ariaLabel || alt || remediationAltOriginal || textToRead;
  }

  if (tagName === 'ABBR') {
    semanticType = NodeSemanticType.ABBR;
    textToRead = title;
  }

  return {
    semanticType,
    textToRead,
    attributesToReturn: attributesToReturnCopy,
  };
};
