import { xpath } from '@uw/utils';
import { NodeSemanticType } from '../../../types/element';
import { IElementAdditionalParams } from '../types';
import { ProcessedElement } from './types';

export const processTextNode = (element: HTMLElement): ProcessedElement => {
  const semanticType = NodeSemanticType.TEXT;
  let textToRead = '';
  if (element.textContent) {
    textToRead = element.textContent
      .trim()
      .replace(/(\n|\r\n)/g, '')
      .replace(/\s+/g, ' ');
  }

  const additionalParams: IElementAdditionalParams = {};
  if (element.parentElement) {
    additionalParams.parentXpath = xpath(element.parentElement);
  }

  return { semanticType, textToRead, additionalParams };
};
