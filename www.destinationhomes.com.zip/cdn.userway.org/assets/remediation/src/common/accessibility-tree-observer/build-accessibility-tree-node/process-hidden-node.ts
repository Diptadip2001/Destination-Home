import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';

export const processHiddenNode = (): ProcessedElement => {
  const semanticType = NodeSemanticType.UNKNOWN;
  return { semanticType, textToRead: '' };
};
