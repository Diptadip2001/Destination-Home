import { composeElementTextRepresentation } from '@uw/utils';
import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';
import { ElementAttributes } from '../types';

export const processHeadingNode = (
  element: HTMLElement,
  attributes: ElementAttributes,
): ProcessedElement => {
  const semanticType = NodeSemanticType.HEADING;
  const textToRead =
    attributes.ariaLabel || composeElementTextRepresentation(element, '');

  return { semanticType, textToRead };
};
