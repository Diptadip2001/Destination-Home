import {
  composeElementTextRepresentation,
  getLabelledByElements,
  findLabelForControlElement,
} from '@uw/utils';
import { NodeSemanticType } from '../../../types/element';
import { ProcessedElement } from './types';
import { ElementAttributes } from '../types';

export const getTextToRead = (
  element: HTMLElement,
  attributes: ElementAttributes,
): string => {
  if (attributes.ariaLabel) {
    return attributes.ariaLabel;
  }
  if (attributes.ariaLabelledBy) {
    return getLabelledByElements(attributes.ariaLabelledBy);
  }
  return composeElementTextRepresentation(element, '');
};

export const processControlNode = (
  element: HTMLElement,
  attributes: ElementAttributes,
): ProcessedElement => {
  const { tagName, role, type, ariaLabel, ariaLabelledBy } = attributes;
  let isLinkOrButton = false;
  let textToRead = '';
  let semanticType = NodeSemanticType.TEXT;

  if (role === 'menuitem' || role === 'option') {
    textToRead = getTextToRead(element, attributes);
    isLinkOrButton = true;
  } else if (role === 'link' || (tagName === 'A' && !role)) {
    semanticType = NodeSemanticType.LINK;
    textToRead = getTextToRead(element, attributes);
    isLinkOrButton = true;
  } else if (role === 'button' || tagName === 'BUTTON') {
    semanticType = NodeSemanticType.BUTTON;
    textToRead = getTextToRead(element, attributes);
    isLinkOrButton = true;
  } else if (
    tagName === 'INPUT' &&
    (type === 'button' || type === 'submit' || type === 'reset')
  ) {
    semanticType = NodeSemanticType.BUTTON;
    if (ariaLabel) {
      textToRead = ariaLabel;
    } else if (ariaLabelledBy) {
      textToRead = getLabelledByElements(ariaLabelledBy);
    }
    isLinkOrButton = true;
  }

  if (!isLinkOrButton) {
    textToRead = findLabelForControlElement(element);

    if (role === 'checkbox' || (tagName === 'INPUT' && type === 'checkbox')) {
      semanticType = NodeSemanticType.CHECKBOX;
    } else if (role === 'radio' || (tagName === 'INPUT' && type === 'radio')) {
      semanticType = NodeSemanticType.RADIOBUTTON;
    } else if (tagName === 'INPUT') {
      semanticType = NodeSemanticType.INPUT;
    }

    if (tagName === 'TEXTAREA') {
      semanticType = NodeSemanticType.TEXTAREA;
    }

    if (tagName === 'SELECT') {
      semanticType = NodeSemanticType.SELECT;
    }
  }

  return { semanticType, textToRead };
};
