import { generateAccessibilityTree } from './post-message-api';
import { enable, disable } from './accessibility-tree-observer-control';
import { TREE_OBSERVER_ACTION } from './constants';

const postMessageApi = {
  'userway:ato-input:enable': enable,
  'userway:ato-input:disable': disable,
  'userway:ato-input:get': generateAccessibilityTree,
};

export const initAccessibilityTreeObserver = (): void => {
  window.addEventListener('message', (event) => {
    const {
      data: { action, type },
    } = event;
    if (action !== TREE_OBSERVER_ACTION) {
      return;
    }

    if (postMessageApi[type as keyof typeof postMessageApi]) {
      postMessageApi[type as keyof typeof postMessageApi]();
    }
  });
};
