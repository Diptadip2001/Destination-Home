export const TREE_OBSERVER_ACTION = 'accessibility-tree-observer';

export const UW_IGNORE_ATTR = 'data-uw-rm-ignore';

export const UW_ELEMENTS_CLASSES = [
  'uw-sl',
  'uwy',
  'uw-s10-reading-guide',
  'uw-s12-tooltip',
];
