import { generateAccessibilityTree } from './post-message-api';
import {
  subscribeOnDomUpdates,
  unsubscribeFromDomUpdates,
} from '../dom-observers/main-observer';

export const processMeta = {
  enabled: false,
};

export const enable = (): void => {
  if (processMeta.enabled) {
    return;
  }

  processMeta.enabled = true;

  subscribeOnDomUpdates(generateAccessibilityTree);

  generateAccessibilityTree();
};

export const disable = (): void => {
  if (!processMeta.enabled) {
    return;
  }

  processMeta.enabled = false;

  unsubscribeFromDomUpdates(generateAccessibilityTree);
};
