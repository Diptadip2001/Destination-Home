import { getTitleFromPageUrl } from '../../../utils/get-title-from-page-url';
import { RuleParams } from '../../../types/remediation-rule';
import { PROCESSED_ATTR, PROCESSED_ATTR_VALUE } from './constants';

const addProcessedAttr = (element: HTMLTitleElement, title: string): void => {
  element.setAttribute(
    PROCESSED_ATTR,
    title ? PROCESSED_ATTR_VALUE.GENERIC : PROCESSED_ATTR_VALUE.UNKNOWN,
  );
};

export const headerTitleRule = ({
  context: { elements },
}: RuleParams): void => {
  /**
   * At any moment host site framework can attach it own valid title
   * => that means that uw should remove generated title if it exists
   */
  if (elements.length && elements[0].innerHTML?.trim()) {
    const uwTitle = document.querySelector(`title[${PROCESSED_ATTR}]`);
    uwTitle?.remove();
    return;
  }

  /**
   * Title element should be only the one per document
   * this is why header title helper is helper that not based on list of updated elements
   * */
  const titleElement = document.getElementsByTagName('title')[0];

  try {
    if (!titleElement) {
      const newTitleElement = document.createElement('title');
      const newTitle = getTitleFromPageUrl();

      newTitleElement.innerHTML = newTitle;
      addProcessedAttr(newTitleElement, newTitle);
      document.head.appendChild(newTitleElement);
    } else if (
      !titleElement.innerHTML?.trim() &&
      !titleElement.hasAttribute(PROCESSED_ATTR)
    ) {
      const newTitle = getTitleFromPageUrl();

      titleElement.innerHTML = newTitle;
      addProcessedAttr(titleElement as HTMLTitleElement, newTitle);
    }
  } catch (err) {
    if (err instanceof Error) {
      console.error(err);
    }
  }
};
