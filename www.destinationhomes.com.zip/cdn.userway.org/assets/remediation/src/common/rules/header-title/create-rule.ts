import { createRemediationRule } from '../rule-factory/create-remediation-rule';
import { headerTitleRule } from './header-title-rule';
import { elementCanBeProcessed } from './is-target-element';

export const HeaderTitleRule = createRemediationRule({
  ruleId: 'header-title',
  rule: headerTitleRule,
  isTargetElement: elementCanBeProcessed,
  /**
   * title rule contains logic that is not related to elements updates => we should
   * run it even if target elements weren't found
   */
  forceRun: true,
});
