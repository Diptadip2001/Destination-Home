import { PROCESSED_ATTR } from './constants';

export const elementCanBeProcessed = (element: HTMLElement): boolean => {
  const isTitle = element.tagName.toLowerCase() === 'title';
  const alreadyProcessed = element.hasAttribute(PROCESSED_ATTR);

  return isTitle && !alreadyProcessed;
};
