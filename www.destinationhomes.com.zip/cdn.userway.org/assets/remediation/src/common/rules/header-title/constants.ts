export const PROCESSED_ATTR = 'data-uw-rm-title';
export const PROCESSED_ATTR_VALUE = {
  UNKNOWN: 'un',
  GENERIC: 'gn',
};
