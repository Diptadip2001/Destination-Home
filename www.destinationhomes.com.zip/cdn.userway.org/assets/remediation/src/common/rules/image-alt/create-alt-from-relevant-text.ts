import { removeNewlinesSpaces } from './utils';
import { isExistingAltInvalid } from './utils/is-existing-alt-invalid';
import { getAltFromClosestTextNode } from './utils/get-alt-from-closest-text-node';
import { searchInAttributesDictionary } from './utils/search-in-attributes-dictionary';

export const createAltFromRelevantText = (
  image: HTMLElement,
): string | null => {
  // Case: generate alt from figcaption
  const figureElement = image.closest('figure');
  if (figureElement) {
    const figcaptionElement = Array.from(figureElement.children).find(
      (childElement) => childElement.tagName.toLowerCase() === 'figcaption',
    );

    if (figcaptionElement) {
      const figcaptionText = removeNewlinesSpaces(
        figcaptionElement.textContent as string,
      );

      if (figcaptionText && !isExistingAltInvalid(figcaptionText))
        return figcaptionText;
    }
  }

  // Case: generate alt from image css classes or id
  const imageCssClasses: string = [].slice.call(image.classList).join(' ');
  const imageId = image.id || '';
  const combinedAttributesText = imageCssClasses + imageId;
  const altFromAttributes = searchInAttributesDictionary(
    combinedAttributesText,
  );
  if (altFromAttributes) return altFromAttributes;

  // Case: generate alt from surrounding text nodes, including ancestors
  const altFromClosestText = getAltFromClosestTextNode(image);
  if (altFromClosestText) return altFromClosestText;

  return null;
};
