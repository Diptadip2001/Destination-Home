import {
  BASE64_REGEXP,
  DecorativeReason,
  ImageProcessedResult,
  MICRO_IMAGE_SIZE,
  MIN_IMAGE_SIZE,
  SVG_REGEXP,
} from '../constants';
import { getImageSource, hasMinAllowedSize } from './image-utils';
import { isExistingAltInvalid } from './is-existing-alt-invalid';
import { isExcludedDomainImage } from './is-excluded-domain-image';
import { hasWrongSrc } from './has-wrong-src';
import { hasWrongAspectRatio } from './has-wrong-aspect-ratio';
import { isImageSizeDetectable } from './is-image-size-detectable';

export const shouldBeDecorative = (
  imageElement: HTMLImageElement,
): DecorativeReason | null => {
  const imageSrc = getImageSource(imageElement);
  const isInvalidAlt = isExistingAltInvalid(imageElement.alt);
  const imageHasComputedSize = isImageSizeDetectable(imageElement);

  // # image src has wrong URL (high priority check)
  const isImageSrcWrong = hasWrongSrc(imageSrc);
  if (isImageSrcWrong) {
    return DecorativeReason.WRONG_SRC;
  }

  // # image src includes excluded domain  (high priority check)
  const isImageDomainExcluded = isExcludedDomainImage(imageSrc);
  if (isImageDomainExcluded) {
    return DecorativeReason.EXCLUDED_SRC;
  }

  // # image is very small (high priority check)
  const isMicroImage = imageHasComputedSize
    ? !hasMinAllowedSize(imageElement, MICRO_IMAGE_SIZE)
    : false;
  if (isMicroImage) {
    return DecorativeReason.MICRO_SIZE;
  }

  // # image has wrong aspect ratio (high priority check)
  const isWrongAspectRatio = imageHasComputedSize
    ? hasWrongAspectRatio(imageElement)
    : false;
  if (isWrongAspectRatio) {
    return DecorativeReason.ASPECT_RATIO;
  }

  // # image is base 64
  // TODO: add support of base64 after BE implementation of sending src hash to alt enpoint
  const isBase64 = BASE64_REGEXP.test(imageSrc);

  if (isBase64) {
    return DecorativeReason.BASE64;
  }

  // # image is hidden for screen readers
  const hiddenForReaders =
    imageElement.getAttribute('aria-hidden') === 'true' ||
    imageElement.getAttribute('role') === 'presentation' ||
    imageElement.getAttribute('role') === 'none';

  if (hiddenForReaders) {
    return DecorativeReason.HIDDEN_FROM_SCREEN_READER;
  }

  // # image is svg and doesn't have own alt attribute
  const isSvgFile = SVG_REGEXP.test(imageSrc);

  if (isSvgFile && isInvalidAlt) {
    return DecorativeReason.SVG;
  }

  // # image is smaller than allowed size and doesn't have own alt attribute or has invalid alt
  const hasCorrectSize = imageHasComputedSize
    ? hasMinAllowedSize(imageElement, MIN_IMAGE_SIZE)
    : true;
  if (!hasCorrectSize && isInvalidAlt) {
    return DecorativeReason.SMALL_SIZE;
  }

  return null;
};

export const getDecorativeReasonAttribute = (
  reason: DecorativeReason,
): ImageProcessedResult => {
  switch (reason) {
    case DecorativeReason.ASPECT_RATIO:
      return ImageProcessedResult.AspectRatio;
    case DecorativeReason.BASE64:
      return ImageProcessedResult.Base64;
    case DecorativeReason.EXCLUDED_SRC:
      return ImageProcessedResult.Excluded;
    case DecorativeReason.SVG:
      return ImageProcessedResult.Svg;
    case DecorativeReason.MICRO_SIZE:
      return ImageProcessedResult.Micro;
    case DecorativeReason.SMALL_SIZE:
      return ImageProcessedResult.Small;
    case DecorativeReason.WRONG_SRC:
      return ImageProcessedResult.InvalidSrc;
    case DecorativeReason.HIDDEN_FROM_SCREEN_READER:
    default:
      return ImageProcessedResult.Hidden;
  }
};
