import { xpath } from '@uw/utils';
import { RelevantTextStorage } from '../types';

/* 
This storage is intended to minimize the number of text searches performed. When we find text for a particular image, we add it to the storage and retrieve it later.
*/
let relevantTextStorage: RelevantTextStorage = {};

export const clearRelevantTextStorage = (): void => {
  relevantTextStorage = {};
};

export const addRelevantTextToStorage = (
  image: HTMLImageElement,
  text: string,
): void => {
  const imageXpath = xpath(image);
  relevantTextStorage[imageXpath] = text;
};

export const getRelevantTextFromStorage = (
  image: HTMLImageElement,
): string | null => {
  const imageXpath = xpath(image);
  return relevantTextStorage[imageXpath] || null;
};
