import { removeNewlinesSpaces } from '.';

import {
  CONTAINING_ALT_ELEMENTS_TAGS,
  CONTAINING_ALT_ELEMENTS_ROLES,
} from '../constants';

// filter allows only not empty text nodes and elements with allowed tags/roles
export const filterNodes = (nodeItem: Node): boolean => {
  const isElementTypeNode = nodeItem.nodeType === Node.ELEMENT_NODE;
  const isTextTypeNode = nodeItem.nodeType === Node.TEXT_NODE;

  if (!isTextTypeNode && !isElementTypeNode) return false;

  if (isElementTypeNode && nodeItem.nodeName.toLowerCase() === 'img')
    return true;

  // for text nodes filter empty text nodes
  if (isTextTypeNode)
    return !!removeNewlinesSpaces(nodeItem.textContent as string);

  const isNodeHasAllowedTagname = CONTAINING_ALT_ELEMENTS_TAGS.some(
    (tag) => tag === (nodeItem as Element).nodeName.toLowerCase(),
  );
  const isNodeHasAllowedRole = CONTAINING_ALT_ELEMENTS_ROLES.some(
    (role) =>
      role === (nodeItem as Element).getAttribute('role')?.toLowerCase(),
  );

  return isNodeHasAllowedTagname || isNodeHasAllowedRole;
};
