import { BASE64_REGEXP } from '../constants';

// return true, if image src is wrong
export const hasWrongSrc = (url: string): boolean => {
  if (!url) return true;
  if (url.match(BASE64_REGEXP)) return false;

  // url starts from http(s) + domain + image extension + optional parameters
  const correctImageUrlPattern = new RegExp(
    `^https?://.{1,256}\\.[a-z]{2,6}/.+$`,
    'i',
  );

  return !correctImageUrlPattern.test(url);
};
