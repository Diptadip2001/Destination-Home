import { ImageCorrection, UpdateImageInfo } from './types';
import { IMAGE_ORIGINAL_ALT_ATTR } from './constants';
import { convertToCorrectionInfo, makeDecorative } from './utils/image-utils';
import { initConfig } from '../../config/config';
import { sendRemediationResults } from './utils/process-images';

const getImagesFromDom = (src: string): NodeListOf<HTMLImageElement> => {
  // some images can have src without protocol, so need to cover both cases
  const srcWithoutProtocol = src.replace(/^https?:\/\//, '');
  return document.querySelectorAll(
    `img[src*="${srcWithoutProtocol}" i],img[srcset*="${srcWithoutProtocol}" i]`,
  );
};

export const revertImage = ({ src }: ImageCorrection): void => {
  const images = getImagesFromDom(src);

  for (const image of images) {
    const originalAlt = image.getAttribute(IMAGE_ORIGINAL_ALT_ATTR);
    if (originalAlt !== null) {
      image.setAttribute('alt', originalAlt);
    }
  }
};

export const updateImageInDom = ({
  src,
  decorative,
  alt,
  role,
}: UpdateImageInfo): void => {
  const images = getImagesFromDom(src);

  if (!images.length) {
    return;
  }

  for (const image of images) {
    // # Apply alt attribute
    image.setAttribute('alt', alt ?? '');

    // # Apply decorative flag
    if (decorative) {
      makeDecorative(image);
    } else {
      if (
        image.getAttribute('role') === 'presentation' ||
        image.getAttribute('role') === 'none'
      ) {
        image.removeAttribute('role');
      }

      if (image.hasAttribute('aria-hidden')) {
        image.removeAttribute('aria-hidden');
      }
    }

    // # for images with role link/button/heading also set aria-label (role data can be received from a11y-editor)
    if (['link', 'button', 'heading'].includes(role)) {
      image.setAttribute('aria-label', alt);
    }
  }

  sendRemediationResults([
    convertToCorrectionInfo(images[0], {
      approved: true,
      decorative,
      fixedByUserWay: false,
    }),
  ]);
};

export const updateImgAltsConfig = (): void => {
  // TODO: change this update after implementation using of separate endpoint for image config
  initConfig();
};
