export const EXCLUDED_DOMAINS = {
  automaticcoupons: /automaticcoupons/,
  'shopping.yahoo': /shopping\.yahoo/,
  shopperapproved: /shopperapproved/,
  rakuten: /rakuten/,
  'translate.google': /translate\.google/,
  'maps.googleapis.com': /maps\.googleapis\.com/,
  's.w.org': /s\.w\.org/,
  avatar: /avatar/,
  companylogos: /companylogos/,
  favicon: /favicon/,
  activecampaign: /lt\.php(.*)?l=open/,
  aweber: /openrate\.aweber\.com/,
  bananatag: /bl-1\.com/,
  boomerang: /mailstat\.us\/tr/,
  'campaign monitor': /cmail(\d+)\.com\/t\//,
  'cirrus insight': /tracking\.cirrusinsight\.com/,
  close: /close\.com\/email_opened/,
  'constant contact': /rs6\.net\/on\.jsp/,
  contactmonkey: /contactmonkey\.com\/api\/v1\/tracker/,
  convertkit: /convertkit-mail\.com\/o/,
  'critical impact': /portal\.criticalimpact\.com\/c2\//,
  emarsys: /emarsys\.com\/e2t\/o/,
  gem: /zen\.sr\/o/,
  getnotify: /email81\.com\/case/,
  getresponse: /getresponse\.com\/open\.html/,
  growthdot: /growthdot\.com\/api\/mail-tracking/,
  front: /app\.frontapp\.com\/(.*)?\/seen/,
  hubspot: /t\.(hubspotemail|hubspotfree|signaux|senal|sidekickopen|sigopn)/,
  icontact: /click\.icptrack\.com\/icp/,
  intercom: /(via\.intercom\.io\/o)|(intercom-mail\.com\/via\/o)/,
  litmus: /emltrk\.com/,
  mailchimp: /list-manage\.com\/track/,
  mailgun: /email\.(mailgun|mg)(.*)?\/o/,
  mailjet: /mjt\.lu\/oo/,
  mailspring: /getmailspring\.com\/open/,
  mailtrack: /(mailtrack\.io\/trace)|(mltrk\.io\/pixel)/,
  mandrill: /mandrillapp\.com\/track/,
  marketo: /resources\.marketo\.com\/trk/,
  mixmax: /(email|track)\.mixmax\.com/,
  mixpanel: /api\.mixpanel\.com\/track/,
  nethunt: /nethunt\.co(.*)?\/pixel\.gif/,
  newton: /tr\.cloudmagic\.com/,
  outreach: /api\/mailings\/opened/,
  phplist: /phplist\.com\/lists\/ut\.php/,
  polymail: /polymail\.io/,
  postmark: /pstmrk\.it\/open/,
  'return path': /returnpath\.net\/pixel\.gif/,
  sailthru: /sailthru\.com\/trk/,
  salesforce: /nova\.collect\.igodigital\.com/,
  sendgrid: /wf\/open\?upn/,
  sendy: /sendy\/t\//,
  streak: /mailfoogae\.appspot\.com/,
  superhuman: /r\.superhuman\.com/,
  thunderhead: /na5\.thunderhead\.com/,
  tinyletter: /tinyletterapp\.com.*open\.gif/,
  yamm: /yamm-track\.appspot/,
  yesware: /t\.yesware\.com/,
  'zendesk sell': /futuresimple\.com\/api\/v1\/sprite\.png/,
};

export const ATTRIBUTES_DICTIONARY = ['icon', 'cart', 'logo'];

export const CONTAINING_ALT_ELEMENTS_TAGS = [
  'h1',
  'h2',
  'h3',
  'h4',
  'h5',
  'h6',
  'span',
  'a',
  'p',
  'figcaption',
  'caption',
  'div',
];
export const CONTAINING_ALT_CHILD_ELEMENTS_TAGS = [
  'a',
  'span',
  'strong',
  'em',
  'b',
  'i',
  'q',
  'mark',
];
export const CONTAINING_ALT_ELEMENTS_ROLES = ['heading'];
export const ALT_FROM_AROUND_TEXT_PARENTS_LIMIT = 2;

export const BASE64_REGEXP = new RegExp('^(data:)');
export const SVG_REGEXP = new RegExp(/^.+\.svg$/);
export const MIN_IMAGE_SIZE = 50;
export const MIN_IMAGE_SIZE_FOR_PROCESSING = 10;
export const MICRO_IMAGE_SIZE = 5;
export const MAX_ASPECT_RATIO = 10;
export const ALT_MAX_LENGTH = 255;

export const enum DecorativeReason {
  EXCLUDED_SRC = 'EXCLUDED_SRC',
  HIDDEN_FROM_SCREEN_READER = 'HIDDEN_FROM_SCREEN_READER',
  BASE64 = 'BASE64',
  SVG = 'SVG',
  SMALL_SIZE = 'SMALL_SIZE',
  MICRO_SIZE = 'MICRO_SIZE',
  WRONG_SRC = 'WRONG_SRC',
  ASPECT_RATIO = 'ASPECT_RATIO',
}

export const SHOW_IN_WIDGET_REMEDIATION_LIST = [
  DecorativeReason.SVG,
  DecorativeReason.SMALL_SIZE,
  DecorativeReason.HIDDEN_FROM_SCREEN_READER,
];

export const IMAGE_ORIGINAL_ALT_ATTR = 'data-uw-rm-alt-original';
export const IMAGE_ALT_HELPER_ID = 'REMEDIATION_IMAGE_MISSING_ALT';
export const IMAGE_PROCESSED_ATTR = 'data-uw-rm-alt';

export const IMG_ALTS_DEBOUNCE_TIME = 1000;
export const IMG_ALTS_DEBOUNCE_MAX_TIME = 2000;

export const IMAGE_EXTENSIONS = [
  'jpg',
  'jpeg',
  'png',
  'gif',
  'bmp',
  'tiff',
  'tif',
  'svg',
  'webp',
  'ico',
  'apng',
  'heif',
  'heic',
  'avif',
  'eps',
  'raw',
  'cr2',
  'nef',
  'orf',
  'sr2',
];

export enum ImageProcessedResult {
  CorrectAlt = 'ALT',
  Reverted = 'RT',
  Backend = 'BE',
  Excluded = 'EX',
  Hidden = 'HD',
  Base64 = 'BS64',
  Svg = 'SVG',
  Small = 'SM',
  Micro = 'MC',
  InvalidSrc = 'SRC',
  AspectRatio = 'AR',
  AI = 'AI',
  AIQuotaExceed = 'QU',
  ClosestText = 'CT',
}
