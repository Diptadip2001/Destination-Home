import { MIN_IMAGE_SIZE_FOR_PROCESSING } from '../constants';
import {
  getImageSource,
  getImageSrcGroupName,
  hasMinAllowedSize,
} from './image-utils';
import { isImageSizeDetectable } from './is-image-size-detectable';

export const isThirdPartyTechImage = (
  image: HTMLImageElement,
  majorityGroupName: string,
): boolean => {
  if (!isImageSizeDetectable(image)) return false;

  const imageSrc = getImageSource(image);
  const groupName = getImageSrcGroupName(imageSrc);

  return (
    groupName !== majorityGroupName &&
    !hasMinAllowedSize(image, MIN_IMAGE_SIZE_FOR_PROCESSING)
  );
};
