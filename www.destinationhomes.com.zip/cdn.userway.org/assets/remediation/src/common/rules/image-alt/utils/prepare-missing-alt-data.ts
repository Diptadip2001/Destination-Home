import { stripUrlParameters } from '../../../../utils/strip-url-parameters';
import {
  GetImageAltDirective,
  GetMissingAltsRequest,
  ImageInfo,
} from '../types';
import { shouldBeDecorative } from './should-be-decorative';
import { getImageSource } from './image-utils';
import { isExistingAltInvalid } from './is-existing-alt-invalid';
import { ImageAltConfig } from '../../../config/config';
import { getRelevantTextFromStorage } from './relevant-text-storage';

export const missingAltsComparator = <T extends { src: string }>(
  a: T,
  b: T,
): number => a.src.localeCompare(b.src);

export const prepareMissingAltData = (elements: HTMLElement[]): ImageInfo[] => {
  const images = elements as HTMLImageElement[];

  const result = images
    // remove duplicates
    .filter(
      (image, index) =>
        index ===
        images.findIndex(
          (elem) => getImageSource(image) === getImageSource(elem),
        ),
    )
    .map((image) => {
      const imageElement = image as HTMLImageElement;
      const imageAlt = imageElement.alt.trim();
      const hasCorrectAlt = imageAlt && !isExistingAltInvalid(imageAlt);
      const imageSrc = getImageSource(imageElement);

      return {
        src: stripUrlParameters(imageSrc),
        alt: imageElement.alt.trim(),
        dir:
          hasCorrectAlt ||
          shouldBeDecorative(imageElement) ||
          getRelevantTextFromStorage(imageElement)
            ? GetImageAltDirective.RO
            : undefined,
      };
    });

  // for caching request
  result.sort(missingAltsComparator);
  return result;
};

export const splitIntoChunks = <T>(array: T[], chunksAmount: number): T[][] => {
  const chunkSize = Math.ceil(array.length / chunksAmount);
  const result = [];
  for (let i = 0; i < array.length; i += chunkSize) {
    result.push(array.slice(i, i + chunkSize));
  }
  return result;
};

const getJsonKbSize = (json: string): number => {
  // const size = new TextEncoder().encode(json).length;
  const size = encodeURIComponent(json).length;
  return size / 1024;
};

const MAX_JSON_SIZE_KB = 8;
const MAX_SPLIT_LEVEL = 15;

export const imageInfoToJson = (
  imageInfoList: ImageInfo[],
  splitLevel: number = 1,
): string[] => {
  if (splitLevel >= MAX_SPLIT_LEVEL) {
    console.warn('Max split level exceed');
    return [];
  }

  const splitedList = splitIntoChunks(imageInfoList, splitLevel);

  const result: string[] = [];

  for (const chunk of splitedList) {
    const data: GetMissingAltsRequest = {
      sorted: chunk,
      tier: ImageAltConfig.tier,
    };
    const jsonData = JSON.stringify(data);

    if (getJsonKbSize(jsonData) > MAX_JSON_SIZE_KB) {
      return imageInfoToJson(imageInfoList, splitLevel + 1);
    }

    result.push(jsonData);
  }

  return result;
};
