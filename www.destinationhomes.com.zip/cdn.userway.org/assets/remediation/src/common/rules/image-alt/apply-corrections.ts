import { normalizeSrc } from '@uw/utils';
import { ImageCorrection } from './types';
import { IMAGE_PROCESSED_ATTR, ImageProcessedResult } from './constants';
import {
  convertToCorrectionInfo,
  getImageSource,
  makeDecorative,
} from './utils/image-utils';
import { isExistingAltInvalid } from './utils/is-existing-alt-invalid';
import { CorrectionInfo } from '../../api/missing-alt';
import { RemediationConfig } from '../../config/config';

export const applyCorrectionData = (
  altsCorrections: CorrectionInfo[],
  imageElement: HTMLImageElement,
): ImageCorrection | null => {
  const imageAlt = imageElement.alt.trim();
  const imageSrc = getImageSource(imageElement);

  const imageCorrection = altsCorrections.find(
    (correction) => normalizeSrc(correction.src) === normalizeSrc(imageSrc),
  );

  // check image corrections from BE
  if (!imageCorrection || imageCorrection.alt === null) {
    return null;
  }

  const { decorative, alt, approved, reverted } = imageCorrection;

  // TODO: backend should remove reverted flag if image was set to decorative, because if it is decorative it is automatically not reverted anymore
  if (reverted && !decorative) {
    imageElement.setAttribute(
      IMAGE_PROCESSED_ATTR,
      ImageProcessedResult.Reverted,
    );

    return convertToCorrectionInfo(imageElement, {
      approved: true,
      decorative: !imageAlt,
      fixedByUserWay: false,
    });
  }

  const isAutoStrategy =
    !RemediationConfig || RemediationConfig.strategy === 'AUTO';
  const waitingForApprove = !isAutoStrategy && !approved;

  if (decorative && !waitingForApprove) {
    makeDecorative(imageElement);
  }

  const altCanBeApplied =
    approved || !imageAlt || isExistingAltInvalid(imageAlt);

  if (alt && !waitingForApprove && altCanBeApplied && !decorative) {
    imageElement.setAttribute('alt', alt);
  }

  imageElement.setAttribute(IMAGE_PROCESSED_ATTR, ImageProcessedResult.Backend);

  const result = convertToCorrectionInfo(imageElement, {
    approved,
    decorative,
    fixedByUserWay: true,
  });

  // alt was not applied in DOM, but we still need to show it in widget
  if (waitingForApprove) {
    result.alt = alt;
  }

  return result;
};
