import { debounce } from 'lodash-es';
import { normalizeSrc } from '@uw/utils';
import { RuleParams } from '../../../types/remediation-rule';
import { ImageAltConfig } from '../../config/config';
import {
  getImageSource,
  getPageImagesMajorityGroup,
} from './utils/image-utils';
import {
  IMG_ALTS_DEBOUNCE_MAX_TIME,
  IMG_ALTS_DEBOUNCE_TIME,
  SHOW_IN_WIDGET_REMEDIATION_LIST,
} from './constants';
import { getMissingAlts } from '../../api/missing-alt';
import {
  imageInfoToJson,
  prepareMissingAltData,
} from './utils/prepare-missing-alt-data';
import { processImages } from './utils/process-images';
import { shouldBeDecorative } from './utils/should-be-decorative';
import { createAltFromRelevantText } from './create-alt-from-relevant-text';
import {
  addRelevantTextToStorage,
  clearRelevantTextStorage,
} from './utils/relevant-text-storage';
import { isThirdPartyTechImage } from './utils/is-third-party-tech-image';

const imagesQueue: HTMLElement[] = [];

const clearImagesQueue = (): void => {
  imagesQueue.length = 0;
};

export const imageAltRule = (elements: HTMLElement[]): void => {
  if (!ImageAltConfig) {
    return;
  }

  const { state } = ImageAltConfig;
  if (state === 'ALTS_OFF') {
    return;
  }

  const imgMajorityGroup = getPageImagesMajorityGroup(
    elements as HTMLImageElement[],
  );

  const imagesForBE: HTMLImageElement[] = [];
  const imagesNotForBE: HTMLImageElement[] = [];

  for (const image of elements) {
    const imageEl = image as HTMLImageElement;
    const isThirdPartyImg = isThirdPartyTechImage(imageEl, imgMajorityGroup);
    const decorativeReason = shouldBeDecorative(imageEl);
    const isImageHasDecorativeReasonNotForBE =
      decorativeReason &&
      !SHOW_IN_WIDGET_REMEDIATION_LIST.includes(decorativeReason);
    const isImageNotForBE =
      isImageHasDecorativeReasonNotForBE || isThirdPartyImg;

    if (isImageNotForBE) {
      imagesNotForBE.push(imageEl);
    } else {
      const altFromRelevantText = createAltFromRelevantText(imageEl);
      if (altFromRelevantText) {
        // we store relevant text to get it when processign images
        addRelevantTextToStorage(imageEl, altFromRelevantText);
      }

      imagesForBE.push(imageEl);
    }
  }

  try {
    const imagesList = prepareMissingAltData(imagesForBE);
    const jsonImagesData = imageInfoToJson(imagesList);

    if (jsonImagesData.length) {
      for (const json of jsonImagesData) {
        getMissingAlts(json)
          .then((info) => {
            if (!info) {
              return;
            }

            const { missingAlts } = info;
            const imagesToProcess = imagesForBE.filter((image) =>
              missingAlts.find(
                (item) =>
                  normalizeSrc(item.src) ===
                  normalizeSrc(getImageSource(image)),
              ),
            );
            processImages(imagesToProcess, missingAlts);
          })
          .finally(() => clearRelevantTextStorage());
      }
    }
  } catch (error) {
    console.error(error);
  }
  processImages(imagesNotForBE as HTMLImageElement[]);
  clearImagesQueue();

  if (!imagesForBE.length) {
    clearRelevantTextStorage();
  }
};

const debouncedAltRule = debounce(
  (elements): void => imageAltRule(elements),
  IMG_ALTS_DEBOUNCE_TIME,
  {
    maxWait: IMG_ALTS_DEBOUNCE_MAX_TIME,
    leading: true,
    trailing: true,
  },
);

export const runImgAltRule = ({ context: { elements } }: RuleParams): void => {
  imagesQueue.push(...elements);
  debouncedAltRule(imagesQueue);
};
