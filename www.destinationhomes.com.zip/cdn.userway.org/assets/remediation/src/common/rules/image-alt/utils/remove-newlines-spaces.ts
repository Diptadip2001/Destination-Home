// remove all newlines and replace double spaces by spaces
export const removeNewlinesSpaces = (str: string): string => {
  if (!str) return '';

  return str.replace(/\n/g, '').replace(/ {2,}/g, ' ').trim();
};
