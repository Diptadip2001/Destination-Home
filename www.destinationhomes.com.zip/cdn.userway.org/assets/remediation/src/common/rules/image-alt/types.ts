export interface MissingAltElement {
  normalizedSrc: string;
  src: string;
  fixed: boolean;
}

export interface MissingAltInfo {
  elements: MissingAltElement[];
  page: string;
  siteId: number;
  userId: number;
}

export interface ImageRemediationInfo {
  approved: boolean;
  decorative: boolean;
  fixedByUserWay: boolean;
  // TODO: rename to AI generation in progress (don't forget angular app)
  loadingFromMS?: boolean;
}

export interface ImageCorrection extends ImageRemediationInfo {
  alt: string;
  src: string;
  originalAlt: string;
}

export interface UpdateImageInfo extends ImageCorrection {
  role: string;
}

export enum GetImageAltDirective {
  RO = 'RO', // Read-only (RO). If image description is found in the database, use it; otherwise, ignore the image.
}

export interface ImageInfo {
  src: string;
  alt?: string;
  dir?: GetImageAltDirective;
}

export interface GetMissingAltsRequest {
  sorted: ImageInfo[];
  tier: AltRemediationTier;
}

export interface ImageGroup {
  name: string;
  weight: number;
}

export type AltTextSourceNode = Element | Text;

export interface RelevantTextStorage {
  [key: string]: string;
}
