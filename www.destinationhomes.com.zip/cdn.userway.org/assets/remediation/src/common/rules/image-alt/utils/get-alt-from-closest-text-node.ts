import { getAltFromSiblings } from './get-alt-from-siblings';
import { filterNodes } from './filter-nodes';

import { AltTextSourceNode } from '../types';

import { ALT_FROM_AROUND_TEXT_PARENTS_LIMIT } from '../constants';

/* 
This counter counts the number of ansestor levels, where we try to find a text.
The first level is siblings of our image. The second level is siblings of the parent of our image and so on.
Search was unsuccessful, when we found ONLY invalid text(s) in the siblings.
If we didn't find any text nodes in the siblings, we don't increase the counter, we just skip this empty level and move to the next level.
*/
let unsuccessfulSearchCounter = 0;

export const getAltFromClosestTextNode = (
  currentEl: HTMLElement,
): string | null => {
  const parentEl = currentEl.parentElement;
  if (!parentEl) return null;

  // stop if we have more than 1 image (including our image) in parent node
  const imagesTotal = parentEl.getElementsByTagName('img').length;
  if (imagesTotal > 1) {
    unsuccessfulSearchCounter = 0;
    return null;
  }

  const childNodes = [].slice
    .call(parentEl.childNodes)
    .filter(filterNodes) as AltTextSourceNode[];

  // go to next parent, if current contains only 1 child
  if (childNodes.length === 1) {
    return getAltFromClosestTextNode(parentEl as HTMLElement);
  }

  const altFromSiblings = getAltFromSiblings(currentEl);
  if (altFromSiblings) {
    unsuccessfulSearchCounter = 0;
    return altFromSiblings;
  }

  unsuccessfulSearchCounter += 1;

  // stop recursion, if parent is <body> element
  if (parentEl.tagName.toLowerCase() === 'body') {
    unsuccessfulSearchCounter = 0;
    return null;
  }

  if (unsuccessfulSearchCounter < ALT_FROM_AROUND_TEXT_PARENTS_LIMIT) {
    // we didn't find relevant text in the current parent, go to a next parent
    return getAltFromClosestTextNode(parentEl as HTMLElement);
  }

  unsuccessfulSearchCounter = 0;
  return null;
};
