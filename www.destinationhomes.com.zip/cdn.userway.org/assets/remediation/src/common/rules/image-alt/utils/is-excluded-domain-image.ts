import { EXCLUDED_DOMAINS } from '../constants';

export const isExcludedDomainImage = (url: string): boolean => {
  if (typeof url !== 'string') return false;

  for (const domain of Object.values(EXCLUDED_DOMAINS)) {
    const regRule = new RegExp(domain, 'i');
    if (url.match(regRule)) return true;
  }

  return false;
};
