import { IMAGE_ORIGINAL_ALT_ATTR } from '../constants';
import { ImageCorrection, ImageRemediationInfo, ImageGroup } from '../types';

export const getImageSource = ({ currentSrc, src }: HTMLImageElement): string =>
  currentSrc || src;

export const hasMinAllowedSize = (
  image: HTMLImageElement,
  minSize: number,
): boolean => {
  const RADIX = 10;
  try {
    const { width, height } = window.getComputedStyle(image);
    return (
      parseInt(width, RADIX) > minSize && parseInt(height, RADIX) > minSize
    );
  } catch (e) {
    return false;
  }
};

export const convertToCorrectionInfo = (
  image: HTMLImageElement,
  { decorative, approved, fixedByUserWay, loadingFromMS }: ImageRemediationInfo,
): ImageCorrection => ({
  src: getImageSource(image),
  alt: image.alt,
  originalAlt: image.getAttribute(IMAGE_ORIGINAL_ALT_ATTR) ?? '',
  decorative,
  approved,
  fixedByUserWay,
  loadingFromMS,
});

export const makeDecorative = (image: HTMLImageElement): void => {
  image.setAttribute('role', 'presentation');
  // we don't need aria hidden if role is presentation
  image.removeAttribute('aria-hidden');
  // do not use remove attribute, we should have an alt attribute
  image.setAttribute('alt', '');
};

export const getImageSrcGroupName = (src: string): string => {
  if (!src) {
    return '';
  }

  try {
    const { hostname } = new URL(src);
    return hostname
      .replace(/^https?:\/\//, '')
      .replace(/^www\./, '')
      .replace(/\.[a-zA-Z0-9]*$/, '');
  } catch (err) {
    return '';
  }
};

export const getPageImagesMajorityGroup = (
  images: HTMLImageElement[],
): string => {
  const groups: ImageGroup[] = [];

  for (const img of images) {
    const imageSrc = getImageSource(img);
    const groupName = getImageSrcGroupName(imageSrc);

    if (groupName) {
      let byName = groups.find((gr) => gr.name === groupName);
      if (!byName) {
        byName = {
          name: groupName,
          weight: 0,
        };
        groups.push(byName);
      }
      byName.weight += 1;
    }
  }
  const sortedGroups = groups.sort((grA, grB) =>
    grA.weight < grB.weight ? 1 : -1,
  );

  return sortedGroups[0]?.name ?? '';
};
