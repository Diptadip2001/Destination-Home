import { ALT_MAX_LENGTH, IMAGE_EXTENSIONS } from '../constants';

export const isExistingAltInvalid = (alt: string): boolean => {
  const endsWithFilenameRegex = new RegExp(
    `\\.(${IMAGE_EXTENSIONS.join('|')})$`,
    'i',
  );
  const endsWithFilename = endsWithFilenameRegex.test(alt);

  const tooLong = alt.length > ALT_MAX_LENGTH;

  const empty = !alt.trim();

  const containManyNumbers = /[0-9]{5,}/.test(alt);

  const specialSymbolsRegex = new RegExp(
    /^[!@#$%^&*()_+{}[\]`:;<>,.?~\\|\-="'/]+$/,
    'u',
  );
  const containOnlySpecialSymbols = specialSymbolsRegex.test(alt);

  return (
    containManyNumbers ||
    endsWithFilename ||
    tooLong ||
    empty ||
    containOnlySpecialSymbols
  );
};
