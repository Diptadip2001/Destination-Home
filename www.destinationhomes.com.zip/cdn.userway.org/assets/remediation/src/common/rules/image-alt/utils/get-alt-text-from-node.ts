import {
  CONTAINING_ALT_CHILD_ELEMENTS_TAGS,
  CONTAINING_ALT_ELEMENTS_TAGS,
} from '../constants';
import { isExistingAltInvalid } from './is-existing-alt-invalid';
import { removeNewlinesSpaces } from './remove-newlines-spaces';

const allowedTagNames = Array.from(
  new Set([
    ...CONTAINING_ALT_ELEMENTS_TAGS,
    ...CONTAINING_ALT_CHILD_ELEMENTS_TAGS,
  ]),
);

export const getAltTextFromNode = (node: ChildNode): string | null => {
  if (node?.nodeType === Node.TEXT_NODE) {
    const trimmedText = removeNewlinesSpaces(node.nodeValue as string);
    if (trimmedText && !isExistingAltInvalid(trimmedText)) {
      return trimmedText;
    }
  }

  if (
    node?.nodeType === Node.ELEMENT_NODE &&
    allowedTagNames.includes((node as Element).tagName.toLowerCase())
  ) {
    for (const childNode of node.childNodes) {
      const altText = getAltTextFromNode(childNode);
      if (altText) {
        return altText;
      }
    }
  }
  return null;
};
