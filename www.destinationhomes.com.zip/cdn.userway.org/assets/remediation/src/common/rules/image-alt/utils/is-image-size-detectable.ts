export const isImageSizeDetectable = (image: HTMLImageElement): boolean => {
  const { width, height } = window.getComputedStyle(image);

  const pixelsUnitPattern = /^\d*px?/i;
  const isWidthInPixels = pixelsUnitPattern.test(width);
  const isHeightInPixels = pixelsUnitPattern.test(height);
  if (isWidthInPixels && isHeightInPixels) return true;

  return false;
};
