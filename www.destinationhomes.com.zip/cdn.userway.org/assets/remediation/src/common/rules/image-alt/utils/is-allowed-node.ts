import {
  CONTAINING_ALT_ELEMENTS_ROLES,
  CONTAINING_ALT_ELEMENTS_TAGS,
} from '../constants';

export const isAllowedNode = (node: ChildNode): boolean => {
  const isElementTypeNode = node.nodeType === Node.ELEMENT_NODE;
  const isTextTypeNode = node.nodeType === Node.TEXT_NODE;

  if (isTextTypeNode) return true;

  if (isElementTypeNode) {
    const isNodeHasAllowedTagname = CONTAINING_ALT_ELEMENTS_TAGS.some(
      (tag) => tag === node.nodeName.toLowerCase(),
    );
    const isNodeHasAllowedRole = CONTAINING_ALT_ELEMENTS_ROLES.some(
      (role) => role === (node as Element).getAttribute('role')?.toLowerCase(),
    );
    return isNodeHasAllowedTagname || isNodeHasAllowedRole;
  }

  return false;
};
