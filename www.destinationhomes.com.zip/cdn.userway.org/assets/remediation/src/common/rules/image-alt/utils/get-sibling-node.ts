import { removeNewlinesSpaces } from '.';

export const getSiblingNode = (
  element: HTMLElement,
  options: { type: 'next' | 'prev' },
): ChildNode | null => {
  if (!element) return null;

  const siblingNode =
    options.type === 'next' ? element.nextSibling : element.previousSibling;

  // skip empty garbage text nodes from html markup
  if (siblingNode?.nodeType === Node.TEXT_NODE) {
    const trimmedTextNode = removeNewlinesSpaces(
      siblingNode.nodeValue as string,
    );
    if (!trimmedTextNode) {
      return getSiblingNode(siblingNode as HTMLElement, { type: options.type });
    }
  }

  return siblingNode;
};
