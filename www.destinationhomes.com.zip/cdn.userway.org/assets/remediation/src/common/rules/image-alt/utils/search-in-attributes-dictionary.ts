import { ATTRIBUTES_DICTIONARY } from '../constants';

export const searchInAttributesDictionary = (str: string): string | null => {
  if (!str.trim()) return null;

  const altFromDictionary = ATTRIBUTES_DICTIONARY.find((word) =>
    str.includes(word),
  );

  return altFromDictionary || null;
};
