import { MIN_IMAGE_SIZE_FOR_PROCESSING, MAX_ASPECT_RATIO } from '../constants';

export const hasWrongAspectRatio = (image: HTMLImageElement): boolean => {
  const RADIX = 10;
  try {
    const { width, height } = window.getComputedStyle(image);
    const widthInt = parseInt(width, RADIX);
    const heightInt = parseInt(height, RADIX);

    const incorrectWidthRatio =
      widthInt <= MIN_IMAGE_SIZE_FOR_PROCESSING &&
      heightInt >= widthInt * MAX_ASPECT_RATIO;

    const incorrectHeightRatio =
      heightInt <= MIN_IMAGE_SIZE_FOR_PROCESSING &&
      widthInt >= heightInt * MAX_ASPECT_RATIO;

    if (incorrectWidthRatio || incorrectHeightRatio) return true;

    return false;
  } catch (e) {
    return false;
  }
};
