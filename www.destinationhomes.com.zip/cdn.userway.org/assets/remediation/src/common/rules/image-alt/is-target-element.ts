import { IMAGE_PROCESSED_ATTR } from './constants';

export const imageCanBeProcessed = (element: HTMLElement): boolean => {
  const isImg = element.tagName.toLowerCase() === 'img';
  const alreadyProcessed = element.hasAttribute(IMAGE_PROCESSED_ATTR);

  if (!isImg || alreadyProcessed) {
    return false;
  }

  const hasSrc = element.getAttribute('src');
  const hasSrcset = element.getAttribute('srcset');

  const hasSomeSrc = hasSrc ?? hasSrcset;

  return !!hasSomeSrc || !!element.closest('picture');
};
