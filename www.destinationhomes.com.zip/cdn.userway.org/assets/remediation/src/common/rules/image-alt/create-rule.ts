import { createRemediationRule } from '../rule-factory/create-remediation-rule';
import { IMAGE_ALT_HELPER_ID } from './constants';
import { imageCanBeProcessed } from './is-target-element';
import {
  revertImage,
  updateImageInDom,
  updateImgAltsConfig,
} from './post-message-api';
import { runImgAltRule } from './rule';

export const ImageAltRule = createRemediationRule({
  ruleId: IMAGE_ALT_HELPER_ID,
  rule: runImgAltRule,
  isTargetElement: imageCanBeProcessed,
  postMessageApi: {
    'image-alt-update': updateImageInDom,
    'image-alt-revert': revertImage,
    'image-alt-update-config': updateImgAltsConfig,
  },
});
