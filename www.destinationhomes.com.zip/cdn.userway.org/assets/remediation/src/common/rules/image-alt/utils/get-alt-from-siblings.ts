import { getSiblingNode } from './get-sibling-node';
import { isAllowedNode } from './is-allowed-node';
import { getAltTextFromNode } from './get-alt-text-from-node';

export const getAltFromSiblings = (element: HTMLElement): string | null => {
  let nextSiblingEl = getSiblingNode(element, { type: 'next' });
  let prevSiblingEl = getSiblingNode(element, { type: 'prev' });
  let textFromNextTextNodeSibling: string | null = null;
  let textFromPrevTextNodeSibling: string | null = null;

  while (nextSiblingEl || prevSiblingEl) {
    if (nextSiblingEl && isAllowedNode(nextSiblingEl)) {
      textFromNextTextNodeSibling = getAltTextFromNode(
        nextSiblingEl as ChildNode,
      );
    }
    if (prevSiblingEl && isAllowedNode(prevSiblingEl)) {
      textFromPrevTextNodeSibling = getAltTextFromNode(
        prevSiblingEl as ChildNode,
      );
    }

    const altTextFromTextNode =
      textFromNextTextNodeSibling || textFromPrevTextNodeSibling;

    if (altTextFromTextNode) return altTextFromTextNode;

    nextSiblingEl = getSiblingNode(nextSiblingEl as HTMLElement, {
      type: 'next',
    });
    prevSiblingEl = getSiblingNode(prevSiblingEl as HTMLElement, {
      type: 'prev',
    });
  }

  return null;
};
