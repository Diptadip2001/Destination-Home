import { CorrectionInfo } from '../../../api/missing-alt';
import { ImageCorrection } from '../types';
import {
  convertToCorrectionInfo,
  getImageSource,
  makeDecorative,
} from './image-utils';
import { isExistingAltInvalid } from './is-existing-alt-invalid';
import {
  DecorativeReason,
  IMAGE_ALT_HELPER_ID,
  IMAGE_ORIGINAL_ALT_ATTR,
  IMAGE_PROCESSED_ATTR,
  ImageProcessedResult,
  SHOW_IN_WIDGET_REMEDIATION_LIST,
  SVG_REGEXP,
} from '../constants';
import { applyCorrectionData } from '../apply-corrections';
import {
  getDecorativeReasonAttribute,
  shouldBeDecorative,
} from './should-be-decorative';
import { ImageAltConfig, ServicesConfig } from '../../../config/config';
import { saveRemediationResults } from '../../../remediation-result/remediation-result';
import { getRelevantTextFromStorage } from './relevant-text-storage';

export const sendRemediationResults = (corrections: ImageCorrection[]): void =>
  saveRemediationResults<ImageCorrection>(
    IMAGE_ALT_HELPER_ID,
    corrections,
    corrections.filter((i) => i.fixedByUserWay).length,
    corrections.filter((i) => !i.approved).length,
  );

const saveOriginalAlt = (imageElement: HTMLImageElement): void => {
  if (!imageElement.hasAttribute(IMAGE_ORIGINAL_ALT_ATTR)) {
    imageElement.setAttribute(IMAGE_ORIGINAL_ALT_ATTR, imageElement.alt);
  }
};

export const processImages = (
  elements: HTMLImageElement[],
  altCorrections: CorrectionInfo[] = [],
): void => {
  if (elements.length === 0) {
    return;
  }

  const { paidAi } = ServicesConfig;
  const imageCorrectionsList: ImageCorrection[] = [];

  for (const elem of elements) {
    const imageElement = elem as HTMLImageElement;
    const isInvalidAlt = isExistingAltInvalid(imageElement.alt);
    const imageSrc = getImageSource(imageElement);

    // Save original alt as attribute
    saveOriginalAlt(imageElement);

    // Add role="img" for svg images for screen reader correct work
    // https://bugs.webkit.org/show_bug.cgi?id=216364
    if (SVG_REGEXP.test(imageSrc) && paidAi) {
      imageElement.setAttribute('role', 'img');
    }

    // try to apply corrections from BE
    const result = applyCorrectionData(altCorrections, imageElement);
    if (result) {
      imageCorrectionsList.push(result);
      continue;
    }

    // for free widget version we only apply corrections received from the BE
    if (!paidAi) {
      continue;
    }

    const decorativeReason = shouldBeDecorative(imageElement);

    // image has own image alt and it is correct
    if (!isInvalidAlt && !decorativeReason) {
      imageElement.setAttribute(
        IMAGE_PROCESSED_ATTR,
        ImageProcessedResult.CorrectAlt,
      );

      imageCorrectionsList.push(
        convertToCorrectionInfo(imageElement, {
          approved: true,
          decorative: false,
          fixedByUserWay: false,
        }),
      );

      continue;
    }

    // check if image should be decorative
    if (decorativeReason !== null) {
      makeDecorative(imageElement);
      imageElement.setAttribute(
        IMAGE_PROCESSED_ATTR,
        getDecorativeReasonAttribute(decorativeReason as DecorativeReason),
      );

      if (
        decorativeReason &&
        SHOW_IN_WIDGET_REMEDIATION_LIST.includes(decorativeReason)
      ) {
        imageCorrectionsList.push(
          convertToCorrectionInfo(imageElement, {
            approved: false,
            decorative: true,
            fixedByUserWay: true,
          }),
        );
      }

      continue;
    }

    // use an alt from the closest relevant text, if we have it in a storage
    const altFromSurroundingText = getRelevantTextFromStorage(imageElement);
    if (altFromSurroundingText) {
      imageElement.setAttribute('alt', altFromSurroundingText);
      imageElement.setAttribute(
        IMAGE_PROCESSED_ATTR,
        ImageProcessedResult.ClosestText,
      );

      imageCorrectionsList.push(
        convertToCorrectionInfo(imageElement, {
          approved: false,
          decorative: false,
          fixedByUserWay: true,
        }),
      );

      continue;
    }

    // if previous options are not applicable, that means that AI generation is in progress (if quota not exceed)
    const { quota, usage } = ImageAltConfig;
    const AIQuotaExceeded = usage >= quota;

    if (AIQuotaExceeded) {
      imageElement.setAttribute(
        IMAGE_PROCESSED_ATTR,
        ImageProcessedResult.AIQuotaExceed,
      );
      imageCorrectionsList.push(
        convertToCorrectionInfo(imageElement, {
          approved: false,
          decorative: false,
          fixedByUserWay: true,
        }),
      );
    } else {
      imageElement.setAttribute(IMAGE_PROCESSED_ATTR, ImageProcessedResult.AI);
      imageCorrectionsList.push(
        convertToCorrectionInfo(imageElement, {
          approved: false,
          decorative: false,
          fixedByUserWay: true,
          loadingFromMS: true,
        }),
      );
    }
  }

  // send Post message data for widget
  sendRemediationResults(imageCorrectionsList);
};
