import {
  RemediationRule,
  RemediationRuleProps,
} from '../../../types/remediation-rule';
import { PostMessageAction } from '../../../constants/base-api';

export const createRemediationRule = ({
  ruleId,
  isTargetElement,
  rule,
  postMessageApi,
  forceRun,
}: RemediationRuleProps): RemediationRule => {
  const elementCanBeProcessed = (element: HTMLElement): boolean =>
    !element.hasAttribute(`uw-ignore-${ruleId}`);

  if (postMessageApi) {
    window.addEventListener('message', (event: MessageEvent) => {
      const { data } = event;
      const { isUserWay, action, type } = data;

      if (
        !isUserWay ||
        (action !== PostMessageAction.Remediation &&
          action !== PostMessageAction.AriaEditor)
      ) {
        return;
      }

      if (postMessageApi[type]) {
        postMessageApi[type](data.data ? data.data : data);
      }
    });
  }

  return {
    run: (elements: HTMLElement[]) => {
      if (!isTargetElement) {
        rule({ context: { elements } });
        return;
      }

      const filteredElements = elements.filter(
        (elem) => elementCanBeProcessed(elem) && isTargetElement(elem),
      );

      if (!filteredElements.length) {
        if (forceRun) {
          rule({ context: { elements: [] } });
        }

        return;
      }

      rule({ context: { elements: filteredElements } });
    },
    stop: (): void => {
      // stops rm process
    },
    rerun: (): void => {},
    ruleId,
  };
};
