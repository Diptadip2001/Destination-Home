import { Correction } from '../types';

const widgetCorrectionsList: Correction[] = [];

export const getWidgetCorrectionsList = (): Correction[] =>
  [].slice.call(widgetCorrectionsList);

export const addToWidgetCorrectionsList = (correction: Correction): void => {
  widgetCorrectionsList.push(correction);
};

export const clearWidgetCorrectionsList = (): void => {
  widgetCorrectionsList.length = 0;
};
