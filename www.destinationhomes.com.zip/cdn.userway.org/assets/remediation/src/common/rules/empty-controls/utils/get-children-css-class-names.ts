// creating an array of children CSS class names including initial element
export const getChildrenCssClassNames = (element: HTMLElement): string[] => {
  const childrenElements = Array.from(element.children) as HTMLElement[];
  childrenElements.push(element);

  let classNames: string[] = [];

  for (const childElement of childrenElements) {
    classNames = classNames.concat(
      Array.from(childElement.classList).map((classnameItem) =>
        classnameItem.toLowerCase(),
      ),
    );
  }

  return classNames;
};
