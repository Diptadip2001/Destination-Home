import { applyCorrection } from './apply-correction';
import { getChildrenCssClassNames } from './utils/get-children-css-class-names';

import { DICTIONARY, ACTIONS_DICTIONARY, REGEXP_DICTIONARY } from './constants';

export const runRuleCheck = (
  element: HTMLElement,
  dataSourceElement?: HTMLElement,
): boolean => {
  const inspectedElement = dataSourceElement || element;

  // looking for matches of element href with dictionary words
  const nameFromDictionary = DICTIONARY.find(
    (word) =>
      inspectedElement.tagName.toLowerCase() === 'a' &&
      (inspectedElement as HTMLLinkElement).href.includes(word),
  );
  if (nameFromDictionary) {
    return applyCorrection(element, nameFromDictionary);
  }

  const classNames = getChildrenCssClassNames(inspectedElement);

  // looking for matches of CSS classnames (element + childred)  with dictionary words
  let nameFromClassnames = DICTIONARY.find((word) =>
    classNames.find((classNameItem) => classNameItem.includes(word)),
  );

  // looking for matches of CSS classnames (element + childred)  with regExp dictionary
  if (!nameFromClassnames) {
    REGEXP_DICTIONARY.find((reEl) =>
      classNames.find((classNameItem) => {
        const result =
          reEl.re.test(classNameItem) &&
          classNameItem.replace(reEl.re, reEl.replacer);

        if (result) {
          nameFromClassnames = result;
          return true;
        }
        return false;
      }),
    );
  }
  if (nameFromClassnames) {
    return applyCorrection(element, nameFromClassnames);
  }

  // looking for matches of element background URL with dictionary words
  const imageUrl = window
    .getComputedStyle(inspectedElement)
    .backgroundImage?.toLowerCase();

  const nameFromBackgroundUrl = DICTIONARY.find((word) =>
    imageUrl.includes(word),
  );
  if (nameFromBackgroundUrl) {
    return applyCorrection(element, nameFromBackgroundUrl);
  }

  // looking for matches of CSS classnames with actions dictionary words
  const actionsKeyFound = Object.keys(ACTIONS_DICTIONARY).find((actionKey) =>
    classNames.find((className) => className.includes(actionKey)),
  );
  type ActionsKey = keyof typeof ACTIONS_DICTIONARY;
  const nameFromActionsDictionary = actionsKeyFound
    ? ACTIONS_DICTIONARY[actionsKeyFound as ActionsKey]
    : null;
  if (nameFromActionsDictionary) {
    return applyCorrection(element, nameFromActionsDictionary);
  }

  return false;
};
