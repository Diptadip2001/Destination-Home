import { recursiveXpathSearch, hashString } from '@uw/utils';
import { getCorrectionDictionary } from './correction-dictionary';
import { applyCorrection } from '../apply-correction';

import { EmptyControlFix } from '../../../../types/remediations-config';

export const updateElement = (correctionItem: EmptyControlFix): void => {
  const correctionDictionary = getCorrectionDictionary();
  correctionDictionary[hashString(correctionItem.xpath)] = correctionItem;
  const element = recursiveXpathSearch(correctionItem.xpath);
  if (element) {
    applyCorrection(element, correctionItem.correction);
  }
};
