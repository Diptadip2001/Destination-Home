import { xpath } from '@uw/utils';
import { RemediationConfig } from '../../config/config';
import { getElementType } from './utils/get-element-type';
import { addToWidgetCorrectionsList } from './utils/widget-corrections-list';

import { PROCESSED_ATTR } from './constants';

export const applyCorrection = (
  element: HTMLElement,
  name: string,
  approved = false,
): boolean => {
  const remediationStrategyAuto =
    !RemediationConfig?.strategy || RemediationConfig.strategy === 'AUTO';

  if (approved || remediationStrategyAuto) {
    element.setAttribute('aria-label', name);
  }
  element.setAttribute(PROCESSED_ATTR, '');

  addToWidgetCorrectionsList({
    correction: name,
    approved,
    xpath: xpath(element),
    name: getElementType(element),
  });

  return true;
};
