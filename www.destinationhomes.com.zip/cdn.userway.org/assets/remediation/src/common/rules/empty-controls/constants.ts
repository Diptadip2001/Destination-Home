export const EMPTY_CONTROLS_RULE_ID = 'REMEDIATION_EMPTY_CONTROLS';

export const PROCESSED_ATTR = 'data-uw-rm-empty-ctrl';

export const DICTIONARY = [
  'facebook',
  'youtube',
  'whatsapp',
  'instagram',
  'twitter',
  'reddit',
  'linkedin',
  'viber',
  'pinterest',
  'telegram',
  'search',
  'cart',
  'home',
];

export const ACTIONS_DICTIONARY = {
  prev: 'Get previous item',
  next: 'Get next item',
  scroll: 'Activate for scroll',
  top: 'Move to top',
  bottom: 'Move to bottom',
  expand: 'Expand this block',
  collapse: 'Collapse this block',
  close: 'Close this option',
};

export const REGEXP_DICTIONARY = [{ re: /(fa-)(.+)/, replacer: '$2' }];
