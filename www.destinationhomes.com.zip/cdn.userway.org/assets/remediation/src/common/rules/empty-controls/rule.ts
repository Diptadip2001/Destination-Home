import { xpath, hashString } from '@uw/utils';
import { getRulesConfig } from '../../config/config';
import { applyCorrection } from './apply-correction';
import { runRuleCheck } from './run-rule-check';
import { getDomainNameFromHref } from '../../../utils/get-domain-name-from-href';
import { saveRemediationResults } from '../../remediation-result/remediation-result';
import { fillCorrectionDictionary } from './utils/correction-dictionary';
import {
  clearWidgetCorrectionsList,
  getWidgetCorrectionsList,
} from './utils/widget-corrections-list';

import { RuleParams } from '../../../types/remediation-rule';

import { IMAGE_ORIGINAL_ALT_ATTR } from '../image-alt/constants';

export const emptyControlsRule = ({
  context: { elements },
}: RuleParams): void => {
  const { EmptyControls: emptyControlsResources } = getRulesConfig();
  const correctionDictionary = fillCorrectionDictionary(emptyControlsResources);

  for (const element of elements) {
    /* correction of empty href getAttribute
    TODO: consider to move this correction to broken_link_helper or another helper */
    const elementHrefValue = element.getAttribute('href');
    const isLink =
      element.tagName.toLowerCase() === 'a' ||
      element.getAttribute('role') === 'link';
    if (isLink && elementHrefValue === '') {
      element.setAttribute('href', '#');
    }

    // apply approved correction for the current element
    if (correctionDictionary) {
      const correctionItem = correctionDictionary[hashString(xpath(element))];
      if (correctionItem) {
        applyCorrection(element, correctionItem.correction, true);
        continue;
      }
    }

    // if main checks in runRuleCheck returned false, we start additional checks to infer aria-label
    if (!runRuleCheck(element)) {
      const role = element.getAttribute('role');
      const elementTagname = element.tagName.toLowerCase();
      const elementTypeValue = element.getAttribute('type');
      const elementAlt = element.getAttribute('alt');
      const elementOriginalAlt = element.getAttribute(IMAGE_ORIGINAL_ALT_ATTR);

      const childrenArr = Array.from(element.children) as HTMLElement[];
      const isRuleAppliedFromChildElement = childrenArr.find((childItem) =>
        runRuleCheck(element, childItem),
      );
      if (isRuleAppliedFromChildElement) continue;

      const domainName = getDomainNameFromHref(element);
      if (domainName) {
        applyCorrection(element, domainName);
        continue;
      }

      if (
        (elementAlt || elementOriginalAlt) &&
        elementTagname === 'img' &&
        role &&
        ['link', 'button'].includes(role)
      ) {
        applyCorrection(element, elementAlt || (elementOriginalAlt as string));
        continue;
      }

      if (
        elementTagname === 'button' ||
        role === 'button' ||
        (elementTagname === 'input' && elementTypeValue === 'button')
      ) {
        applyCorrection(element, 'button');
        continue;
      }

      if (elementTagname === 'input' && elementTypeValue === 'submit') {
        applyCorrection(element, 'submit');
        continue;
      }

      if (elementTagname === 'input' && elementTypeValue === 'reset') {
        applyCorrection(element, 'reset');
        continue;
      }

      // default correction, if all checkes were unsuccessful
      applyCorrection(element, 'Open this option');
    }
  }

  const widgetCorrectionsList = getWidgetCorrectionsList();

  saveRemediationResults(
    'REMEDIATION_EMPTY_CONTROLS',
    widgetCorrectionsList,
    widgetCorrectionsList.length,
    widgetCorrectionsList.filter((e) => !e.approved).length,
  );

  clearWidgetCorrectionsList();
};
