export const getElementType = (element: HTMLElement): string => {
  const tag = element.tagName.toLowerCase();
  const type = (element as HTMLInputElement)?.type;
  const role = element.getAttribute('role');

  if (['a', 'button'].includes(tag)) {
    return tag === 'a' ? '<link>' : '<button>';
  }

  if (tag === 'input' && ['button', 'submit', 'reset'].includes(type)) {
    return '<input>';
  }

  return role === 'link' ? '<link> (role)' : '<button> (role)';
};
