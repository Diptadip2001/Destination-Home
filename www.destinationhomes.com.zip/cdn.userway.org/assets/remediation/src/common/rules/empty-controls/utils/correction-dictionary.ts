import { hashString } from '@uw/utils';

import { EmptyControlFix } from '../../../../types/remediations-config';

type CorrectionDictionary = { [key: number]: EmptyControlFix };

// It's a store for empty controls rule corrections, received from BE
// when we receive corrections from BE, we save them here in the dictionary
// We need that to optimise performance, because mapping correction's list for every rule element is much slower

const correctionDictionary: CorrectionDictionary = {};

export const fillCorrectionDictionary = (
  emptyControlsResources: EmptyControlFix[],
): CorrectionDictionary | null => {
  if (!emptyControlsResources?.length) {
    return null;
  }

  for (const resourceItem of emptyControlsResources) {
    const key = hashString(resourceItem.xpath);
    const isAlreadyExist = correctionDictionary[key];
    const isCorrectionForPage = resourceItem.page;

    if (!isAlreadyExist || (isAlreadyExist && isCorrectionForPage)) {
      correctionDictionary[key] = resourceItem;
    }
  }

  return { ...correctionDictionary };
};

export const getCorrectionDictionary = (): CorrectionDictionary => ({
  ...correctionDictionary,
});
