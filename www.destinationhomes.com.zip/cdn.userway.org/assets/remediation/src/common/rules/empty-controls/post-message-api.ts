import { updateElement } from './utils/update-element';

import { EmptyControlFix } from '../../../types/remediations-config';

export const emptyControlsUpdate = ({
  data: correctionItem,
}: {
  data: EmptyControlFix;
}): void => {
  if (correctionItem?.xpath ?? correctionItem?.correction) {
    updateElement(correctionItem);
  }
};
