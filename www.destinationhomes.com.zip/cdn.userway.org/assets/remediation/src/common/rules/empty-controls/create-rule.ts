import { createRemediationRule } from '../rule-factory/create-remediation-rule';
import { emptyControlsRule } from './rule';
import { isTargetElement } from './is-target-element';
import { emptyControlsUpdate } from './post-message-api';

import { EMPTY_CONTROLS_RULE_ID } from './constants';

export const EmptyControlsRule = createRemediationRule({
  ruleId: EMPTY_CONTROLS_RULE_ID,
  rule: emptyControlsRule,
  isTargetElement,
  postMessageApi: {
    'empty-controls-update': emptyControlsUpdate,
  },
});
