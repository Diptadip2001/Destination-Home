import { getElementAccessibleName } from '@uw/utils';

import { PROCESSED_ATTR } from './constants';

export const isTargetElement = (element: HTMLElement): boolean => {
  if (element.hasAttribute(PROCESSED_ATTR)) {
    return false;
  }

  const tagName = element.tagName.toLowerCase();
  const roleAttribute = element.getAttribute('role');
  const typeAttribute = (element as HTMLInputElement)?.type;

  const hasAllowedTagName = tagName === 'a' || tagName === 'button';
  const hasAllowedRole = roleAttribute === 'link' || roleAttribute === 'button';
  const hasAllowedInputType =
    tagName === 'input' &&
    ['button', 'submit', 'reset'].includes(typeAttribute);

  const isAllowedElement =
    hasAllowedTagName || hasAllowedRole || hasAllowedInputType;

  /**
   *  DO NOT CHANGE condition order, we need to run getElementAccessibleName only for allowed elements.
   *  Because getElementAccessibleName is quite expensive.
   */
  if (!isAllowedElement || getElementAccessibleName(element)) {
    return false;
  }

  return true;
};
