import { getElementByXpath } from '@uw/utils/src/xpath-search';
import { ElementSelectionSource } from 'accessibility-editor/constants/elements';
import { EDITOR_IFRAME_NAME, PROCESSED_ATTR } from './constants';
import { initConfig } from '../../config/config';
import { selectNeighborsByElement } from './select-neighbors-by-element';

export const updateCorrections = (data: { xpath: string }): void => {
  const { xpath } = data;
  const element = getElementByXpath(xpath) as Element;
  element?.removeAttribute(PROCESSED_ATTR);
  initConfig();
};

export const updateAriaLabel = (data: {
  xpath: string;
  label: string;
}): void => {
  const { xpath, label } = data;
  if (!xpath || label == null) {
    return;
  }

  const element = getElementByXpath(xpath) as HTMLElement;

  if (element?.nodeType === Node.ELEMENT_NODE) {
    element.setAttribute('aria-label', data.label);
  }
};

export const updateAriaLevel = (data: {
  xpath: string;
  ariaLevel: string;
}): void => {
  const { xpath, ariaLevel } = data;
  if (!xpath) {
    return;
  }

  const element = getElementByXpath(xpath) as HTMLElement;

  if (element?.nodeType === Node.ELEMENT_NODE) {
    ariaLevel
      ? element.setAttribute('aria-level', ariaLevel)
      : element.removeAttribute('aria-level');
  }
};

export const updateRole = (data: { xpath: string; role: string }): void => {
  const { xpath, role } = data;
  if (!xpath) {
    return;
  }
  const element = getElementByXpath(xpath) as HTMLElement;

  if (element?.nodeType === Node.ELEMENT_NODE) {
    const hasSomeRole = role && role !== 'no role';
    hasSomeRole
      ? element.setAttribute('role', role)
      : element.removeAttribute('role');
  }
};

export const updateTabindex = (data: {
  xpath: string;
  focusable: boolean;
  isControl: boolean;
}): void => {
  const { xpath, focusable, isControl } = data;
  if (!xpath) {
    return;
  }
  const element = getElementByXpath(xpath) as HTMLElement;

  if (element?.nodeType === Node.ELEMENT_NODE) {
    if (isControl) {
      element[focusable ? 'removeAttribute' : 'setAttribute']('tabindex', '-1');
    } else {
      element[focusable ? 'setAttribute' : 'removeAttribute']('tabindex', '0');
    }
  }
};

export const updateAriaHidden = (data: {
  xpath: string;
  hidden: boolean;
}): void => {
  const { xpath, hidden } = data;
  if (!xpath) {
    return;
  }
  const element = getElementByXpath(xpath) as HTMLElement;

  if (element?.nodeType === Node.ELEMENT_NODE) {
    hidden
      ? element.setAttribute('aria-hidden', 'true')
      : element.removeAttribute('aria-hidden');
  }
};

export const selectElementsAtPoint = (data: {
  position: { x: number; y: number };
}): void => {
  const {
    position: { x, y },
  } = data;

  let elements = document.elementsFromPoint(x, y);

  const iframeIndex = elements.findIndex(
    (element) => element.getAttribute('name') === EDITOR_IFRAME_NAME,
  );

  if (iframeIndex !== -1) {
    elements.splice(iframeIndex, 1);
  }

  elements = elements
    .filter((e) => !['HTML', 'BODY'].includes(e.tagName))
    .slice(0, 2);

  if (elements.length) {
    selectNeighborsByElement(elements[0] as HTMLElement);
  }
};

export const selectElementsByXpath = (data: {
  xpath: string;
  source: ElementSelectionSource;
}): void => {
  const { xpath, source } = data;

  if (!xpath) {
    return;
  }

  const selectedElement = getElementByXpath(xpath) as HTMLElement;

  if (selectedElement) {
    selectNeighborsByElement(selectedElement, source);
  }
};
