import { EXCLUDED_TAG_NAMES } from '../../../constants';

const SEPARATOR = '|';

export const getByXpath = (xpath: string): Node | null => {
  if (!xpath) {
    return null;
  }
  const splittedXpath = xpath.split(SEPARATOR)[0];
  return document.evaluate(
    splittedXpath,
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null,
  ).singleNodeValue;
};

export const isControl = (el: Element): boolean => {
  if (
    ['input', 'select', 'button', 'textarea', 'a'].includes(
      el.tagName.toLowerCase(),
    )
  ) {
    return true;
  }
  return ['button', 'checkbox', 'link', 'option'].includes(
    (el.getAttribute('role') || '').toLowerCase(),
  );
};

export const getTabindex = (el: Element): number | undefined => {
  const tabindexAttr = el.getAttribute('tabindex');
  if (tabindexAttr !== null) {
    const parsedTabindex = parseInt(tabindexAttr, 10);
    if (!Number.isNaN(parsedTabindex)) {
      return parsedTabindex;
    }
  }
  return undefined;
};

export const isFocusable = (el: Element): boolean => {
  if (isControl(el)) {
    return true;
  }

  const tabindex = getTabindex(el);
  return tabindex !== undefined && !Number.isNaN(tabindex) && tabindex >= 0;
};

export const isExcludedTag = (tagName: string): boolean =>
  !!EXCLUDED_TAG_NAMES.includes(tagName.toLowerCase());

export const getLabel = (
  tagName: string,
  element: HTMLElement,
): string | null =>
  (tagName === 'img'
    ? element.getAttribute('alt')
    : element.getAttribute('aria-label')) || null;

export const isHidden = (element: HTMLElement): boolean =>
  element.getAttribute('aria-hidden') === 'true' ||
  element.getAttribute('role') === 'presentation';

export const getRole = (element: HTMLElement): string | null =>
  element.getAttribute('role') || null;

export const getAriaLevel = (element: HTMLElement): string | null =>
  element.getAttribute('aria-level') || null;

export const getSrc = (tagName: string, element: HTMLElement): string | null =>
  tagName === 'img' ? element.getAttribute('src') : null;
