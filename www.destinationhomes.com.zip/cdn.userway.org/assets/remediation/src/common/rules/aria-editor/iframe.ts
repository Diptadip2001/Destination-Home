// these functions are used for creating, initialization, opening and closing events of AE iframe
import { postMessage, hashString } from '@uw/utils';
import { ServicesConfig } from '../../config/config';
import {
  EDITOR_IFRAME_NAME,
  IFRAME_ARIA_EDITOR_URL,
  AE_POST_MSG_ACTION,
} from './constants';

let iframeOnLoad: Promise<void>;
let editorIframe: HTMLIFrameElement | null;

export const createIframe = (): void => {
  editorIframe = document.querySelector(`iframe[name=${EDITOR_IFRAME_NAME}]`);

  if (!editorIframe) {
    iframeOnLoad = new Promise((resolve) => {
      const iframeStyles = `
            z-index: 2147483647;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%!important;
            max-width: 100%!important;
            height: 100%!important;
            max-height: 100%!important;
            visibility: hidden;
            opacity: 0!important;
            border: none;
          `;
      const iframeAttributes = {
        class: 'userway_iframe_aria_editor',
        name: 'uwAccessibilityEditor',
        title: 'Aria Editor',
        style: iframeStyles,
        src: IFRAME_ARIA_EDITOR_URL,
      };

      editorIframe = document.createElement('iframe');

      Object.entries(iframeAttributes).forEach(([key, value]) => {
        editorIframe?.setAttribute(key, value);
      });

      editorIframe.onload = () => {
        resolve();
      };
      if (editorIframe) {
        document.body.appendChild(editorIframe);
      }
    });
  }
};

export const onAriaEditorInit = (): void => {
  const paidProducts = ServicesConfig;
  const hasPaidProducts =
    !!paidProducts &&
    (!!paidProducts.CUSTOM_BRANDING || !!paidProducts.WHITE_LABEL);
  postMessage(
    {
      action: AE_POST_MSG_ACTION,
      type: 'open-aria-editor',
      data: {
        siteId: ServicesConfig.siteId,
        showTutorial: true,
        whiteLabel: hasPaidProducts,
        hash: hashString(window.location.pathname),
      },
    },
    [EDITOR_IFRAME_NAME],
  );
};

export const openAriaEditor = (): void => {
  iframeOnLoad.then(() => {
    window.parent.postMessage({ action: 'close', isUserWay: true });
    window.parent.postMessage({
      action: 'manageIconVisibility',
      isUserWay: true,
      type: 'hidden',
    });

    if (editorIframe) {
      editorIframe.style.visibility = 'visible';
      editorIframe.style.opacity = '1';
    }

    postMessage(
      {
        action: AE_POST_MSG_ACTION,
        type: 'aria-editor-open-request',
      },
      [EDITOR_IFRAME_NAME],
    );
  });
};

export const closeAriaEditor = (): void => {
  window.parent.postMessage({ action: 'open', isUserWay: true });
  window.parent.postMessage({
    action: 'manageIconVisibility',
    isUserWay: true,
    type: 'visible',
  });

  if (editorIframe) {
    editorIframe.style.visibility = 'hidden';
    editorIframe.style.opacity = '0';
  }

  postMessage(
    {
      action: AE_POST_MSG_ACTION,
      type: 'aria-editor-closed',
    },
    [EDITOR_IFRAME_NAME],
  );
};
