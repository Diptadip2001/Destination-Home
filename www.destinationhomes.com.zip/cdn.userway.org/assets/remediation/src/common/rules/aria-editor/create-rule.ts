import { createRemediationRule } from '../rule-factory/create-remediation-rule';
import {
  updateAriaHidden,
  updateAriaLabel,
  updateAriaLevel,
  updateRole,
  updateTabindex,
  updateCorrections,
  selectElementsAtPoint,
  selectElementsByXpath,
} from './post-message-api';
import {
  createIframe,
  openAriaEditor,
  closeAriaEditor,
  onAriaEditorInit,
} from './iframe';
import { ariaEditorRule } from './rule';
import { ARIA_EDITOR_HELPER_ID } from './constants';

export const AriaEditorRule = createRemediationRule({
  ruleId: ARIA_EDITOR_HELPER_ID,
  rule: ariaEditorRule,
  postMessageApi: {
    'add-aria-editor': createIframe,
    'open-aria-editor': openAriaEditor,
    'close-aria-editor': closeAriaEditor,
    'editor-init': onAriaEditorInit,
    'update-aria-hidden': updateAriaHidden,
    'update-tabindex': updateTabindex,
    'update-aria-label': updateAriaLabel,
    'update-aria-level': updateAriaLevel,
    'update-role': updateRole,
    'update-corrections': updateCorrections,
    'select-elements-by-xpath': selectElementsByXpath,
    'select-elements-at-point': selectElementsAtPoint,
  },
});
