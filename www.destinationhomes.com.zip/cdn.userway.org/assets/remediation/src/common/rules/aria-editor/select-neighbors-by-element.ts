import { xpath, postMessage } from '@uw/utils';
import {
  isControl,
  getTabindex,
  isFocusable,
  isExcludedTag,
  getLabel,
  isHidden,
  getAriaLevel,
  getRole,
  getSrc,
} from './utils';
import { CustomElement, TreeNode } from './types';
import { EDITOR_IFRAME_NAME, AE_POST_MSG_ACTION } from './constants';
import { buildAccessibilityTreeNode } from '../../accessibility-tree-observer/build-accessibility-tree-node/build-accessibility-tree-node';
import { getNodes } from '../../accessibility-tree-observer/post-message-api';
import { AccessibilityTreeNode } from '../../accessibility-tree-observer/types';

export const getNextSibling = (el: HTMLElement): HTMLElement | null => {
  if (el?.nextElementSibling) {
    const sibling = el.nextElementSibling as HTMLElement;
    if (!isExcludedTag(sibling.tagName)) {
      return sibling;
    }
    return getNextSibling(sibling);
  }
  return null;
};

export const getPreviousSibling = (el: HTMLElement): HTMLElement | null => {
  if (el?.previousElementSibling) {
    const sibling = el.previousElementSibling as HTMLElement;
    if (!isExcludedTag(sibling.tagName)) {
      return sibling;
    }
    return getPreviousSibling(sibling);
  }
  return null;
};

const getAtoIdForSelected = (el: CustomElement): number | null =>
  el.uwAtoId ?? null;

export const getClosestAccessibleParentXpath = (
  element: HTMLElement,
): string | null => {
  if (!element.parentElement) {
    return null;
  }

  const { parentElement } = element;
  const parentElementXpath = xpath(parentElement);

  const nodes = getNodes();
  return nodes.find(
    (observerNode: AccessibilityTreeNode) =>
      observerNode.xpath === parentElementXpath,
  )
    ? parentElementXpath
    : getClosestAccessibleParentXpath(parentElement);
};

export const getClosestAccessibleChildXpath = (
  element: HTMLElement,
): string | null => {
  const childNodesArray = (Array.from(
    element.childNodes,
  ) as unknown) as CustomElement[];

  const childElement = (childNodesArray.find(
    (node: CustomElement) => node.uwAtoId,
  ) as unknown) as HTMLElement;

  if (childElement) {
    const childElementXpath = xpath(childElement);

    const nodes = getNodes();
    return nodes.find(
      (observerNode: AccessibilityTreeNode) =>
        observerNode.xpath === childElementXpath,
    )
      ? childElementXpath
      : null;
  }

  return null;
};

export const makeTree = (
  node: CustomElement,
  nodes: CustomElement[],
): TreeNode | undefined => {
  if (!node) {
    return undefined;
  }
  const { tabindex, el, ...res } = node;
  const children = node.el ? [...node.el.children] : [];

  const filteredNodes = nodes.filter((nodeToCheck) =>
    children.includes(nodeToCheck.el),
  );

  if (filteredNodes.length) {
    const childrenTree = filteredNodes.map((childNode) =>
      makeTree(childNode, nodes),
    ) as TreeNode[];

    return { ...res, children: childrenTree };
  }

  return res;
};

export const selectNeighborsByElement = (
  selectedEl: HTMLElement,
  source = '',
): void => {
  const elements: HTMLElement[] = [selectedEl];

  if (selectedEl.parentElement) {
    elements.push(selectedEl.parentElement);
  }

  let selectedIdx = 0;

  const children: HTMLElement[] = selectedEl?.children
    ? ([...selectedEl.children] as HTMLElement[])
        .filter((el) => !isExcludedTag(el.tagName))
        .reverse()
    : [];

  if (children.length) {
    elements.unshift(...children);
    selectedIdx += children.length;
  }

  const nextSibling = getNextSibling(selectedEl);
  if (nextSibling && !elements.includes(nextSibling)) {
    elements.splice(selectedIdx, 0, nextSibling);
    selectedIdx += 1;
  }

  const prevSibling = getPreviousSibling(selectedEl);
  if (prevSibling && !elements.includes(prevSibling)) {
    elements.splice(selectedIdx + 1, 0, prevSibling);
  }

  const elementsParsed: CustomElement[] | null = elements
    .map((el) => {
      const tagName = el.tagName.toLowerCase();
      const resultElement = buildAccessibilityTreeNode(el, true);

      if (!resultElement) {
        return null;
      }

      const { type: semanticType, label: textToRead, id } = resultElement;

      const attributes =
        typeof el.getAttribute === 'function'
          ? {
              label: getLabel(tagName, el),
              isHidden: isHidden(el),
              role: getRole(el),
              ariaLevel: getAriaLevel(el),
              src: getSrc(tagName, el),
              isControl: isControl(el),
              focusable: isFocusable(el),
              tabindex: getTabindex(el),
            }
          : {};

      return {
        tagName,
        text: [...el.childNodes]
          .filter((element) => element.nodeType === Node.TEXT_NODE)
          .map((element) => element.textContent?.trim())
          .join(' ')
          .trim(),
        id,
        xpath: xpath(el as HTMLElement),
        selected: el === selectedEl,
        el,
        semanticType,
        textToRead,
        uwAtoId: getAtoIdForSelected((el as unknown) as CustomElement),
        accessibleParentXpath: getClosestAccessibleParentXpath(el),
        accessibleChildXpath: getClosestAccessibleChildXpath(el),
        ...attributes,
      };
    })
    .filter(Boolean)
    .reverse() as CustomElement[];

  if (elementsParsed) {
    const tree = makeTree(
      elementsParsed[0] as CustomElement,
      elementsParsed as CustomElement[],
    );

    if (tree) {
      postMessage(
        {
          action: AE_POST_MSG_ACTION,
          type: 'elements-selected',
          data: {
            tree,
            source,
          },
        },
        [EDITOR_IFRAME_NAME],
      );
    }
  }
};
