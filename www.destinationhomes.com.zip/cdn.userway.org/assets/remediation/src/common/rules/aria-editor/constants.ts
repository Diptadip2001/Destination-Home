import { ServicesConfig } from '../../config/config';

export const EDITOR_IFRAME_NAME: string = 'uwAccessibilityEditor';

export const IFRAME_ARIA_EDITOR_URL = ServicesConfig.editorBuildUrl;

export const ARIA_EDITOR_HELPER_ID = 'aria-editor';

export const PROCESSED_ATTR = 'data-uw-rm-heading';

export const AE_POST_MSG_ACTION = 'aria-editor';
