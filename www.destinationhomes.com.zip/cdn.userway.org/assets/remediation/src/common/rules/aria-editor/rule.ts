import { hashString } from '@uw/utils';
import { getRulesConfig, RemediationConfig } from '../../config/config';
import type { AriaEditorFix } from '../../../types/remediations-config';
import { PROCESSED_ATTR } from './constants';
import { getByXpath } from './utils';

let allSavedCorrections: AriaEditorFix[] | null;

const filterCorrections = (): AriaEditorFix[] | null => {
  let corrections = getRulesConfig().AriaEditorValues;

  const pageHash = `${hashString(window.location.pathname)}`;

  corrections = corrections
    .filter(
      (correction: AriaEditorFix) =>
        !correction.page || correction.page === pageHash,
    )
    .sort((correction: AriaEditorFix) => (correction.page ? -1 : 1)); // first apply per site corrections, then - per page

  return corrections;
};

const applyHidden = (element: HTMLElement): void => {
  element.setAttribute('aria-hidden', 'true');
};

const applyTextCorrection = (
  element: HTMLElement,
  correctionText: string,
): void => {
  const isImage = element?.tagName.toLowerCase() === 'img';
  // applying of image corrections is responsibility of img alt rule
  if (correctionText && !isImage) {
    element.setAttribute('aria-label', correctionText);
  }
};

const setRoleAndTabindex = (
  element: HTMLElement,
  correction: AriaEditorFix,
): void => {
  const { tabindex, role, ariaLevel } = correction;

  if (tabindex) {
    element.setAttribute('tabindex', tabindex);
  }

  if (role && role !== 'no role') {
    element.setAttribute('role', role);
  } else if (!role || role === 'no role') {
    element.removeAttribute('role');
  }

  if (ariaLevel) {
    element.setAttribute('aria-level', ariaLevel);
  }
};

export const ariaEditorRule = (): void => {
  if (!RemediationConfig.ariaEditor.enabled) {
    return;
  }

  allSavedCorrections = filterCorrections();

  if (allSavedCorrections) {
    for (const correction of allSavedCorrections) {
      if (correction.processed) {
        return;
      }
      const elementToFix = getByXpath(correction.xpath) as HTMLElement;
      if (elementToFix && elementToFix.nodeType === Node.ELEMENT_NODE) {
        if (elementToFix.hasAttribute(PROCESSED_ATTR)) {
          return;
        }
        const { hidden, correction: correctionText } = correction;
        if (hidden) {
          applyHidden(elementToFix);
        }
        applyTextCorrection(elementToFix, correctionText);
        setRoleAndTabindex(elementToFix, correction);
        elementToFix.setAttribute(PROCESSED_ATTR, '');
        correction.processed = true;
      }
    }
  }
};
