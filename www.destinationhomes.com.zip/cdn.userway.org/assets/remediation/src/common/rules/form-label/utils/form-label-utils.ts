import { createScreenRearedElement, generateRandomId } from '@uw/utils';
import {
  FORM_PROCESSED_ATTR,
  INPUTS_LABEL_MAP,
  SELECTS_LABEL_MAP,
  INPUT_TYPE_MAP,
} from '../constants';

/** Check and return custom element type (string)
 *
 * @param {HTMLElement} element - control element to be checked
 * @returns {string} - 'text' | 'textarea' | 'select' */
export const checkControlElementType = (element: HTMLElement): string => {
  const { tagName: tag } = element;
  return tag === 'SELECT' || tag === 'TEXTAREA' ? tag.toLowerCase() : 'text';
};

/** Bind a control and label elements with aria-labelledby attribute
 *
 * @param {HTMLElement} element - control element to which aria-labelledby attribute should be applied
 * @param {HTMLElement} label - label element which will be used as accessible name for control given */
export const addAriaLabelledBy = (
  element: HTMLElement,
  label: HTMLElement,
): void => {
  const id = label.getAttribute('id') || generateRandomId();
  label.setAttribute('id', id);
  element.setAttribute('aria-labelledby', id);
};

/** Finding a label element by "for" attribute
 *
 * @param {HTMLElement} element - control element, which should have corresponding label element
 * @returns {HTMLElement | null} - label element if present or null */
export const findLabelElementByFor = (
  element: HTMLElement,
): HTMLElement | null => {
  const id = element.getAttribute('id');
  if (!id) return null;

  try {
    return document.querySelector(`label[for='${id}']`);
  } catch (e) {
    console.log('Query selector error: ', e);
    return null;
  }
};

/** Compose accessible name for control element based on its tag name
 *
 * @param {HTMLElement} element - target control element
 * @returns {string} - accessible name based on element tag name */
export const getAccessibleNameByTagName = (
  element: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement,
): string => {
  const { tagName, type } = element;

  if (tagName === 'SELECT')
    return type === 'select-multiple' ? 'Multiple select' : 'Single select';

  if (tagName === 'TEXTAREA') return 'Text area';

  if (tagName === 'INPUT' && type && INPUT_TYPE_MAP[type])
    return INPUT_TYPE_MAP[type];

  return '';
};

/** Trying to find matches in a string given and return appropriate accessible name,
 * string is usually a combination of name and class attributes of control element.
 *
 * @param {string} text - string in which substrings are searched
 * @param {Map<string, RegExp>} patterns - Map which contains all the patterns and accessible names.
 *
 * @returns {string} - composed accessible name for control or an empty string  */
const getAccessibleNameByPattern = (
  text: string,
  patterns: Map<string, RegExp>,
): string => {
  for (const [name, regExp] of patterns) {
    if (regExp.test(text)) return name;
  }
  return '';
};

/** Trying to find an accessible name for control element
 * by parsing some secondary attributes such as placeholder, title, class etc..
 *
 * @param {HTMLElement} element - control element, which has no accessible name
 * @returns {string} - composed accessible name for control or an empty string  */
export const parseAttributes = (
  element: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement,
): string => {
  let label: string = '';

  const elementPlaceholder = element.getAttribute('placeholder');
  const elementTitle = element.getAttribute('title');

  // return placeholder or title attribute, if present
  if (elementPlaceholder && elementPlaceholder.trim())
    return elementPlaceholder;
  if (elementTitle && elementTitle.trim()) return elementTitle;

  // trying to compose accessible name by parsing class and name attributes of the control element
  const { classList, name, tagName, type } = element;
  const attributesText: string = `${[...classList].join(' ') || ''} ${
    name || ''
  }`.trim();

  // trying to find an english words pattern
  if (type === 'text')
    label = getAccessibleNameByPattern(attributesText, INPUTS_LABEL_MAP);
  if (tagName === 'SELECT')
    label = getAccessibleNameByPattern(attributesText, SELECTS_LABEL_MAP);

  return label || getAccessibleNameByTagName(element);
};

/** This method checks if:
 * - element given is a label element
 * - "for" attribute of the element given is not empty
 * - there's corresponding control element present in DOM tree
 *
 * @param {HTMLElement} element - a label element, which should be tested
 * @returns {boolean} - true if corresponding control element was not found
 * for argument (label element) or it's for attribute is empty */
export const isUnmappedLabelElement = (element: HTMLElement): boolean => {
  const isLabelElement = element.tagName === 'LABEL';
  const forAttribute = element.getAttribute('for');

  return (
    isLabelElement &&
    (!forAttribute?.trim() || !document.getElementById(forAttribute as string))
  );
};

/** Check if element is div, span or p, and it has inner text node
 *
 * @param {HTMLElement} element - any HTML element
 * @returns {boolean} - true if element tag is allowed, and it has inner text node */
export const isUnmappedElement = (element: HTMLElement): boolean => {
  const allowedTags = ['DIV', 'SPAN', 'P'];
  const isAllowedElement = allowedTags.includes(element.tagName);
  return isAllowedElement && Boolean(element.textContent?.trim());
};

/** Trying to retrieve text node from unmapped label element
 *
 * @param {HTMLElement} element - any HTML element, usually a control element
 * whose siblings and children's can potentially be an unmapped label element
 * @returns {string | null} - text of the unmapped label element or null */
export const getUnmappedLabelText = (element: HTMLElement): string | null => {
  if (element.parentElement) {
    const unmappedLabels = [...element.parentElement.querySelectorAll('label')];

    if (
      unmappedLabels.length === 1 &&
      isUnmappedLabelElement(unmappedLabels[0])
    ) {
      return unmappedLabels[0].textContent;
    }
  }

  return null;
};

/** Trying to get previous sibling's text node of the argument given if sibling tag is div span or paragraph
 *
 * @param {HTMLElement} element - any HTML element, method will look for the text content of previous sibling of this element
 * @returns {string | null} - text of the unmapped sibling element or null */
export const getUnmappedElementText = (element: HTMLElement): string | null => {
  const sibling = element.previousElementSibling as HTMLElement;
  if (sibling && isUnmappedElement(sibling)) {
    addAriaLabelledBy(element, sibling);
    return sibling.textContent;
  }

  return null;
};

/** Trying to update target control element in DOM,
 *  if isAutoStrategy argument is falsy, this method will immediately return
 *
 * @param {HTMLElement} element - target control element to which new accessible name should be attached
 * @param {string} accessibleName - string with an accessible name which will be attached to target element
 * @param {boolean | null} isAutoStrategy - a flag responsible for applying a corrections which was founded by remediation tool */
export const updateControlElement = (
  element: HTMLElement,
  accessibleName: string,
  isAutoStrategy: boolean = true,
): void => {
  if (!isAutoStrategy) return;
  // accessibility checkers considers empty labels as a violation, so we should
  // remediate such issues by adding an element inside empty labels
  const parentLabelElement = element.closest('label');
  const labelElementByFor = findLabelElementByFor(element);

  const correspondingLabel = parentLabelElement || labelElementByFor;

  if (correspondingLabel) {
    // if label element is present, we should add an element inside it
    const existingHiddenElement = correspondingLabel.querySelector(
      'span[data-uw-reader-element]',
    );
    if (existingHiddenElement) {
      existingHiddenElement.textContent = accessibleName;
    } else {
      const hiddenElement = createScreenRearedElement(accessibleName);
      correspondingLabel.appendChild(hiddenElement);
    }
  } else {
    // otherwise we should add aria-label attribute to the control element
    element.setAttribute('aria-label', accessibleName);
  }

  element.setAttribute(FORM_PROCESSED_ATTR, 'fx');
};

/** Trying to retrieve element's original accessible name
 *
 * @param {HTMLElement} element - target control element (input, select, textarea)
 * @returns {string | null} - an original accessible name of the element given, or null if it absent */
export const getOriginalLabel = (element: HTMLElement): string | null => {
  const parentLabel = element.closest('label');
  const ariaLabel = element.getAttribute('aria-label');

  return parentLabel?.textContent?.trim() || ariaLabel || null;
};

// TODO THIS METHODS MAY BE USER IN THE FUTURE
// /** */
// export const findElementTextNodes = (element: HTMLElement): Node[] =>
//   [...element.childNodes].filter((node) => node.nodeType === Node.TEXT_NODE);
//
// /** */
// export const findTextElementNodes = (element: HTMLElement): Node[] =>
//   [...element.childNodes].filter((node) => node instanceof HTMLElement && node.tagName === 'SPAN');
//
// /** */
// export const testAndConcatTextNodes = (nodes: Node[]): string =>
//   nodes
//     .filter((node) => node.nodeValue && Boolean(node.nodeValue.trim()))
//     .map((node) => node.nodeValue)
//     .join(' ');
