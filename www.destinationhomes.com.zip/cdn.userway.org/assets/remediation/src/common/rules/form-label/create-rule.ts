import { createRemediationRule } from '../rule-factory/create-remediation-rule';
import { FORM_RULE_ID } from './constants';
import { updateFormLabel } from './post-message-api';
import { formLabelRule } from './rule';
import { isTargetElement } from './is-target-element';

export const FormLabelRule = createRemediationRule({
  ruleId: FORM_RULE_ID,
  rule: formLabelRule,
  isTargetElement,
  postMessageApi: {
    'form-label-update': updateFormLabel,
  },
});
