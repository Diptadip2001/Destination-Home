import { hashString, xpath } from '@uw/utils';
import { getRulesConfig } from '../../config/config';
import { FormLabelCorrection } from './types';
import {
  getOriginalLabel,
  updateControlElement,
} from './utils/form-label-utils';
import { FORM_PROCESSED_ATTR } from './constants';

export const applyCorrectionData = (
  element: HTMLElement,
): FormLabelCorrection | null => {
  const { Forms: ariaLabelCorrection } = getRulesConfig();
  const elementXpath = xpath(element);

  const originalLabel = getOriginalLabel(element);

  if (originalLabel) element.setAttribute(FORM_PROCESSED_ATTR, 'nfx');

  // check if
  //  - consolidated json correction was approved by user
  //  - correction has the same xpath as element
  const consolidatedCorrection = ariaLabelCorrection.find(
    ({ xpath: correctionXpath, approved }) =>
      approved && +correctionXpath === hashString(elementXpath),
  );

  // updating aria label attribute which was found in consolidated array
  if (consolidatedCorrection) {
    updateControlElement(element, consolidatedCorrection.correction, true);

    return {
      type: consolidatedCorrection.type,
      xpath: elementXpath,
      required: consolidatedCorrection.required,
      correction: consolidatedCorrection.correction,
      approved: consolidatedCorrection.approved,

      xpathHash: hashString(elementXpath),
      label: originalLabel,
    };
  }

  return null;
};
