import { isElementVisible, onElementVisible } from '@uw/utils';
import {
  parseAttributes,
  getUnmappedLabelText,
  getUnmappedElementText,
} from './form-label-utils';
import {
  HIDDEN_CONTROL_DATA_ATTRIBUTE,
  HIDDEN_CONTROL_DATA_ATTRIBUTE_VALUE,
} from '../constants';

/** Trying to find and return accessible name of the element given
 *
 * @param {HTMLElement} element - control element that should be remediated (input, textarea, select..)
 * @returns {string | null} - method returns element accessible name (string) or null */
export const composeAccessibleName = (
  element: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement,
): string | null => {
  // WORKAROUND FOR WAVE CHECKER
  if (!isElementVisible(element, { shouldBeInViewport: false })) {
    element.setAttribute('aria-label', HIDDEN_CONTROL_DATA_ATTRIBUTE_VALUE);
    element.setAttribute(
      HIDDEN_CONTROL_DATA_ATTRIBUTE,
      HIDDEN_CONTROL_DATA_ATTRIBUTE_VALUE,
    );
    // REMOVE ALL STUBBED ATTRIBUTES WHEN ELEMENT BECAME VISIBLE
    onElementVisible(element, (): void => {
      if (
        element.hasAttribute(HIDDEN_CONTROL_DATA_ATTRIBUTE) &&
        element.hasAttribute('aria-label') &&
        element.getAttribute(HIDDEN_CONTROL_DATA_ATTRIBUTE) ===
          element.getAttribute('aria-label')
      ) {
        element.removeAttribute(HIDDEN_CONTROL_DATA_ATTRIBUTE);
        element.removeAttribute('aria-label');
      }
    });
  }
  // TRYING TO FIND ACCESSIBLE NAME AMONG LABEL ELEMENTS LOCATED ON THE SAME LEVEL (SIBLINGS)
  const unmappedLabelAccessibleName = getUnmappedLabelText(element);
  if (unmappedLabelAccessibleName) return unmappedLabelAccessibleName;

  // TRYING TO COMPOSE ACCESSIBLE NAME FOR CONTROL ELEMENT
  // USING IT'S ATTRIBUTES SUCH AS CLASS, PLACEHOLDER, TITLE, ETC..
  const composedAccessibleName = parseAttributes(element);
  if (composedAccessibleName) return composedAccessibleName;

  // TRYING TO FIND ACCESSIBLE NAME IN PREVIOUS SIBLING (ONLY DIV, SPAN, P)
  const unmappedElementAccessibleName = getUnmappedElementText(element);
  if (unmappedElementAccessibleName) return unmappedElementAccessibleName;

  return null;
};
