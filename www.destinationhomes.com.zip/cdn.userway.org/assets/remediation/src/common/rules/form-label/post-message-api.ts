import { getElementByXpath } from '@uw/utils';
import { FormLabelCorrection } from './types';
import { updateControlElement } from './utils/form-label-utils';

export const updateFormLabel = ({
  correction,
  xpath,
}: FormLabelCorrection): void => {
  const element = getElementByXpath(xpath.toString()) as HTMLElement;
  if (!element) return;

  updateControlElement(element, correction || '', true);
};
