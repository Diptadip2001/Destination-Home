import {
  FORM_PROCESSED_ATTR,
  ALLOWED_TAGS_LIST,
  EXCLUDED_PARENT_FORMS,
  INPUT_TYPE_MAP,
} from './constants';

const allowedInputTypes = Object.keys(INPUT_TYPE_MAP);

/** Checks if:
 * - element tag is allowed for form label rule (input, textarea, select)
 * - element type attribute is allowed, if input tag is given as argument
 * - element has no excluded elements among it's parent
 *
 * @param {HTMLElement} element - element which should be tested
 * @returns {boolean} - true if element can be processed with form label rule */

export const isTargetElement = (element: HTMLElement): boolean => {
  const isAllowedTag = ALLOWED_TAGS_LIST.includes(element.tagName);
  const alreadyProcessed = element.hasAttribute(FORM_PROCESSED_ATTR);

  if (alreadyProcessed || !isAllowedTag) return false;

  const type = element.getAttribute('type');
  const isAllowedType =
    element.tagName === 'SELECT' ||
    element.tagName === 'TEXTAREA' ||
    (element.tagName === 'INPUT' &&
      !!type &&
      allowedInputTypes.includes(type.toLowerCase()));

  if (!isAllowedType) return false;

  const closestForm = element.closest('form');
  const hasExcludedParentForm = EXCLUDED_PARENT_FORMS.some((excludedAction) => {
    const action =
      closestForm && closestForm.getAttribute('action')?.toLowerCase();

    return action?.includes(excludedAction);
  });

  return !hasExcludedParentForm;
};
