export const FORM_RULE_ID = 'REMEDIATION_FORM_LABEL';
export const FORM_PROCESSED_ATTR = 'data-uw-rm-form';

export const ALLOWED_TAGS_LIST = ['INPUT', 'TEXTAREA', 'SELECT'];
export const EXCLUDED_PARENT_FORMS = ['facebook', 'google'];

export const HIDDEN_CONTROL_DATA_ATTRIBUTE = 'data-uw-hidden-control';
export const HIDDEN_CONTROL_DATA_ATTRIBUTE_VALUE = 'hidden-control-element';

// keys of this object is also used to check if element type is allowed
export const INPUT_TYPE_MAP: { [key: string]: string } = {
  text: 'Text field',
  radio: 'Radio button',
  checkbox: 'Checkbox field',
  email: 'Please enter email address',
  url: 'Please enter url',
  tel: 'Please enter a phone number',
  password: 'Password field',
  search: 'Search field',
  date: 'Date field',
  time: 'Time field',
  image: 'Image field',
  file: 'File field',
  number: 'Number',
  range: 'Select range',
  submit: 'Submit button',
  color: 'Select color',
};

// class and name attributes will be tested with this regular expressions
export const INPUTS_LABEL_MAP = new Map([
  ['Name', /(name)/],
  ['Age', /(age)/],
  ['Search', /(search|srch)/],
  ['Quantity', /(qua|qty|quantity)/],
  ['Count', /(count|cnt)/],
]);
// class and name attributes will be tested with this regular expressions
export const SELECTS_LABEL_MAP = new Map([
  ['Search', /(search|srch)/],
  ['Select name', /(name)/],
]);
