import { hashString, xpath, findLabelForControlElement } from '@uw/utils';
import { RuleParams } from '../../../types/remediation-rule';
import { FormLabelCorrection } from './types';
import { AUTO_STRATEGY_VALUE } from '../../../constants';
import { FORM_RULE_ID } from './constants';
import { RemediationConfig } from '../../config/config';
import { applyCorrectionData } from './apply-corrections';
import { composeAccessibleName } from './utils/compose-accessible-name';
import { saveRemediationResults } from '../../remediation-result/remediation-result';
import {
  checkControlElementType,
  updateControlElement,
} from './utils/form-label-utils';

export const formLabelRule = ({ context: { elements } }: RuleParams): void => {
  const widgetCorrectionsList: FormLabelCorrection[] = [];

  for (const elem of elements) {
    // save the statistic and continue cycle if consolidated correction is present
    const result = applyCorrectionData(elem);

    if (result) {
      widgetCorrectionsList.push(result);
      continue;
    }

    const isRequiredElement = elem.hasAttribute('required');
    const isAutoStrategy = RemediationConfig.strategy === AUTO_STRATEGY_VALUE; // only consolidated fixes will be applied if strategy is not auto
    const elementXpath = xpath(elem);
    const elementType = checkControlElementType(elem); // expected output: 'select' | 'textarea' | 'text'

    // save the statistic and continue cycle if element has its own accessible name
    const elementAccessibleName = findLabelForControlElement(elem);
    if (elementAccessibleName) {
      widgetCorrectionsList.push({
        type: elementType,
        xpath: elementXpath,
        correction: elementAccessibleName,
        approved: true, // always true because element is valid
        xpathHash: hashString(elementXpath),
        label: elementAccessibleName,
        required: isRequiredElement,
      });

      continue;
    }

    // if no corrections is coming from backend (consolidated.json),
    // rule will try to find accessible name in dom tree or
    // compose it using element secondary attributes such as class or title
    const composedAccessibleName = composeAccessibleName(
      elem as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement,
    );
    if (!composedAccessibleName) {
      widgetCorrectionsList.push({
        type: elementType,
        xpath: elementXpath,
        correction: null,
        approved: false,
        xpathHash: hashString(elementXpath),
        label: null,
        required: isRequiredElement,
      });

      continue;
    }

    updateControlElement(elem, composedAccessibleName, isAutoStrategy);

    widgetCorrectionsList.push({
      type: elementType,
      xpath: elementXpath,
      correction: composedAccessibleName,
      approved: false,
      xpathHash: hashString(elementXpath),
      label: null,
      required: isRequiredElement,
    });
  }

  // Send Post message data for widget
  saveRemediationResults<FormLabelCorrection>(
    FORM_RULE_ID,
    widgetCorrectionsList,
    widgetCorrectionsList.filter((correction) => correction.approved).length,
    widgetCorrectionsList.filter((correction) => !correction.approved).length,
  );
};
