import { PostMessageAction } from '../../constants/base-api';

export const onPostMessage = (
  messageType: string,
  callback: () => void,
): (() => void) => {
  const listener = (event: MessageEvent): void => {
    const { data } = event;
    const { isUserWay, action, type } = data;

    if (
      !isUserWay ||
      action !== PostMessageAction.Remediation ||
      type !== messageType
    ) {
      return;
    }

    callback();
  };

  window.addEventListener('message', listener);

  const unubscribe = (): void => {
    window.removeEventListener('message', listener);
  };

  return unubscribe;
};
