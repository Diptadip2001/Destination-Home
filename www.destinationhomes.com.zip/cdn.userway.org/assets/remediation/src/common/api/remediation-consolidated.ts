import { RemediationConfiguration } from '../../types/remediations-config';

export const getRemediationSettings = async (
  jsonUrl: string,
): Promise<RemediationConfiguration> => {
  const response = await fetch(jsonUrl);
  const json = await response.json();
  return json;
};
