import { ENDPOINT_CDN } from '../../constants/base-api';
import { ImageAltConfig, ServicesConfig } from '../config/config';

export interface CorrectionInfo {
  src: string;
  alt: string;
  approved: boolean;
  decorative: boolean;
  reverted?: boolean;
  metadata: {
    foundCachedResponse: boolean;
    normalizedImageUrl: string;
  };
}
interface MissingAltResponse {
  missingAlts: CorrectionInfo[];
}

export const getMissingAlts = async (
  altListJson: string,
): Promise<MissingAltResponse> => {
  const { account } = UserWayWidgetApp.ContextHolder.config;
  const { siteId } = ServicesConfig;
  const { resourceHash } = ImageAltConfig;

  const preparedAltsData = encodeURIComponent(altListJson);
  const response = await fetch(
    `${ENDPOINT_CDN}api/img-dscr/v2/${account}/${siteId}/${resourceHash}/alts.json?dto=${preparedAltsData}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    },
  );
  const json = await response.json();
  return json.payload;
};
