import { RemediationRule } from '../../types/remediation-rule';
import { AriaEditorRule } from '../rules/aria-editor';
import { ImageAltRule } from '../rules/image-alt';
import { FormLabelRule } from '../rules/form-label';
import { EmptyControlsRule } from '../rules/empty-controls';
import { HeaderTitleRule } from '../rules/header-title';
// import { BrokenLinkRule } from '../rules/broken-links';

export const RulesList: RemediationRule[] = [
  HeaderTitleRule,
  ImageAltRule,
  FormLabelRule,
  AriaEditorRule,
  EmptyControlsRule,
  // BrokenLinkRule,
];
