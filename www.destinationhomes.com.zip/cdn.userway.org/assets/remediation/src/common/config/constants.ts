export const InitialRemediationConfig = {
  AriaEditorValues: [],
  BrokenLink: [],
  Contrast: [],
  EmptyControls: [],
  ExternalLink: [],
  Forms: [],
  Headings: [],
  Language: [],
  MissingAlts: [],
  Pdfs: [],
  VagueLinks: [],
};
