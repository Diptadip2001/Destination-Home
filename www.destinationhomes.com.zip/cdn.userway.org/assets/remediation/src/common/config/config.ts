import { getRemediationSettings } from '../api/remediation-consolidated';
import type { RemediationConfiguration } from '../../types/remediations-config';
import { InitialRemediationConfig } from './constants';

export const RemediationConfig =
  UserWayWidgetApp.ContextHolder.config.remediation;
export const TuningsConfig = UserWayWidgetApp.ContextHolder.config.tunings;
export const ServicesConfig = UserWayWidgetApp.ContextHolder.config.services;
export const ImageAltConfig = UserWayWidgetApp.ContextHolder.config.imageAlt;

export const { isMobile } = UserWayWidgetApp.ContextHolder.config;

let RulesConfig: RemediationConfiguration = {} as RemediationConfiguration;

export function setRulesConfig(data: RemediationConfiguration): void {
  RulesConfig = { ...data };
}

export function getRulesConfig(): RemediationConfiguration {
  return RulesConfig;
}

export const initConfig = async (): Promise<void> => {
  if (RemediationConfig?.consolidated) {
    const config = await getRemediationSettings(RemediationConfig.consolidated);
    // BE saves new updates as new element, so more relevant data will be the last => need reverse before find correction
    config.MissingAlts.reverse();
    setRulesConfig(config);
    return;
  }

  // in case we do not have consolidated json link from BE, use empty config
  setRulesConfig(InitialRemediationConfig);
};
