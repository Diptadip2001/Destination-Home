import { isMobile, RemediationConfig } from '../../config/config';

export const isRemediationExcluded = (): boolean => {
  const WP_ADMIN_PATH = 'wp-admin';
  const isWordpressAdmin =
    window.location?.pathname.indexOf(WP_ADMIN_PATH) > -1;

  if (isWordpressAdmin) {
    return true;
  }

  if (!RemediationConfig?.commonSettings) {
    return false;
  }

  const {
    mobile: mobileSettings,
    disabledPages,
  } = RemediationConfig.commonSettings.config;

  if (isMobile && mobileSettings && !mobileSettings.enabled) {
    return true;
  }

  if (
    disabledPages?.some(
      (page: string) => window.location?.href.indexOf(page) > -1,
    )
  ) {
    return true;
  }

  return false;
};
