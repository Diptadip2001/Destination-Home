import { RemediationRule } from '../../../types/remediation-rule';
import { getRuleConfigName } from '../../../utils/get-rule-config-name/get-rule-config-name';
import { RemediationConfig, ServicesConfig } from '../../config/config';

export const getFilteredRulesList = (
  rules: RemediationRule[],
): RemediationRule[] =>
  rules.filter((rule: RemediationRule) => {
    const configKey = getRuleConfigName(rule.ruleId);

    if (!configKey || !ServicesConfig.paidAi) {
      return true;
    }

    const config = RemediationConfig[configKey];

    if (!config) {
      return true;
    }

    return (config as RemediationRuleConfigV2).enabled;
  });
