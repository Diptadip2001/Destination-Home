import { TuningsConfig } from '../config/config';
import { getAllElements } from '../../utils/get-all-elements/get-all-elements';
import type { PerformanceService } from '../performance-service/performance-service';
import { useDeferredRunner } from '../performance-control/use-deferred-runner';
import { RemediationRule } from '../../types/remediation-rule';
import { PostMessageType } from '../../constants/base-api';
import { onPostMessage } from '../api/on-post-message';
import { initAccessibilityTreeObserver } from '../accessibility-tree-observer/accessibility-tree-observer';
import { subscribeOnDomUpdates } from '../dom-observers/main-observer';
import { isRemediationExcluded } from './utils/is-remediation-excluded';
import { getFilteredRulesList } from './utils/get-filtered-rules-list';

interface RemediationManager {
  run: (elements: HTMLElement[]) => void;
  init: () => void;
  onDomUpdates: (elements: HTMLElement[]) => void;
}

const ENV: string = '__ENV__';
const RULES_LIST: string = '__RULES_LIST__';

export const createRemediationManager = (): RemediationManager => {
  let remediationInProgress: boolean = false;
  let performanceService: PerformanceService;
  let rulesList: RemediationRule[] = [];
  let remediationElementsQueue: HTMLElement[] = [];

  const runCallback = (elements: HTMLElement[]): void => {
    const measureId = performanceService?.startMeasurement();
    // TODO: check do we need run it cause now remediation is sync
    if (remediationInProgress) {
      return;
    }

    remediationInProgress = true;
    rulesList.forEach((rule: RemediationRule) => {
      rule.run(elements);
    });
    remediationInProgress = false;
    remediationElementsQueue = [];

    performanceService?.stopMeasurement(measureId);
  };

  const { run } = useDeferredRunner(runCallback);

  const onDomUpdates = (elements: HTMLElement[]): void => {
    /** PUSHING MUTATED ELEMENTS TO ARRAY */
    remediationElementsQueue.push(...elements);
    /** THROTTLED/DEBOUNCED CALL */
    run(remediationElementsQueue);
  };

  const startRemediationProcess = (): void => {
    const allElements = getAllElements();
    run([...allElements]);
    initAccessibilityTreeObserver();
    subscribeOnDomUpdates(onDomUpdates);
  };

  const init = async (): Promise<void> => {
    if (isRemediationExcluded()) {
      return;
    }

    if (ENV === 'development') {
      const performanceServiceModule = await import(
        '../performance-service/performance-service'
      );

      performanceService = performanceServiceModule.performanceService;
    }

    const RulesListModule = await import(
      RULES_LIST === 'paid'
        ? '../rules-list/rules-list'
        : '../rules-list/rules-list-free'
    );

    // filter rules disabled by BE config
    rulesList = getFilteredRulesList(RulesListModule.RulesList);

    if (!TuningsConfig.tech_rem_on_tab) {
      startRemediationProcess();
    }

    const unsubscribe = onPostMessage(
      PostMessageType.KeyboardNavEnabled,
      () => {
        startRemediationProcess();
        unsubscribe();
      },
    );
  };

  return { run, init, onDomUpdates };
};

export const remediationManager = createRemediationManager();
