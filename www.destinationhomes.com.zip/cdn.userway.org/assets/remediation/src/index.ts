import { initDomObserver } from './common/dom-observers/main-observer';
import { remediationManager } from './common/remediation-manager/remediation-manager';
import { initConfig, TuningsConfig } from './common/config/config';
import { DEFAULT_REMEDIATION_TIMEOUT } from './constants';

const initApp = async (): Promise<void> => {
  await initConfig();
  const REMEDIATION_TIMEOUT =
    TuningsConfig.tech_rem_in_throttle_ms ?? DEFAULT_REMEDIATION_TIMEOUT;

  setTimeout(() => {
    remediationManager.init();
    initDomObserver();
  }, REMEDIATION_TIMEOUT);
};

initApp();
