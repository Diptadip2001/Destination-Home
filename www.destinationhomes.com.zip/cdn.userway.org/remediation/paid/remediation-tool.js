var __defProp = Object.defineProperty,
    __defProps = Object.defineProperties,
    __getOwnPropDescs = Object.getOwnPropertyDescriptors,
    __getOwnPropSymbols = Object.getOwnPropertySymbols,
    __hasOwnProp = Object.prototype.hasOwnProperty,
    __propIsEnum = Object.prototype.propertyIsEnumerable,
    __defNormalProp = (e, t, r) => t in e ? __defProp(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : e[t] = r,
    __spreadValues = (e, t) => {
        for (var r in t || (t = {})) __hasOwnProp.call(t, r) && __defNormalProp(e, r, t[r]);
        if (__getOwnPropSymbols)
            for (var r of __getOwnPropSymbols(t)) __propIsEnum.call(t, r) && __defNormalProp(e, r, t[r]);
        return e
    },
    __spreadProps = (e, t) => __defProps(e, __getOwnPropDescs(t)),
    __objRest = (e, t) => {
        var r = {};
        for (var n in e) __hasOwnProp.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
        if (null != e && __getOwnPropSymbols)
            for (var n of __getOwnPropSymbols(e)) t.indexOf(n) < 0 && __propIsEnum.call(e, n) && (r[n] = e[n]);
        return r
    },
    __async = (e, t, r) => new Promise(((n, i) => {
        var o = e => {
                try {
                    l(r.next(e))
                } catch (t) {
                    i(t)
                }
            },
            a = e => {
                try {
                    l(r.throw(e))
                } catch (t) {
                    i(t)
                }
            },
            l = e => e.done ? n(e.value) : Promise.resolve(e.value).then(o, a);
        l((r = r.apply(e, t)).next())
    }));
! function() {
    "use strict";
    const e = ["script", "noscript", "style", "meta", "link", "path", "circle", "rect", "ellipse", "line", "polygon", "polyline", "g"],
        t = [".uwy", ".uwy *", ".uw-sl *"],
        r = ["data-uw-ignore", "data-uw-rm-ignore"],
        n = n => !(n instanceof HTMLElement) || r.some((e => n.hasAttribute(e))) || t.some((e => n.classList.contains(e))) || e.includes(n.nodeName.toLowerCase()),
        i = (e, t) => {
            if ("childList" === t) {
                const t = [...e.addedNodes].reduce(((e, t) => {
                    if (t instanceof HTMLElement) {
                        const r = [...t.getElementsByTagName("*")];
                        return [...e, ...r]
                    }
                    return e
                }), []);
                return [].filter.call([...e.addedNodes, ...t], (e => !n(e)))
            }
            return "attributes" === t ? n(e.target) ? [] : [e.target] : []
        },
        o = e => __async(this, null, (function*() {
            const t = yield fetch(e);
            return yield t.json()
        })),
        a = {
            AriaEditorValues: [],
            BrokenLink: [],
            Contrast: [],
            EmptyControls: [],
            ExternalLink: [],
            Forms: [],
            Headings: [],
            Language: [],
            MissingAlts: [],
            Pdfs: [],
            VagueLinks: []
        },
        l = UserWayWidgetApp.ContextHolder.config.remediation,
        s = UserWayWidgetApp.ContextHolder.config.tunings,
        u = UserWayWidgetApp.ContextHolder.config.services,
        c = UserWayWidgetApp.ContextHolder.config.imageAlt,
        {
            isMobile: d
        } = UserWayWidgetApp.ContextHolder.config;
    let p = {};

    function m(e) {
        p = __spreadValues({}, e)
    }

    function f() {
        return p
    }
    const g = () => __async(this, null, (function*() {
        if (null == l ? void 0 : l.consolidated) {
            const e = yield o(l.consolidated);
            return e.MissingAlts.reverse(), void m(e)
        }
        m(a)
    }));
    var b = (e => (e.Remediation = "remediation", e.AriaEditor = "aria-editor", e))(b || {}),
        h = (e => (e.KeyboardNavEnabled = "app-key-nav-enabled", e))(h || {});
    const A = (e, t) => {
            const r = r => {
                const {
                    data: n
                } = r, {
                    isUserWay: i,
                    action: o,
                    type: a
                } = n;
                i && o === b.Remediation && a === e && t()
            };
            window.addEventListener("message", r);
            return () => {
                window.removeEventListener("message", r)
            }
        },
        E = document.documentElement,
        y = {
            attributes: !0,
            attributeFilter: ["aria-label", "alt"],
            childList: !0,
            subtree: !0
        },
        v = new Set,
        T = e => {
            v.add(e)
        },
        N = new MutationObserver((e => {
            const t = (e => {
                const t = [];
                for (const r of e) t.push(...i(r, r.type));
                return t
            })(e);
            t.length && v.forEach((e => e(t)))
        }));
    const w = "object" == typeof global && global && global.Object === Object && global;
    var _ = "object" == typeof self && self && self.Object === Object && self;
    const x = w || _ || Function("return this")();
    const L = x.Symbol;
    var O = Object.prototype,
        R = O.hasOwnProperty,
        S = O.toString,
        C = L ? L.toStringTag : void 0;
    var I = Object.prototype.toString;
    var D = "[object Null]",
        M = "[object Undefined]",
        k = L ? L.toStringTag : void 0;

    function P(e) {
        return null == e ? void 0 === e ? M : D : k && k in Object(e) ? function(e) {
            var t = R.call(e, C),
                r = e[C];
            try {
                e[C] = void 0;
                var n = !0
            } catch (o) {}
            var i = S.call(e);
            return n && (t ? e[C] = r : delete e[C]), i
        }(e) : function(e) {
            return I.call(e)
        }(e)
    }
    var B = "[object Symbol]";
    var U = /\s/;
    var W = /^\s+/;

    function H(e) {
        return e ? e.slice(0, function(e) {
            for (var t = e.length; t-- && U.test(e.charAt(t)););
            return t
        }(e) + 1).replace(W, "") : e
    }

    function j(e) {
        var t = typeof e;
        return null != e && ("object" == t || "function" == t)
    }
    var X = NaN,
        V = /^[-+]0x[0-9a-f]+$/i,
        $ = /^0b[01]+$/i,
        F = /^0o[0-7]+$/i,
        G = parseInt;

    function q(e) {
        if ("number" == typeof e) return e;
        if (function(e) {
                return "symbol" == typeof e || function(e) {
                    return null != e && "object" == typeof e
                }(e) && P(e) == B
            }(e)) return X;
        if (j(e)) {
            var t = "function" == typeof e.valueOf ? e.valueOf() : e;
            e = j(t) ? t + "" : t
        }
        if ("string" != typeof e) return 0 === e ? e : +e;
        e = H(e);
        var r = $.test(e);
        return r || F.test(e) ? G(e.slice(2), r ? 2 : 8) : V.test(e) ? X : +e
    }
    const K = function() {
        return x.Date.now()
    };
    var Z = "Expected a function",
        Y = Math.max,
        z = Math.min;

    function Q(e, t, r) {
        var n, i, o, a, l, s, u = 0,
            c = !1,
            d = !1,
            p = !0;
        if ("function" != typeof e) throw new TypeError(Z);

        function m(t) {
            var r = n,
                o = i;
            return n = i = void 0, u = t, a = e.apply(o, r)
        }

        function f(e) {
            var r = e - s;
            return void 0 === s || r >= t || r < 0 || d && e - u >= o
        }

        function g() {
            var e = K();
            if (f(e)) return b(e);
            l = setTimeout(g, function(e) {
                var r = t - (e - s);
                return d ? z(r, o - (e - u)) : r
            }(e))
        }

        function b(e) {
            return l = void 0, p && n ? m(e) : (n = i = void 0, a)
        }

        function h() {
            var e = K(),
                r = f(e);
            if (n = arguments, i = this, s = e, r) {
                if (void 0 === l) return function(e) {
                    return u = e, l = setTimeout(g, t), c ? m(e) : a
                }(s);
                if (d) return clearTimeout(l), l = setTimeout(g, t), m(s)
            }
            return void 0 === l && (l = setTimeout(g, t)), a
        }
        return t = q(t) || 0, j(r) && (c = !!r.leading, o = (d = "maxWait" in r) ? Y(q(r.maxWait) || 0, t) : o, p = "trailing" in r ? !!r.trailing : p), h.cancel = function() {
            void 0 !== l && clearTimeout(l), u = 0, n = s = i = l = void 0
        }, h.flush = function() {
            return void 0 === l ? a : b(K())
        }, h
    }
    let J = !0;
    const ee = e => {
            setTimeout((() => {
                J = !1
            }), 2e3);
            const t = function(e, t, r) {
                    var n = !0,
                        i = !0;
                    if ("function" != typeof e) throw new TypeError("Expected a function");
                    return j(r) && (n = "leading" in r ? !!r.leading : n, i = "trailing" in r ? !!r.trailing : i), Q(e, t, {
                        leading: n,
                        maxWait: t,
                        trailing: i
                    })
                }((t => e(t)), 300, {
                    leading: !0,
                    trailing: !0
                }),
                r = Q((t => e(t)), 500, {
                    maxWait: 2e3,
                    leading: !0,
                    trailing: !0
                });
            return {
                run: e => J ? t(e) : r(e)
            }
        },
        te = (e, t = ["userway"]) => {
            const r = __spreadProps(__spreadValues({}, e), {
                isUserWay: !0
            });
            t.forEach((e => {
                let t = window.frames[e];
                if (!t || "function" != typeof t.postMessage) try {
                    t = document.querySelector(`iframe[name=${e}]`), t = t ? t.contentWindow : null
                } catch (n) {
                    console.error(n)
                }
                t && t.postMessage(r, "*")
            }))
        },
        re = (e, t) => {
            if (e === document) return !0;
            const r = e,
                n = getComputedStyle(r),
                i = r.getBoundingClientRect(),
                o = (e => e.top >= 0 && e.left >= 0 && e.bottom <= (window.innerHeight || document.documentElement.clientHeight) && e.right <= (window.innerWidth || document.documentElement.clientWidth))(i),
                a = 0 === i.width || 0 === i.height,
                l = "0" !== n.opacity && "hidden" !== n.visibility && "none" !== n.display && "collapse" !== n.visibility;
            return (r.offsetWidth > 0 || r.offsetHeight > 0 || r.getClientRects().length > 0) && (!t.shouldBeInViewport || o) && !a && l
        },
        ne = e => {
            if (["#text", "#comment"].includes(e.nodeName)) return !1;
            let t = e.getAttribute("aria-hidden"),
                r = e.getAttribute("hidden");
            return (e => "none" === window.getComputedStyle(e).display)(e) || "true" === t || null !== r && "" !== r
        },
        ie = ["NOSCRIPT", "SCRIPT", "style"],
        oe = (e, t) => {
            var r;
            for (let n = 0; n < e.length; n++) {
                let i = e[n];
                switch (i.nodeType) {
                    case Node.TEXT_NODE:
                        t += " " + (null == (r = i.textContent) ? void 0 : r.trim().replace(/(\n|\r\n)/g, ""));
                        break;
                    case Node.ELEMENT_NODE:
                        if (ie.includes(i.tagName) || ne(i)) break;
                        const e = i.getAttribute("aria-hidden"),
                            n = i.getAttribute("alt"),
                            o = i.getAttribute("aria-label");
                        if (!e || "false" === e) {
                            if (o) {
                                t += " " + o;
                                break
                            }
                            n && (t += n + " "), "IMG" !== i.tagName && (t = oe(i.childNodes, t))
                        }
                }
            }
            return t
        },
        ae = (e, t = "") => {
            let r = t;
            return (t = oe(e.childNodes, r)).replace(/\s+/g, " ").trim()
        },
        le = e => {
            let t = e.split(" "),
                r = "";
            for (let n = 0; n < t.length; n++) {
                let e = document.getElementById(t[n]);
                e && (r = " " + ae(e, r))
            }
            return r
        },
        se = e => {
            const t = e.alt;
            if (t && t.trim()) return t.trim();
            const r = e.getAttribute("aria-label");
            if (r && r.trim()) return r.trim();
            const n = e.getAttribute("aria-describedby");
            if (n) {
                const e = ue(n);
                if (e) return e
            }
            const i = e.getAttribute("aria-labelledby");
            if (i) {
                let e = ue(i);
                if (e) return e
            }
            return null
        },
        ue = e => e.split(" ").reduce(((e, t) => {
            var r;
            const n = document.getElementById(t.trim());
            return e + (null != (r = null == n ? void 0 : n.textContent) ? r : "")
        }), ""),
        ce = (e, t = 0) => {
            let r = 3735928559 ^ t,
                n = 1103547991 ^ t;
            for (let i, o = 0; o < e.length; o++) i = e.charCodeAt(o), r = Math.imul(r ^ i, 2654435761), n = Math.imul(n ^ i, 1597334677);
            return r = Math.imul(r ^ r >>> 16, 2246822507) ^ Math.imul(n ^ n >>> 13, 3266489909), n = Math.imul(n ^ n >>> 16, 2246822507) ^ Math.imul(r ^ r >>> 13, 3266489909), 4294967296 * (2097151 & n) + (r >>> 0)
        },
        de = (e, t = !1) => {
            var r;
            if ("html" === e.nodeName.toLowerCase()) return "/HTML";
            if ("body" === e.nodeName.toLowerCase()) return "/HTML/BODY";
            if ("head" === e.nodeName.toLowerCase()) return "/HTML/HEAD";
            let n = 0;
            const i = null == (r = e.parentElement) ? void 0 : r.children;
            if (!i) return "";
            for (let o = 0; o < i.length; o++) {
                let r = i[o];
                if (r === e) return de(e.parentElement, !0) + `/${e.tagName}[${n+1}]` + (t ? "" : pe(e));
                r.tagName === e.tagName && n++
            }
            return ""
        };

    function pe(e) {
        const t = {
                s: "src",
                h: "href"
            },
            r = e.innerText ? ce(e.innerText) : "";
        return Object.keys(t).reduce(((r, n) => {
            const i = t[n],
                o = e.getAttribute(i) || "";
            return e.hasAttribute && e.hasAttribute(i) && "" !== o ? r + ";" + n + ":" + ce(o) : r
        }), "|" + r)
    }
    const me = new RegExp("^(data:)"),
        fe = new RegExp("(.)(gif|jpe?g|tiff?|png|webp|bmp)", "i"),
        ge = e => {
            if (me.test(e)) return e;
            e && (e = e.replace(/^(http|https)(:\/\/)/, "").replace(/^(www\.)/, ""));
            const t = e.match(fe);
            return (null == t ? void 0 : t.index) && (null == t ? void 0 : t.length) ? e.substring(0, t.index + t[0].length) : e.split("?")[0]
        },
        be = (e, t, r = !1) => e.reduce(((e, n) => {
            const i = r && n.position ? ":nth-of-type(" + n.position + ")" : "";
            return e += n.tag + i + (n.idx >= t ? ">" : " ")
        }), "").slice(0, -1),
        he = (e, t) => {
            if (null === t) return !0;
            const r = e.innerText ? ce(e.innerText).toString() : "";
            if (t.innerText.toString() !== r) return !1;
            const n = e.hasAttribute("href") ? ce(e.getAttribute("href")).toString() : "";
            if (t.href && t.href !== n) return !1;
            const i = e.hasAttribute("src") ? ce(e.getAttribute("src")).toString() : "";
            return !t.src || t.src === i
        },
        Ae = (e, t = null, r) => {
            const n = (i = e, [].slice.call(document.querySelectorAll(i)));
            var i;
            if (1 === n.length) {
                if (null == r.params) return n[0];
                if (he(n[0], t)) return n[0]
            }
            if (n.length > 1) {
                if (null == r.params) return null;
                const e = n.filter((e => he(e, t)));
                if (1 === e.length) return e[0]
            }
            return null
        };
    var Ee = (e => (e[e.Strict = 0] = "Strict", e[e.Medium = 1] = "Medium", e[e.Loose = 2] = "Loose", e))(Ee || {});
    const ye = {
            i: "innerText",
            s: "src",
            h: "href"
        },
        ve = e => {
            const [t, r] = e.split("|");
            let n = {
                innerText: ""
            };
            if (r) {
                const [e, ...t] = r.split(";");
                n.innerText = e, t.forEach((e => {
                    const [t, r] = e.split(":");
                    n[ye[t]] = r
                }))
            }
            return {
                xpath: t,
                params: n
            }
        },
        Te = e => {
            const {
                xpath: t,
                params: r
            } = ve(e), n = ((e, t) => {
                const r = ("/" === e[0] ? e.slice(1) : e).split("/");
                return r.map(((e, n) => {
                    const i = e.toLowerCase(),
                        [, o, a] = i.match(/(\S+)\[(\S+)?\]/) || [, i],
                        l = r.length - 1 === n,
                        s = {
                            idx: n,
                            tag: o
                        };
                    return a && (s.position = +a), l && t && (s.params = t), s
                }))
            })(t, r);
            return ((e, t = 4) => {
                let r = e.length - 2 - t;
                const n = e[e.length - 1];
                let i;
                const o = n.params;
                if (r < 0) {
                    i = be(e, 0, !0);
                    return Ae(i, o, n) || (i = be(e, 0), Ae(i, o, n))
                }
                const a = a => {
                        for (r = e.length - 2 - t; r >= 0; r--) {
                            i = a === Ee.Loose ? be(e.slice(0, 2).concat(...e.slice(-r - t)), e.length - t) : be(e, e.length - t - r - 1, a === Ee.Strict);
                            const l = Ae(i, o, n);
                            if (l) return l
                        }
                    },
                    l = [Ee.Strict, Ee.Medium, Ee.Loose];
                for (let s = 0; s < l.length; s++) {
                    const e = a(l[s]);
                    if (e) return e
                }
                return null
            })(n)
        },
        Ne = e => {
            const {
                xpath: t,
                params: r
            } = ve(e), n = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            return he(n, r) ? n : null
        },
        we = e => {
            let t = e.closest("label"),
                r = "";
            if (t) {
                for (let e of t.childNodes) e.nodeType === Node.TEXT_NODE && (r += e.textContent);
                if (r.trim()) return r.trim()
            }
            if (e.id) {
                let t = (e => {
                    const t = document.querySelectorAll("LABEL");
                    for (let r = 0; r < t.length; r++)
                        if (t[r].htmlFor === e) return t[r];
                    return null
                })(e.id);
                if (t) return ae(t, "")
            }
            const n = e.getAttribute("aria-label"),
                i = e.getAttribute("aria-labelledby");
            if (n) return n;
            if (i) return le(i);
            const o = e.getAttribute("title");
            if (o) return o;
            return ae(e, "") || ""
        };
    var _e = (e => (e.TABINDEX = "tabindex", e.ROLE = "role", e.TYPE = "type", e.SRC = "src", e.ARIA_LEVEL = "ariaLevel", e.ORIGINAL_ALT = "originalAlt", e))(_e || {}),
        xe = (e => (e.UNKNOWN = "UNKNOWN", e.NOT_ALLOWED = "NOT_ALLOWED", e.TEXT_NODE = "TEXT_NODE", e.LANDMARK = "LANDMARK", e.CONTROL = "CONTROL", e.HEADING = "HEADING", e.HAS_ALT_DESCRIPTION = "HAS_ALT_DESCRIPTION", e.COMPOSED_TEXT_NODES = "COMPOSED_TEXT_NODES", e.IFRAME = "IFRAME", e.HIDDEN_FOR_READER = "HIDDEN_FOR_READER", e))(xe || {}),
        Le = (e => (e.UNKNOWN = "unknown", e.TEXT = "text", e.IMAGE = "image", e.HEADING = "heading", e.FOOTER = "footer", e.HEADER = "header", e.NAV = "nav", e.MAIN = "main", e.FORM = "form", e.LANDMARK = "landmark", e.LINK = "link", e.BUTTON = "button", e.CHECKBOX = "checkbox", e.RADIOBUTTON = "radiobutton", e.INPUT = "input", e.TEXTAREA = "textarea", e.SELECT = "select", e.ABBR = "abbr", e.LIST_ITEM = "list item", e))(Le || {});
    const Oe = "accessibility-tree-observer",
        Re = ["uw-sl", "uwy", "uw-s10-reading-guide", "uw-s12-tooltip"],
        Se = (e, t) => t.ariaLabel ? t.ariaLabel : t.ariaLabelledBy ? le(t.ariaLabelledBy) : ae(e, ""),
        Ce = {},
        Ie = UserWayWidgetApp.getLib("accessibility_tree_walker");
    let De, Me = [],
        ke = 1;
    const Pe = (e, t) => {
            var r;
            if (Me = [], (e => {
                    const t = 3 === e.nodeType;
                    return Re.some((t => !!e.closest && e.closest(`.${t}`))) || !t && e.hasAttribute("data-uw-rm-ignore")
                })(e) && !t) return null;
            const n = {
                    node: e,
                    type: Ie.identifyElementType(e)
                },
                i = (e => {
                    if (!e || !e.type) return {};
                    const {
                        node: t
                    } = e;
                    return [xe.UNKNOWN, xe.NOT_ALLOWED, xe.TEXT_NODE].includes(e.type) ? {
                        uwAtoId: t.uwAtoId
                    } : {
                        tagName: t.tagName,
                        tabindex: t.getAttribute("tabindex") || "",
                        role: t.getAttribute("role") || "",
                        ariaLevel: t.getAttribute("aria-level") || "",
                        ariaLabel: t.getAttribute("aria-label") || "",
                        ariaLabelledBy: t.getAttribute("aria-labelledby") || "",
                        type: t.getAttribute("type") || "",
                        uwAtoId: t.uwAtoId
                    }
                })(n);
            De = Ie.identifyElementType(e);
            const o = De === xe.HIDDEN_FOR_READER;
            let a, l;
            switch (Me = (e => (e.tabindex && Me.push({
                name: _e.TABINDEX,
                value: e.tabindex
            }), e.role && Me.push({
                name: _e.ROLE,
                value: e.role
            }), e.type && Me.push({
                name: _e.TYPE,
                value: e.type
            }), e.ariaLevel && Me.push({
                name: _e.ARIA_LEVEL,
                value: e.ariaLevel
            }), Me))(i), o && ((e, t) => {
                const r = e.cloneNode(!0);
                r.removeAttribute("aria-hidden"), De = Ie.identifyElementType(r), De !== xe.UNKNOWN || "IMG" !== t.tagName && "img" !== t.role || (De = xe.HAS_ALT_DESCRIPTION)
            })(e, i), De) {
                case xe.TEXT_NODE:
                    a = (e => {
                        const t = Le.TEXT;
                        let r = "";
                        e.textContent && (r = e.textContent.trim().replace(/(\n|\r\n)/g, "").replace(/\s+/g, " "));
                        const n = {};
                        return e.parentElement && (n.parentXpath = de(e.parentElement)), {
                            semanticType: t,
                            textToRead: r,
                            additionalParams: n
                        }
                    })(e), Ce.parentXpath = null == (r = a.additionalParams) ? void 0 : r.parentXpath;
                    break;
                case xe.COMPOSED_TEXT_NODES:
                    a = ((e, t) => ({
                        semanticType: "LI" === t.tagName ? Le.LIST_ITEM : Le.TEXT,
                        textToRead: t.ariaLabel || ae(e, "")
                    }))(e, i);
                    break;
                case xe.HIDDEN_FOR_READER:
                    a = {
                        semanticType: Le.UNKNOWN,
                        textToRead: ""
                    };
                    break;
                case xe.HEADING:
                    a = ((e, t) => ({
                        semanticType: Le.HEADING,
                        textToRead: t.ariaLabel || ae(e, "")
                    }))(e, i);
                    break;
                case xe.LANDMARK:
                    a = (e => {
                        let t, r = "";
                        e.ariaLabel ? r = e.ariaLabel : e.ariaLabelledBy && (r = le(e.ariaLabelledBy));
                        const {
                            tagName: n
                        } = e, {
                            role: i
                        } = e;
                        return t = "FOOTER" === n || "contentinfo" === i ? Le.FOOTER : "HEADER" === n || "banner" === i ? Le.HEADER : "FORM" === n || "form" === i ? Le.FORM : "MAIN" === n || "main" === i ? Le.MAIN : "NAV" === n || "navigation" === i ? Le.NAV : Le.LANDMARK, {
                            semanticType: t,
                            textToRead: r
                        }
                    })(i);
                    break;
                case xe.CONTROL:
                    a = ((e, t) => {
                        const {
                            tagName: r,
                            role: n,
                            type: i,
                            ariaLabel: o,
                            ariaLabelledBy: a
                        } = t;
                        let l = !1,
                            s = "",
                            u = Le.TEXT;
                        return "menuitem" === n || "option" === n ? (s = Se(e, t), l = !0) : "link" === n || "A" === r && !n ? (u = Le.LINK, s = Se(e, t), l = !0) : "button" === n || "BUTTON" === r ? (u = Le.BUTTON, s = Se(e, t), l = !0) : "INPUT" !== r || "button" !== i && "submit" !== i && "reset" !== i || (u = Le.BUTTON, o ? s = o : a && (s = le(a)), l = !0), l || (s = we(e), "checkbox" === n || "INPUT" === r && "checkbox" === i ? u = Le.CHECKBOX : "radio" === n || "INPUT" === r && "radio" === i ? u = Le.RADIOBUTTON : "INPUT" === r && (u = Le.INPUT), "TEXTAREA" === r && (u = Le.TEXTAREA), "SELECT" === r && (u = Le.SELECT)), {
                            semanticType: u,
                            textToRead: s
                        }
                    })(e, i);
                    break;
                case xe.HAS_ALT_DESCRIPTION:
                    a = ((e, t, r) => {
                        const {
                            tagName: n,
                            role: i,
                            ariaLabel: o
                        } = t, a = e.getAttribute("alt") || "", l = e.getAttribute("title") || "", s = e.getAttribute("data-uw-rm-ima-original") || "";
                        let u = "",
                            c = Le.TEXT;
                        const d = r;
                        return "IMG" !== n && "img" !== i || (c = Le.IMAGE, d.push({
                            name: _e.SRC,
                            value: e.src
                        }), d.push({
                            name: _e.ORIGINAL_ALT,
                            value: s
                        }), u = o || a || s || u), "ABBR" === n && (c = Le.ABBR, u = l), {
                            semanticType: c,
                            textToRead: u,
                            attributesToReturn: d
                        }
                    })(e, i, Me), a.attributesToReturn && (Me = a.attributesToReturn);
                    break;
                case xe.UNKNOWN:
                    a = ((e, t) => {
                        let r = Le.TEXT;
                        return "DIV" !== t.tagName || e.innerHTML || (r = Le.LANDMARK), {
                            semanticType: r,
                            textToRead: ""
                        }
                    })(e, i);
                    break;
                default:
                    a = {
                        textToRead: "",
                        semanticType: Le.TEXT
                    }
            }
            return i.uwAtoId ? l = i.uwAtoId : (l = ke, ke += 1, n.node.uwAtoId = l), __spreadValues({
                id: l,
                xpath: de(e),
                label: a.textToRead.replace(/\|/g, "").trim(),
                tagName: i.tagName || "",
                type: a.semanticType,
                hidden: o,
                attributes: Me,
                el: n.node
            }, Ce)
        },
        Be = UserWayWidgetApp.getLib("accessibility_tree_walker");
    let Ue = [];
    const We = () => {
            let e = null;
            Ue = [];
            do {
                const t = Be.getNextAccessibilityTreeNode(e);
                if (!t) break;
                const r = Pe(t.node);
                r && Ue.push(r), e = t.node
            } while (e);
            Ue = Ue.map((e => {
                const t = e,
                    {
                        el: r
                    } = t;
                return __objRest(t, ["el"])
            })), te({
                action: Oe,
                type: "userway:ato-output:get",
                data: {
                    nodes: Ue,
                    version: Date.now()
                }
            }, ["uwAccessibilityEditor"])
        },
        He = () => Ue,
        je = {
            enabled: !1
        },
        Xe = {
            "userway:ato-input:enable": () => {
                je.enabled || (je.enabled = !0, T(We), We())
            },
            "userway:ato-input:disable": () => {
                var e;
                je.enabled && (je.enabled = !1, e = We, v.delete(e))
            },
            "userway:ato-input:get": We
        },
        Ve = {
            automaticcoupons: /automaticcoupons/,
            "shopping.yahoo": /shopping\.yahoo/,
            shopperapproved: /shopperapproved/,
            rakuten: /rakuten/,
            "translate.google": /translate\.google/,
            "maps.googleapis.com": /maps\.googleapis\.com/,
            "s.w.org": /s\.w\.org/,
            avatar: /avatar/,
            companylogos: /companylogos/,
            favicon: /favicon/,
            activecampaign: /lt\.php(.*)?l=open/,
            aweber: /openrate\.aweber\.com/,
            bananatag: /bl-1\.com/,
            boomerang: /mailstat\.us\/tr/,
            "campaign monitor": /cmail(\d+)\.com\/t\//,
            "cirrus insight": /tracking\.cirrusinsight\.com/,
            close: /close\.com\/email_opened/,
            "constant contact": /rs6\.net\/on\.jsp/,
            contactmonkey: /contactmonkey\.com\/api\/v1\/tracker/,
            convertkit: /convertkit-mail\.com\/o/,
            "critical impact": /portal\.criticalimpact\.com\/c2\//,
            emarsys: /emarsys\.com\/e2t\/o/,
            gem: /zen\.sr\/o/,
            getnotify: /email81\.com\/case/,
            getresponse: /getresponse\.com\/open\.html/,
            growthdot: /growthdot\.com\/api\/mail-tracking/,
            front: /app\.frontapp\.com\/(.*)?\/seen/,
            hubspot: /t\.(hubspotemail|hubspotfree|signaux|senal|sidekickopen|sigopn)/,
            icontact: /click\.icptrack\.com\/icp/,
            intercom: /(via\.intercom\.io\/o)|(intercom-mail\.com\/via\/o)/,
            litmus: /emltrk\.com/,
            mailchimp: /list-manage\.com\/track/,
            mailgun: /email\.(mailgun|mg)(.*)?\/o/,
            mailjet: /mjt\.lu\/oo/,
            mailspring: /getmailspring\.com\/open/,
            mailtrack: /(mailtrack\.io\/trace)|(mltrk\.io\/pixel)/,
            mandrill: /mandrillapp\.com\/track/,
            marketo: /resources\.marketo\.com\/trk/,
            mixmax: /(email|track)\.mixmax\.com/,
            mixpanel: /api\.mixpanel\.com\/track/,
            nethunt: /nethunt\.co(.*)?\/pixel\.gif/,
            newton: /tr\.cloudmagic\.com/,
            outreach: /api\/mailings\/opened/,
            phplist: /phplist\.com\/lists\/ut\.php/,
            polymail: /polymail\.io/,
            postmark: /pstmrk\.it\/open/,
            "return path": /returnpath\.net\/pixel\.gif/,
            sailthru: /sailthru\.com\/trk/,
            salesforce: /nova\.collect\.igodigital\.com/,
            sendgrid: /wf\/open\?upn/,
            sendy: /sendy\/t\//,
            streak: /mailfoogae\.appspot\.com/,
            superhuman: /r\.superhuman\.com/,
            thunderhead: /na5\.thunderhead\.com/,
            tinyletter: /tinyletterapp\.com.*open\.gif/,
            yamm: /yamm-track\.appspot/,
            yesware: /t\.yesware\.com/,
            "zendesk sell": /futuresimple\.com\/api\/v1\/sprite\.png/
        },
        $e = ["icon", "cart", "logo"],
        Fe = ["h1", "h2", "h3", "h4", "h5", "h6", "span", "a", "p", "figcaption", "caption", "div"],
        Ge = ["heading"],
        qe = new RegExp("^(data:)"),
        Ke = new RegExp(/^.+\.svg$/);
    var Ze = (e => (e.EXCLUDED_SRC = "EXCLUDED_SRC", e.HIDDEN_FROM_SCREEN_READER = "HIDDEN_FROM_SCREEN_READER", e.BASE64 = "BASE64", e.SVG = "SVG", e.SMALL_SIZE = "SMALL_SIZE", e.MICRO_SIZE = "MICRO_SIZE", e.WRONG_SRC = "WRONG_SRC", e.ASPECT_RATIO = "ASPECT_RATIO", e))(Ze || {});
    const Ye = ["SVG", "SMALL_SIZE", "HIDDEN_FROM_SCREEN_READER"],
        ze = "data-uw-rm-alt-original",
        Qe = "REMEDIATION_IMAGE_MISSING_ALT",
        Je = "data-uw-rm-alt",
        et = ["jpg", "jpeg", "png", "gif", "bmp", "tiff", "tif", "svg", "webp", "ico", "apng", "heif", "heic", "avif", "eps", "raw", "cr2", "nef", "orf", "sr2"];
    var tt = (e => (e.CorrectAlt = "ALT", e.Reverted = "RT", e.Backend = "BE", e.Excluded = "EX", e.Hidden = "HD", e.Base64 = "BS64", e.Svg = "SVG", e.Small = "SM", e.Micro = "MC", e.InvalidSrc = "SRC", e.AspectRatio = "AR", e.AI = "AI", e.AIQuotaExceed = "QU", e.ClosestText = "CT", e))(tt || {});
    const rt = "uwAccessibilityEditor",
        nt = u.editorBuildUrl,
        it = "aria-editor",
        ot = "data-uw-rm-heading",
        at = "aria-editor",
        lt = "REMEDIATION_EMPTY_CONTROLS",
        st = "data-uw-rm-empty-ctrl",
        ut = ["facebook", "youtube", "whatsapp", "instagram", "twitter", "reddit", "linkedin", "viber", "pinterest", "telegram", "search", "cart", "home"],
        ct = {
            prev: "Get previous item",
            next: "Get next item",
            scroll: "Activate for scroll",
            top: "Move to top",
            bottom: "Move to bottom",
            expand: "Expand this block",
            collapse: "Collapse this block",
            close: "Close this option"
        },
        dt = [{
            re: /(fa-)(.+)/,
            replacer: "$2"
        }],
        pt = "REMEDIATION_FORM_LABEL",
        mt = "data-uw-rm-form",
        ft = ["INPUT", "TEXTAREA", "SELECT"],
        gt = ["facebook", "google"],
        bt = "data-uw-hidden-control",
        ht = "hidden-control-element",
        At = {
            text: "Text field",
            radio: "Radio button",
            checkbox: "Checkbox field",
            email: "Please enter email address",
            url: "Please enter url",
            tel: "Please enter a phone number",
            password: "Password field",
            search: "Search field",
            date: "Date field",
            time: "Time field",
            image: "Image field",
            file: "File field",
            number: "Number",
            range: "Select range",
            submit: "Submit button",
            color: "Select color"
        },
        Et = new Map([
            ["Name", /(name)/],
            ["Age", /(age)/],
            ["Search", /(search|srch)/],
            ["Quantity", /(qua|qty|quantity)/],
            ["Count", /(count|cnt)/]
        ]),
        yt = new Map([
            ["Search", /(search|srch)/],
            ["Select name", /(name)/]
        ]),
        vt = e => e.filter((e => {
            const t = (e => {
                switch (e) {
                    case Qe:
                        return "alt";
                    case it:
                        return "ariaEditor";
                    case lt:
                        return "emptyControls";
                    case pt:
                        return "forms";
                    default:
                        return null
                }
            })(e.ruleId);
            if (!t || !u.paidAi) return !0;
            const r = l[t];
            return !r || r.enabled
        })),
        Tt = (() => {
            let t = !1,
                n = [],
                i = [];
            const {
                run: o
            } = ee((e => {
                t || (t = !0, n.forEach((t => {
                    t.run(e)
                })), t = !1, i = [])
            })), a = e => {
                i.push(...e), o(i)
            }, u = () => {
                const t = (() => {
                    const t = `${e.join(",")},${r.map((e=>`[${e}]`)).join(",")}`;
                    return document.body.querySelectorAll(`*:not(${t})`)
                })();
                o([...t]), window.addEventListener("message", (e => {
                    const {
                        data: {
                            action: t,
                            type: r
                        }
                    } = e;
                    t === Oe && Xe[r] && Xe[r]()
                })), T(a)
            };
            return {
                run: o,
                init: () => __async(this, null, (function*() {
                    if ((() => {
                            var e;
                            if ((null == (e = window.location) ? void 0 : e.pathname.indexOf("wp-admin")) > -1) return !0;
                            if (!(null == l ? void 0 : l.commonSettings)) return !1;
                            const {
                                mobile: t,
                                disabledPages: r
                            } = l.commonSettings.config;
                            return !(!d || !t || t.enabled) || !!(null == r ? void 0 : r.some((e => {
                                var t;
                                return (null == (t = window.location) ? void 0 : t.href.indexOf(e)) > -1
                            })))
                        })()) return;
                    const e = yield Promise.resolve().then((() => tn));
                    n = vt(e.RulesList), s.tech_rem_on_tab || u();
                    const t = A(h.KeyboardNavEnabled, (() => {
                        u(), t()
                    }))
                })),
                onDomUpdates: a
            }
        })();
    (() => {
        __async(this, null, (function*() {
            var e;
            yield g();
            const t = null != (e = s.tech_rem_in_throttle_ms) ? e : 500;
            setTimeout((() => {
                Tt.init(), ((e = E, t = y) => {
                    s.tech_rem_on_tab || N.observe(e, t);
                    const r = A(h.KeyboardNavEnabled, (() => {
                        N.observe(e, t), r()
                    }))
                })()
            }), t)
        }))
    })();
    const Nt = ({
            ruleId: e,
            isTargetElement: t,
            rule: r,
            postMessageApi: n,
            forceRun: i
        }) => (n && window.addEventListener("message", (e => {
            const {
                data: t
            } = e, {
                isUserWay: r,
                action: i,
                type: o
            } = t;
            !r || i !== b.Remediation && i !== b.AriaEditor || n[o] && n[o](t.data ? t.data : t)
        })), {
            run: n => {
                if (!t) return void r({
                    context: {
                        elements: n
                    }
                });
                const o = n.filter((r => !r.hasAttribute(`uw-ignore-${e}`) && t(r)));
                o.length ? r({
                    context: {
                        elements: o
                    }
                }) : i && r({
                    context: {
                        elements: []
                    }
                })
            },
            stop: () => {},
            rerun: () => {},
            ruleId: e
        }),
        wt = e => {
            if (!e) return null;
            const t = e.split("|")[0];
            return document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
        },
        _t = e => !!["input", "select", "button", "textarea", "a"].includes(e.tagName.toLowerCase()) || ["button", "checkbox", "link", "option"].includes((e.getAttribute("role") || "").toLowerCase()),
        xt = e => {
            const t = e.getAttribute("tabindex");
            if (null !== t) {
                const e = parseInt(t, 10);
                if (!Number.isNaN(e)) return e
            }
        },
        Lt = e => {
            if (_t(e)) return !0;
            const t = xt(e);
            return void 0 !== t && !Number.isNaN(t) && t >= 0
        },
        Ot = t => !!e.includes(t.toLowerCase()),
        Rt = (e, t) => ("img" === e ? t.getAttribute("alt") : t.getAttribute("aria-label")) || null,
        St = e => e.getAttribute("role") || null,
        Ct = e => e.getAttribute("aria-level") || null,
        It = (e, t) => "img" === e ? t.getAttribute("src") : null,
        Dt = e => {
            if (null == e ? void 0 : e.nextElementSibling) {
                const t = e.nextElementSibling;
                return Ot(t.tagName) ? Dt(t) : t
            }
            return null
        },
        Mt = e => {
            if (null == e ? void 0 : e.previousElementSibling) {
                const t = e.previousElementSibling;
                return Ot(t.tagName) ? Mt(t) : t
            }
            return null
        },
        kt = e => {
            var t;
            return null != (t = e.uwAtoId) ? t : null
        },
        Pt = e => {
            if (!e.parentElement) return null;
            const {
                parentElement: t
            } = e, r = de(t);
            return He().find((e => e.xpath === r)) ? r : Pt(t)
        },
        Bt = e => {
            const t = Array.from(e.childNodes).find((e => e.uwAtoId));
            if (t) {
                const e = de(t);
                return He().find((t => t.xpath === e)) ? e : null
            }
            return null
        },
        Ut = (e, t) => {
            if (!e) return;
            const r = e,
                {
                    tabindex: n,
                    el: i
                } = r,
                o = __objRest(r, ["tabindex", "el"]),
                a = e.el ? [...e.el.children] : [],
                l = t.filter((e => a.includes(e.el)));
            if (l.length) {
                const e = l.map((e => Ut(e, t)));
                return __spreadProps(__spreadValues({}, o), {
                    children: e
                })
            }
            return o
        },
        Wt = (e, t = "") => {
            const r = [e];
            e.parentElement && r.push(e.parentElement);
            let n = 0;
            const i = (null == e ? void 0 : e.children) ? [...e.children].filter((e => !Ot(e.tagName))).reverse() : [];
            i.length && (r.unshift(...i), n += i.length);
            const o = Dt(e);
            o && !r.includes(o) && (r.splice(n, 0, o), n += 1);
            const a = Mt(e);
            a && !r.includes(a) && r.splice(n + 1, 0, a);
            const l = r.map((t => {
                const r = t.tagName.toLowerCase(),
                    n = Pe(t, !0);
                if (!n) return null;
                const {
                    type: i,
                    label: o,
                    id: a
                } = n, l = "function" == typeof t.getAttribute ? {
                    label: Rt(r, t),
                    isHidden: (s = t, "true" === s.getAttribute("aria-hidden") || "presentation" === s.getAttribute("role")),
                    role: St(t),
                    ariaLevel: Ct(t),
                    src: It(r, t),
                    isControl: _t(t),
                    focusable: Lt(t),
                    tabindex: xt(t)
                } : {};
                var s;
                return __spreadValues({
                    tagName: r,
                    text: [...t.childNodes].filter((e => e.nodeType === Node.TEXT_NODE)).map((e => {
                        var t;
                        return null == (t = e.textContent) ? void 0 : t.trim()
                    })).join(" ").trim(),
                    id: a,
                    xpath: de(t),
                    selected: t === e,
                    el: t,
                    semanticType: i,
                    textToRead: o,
                    uwAtoId: kt(t),
                    accessibleParentXpath: Pt(t),
                    accessibleChildXpath: Bt(t)
                }, l)
            })).filter(Boolean).reverse();
            if (l) {
                const e = Ut(l[0], l);
                e && te({
                    action: at,
                    type: "elements-selected",
                    data: {
                        tree: e,
                        source: t
                    }
                }, [rt])
            }
        };
    let Ht, jt;
    let Xt;
    const Vt = (e, t) => {
            const r = "img" === (null == e ? void 0 : e.tagName.toLowerCase());
            t && !r && e.setAttribute("aria-label", t)
        },
        $t = (e, t) => {
            const {
                tabindex: r,
                role: n,
                ariaLevel: i
            } = t;
            r && e.setAttribute("tabindex", r), n && "no role" !== n ? e.setAttribute("role", n) : n && "no role" !== n || e.removeAttribute("role"), i && e.setAttribute("aria-level", i)
        },
        Ft = Nt({
            ruleId: it,
            rule: () => {
                if (l.ariaEditor.enabled && (Xt = (() => {
                        let e = f().AriaEditorValues;
                        const t = `${ce(window.location.pathname)}`;
                        return e = e.filter((e => !e.page || e.page === t)).sort((e => e.page ? -1 : 1)), e
                    })(), Xt))
                    for (const e of Xt) {
                        if (e.processed) return;
                        const t = wt(e.xpath);
                        if (t && t.nodeType === Node.ELEMENT_NODE) {
                            if (t.hasAttribute(ot)) return;
                            const {
                                hidden: r,
                                correction: n
                            } = e;
                            r && t.setAttribute("aria-hidden", "true"), Vt(t, n), $t(t, e), t.setAttribute(ot, ""), e.processed = !0
                        }
                    }
            },
            postMessageApi: {
                "add-aria-editor": () => {
                    jt = document.querySelector(`iframe[name=${rt}]`), jt || (Ht = new Promise((e => {
                        const t = {
                            class: "userway_iframe_aria_editor",
                            name: "uwAccessibilityEditor",
                            title: "Aria Editor",
                            style: "\n            z-index: 2147483647;\n            position: fixed;\n            left: 0;\n            top: 0;\n            width: 100%!important;\n            max-width: 100%!important;\n            height: 100%!important;\n            max-height: 100%!important;\n            visibility: hidden;\n            opacity: 0!important;\n            border: none;\n          ",
                            src: nt
                        };
                        jt = document.createElement("iframe"), Object.entries(t).forEach((([e, t]) => {
                            null == jt || jt.setAttribute(e, t)
                        })), jt.onload = () => {
                            e()
                        }, jt && document.body.appendChild(jt)
                    })))
                },
                "open-aria-editor": () => {
                    Ht.then((() => {
                        window.parent.postMessage({
                            action: "close",
                            isUserWay: !0
                        }), window.parent.postMessage({
                            action: "manageIconVisibility",
                            isUserWay: !0,
                            type: "hidden"
                        }), jt && (jt.style.visibility = "visible", jt.style.opacity = "1"), te({
                            action: at,
                            type: "aria-editor-open-request"
                        }, [rt])
                    }))
                },
                "close-aria-editor": () => {
                    window.parent.postMessage({
                        action: "open",
                        isUserWay: !0
                    }), window.parent.postMessage({
                        action: "manageIconVisibility",
                        isUserWay: !0,
                        type: "visible"
                    }), jt && (jt.style.visibility = "hidden", jt.style.opacity = "0"), te({
                        action: at,
                        type: "aria-editor-closed"
                    }, [rt])
                },
                "editor-init": () => {
                    const e = u,
                        t = !(!e || !e.CUSTOM_BRANDING && !e.WHITE_LABEL);
                    te({
                        action: at,
                        type: "open-aria-editor",
                        data: {
                            siteId: u.siteId,
                            showTutorial: !0,
                            whiteLabel: t,
                            hash: ce(window.location.pathname)
                        }
                    }, [rt])
                },
                "update-aria-hidden": e => {
                    const {
                        xpath: t,
                        hidden: r
                    } = e;
                    if (!t) return;
                    const n = Ne(t);
                    (null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE && (r ? n.setAttribute("aria-hidden", "true") : n.removeAttribute("aria-hidden"))
                },
                "update-tabindex": e => {
                    const {
                        xpath: t,
                        focusable: r,
                        isControl: n
                    } = e;
                    if (!t) return;
                    const i = Ne(t);
                    (null == i ? void 0 : i.nodeType) === Node.ELEMENT_NODE && (n ? i[r ? "removeAttribute" : "setAttribute"]("tabindex", "-1") : i[r ? "setAttribute" : "removeAttribute"]("tabindex", "0"))
                },
                "update-aria-label": e => {
                    const {
                        xpath: t,
                        label: r
                    } = e;
                    if (!t || null == r) return;
                    const n = Ne(t);
                    (null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE && n.setAttribute("aria-label", e.label)
                },
                "update-aria-level": e => {
                    const {
                        xpath: t,
                        ariaLevel: r
                    } = e;
                    if (!t) return;
                    const n = Ne(t);
                    (null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE && (r ? n.setAttribute("aria-level", r) : n.removeAttribute("aria-level"))
                },
                "update-role": e => {
                    const {
                        xpath: t,
                        role: r
                    } = e;
                    if (!t) return;
                    const n = Ne(t);
                    if ((null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE) {
                        r && "no role" !== r ? n.setAttribute("role", r) : n.removeAttribute("role")
                    }
                },
                "update-corrections": e => {
                    const {
                        xpath: t
                    } = e, r = Ne(t);
                    null == r || r.removeAttribute(ot), g()
                },
                "select-elements-by-xpath": e => {
                    const {
                        xpath: t,
                        source: r
                    } = e;
                    if (!t) return;
                    const n = Ne(t);
                    n && Wt(n, r)
                },
                "select-elements-at-point": e => {
                    const {
                        position: {
                            x: t,
                            y: r
                        }
                    } = e;
                    let n = document.elementsFromPoint(t, r);
                    const i = n.findIndex((e => e.getAttribute("name") === rt)); - 1 !== i && n.splice(i, 1), n = n.filter((e => !["HTML", "BODY"].includes(e.tagName))).slice(0, 2), n.length && Wt(n[0])
                }
            }
        }),
        Gt = ({
            currentSrc: e,
            src: t
        }) => e || t,
        qt = (e, t) => {
            try {
                const {
                    width: r,
                    height: n
                } = window.getComputedStyle(e);
                return parseInt(r, 10) > t && parseInt(n, 10) > t
            } catch (r) {
                return !1
            }
        },
        Kt = (e, {
            decorative: t,
            approved: r,
            fixedByUserWay: n,
            loadingFromMS: i
        }) => {
            var o;
            return {
                src: Gt(e),
                alt: e.alt,
                originalAlt: null != (o = e.getAttribute(ze)) ? o : "",
                decorative: t,
                approved: r,
                fixedByUserWay: n,
                loadingFromMS: i
            }
        },
        Zt = e => {
            e.setAttribute("role", "presentation"), e.removeAttribute("aria-hidden"), e.setAttribute("alt", "")
        },
        Yt = e => {
            if (!e) return "";
            try {
                const {
                    hostname: t
                } = new URL(e);
                return t.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\.[a-zA-Z0-9]*$/, "")
            } catch (t) {
                return ""
            }
        },
        zt = e => {
            const t = new RegExp(`\\.(${et.join("|")})$`, "i").test(e),
                r = e.length > 255,
                n = !e.trim(),
                i = /[0-9]{5,}/.test(e),
                o = new RegExp(/^[!@#$%^&*()_+{}[\]`:;<>,.?~\\|\-="'/]+$/, "u").test(e);
            return i || t || r || n || o
        },
        Qt = (e, t) => {
            const r = t.alt.trim(),
                n = Gt(t),
                i = e.find((e => ge(e.src) === ge(n)));
            if (!i || null === i.alt) return null;
            const {
                decorative: o,
                alt: a,
                approved: s,
                reverted: u
            } = i;
            if (u && !o) return t.setAttribute(Je, tt.Reverted), Kt(t, {
                approved: !0,
                decorative: !r,
                fixedByUserWay: !1
            });
            const c = !(!l || "AUTO" === l.strategy) && !s;
            o && !c && Zt(t);
            const d = s || !r || zt(r);
            a && !c && d && !o && t.setAttribute("alt", a), t.setAttribute(Je, tt.Backend);
            const p = Kt(t, {
                approved: s,
                decorative: o,
                fixedByUserWay: !0
            });
            return c && (p.alt = a), p
        },
        Jt = e => {
            const {
                width: t,
                height: r
            } = window.getComputedStyle(e), n = /^\d*px?/i, i = n.test(t), o = n.test(r);
            return !(!i || !o)
        },
        er = e => {
            const t = Gt(e),
                r = zt(e.alt),
                n = Jt(e);
            var i;
            if (!(i = t) || !i.match(qe) && !new RegExp("^https?://.{1,256}\\.[a-z]{2,6}/.+$", "i").test(i)) return Ze.WRONG_SRC;
            const o = (e => {
                if ("string" != typeof e) return !1;
                for (const t of Object.values(Ve)) {
                    const r = new RegExp(t, "i");
                    if (e.match(r)) return !0
                }
                return !1
            })(t);
            if (o) return Ze.EXCLUDED_SRC;
            if (!!n && !qt(e, 5)) return Ze.MICRO_SIZE;
            if (!!n && (e => {
                    try {
                        const {
                            width: t,
                            height: r
                        } = window.getComputedStyle(e), n = parseInt(t, 10), i = parseInt(r, 10);
                        return !!(n <= 10 && i >= 10 * n || i <= 10 && n >= 10 * i)
                    } catch (t) {
                        return !1
                    }
                })(e)) return Ze.ASPECT_RATIO;
            if (qe.test(t)) return Ze.BASE64;
            if ("true" === e.getAttribute("aria-hidden") || "presentation" === e.getAttribute("role") || "none" === e.getAttribute("role")) return Ze.HIDDEN_FROM_SCREEN_READER;
            if (Ke.test(t) && r) return Ze.SVG;
            return !(!n || qt(e, 50)) && r ? Ze.SMALL_SIZE : null
        },
        tr = e => {
            switch (e) {
                case Ze.ASPECT_RATIO:
                    return tt.AspectRatio;
                case Ze.BASE64:
                    return tt.Base64;
                case Ze.EXCLUDED_SRC:
                    return tt.Excluded;
                case Ze.SVG:
                    return tt.Svg;
                case Ze.MICRO_SIZE:
                    return tt.Micro;
                case Ze.SMALL_SIZE:
                    return tt.Small;
                case Ze.WRONG_SRC:
                    return tt.InvalidSrc;
                case Ze.HIDDEN_FROM_SCREEN_READER:
                default:
                    return tt.Hidden
            }
        },
        rr = (e, t, r, n) => {
            const i = UserWayWidgetApp.getLib("remediation_manager"),
                o = UserWayWidgetApp.getLib("remediation_helper_outcome");
            if (!o.of) return;
            const a = o.of(e, {
                items: t
            }, null, r, n);
            i.HelperCallbackAggregator.onHelperRemediationCompleted(a)
        };
    let nr = {};
    const ir = () => {
            nr = {}
        },
        or = (e, t) => {
            const r = de(e);
            nr[r] = t
        },
        ar = e => {
            const t = de(e);
            return nr[t] || null
        },
        lr = e => rr(Qe, e, e.filter((e => e.fixedByUserWay)).length, e.filter((e => !e.approved)).length),
        sr = e => {
            e.hasAttribute(ze) || e.setAttribute(ze, e.alt)
        },
        ur = (e, t = []) => {
            if (0 === e.length) return;
            const {
                paidAi: r
            } = u, n = [];
            for (const i of e) {
                const e = i,
                    o = zt(e.alt),
                    a = Gt(e);
                sr(e), Ke.test(a) && r && e.setAttribute("role", "img");
                const l = Qt(t, e);
                if (l) {
                    n.push(l);
                    continue
                }
                if (!r) continue;
                const s = er(e);
                if (!o && !s) {
                    e.setAttribute(Je, tt.CorrectAlt), n.push(Kt(e, {
                        approved: !0,
                        decorative: !1,
                        fixedByUserWay: !1
                    }));
                    continue
                }
                if (null !== s) {
                    Zt(e), e.setAttribute(Je, tr(s)), s && Ye.includes(s) && n.push(Kt(e, {
                        approved: !1,
                        decorative: !0,
                        fixedByUserWay: !0
                    }));
                    continue
                }
                const u = ar(e);
                if (u) {
                    e.setAttribute("alt", u), e.setAttribute(Je, tt.ClosestText), n.push(Kt(e, {
                        approved: !1,
                        decorative: !1,
                        fixedByUserWay: !0
                    }));
                    continue
                }
                const {
                    quota: d,
                    usage: p
                } = c;
                p >= d ? (e.setAttribute(Je, tt.AIQuotaExceed), n.push(Kt(e, {
                    approved: !1,
                    decorative: !1,
                    fixedByUserWay: !0
                }))) : (e.setAttribute(Je, tt.AI), n.push(Kt(e, {
                    approved: !1,
                    decorative: !1,
                    fixedByUserWay: !0,
                    loadingFromMS: !0
                })))
            }
            lr(n)
        },
        cr = e => {
            const t = e.replace(/^https?:\/\//, "");
            return document.querySelectorAll(`img[src*="${t}" i],img[srcset*="${t}" i]`)
        },
        dr = e => __async(this, null, (function*() {
            const {
                account: t
            } = UserWayWidgetApp.ContextHolder.config, {
                siteId: r
            } = u, {
                resourceHash: n
            } = c, i = encodeURIComponent(e), o = yield fetch(`https://cdn77.api.userway.org/api/img-dscr/v2/${t}/${r}/${n}/alts.json?dto=${i}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json"
                }
            });
            return (yield o.json()).payload
        })),
        pr = e => {
            const t = `(.*\\.(${et.join("|")}))\\?.*$`,
                r = new RegExp(t),
                n = e.match(r);
            return n && n[1] ? n[1].toLowerCase() : e
        };
    var mr = (e => (e.RO = "RO", e))(mr || {});
    const fr = (e, t) => e.src.localeCompare(t.src),
        gr = (e, t = 1) => {
            if (t >= 15) return console.warn("Max split level exceed"), [];
            const r = ((e, t) => {
                    const r = Math.ceil(e.length / t),
                        n = [];
                    for (let i = 0; i < e.length; i += r) n.push(e.slice(i, i + r));
                    return n
                })(e, t),
                n = [];
            for (const i of r) {
                const r = {
                        sorted: i,
                        tier: c.tier
                    },
                    o = JSON.stringify(r);
                if (encodeURIComponent(o).length / 1024 > 8) return gr(e, t + 1);
                n.push(o)
            }
            return n
        },
        br = e => e ? e.replace(/\n/g, "").replace(/ {2,}/g, " ").trim() : "",
        hr = (e, t) => {
            if (!e) return null;
            const r = "next" === t.type ? e.nextSibling : e.previousSibling;
            if ((null == r ? void 0 : r.nodeType) === Node.TEXT_NODE) {
                if (!br(r.nodeValue)) return hr(r, {
                    type: t.type
                })
            }
            return r
        },
        Ar = e => {
            const t = e.nodeType === Node.ELEMENT_NODE;
            if (e.nodeType === Node.TEXT_NODE) return !0;
            if (t) {
                const t = Fe.some((t => t === e.nodeName.toLowerCase())),
                    r = Ge.some((t => {
                        var r;
                        return t === (null == (r = e.getAttribute("role")) ? void 0 : r.toLowerCase())
                    }));
                return t || r
            }
            return !1
        },
        Er = Array.from(new Set([...Fe, "a", "span", "strong", "em", "b", "i", "q", "mark"])),
        yr = e => {
            if ((null == e ? void 0 : e.nodeType) === Node.TEXT_NODE) {
                const t = br(e.nodeValue);
                if (t && !zt(t)) return t
            }
            if ((null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && Er.includes(e.tagName.toLowerCase()))
                for (const t of e.childNodes) {
                    const e = yr(t);
                    if (e) return e
                }
            return null
        },
        vr = e => {
            const t = e.nodeType === Node.ELEMENT_NODE,
                r = e.nodeType === Node.TEXT_NODE;
            if (!r && !t) return !1;
            if (t && "img" === e.nodeName.toLowerCase()) return !0;
            if (r) return !!br(e.textContent);
            const n = Fe.some((t => t === e.nodeName.toLowerCase())),
                i = Ge.some((t => {
                    var r;
                    return t === (null == (r = e.getAttribute("role")) ? void 0 : r.toLowerCase())
                }));
            return n || i
        };
    let Tr = 0;
    const Nr = e => {
            const t = e.parentElement;
            if (!t) return null;
            if (t.getElementsByTagName("img").length > 1) return Tr = 0, null;
            if (1 === [].slice.call(t.childNodes).filter(vr).length) return Nr(t);
            const r = (e => {
                let t = hr(e, {
                        type: "next"
                    }),
                    r = hr(e, {
                        type: "prev"
                    }),
                    n = null,
                    i = null;
                for (; t || r;) {
                    t && Ar(t) && (n = yr(t)), r && Ar(r) && (i = yr(r));
                    const e = n || i;
                    if (e) return e;
                    t = hr(t, {
                        type: "next"
                    }), r = hr(r, {
                        type: "prev"
                    })
                }
                return null
            })(e);
            return r ? (Tr = 0, r) : (Tr += 1, "body" === t.tagName.toLowerCase() ? (Tr = 0, null) : Tr < 2 ? Nr(t) : (Tr = 0, null))
        },
        wr = e => {
            const t = e.closest("figure");
            if (t) {
                const e = Array.from(t.children).find((e => "figcaption" === e.tagName.toLowerCase()));
                if (e) {
                    const t = br(e.textContent);
                    if (t && !zt(t)) return t
                }
            }
            const r = [].slice.call(e.classList).join(" "),
                n = e.id || "",
                i = (o = r + n).trim() && $e.find((e => o.includes(e))) || null;
            var o;
            if (i) return i;
            const a = Nr(e);
            return a || null
        },
        _r = (e, t) => {
            if (!Jt(e)) return !1;
            const r = Gt(e);
            return Yt(r) !== t && !qt(e, 10)
        },
        xr = [],
        Lr = e => {
            if (!c) return;
            const {
                state: t
            } = c;
            if ("ALTS_OFF" === t) return;
            const r = (e => {
                    var t, r;
                    const n = [];
                    for (const i of e) {
                        const e = Gt(i),
                            t = Yt(e);
                        if (t) {
                            let e = n.find((e => e.name === t));
                            e || (e = {
                                name: t,
                                weight: 0
                            }, n.push(e)), e.weight += 1
                        }
                    }
                    return null != (r = null == (t = n.sort(((e, t) => e.weight < t.weight ? 1 : -1))[0]) ? void 0 : t.name) ? r : ""
                })(e),
                n = [],
                i = [];
            for (const a of e) {
                const e = a,
                    t = _r(e, r),
                    o = er(e);
                if (o && !Ye.includes(o) || t) i.push(e);
                else {
                    const t = wr(e);
                    t && or(e, t), n.push(e)
                }
            }
            try {
                const e = (e => {
                        const t = e,
                            r = t.filter(((e, r) => r === t.findIndex((t => Gt(e) === Gt(t))))).map((e => {
                                const t = e,
                                    r = t.alt.trim(),
                                    n = r && !zt(r),
                                    i = Gt(t);
                                return {
                                    src: pr(i),
                                    alt: t.alt.trim(),
                                    dir: n || er(t) || ar(t) ? mr.RO : void 0
                                }
                            }));
                        return r.sort(fr), r
                    })(n),
                    t = gr(e);
                if (t.length)
                    for (const r of t) dr(r).then((e => {
                        if (!e) return;
                        const {
                            missingAlts: t
                        } = e, r = n.filter((e => t.find((t => ge(t.src) === ge(Gt(e))))));
                        ur(r, t)
                    })).finally((() => ir()))
            } catch (o) {
                console.error(o)
            }
            ur(i), xr.length = 0, n.length || ir()
        },
        Or = Q((e => Lr(e)), 1e3, {
            maxWait: 2e3,
            leading: !0,
            trailing: !0
        }),
        Rr = Nt({
            ruleId: Qe,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                xr.push(...e), Or(xr)
            },
            isTargetElement: e => {
                const t = "img" === e.tagName.toLowerCase(),
                    r = e.hasAttribute(Je);
                if (!t || r) return !1;
                const n = e.getAttribute("src"),
                    i = e.getAttribute("srcset");
                return !!(null != n ? n : i) || !!e.closest("picture")
            },
            postMessageApi: {
                "image-alt-update": ({
                    src: e,
                    decorative: t,
                    alt: r,
                    role: n
                }) => {
                    const i = cr(e);
                    if (i.length) {
                        for (const e of i) e.setAttribute("alt", null != r ? r : ""), t ? Zt(e) : ("presentation" !== e.getAttribute("role") && "none" !== e.getAttribute("role") || e.removeAttribute("role"), e.hasAttribute("aria-hidden") && e.removeAttribute("aria-hidden")), ["link", "button", "heading"].includes(n) && e.setAttribute("aria-label", r);
                        lr([Kt(i[0], {
                            approved: !0,
                            decorative: t,
                            fixedByUserWay: !1
                        })])
                    }
                },
                "image-alt-revert": ({
                    src: e
                }) => {
                    const t = cr(e);
                    for (const r of t) {
                        const e = r.getAttribute(ze);
                        null !== e && r.setAttribute("alt", e)
                    }
                },
                "image-alt-update-config": () => {
                    g()
                }
            }
        }),
        Sr = e => {
            const {
                tagName: t
            } = e;
            return "SELECT" === t || "TEXTAREA" === t ? t.toLowerCase() : "text"
        },
        Cr = (e, t) => {
            const r = t.getAttribute("id") || "uw" + (~~(1e8 * Math.random())).toString(16);
            t.setAttribute("id", r), e.setAttribute("aria-labelledby", r)
        },
        Ir = (e, t) => {
            for (const [r, n] of t)
                if (n.test(e)) return r;
            return ""
        },
        Dr = e => {
            let t = "";
            const r = e.getAttribute("placeholder"),
                n = e.getAttribute("title");
            if (r && r.trim()) return r;
            if (n && n.trim()) return n;
            const {
                classList: i,
                name: o,
                tagName: a,
                type: l
            } = e, s = `${[...i].join(" ")||""} ${o||""}`.trim();
            return "text" === l && (t = Ir(s, Et)), "SELECT" === a && (t = Ir(s, yt)), t || (e => {
                const {
                    tagName: t,
                    type: r
                } = e;
                return "SELECT" === t ? "select-multiple" === r ? "Multiple select" : "Single select" : "TEXTAREA" === t ? "Text area" : "INPUT" === t && r && At[r] ? At[r] : ""
            })(e)
        },
        Mr = e => {
            if (e.parentElement) {
                const t = [...e.parentElement.querySelectorAll("label")];
                if (1 === t.length && (e => {
                        const t = "LABEL" === e.tagName,
                            r = e.getAttribute("for");
                        return t && (!(null == r ? void 0 : r.trim()) || !document.getElementById(r))
                    })(t[0])) return t[0].textContent
            }
            return null
        },
        kr = e => {
            const t = e.previousElementSibling;
            return t && (e => {
                var t;
                return ["DIV", "SPAN", "P"].includes(e.tagName) && Boolean(null == (t = e.textContent) ? void 0 : t.trim())
            })(t) ? (Cr(e, t), t.textContent) : null
        },
        Pr = (e, t, r = !0) => {
            if (!r) return;
            const n = e.closest("label"),
                i = (e => {
                    const t = e.getAttribute("id");
                    if (!t) return null;
                    try {
                        return document.querySelector(`label[for='${t}']`)
                    } catch (r) {
                        return console.log("Query selector error: ", r), null
                    }
                })(e),
                o = n || i;
            if (o) {
                const e = o.querySelector("span[data-uw-reader-element]");
                if (e) e.textContent = t;
                else {
                    const e = ((e, t = "") => {
                        const r = document.createElement("span");
                        return r.textContent = e, r.setAttribute("style", "color: #ffffff!important;background: #000000!important;clip: rect(1px, 1px, 1px, 1px)!important;clip-path: inset(50%)!important;height: 1px!important;width: 1px!important;margin: -1px!important;overflow: hidden!important;padding: 0!important;position: absolute!important;"), r.setAttribute("class", t), r.setAttribute("data-uw-reader-element", ""), r.setAttribute("data-uw-rm-ignore", ""), r
                    })(t);
                    o.appendChild(e)
                }
            } else e.setAttribute("aria-label", t);
            e.setAttribute(mt, "fx")
        },
        Br = e => {
            const {
                Forms: t
            } = f(), r = de(e), n = (e => {
                var t;
                const r = e.closest("label"),
                    n = e.getAttribute("aria-label");
                return (null == (t = null == r ? void 0 : r.textContent) ? void 0 : t.trim()) || n || null
            })(e);
            n && e.setAttribute(mt, "nfx");
            const i = t.find((({
                xpath: e,
                approved: t
            }) => t && +e === ce(r)));
            return i ? (Pr(e, i.correction, !0), {
                type: i.type,
                xpath: r,
                required: i.required,
                correction: i.correction,
                approved: i.approved,
                xpathHash: ce(r),
                label: n
            }) : null
        },
        Ur = e => {
            ((e, t = {}) => {
                var r, n;
                const i = {
                    skipParentCheck: null != (r = t.skipParentCheck) && r,
                    shouldBeInViewport: null == (n = t.shouldBeInViewport) || n
                };
                let o = e,
                    a = re(o, i);
                if (!i.skipParentCheck)
                    for (; a && o.parentNode && o.parentNode !== document;) re(o.parentNode, {
                        shouldBeInViewport: !1
                    }) ? o = o.parentNode : a = !1;
                return a
            })(e, {
                shouldBeInViewport: !1
            }) || (e.setAttribute("aria-label", ht), e.setAttribute(bt, ht), ((e, t) => {
                new IntersectionObserver(((r, n) => {
                    for (const i of r) i.intersectionRatio > 0 && (t(e), n.disconnect())
                })).observe(e)
            })(e, (() => {
                e.hasAttribute(bt) && e.hasAttribute("aria-label") && e.getAttribute(bt) === e.getAttribute("aria-label") && (e.removeAttribute(bt), e.removeAttribute("aria-label"))
            })));
            const t = Mr(e);
            if (t) return t;
            const r = Dr(e);
            if (r) return r;
            const n = kr(e);
            return n || null
        },
        Wr = Object.keys(At),
        Hr = Nt({
            ruleId: pt,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const t = [];
                for (const r of e) {
                    const e = Br(r);
                    if (e) {
                        t.push(e);
                        continue
                    }
                    const n = r.hasAttribute("required"),
                        i = "AUTO" === l.strategy,
                        o = de(r),
                        a = Sr(r),
                        s = we(r);
                    if (s) {
                        t.push({
                            type: a,
                            xpath: o,
                            correction: s,
                            approved: !0,
                            xpathHash: ce(o),
                            label: s,
                            required: n
                        });
                        continue
                    }
                    const u = Ur(r);
                    u ? (Pr(r, u, i), t.push({
                        type: a,
                        xpath: o,
                        correction: u,
                        approved: !1,
                        xpathHash: ce(o),
                        label: null,
                        required: n
                    })) : t.push({
                        type: a,
                        xpath: o,
                        correction: null,
                        approved: !1,
                        xpathHash: ce(o),
                        label: null,
                        required: n
                    })
                }
                rr(pt, t, t.filter((e => e.approved)).length, t.filter((e => !e.approved)).length)
            },
            isTargetElement: e => {
                const t = ft.includes(e.tagName);
                if (e.hasAttribute(mt) || !t) return !1;
                const r = e.getAttribute("type");
                if (!("SELECT" === e.tagName || "TEXTAREA" === e.tagName || "INPUT" === e.tagName && !!r && Wr.includes(r.toLowerCase()))) return !1;
                const n = e.closest("form");
                return !gt.some((e => {
                    var t;
                    const r = n && (null == (t = n.getAttribute("action")) ? void 0 : t.toLowerCase());
                    return null == r ? void 0 : r.includes(e)
                }))
            },
            postMessageApi: {
                "form-label-update": ({
                    correction: e,
                    xpath: t
                }) => {
                    const r = Ne(t.toString());
                    r && Pr(r, e || "", !0)
                }
            }
        }),
        jr = e => {
            const t = e.tagName.toLowerCase(),
                r = null == e ? void 0 : e.type,
                n = e.getAttribute("role");
            return ["a", "button"].includes(t) ? "a" === t ? "<link>" : "<button>" : "input" === t && ["button", "submit", "reset"].includes(r) ? "<input>" : "link" === n ? "<link> (role)" : "<button> (role)"
        },
        Xr = [],
        Vr = (e, t, r = !1) => {
            const n = !(null == l ? void 0 : l.strategy) || "AUTO" === l.strategy;
            var i;
            return (r || n) && e.setAttribute("aria-label", t), e.setAttribute(st, ""), i = {
                correction: t,
                approved: r,
                xpath: de(e),
                name: jr(e)
            }, Xr.push(i), !0
        },
        $r = (e, t) => {
            var r;
            const n = t || e,
                i = ut.find((e => "a" === n.tagName.toLowerCase() && n.href.includes(e)));
            if (i) return Vr(e, i);
            const o = (e => {
                const t = Array.from(e.children);
                t.push(e);
                let r = [];
                for (const n of t) r = r.concat(Array.from(n.classList).map((e => e.toLowerCase())));
                return r
            })(n);
            let a = ut.find((e => o.find((t => t.includes(e)))));
            if (a || dt.find((e => o.find((t => {
                    const r = e.re.test(t) && t.replace(e.re, e.replacer);
                    return !!r && (a = r, !0)
                })))), a) return Vr(e, a);
            const l = null == (r = window.getComputedStyle(n).backgroundImage) ? void 0 : r.toLowerCase(),
                s = ut.find((e => l.includes(e)));
            if (s) return Vr(e, s);
            const u = Object.keys(ct).find((e => o.find((t => t.includes(e))))),
                c = u ? ct[u] : null;
            return !!c && Vr(e, c)
        },
        Fr = e => {
            if (!e.hasAttribute("href")) return null;
            const t = e.getAttribute("href").toLowerCase().match(/^https?:\/\/(?:www\.)?([^/?#]+)/);
            return t ? t[1] : null
        },
        Gr = {},
        qr = e => {
            __spreadValues({}, Gr)[ce(e.xpath)] = e;
            const t = Te(e.xpath);
            t && Vr(t, e.correction)
        },
        Kr = Nt({
            ruleId: lt,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const {
                    EmptyControls: t
                } = f(), r = (e => {
                    if (!(null == e ? void 0 : e.length)) return null;
                    for (const t of e) {
                        const e = ce(t.xpath),
                            r = Gr[e],
                            n = t.page;
                        (!r || r && n) && (Gr[e] = t)
                    }
                    return __spreadValues({}, Gr)
                })(t);
                for (const i of e) {
                    const e = i.getAttribute("href");
                    if (("a" === i.tagName.toLowerCase() || "link" === i.getAttribute("role")) && "" === e && i.setAttribute("href", "#"), r) {
                        const e = r[ce(de(i))];
                        if (e) {
                            Vr(i, e.correction, !0);
                            continue
                        }
                    }
                    if (!$r(i)) {
                        const e = i.getAttribute("role"),
                            t = i.tagName.toLowerCase(),
                            r = i.getAttribute("type"),
                            n = i.getAttribute("alt"),
                            o = i.getAttribute(ze);
                        if (Array.from(i.children).find((e => $r(i, e)))) continue;
                        const a = Fr(i);
                        if (a) {
                            Vr(i, a);
                            continue
                        }
                        if ((n || o) && "img" === t && e && ["link", "button"].includes(e)) {
                            Vr(i, n || o);
                            continue
                        }
                        if ("button" === t || "button" === e || "input" === t && "button" === r) {
                            Vr(i, "button");
                            continue
                        }
                        if ("input" === t && "submit" === r) {
                            Vr(i, "submit");
                            continue
                        }
                        if ("input" === t && "reset" === r) {
                            Vr(i, "reset");
                            continue
                        }
                        Vr(i, "Open this option")
                    }
                }
                const n = [].slice.call(Xr);
                rr("REMEDIATION_EMPTY_CONTROLS", n, n.length, n.filter((e => !e.approved)).length), Xr.length = 0
            },
            isTargetElement: e => {
                if (e.hasAttribute(st)) return !1;
                const t = e.tagName.toLowerCase(),
                    r = e.getAttribute("role"),
                    n = null == e ? void 0 : e.type,
                    i = "a" === t || "button" === t,
                    o = "link" === r || "button" === r,
                    a = "input" === t && ["button", "submit", "reset"].includes(n);
                return !(!(i || o || a) || (e => {
                    var t, r, n;
                    let i = null != (r = null == (t = e.getAttribute("aria-label")) ? void 0 : t.trim()) ? r : "";
                    const o = e.getAttribute("aria-describedby");
                    if (i += o ? ue(o) : "", i) return i.toLowerCase();
                    const a = e.getAttribute("aria-labelledby");
                    if (a && (i += ue(a)), i.trim()) return i.toLowerCase();
                    if (i = null != (n = e.textContent) ? n : "", i.trim()) return i.toLowerCase();
                    const l = e;
                    if (i = l.value || "", i.trim() && l.type && ["button", "submit", "reset"].includes(l.type.toLowerCase())) return i.toLowerCase();
                    if (!e.hasChildNodes()) return null;
                    let s = e.querySelector('img, *[role="img"]');
                    return s && (i = se(s) || "", i.trim()) ? i.toLowerCase() : null
                })(e))
            },
            postMessageApi: {
                "empty-controls-update": ({
                    data: e
                }) => {
                    var t;
                    (null != (t = null == e ? void 0 : e.xpath) ? t : null == e ? void 0 : e.correction) && qr(e)
                }
            }
        }),
        Zr = () => {
            const {
                hostname: e,
                pathname: t
            } = window.location, r = e.replace("www.", "").split("."), n = (i = r, i.length > 1 ? i.slice(0, -1) : i).join("-");
            var i;
            const o = t.split("/").filter((e => e)).join(" ").replace(/^\d+|\s\d+/g, "").trim();
            return (o + (o ? " - " : " ") + n).trim()
        },
        Yr = "data-uw-rm-title",
        zr = "un",
        Qr = "gn",
        Jr = (e, t) => {
            e.setAttribute(Yr, t ? Qr : zr)
        },
        en = [Nt({
            ruleId: "header-title",
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                var t, r;
                if (e.length && (null == (t = e[0].innerHTML) ? void 0 : t.trim())) {
                    const e = document.querySelector(`title[${Yr}]`);
                    return void(null == e || e.remove())
                }
                const n = document.getElementsByTagName("title")[0];
                try {
                    if (n) {
                        if (!(null == (r = n.innerHTML) ? void 0 : r.trim()) && !n.hasAttribute(Yr)) {
                            const e = Zr();
                            n.innerHTML = e, Jr(n, e)
                        }
                    } else {
                        const e = document.createElement("title"),
                            t = Zr();
                        e.innerHTML = t, Jr(e, t), document.head.appendChild(e)
                    }
                } catch (i) {
                    i instanceof Error && console.error(i)
                }
            },
            isTargetElement: e => {
                const t = "title" === e.tagName.toLowerCase(),
                    r = e.hasAttribute(Yr);
                return t && !r
            },
            forceRun: !0
        }), Rr, Hr, Ft, Kr],
        tn = Object.freeze(Object.defineProperty({
            __proto__: null,
            RulesList: en
        }, Symbol.toStringTag, {
            value: "Module"
        }))
}();
//# sourceMappingURL=remediation-tool.js.map