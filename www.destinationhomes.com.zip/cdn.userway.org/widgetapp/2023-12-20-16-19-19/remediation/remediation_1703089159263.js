! function() {
    function e(e) {
        setTimeout(function() {
            n.totalProcessed.AUTOFOCUS_ON_LOAD = 0, t(e), window.addEventListener("popstate", t, !1)
        }, 1500)
    }

    function t(e) {
        var t = document.activeElement;
        t && ["INPUT", "TEXTAREA"].includes(t.tagName) ? (t.blur(), t.setAttribute(n.DATA_ATTRIBUTE_NAME, "autofocus"), i = 1) : i = 0, n.totalProcessed.AUTOFOCUS_ON_LOAD = i, 0 !== i && UserWayWidgetApp.ContextHolder.config.services.siteId, e({
            postMessageAppData: i,
            backEndData: null,
            countFixed: i || 0,
            countTodo: i || 0
        })
    }
    var r = UserWayWidgetApp.addLib("REMEDIATION_AUTOFOCUS_ON_LOAD"),
        n = UserWayWidgetApp.getLib("remediation"),
        i = (UserWayWidgetApp.getLib("util"), 0);
    r.filter = function(e) {
        return []
    }, r.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, r.doRemediation = function(t, r) {
        return new Promise(function(t, r) {
            try {
                e(t)
            } catch (e) {
                r(e)
            }
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e() {
        [].slice.call(document.querySelectorAll("[" + i + "]")).forEach(function(e) {
            e.removeAttribute(i)
        })
    }

    function t(e, t, r, o, a) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_AUTO_PLAY_VIDEO");
            for (var u = 0, l = 0; l < t.length; l++) {
                var c = t[l];
                if (!c.hasAttribute(i))
                    if ("IFRAME" === c.nodeName) {
                        var s = c.getAttribute("src");
                        s && (s.toLowerCase().indexOf("youtube.com") || s.toLowerCase().indexOf("vimeo.com")) && (s.indexOf("autoplay=1") > -1 || s.indexOf("autoplay=true")) && (s.indexOf("mute=1") > -1 || s.indexOf("mute=true") > -1) && (c.setAttribute(i, "if"), u++)
                    } else "VIDEO" === c.nodeName && c.hasAttribute("autoplay") && c.hasAttribute("muted") && (c.setAttribute(i, "vi"), u++)
            }
            e.onHelperRemediationCompleted(n.of("REMEDIATION_AUTO_PLAY_VIDEO", null, null, u, 0)), o()
        } catch (e) {
            a(e)
        }
    }
    var r = UserWayWidgetApp.addLib("REMEDIATION_AUTO_PLAY_VIDEO"),
        n = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        i = "data-uw-rm-av";
    r.filter = function(e) {
        return [].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(e.querySelectorAll("iframe[src], video"))
        })), !1))
    }, r.awaitForResources = function(t, r) {
        return r.reset ? (e(), Promise.resolve()) : Promise.resolve()
    }, r.doRemediation = function(e, r, n) {
        return new Promise(function(i, o) {
            t(e, r, n, i, o)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e) {
        e.forEach(function(e) {
            g[e.page + e.href] = e
        })
    }

    function t() {
        f = new Set, p = new Set, m = new Set, [].slice.call(document.querySelectorAll("[" + y + "]")).forEach(function(e) {
            e.removeAttribute(y)
        })
    }

    function r(e, t) {
        var r = " - target website may not be available",
            n = e.hasAttribute("aria-label") ? e.getAttribute("aria-label") : null;
        if (!(n && n.indexOf(r) > -1)) {
            var i = n || t,
                o = i ? i + r : r;
            return e.setAttribute("aria-label", o), e.setAttribute(y, "true"), o
        }
    }

    function n(e) {
        var t = {
                originalHref: "",
                normalizedHref: ""
            },
            r = e.href && e.href.trim();
        return r.length ? (t.originalHref = r, t.normalizedHref = r.split("?")[0].split("#")[0], t) : t
    }

    function i(e) {
        var t = e.href && e.href.trim();
        return t.length ? t = t.split("?")[0].split("#")[0] : ""
    }

    function o(e) {
        try {
            var t = e.hostname;
            return h.indexOf(t) > -1
        } catch (e) {
            return !1
        }
    }

    function a(e) {
        return e.filter(function(e) {
            if (!e || e.nodeType !== Node.ELEMENT_NODE || "A" !== e.nodeName) return !1;
            if (e.hasAttribute(y)) return !1;
            var t = n(e).originalHref;
            return t ? /(^tel:|^mailto:)/.test(t) ? (e.setAttribute(y, "exc"), !1) : /^(http|https):/.test(t) ? !/\.pdf/.test(t) && (!/wp-admin/.test(t) && (!o(e) || (e.setAttribute(y, "exc"), !1))) : (e.setAttribute(y, "exc"), !1) : (e.setAttribute(y, "na"), !1)
        })
    }
    var u = UserWayWidgetApp.addLib("REMEDIATION_BROKEN_LINK"),
        l = UserWayWidgetApp.getLib("remediationConfig").brokenLinks || {},
        c = UserWayWidgetApp.getLib("remediation_utils"),
        s = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        d = UserWayWidgetApp.getLib("util"),
        f = new Set,
        p = new Set,
        m = new Set,
        h = ["localhost", "userway.dev", "linkedin.com", "www.linkedin.com", "youtube.com", "www.youtube.com"],
        y = "data-uw-rm-brl",
        g = {};
    u.filter = function(e, r) {
        return r.reset && t(), [].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(e.querySelectorAll("a[href]"))
        })), !1))
    }, u.awaitForResources = function(t, r) {
        return new Promise(function(r, n) {
            if (!l.enabled) return r(!0);
            var o = [];
            if (t = a(t), t.forEach(function(e) {
                    var t = i(e);
                    f.has(t) || (f.add(t), o.push(t))
                }), !o.length) return r(!0);
            c.sendBackEnd("/br-links/v0/links", null, {
                page: location.pathname,
                fullPage: location.href,
                links: o
            }).then(function(t) {
                var n, i = t && t.response && JSON.parse(t.response);
                o.forEach(function(e, t) {
                    switch (i.statuses[t]) {
                        case 0:
                            p.add(e);
                            break;
                        case 2:
                            m.add(e)
                    }
                }), (null === (n = UserWayWidgetApp.ContextHolder.remediationResources) || void 0 === n ? void 0 : n.BrokenLink) && e(UserWayWidgetApp.ContextHolder.remediationResources.BrokenLink), r(!0)
            }).catch(function(e) {
                return n(e)
            })
        })
    }, u.doRemediation = function(e, t, n) {
        t = a(t);
        var o = 0;
        return new Promise(function(n, a) {
            e.onHelperRemediationStarted("REMEDIATION_BROKEN_LINK");
            try {
                var u = [];
                t.forEach(function(e, t) {
                    var n = i(e),
                        a = window.location.pathname,
                        l = "" + d.hashString(a),
                        s = UserWayWidgetApp.ContextHolder.config.services.siteId;
                    if (p.has(n)) {
                        var f = c.getElementAccessibleName(e),
                            h = n,
                            b = g[l + n];
                        b ? (b.text_correction && (e.setAttribute("aria-label", b.text_correction), e.setAttribute("data-uw-rm-brl-text", ""), f = b.text_correction), b.href_correction && (e.setAttribute("href", b.href_correction), e.setAttribute("data-uw-rm-brl-href", ""), h = b.href_correction), e.setAttribute(y, "true")) : f = r(e, f), o++, u.push({
                            href: h,
                            text: f,
                            pageHash: l,
                            page: a,
                            siteId: s
                        })
                    } else m.has(n) ? e.setAttribute(y, "pending") : e.setAttribute(y, "false")
                }), e.onHelperRemediationCompleted(s.of("REMEDIATION_BROKEN_LINK", {
                    items: u
                }, null, o, o)), n(!0)
            } catch (e) {
                a(e)
            }
        })
    }
}();
var __assign = this && this.__assign || function() {
        return __assign = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) {
                t = arguments[r];
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }
            return e
        }, __assign.apply(this, arguments)
    },
    __awaiter = this && this.__awaiter || function(e, t, r, n) {
        function i(e) {
            return e instanceof r ? e : new r(function(t) {
                t(e)
            })
        }
        return new(r || (r = Promise))(function(r, o) {
            function a(e) {
                try {
                    l(n.next(e))
                } catch (e) {
                    o(e)
                }
            }

            function u(e) {
                try {
                    l(n.throw(e))
                } catch (e) {
                    o(e)
                }
            }

            function l(e) {
                e.done ? r(e.value) : i(e.value).then(a, u)
            }
            l((n = n.apply(e, t || [])).next())
        })
    },
    __generator = this && this.__generator || function(e, t) {
        function r(e) {
            return function(t) {
                return n([e, t])
            }
        }

        function n(r) {
            if (i) throw new TypeError("Generator is already executing.");
            for (; u && (u = 0, r[0] && (l = 0)), l;) try {
                if (i = 1, o && (a = 2 & r[0] ? o.return : r[0] ? o.throw || ((a = o.return) && a.call(o), 0) : o.next) && !(a = a.call(o, r[1])).done) return a;
                switch (o = 0, a && (r = [2 & r[0], a.value]), r[0]) {
                    case 0:
                    case 1:
                        a = r;
                        break;
                    case 4:
                        return l.label++, {
                            value: r[1],
                            done: !1
                        };
                    case 5:
                        l.label++, o = r[1], r = [0];
                        continue;
                    case 7:
                        r = l.ops.pop(), l.trys.pop();
                        continue;
                    default:
                        if (a = l.trys, !(a = a.length > 0 && a[a.length - 1]) && (6 === r[0] || 2 === r[0])) {
                            l = 0;
                            continue
                        }
                        if (3 === r[0] && (!a || r[1] > a[0] && r[1] < a[3])) {
                            l.label = r[1];
                            break
                        }
                        if (6 === r[0] && l.label < a[1]) {
                            l.label = a[1], a = r;
                            break
                        }
                        if (a && l.label < a[2]) {
                            l.label = a[2], l.ops.push(r);
                            break
                        }
                        a[2] && l.ops.pop(), l.trys.pop();
                        continue
                }
                r = t.call(e, l)
            } catch (e) {
                r = [6, e], o = 0
            } finally {
                i = a = 0
            }
            if (5 & r[0]) throw r[1];
            return {
                value: r[0] ? r[1] : void 0,
                done: !0
            }
        }
        var i, o, a, u, l = {
            label: 0,
            sent: function() {
                if (1 & a[0]) throw a[1];
                return a[1]
            },
            trys: [],
            ops: []
        };
        return u = {
            next: r(0),
            throw: r(1),
            return: r(2)
        }, "function" == typeof Symbol && (u[Symbol.iterator] = function() {
            return this
        }), u
    },
    __rest = this && this.__rest || function(e, t) {
        var r = {};
        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols)
            for (var i = 0, n = Object.getOwnPropertySymbols(e); i < n.length; i++) t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (r[n[i]] = e[n[i]]);
        return r
    },
    __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e) {
        var t = e.resolve,
            r = (e.reject, e.params);
        e.filteredElements;
        if (!r.reset) return t();
        A.isSmartContrastEnabled() || i(), E.config.autofix && A.enable(), UserWayWidgetApp.ContextHolder.remediationResources ? (D.acceptedFixes = UserWayWidgetApp.ContextHolder.remediationResources.Contrast || [], l().then(t)) : t()
    }

    function t() {
        var e = function(e) {
                return e.hasAttribute("data-uw-rm-ignore")
            },
            t = ["SVG", "SCRIPT", "IMG", "STYLE"],
            r = [],
            n = document.body,
            i = H(),
            o = function(e) {
                return i.includes(w.xpath(e))
            },
            a = function(e) {
                return e.hasAttribute(I)
            };
        s(n) && a(n) && r.push(n);
        var u = function(n) {
            n.children && Array.from(n.children).forEach(function(n) {
                var i = n.tagName.toUpperCase(),
                    l = "INPUT" === i && ("radio" === n.getAttribute("type") || "checkbox" === n.getAttribute("type"));
                if (!(t.includes(i) || e(n) || l)) return a(n) || !s(n) || o(n) || r.push(n), n.childNodes && u(n)
            })
        };
        return u(n), r
    }

    function r() {
        [].slice.call(document.querySelectorAll("[" + I + "=" + O.AUTOFIX + "]")).forEach(function(e) {
            e.setAttribute(I, O.PARSED), x.resetInlineStyles(e, I, R)
        }), E.config.autofix = !1
    }

    function n() {
        var e = Object.keys(O).map(function(e) {
            return O[e]
        }).filter(function(e) {
            return e !== O.SET
        }).map(function(e) {
            return "[" + I + "=" + e + "]"
        }).join(", ");
        [].slice.call(document.querySelectorAll(e)).forEach(function(e) {
            e.getAttribute(I) === O.AUTOFIX && x.resetInlineStyles(e, I, R), e.removeAttribute(I)
        }), D.foundedIssues = [], D.contrastIssues = []
    }

    function i() {
        [].slice.call(document.querySelectorAll("[" + I + "]")).forEach(function(e) {
            e.setAttribute(I, O.PARSED), x.resetInlineStyles(e, I, R)
        })
    }

    function o() {
        return D.foundedIssues.filter(function(e) {
            var t = e.xpath;
            return !D.acceptedFixes.find(function(e) {
                return e.xpath === t
            })
        })
    }

    function a(e) {
        var t = e.callbackAggregator,
            r = e.items,
            n = e.resolve,
            i = e.reject;
        return __awaiter(this, void 0, void 0, function() {
            var e, o, a;
            return __generator(this, function(l) {
                switch (l.label) {
                    case 0:
                        console.log(E), E.enabled || n(), e = function() {
                            t.onHelperRemediationStarted(v);
                            var e = D.foundedIssues.concat(U());
                            t.onHelperRemediationCompleted(_.of(v, {
                                items: function(e) {
                                    return e.map(function(e) {
                                        return __assign(__assign({}, e), {
                                            contrastData: __assign(__assign({}, e.contrastData), {
                                                backgroundColorParentElement: null
                                            })
                                        })
                                    })
                                }(e),
                                acceptedFixes: H(),
                                autofix: E.config.autofix
                            }, null, D.foundedIssues.length, 0))
                        }, o = E.config.autofix || A.isSmartContrastEnabled(), l.label = 1;
                    case 1:
                        return l.trys.push([1, 3, , 4]), [4, u(r, o, e)];
                    case 2:
                        return l.sent(), [3, 4];
                    case 3:
                        return a = l.sent(), i(a), [3, 4];
                    case 4:
                        return n(), [2]
                }
            })
        })
    }

    function u(e, t, r) {
        return __awaiter(this, void 0, void 0, function() {
            var n, i, o, a, u;
            return __generator(this, function(l) {
                switch (l.label) {
                    case 0:
                        n = H(), i = function(e) {
                            return n.includes(w.xpath(e))
                        }, o = 0, l.label = 1;
                    case 1:
                        if (!(o < e.length)) return [3, 6];
                        a = e[o], l.label = 2;
                    case 2:
                        return l.trys.push([2, 4, , 5]), [4, d(a)];
                    case 3:
                        return l.sent(), i(a) || a.setAttribute(I, O.PARSED), [3, 5];
                    case 4:
                        throw u = l.sent(), console.error("Error in the Color Contrast helper:", u), u;
                    case 5:
                        return o++, [3, 1];
                    case 6:
                        return c(), D.foundedIssues = D.foundedIssues.concat(D.contrastIssues.slice()), D.contrastIssues = [], r && r(), t && A.autofixAllIssues(), [2]
                }
            })
        })
    }

    function l() {
        return __awaiter(this, void 0, void 0, function() {
            var e, t, r, n;
            return __generator(this, function(i) {
                switch (i.label) {
                    case 0:
                        if (N || !D.acceptedFixes.length) return [3, 6];
                        e = [], i.label = 1;
                    case 1:
                        return [4, new Promise(requestAnimationFrame)];
                    case 2:
                        return i.sent(), t = e.length, [4, g(D.acceptedFixes[t])];
                    case 3:
                        r = i.sent(), e.push(r), i.label = 4;
                    case 4:
                        if (e.length !== D.acceptedFixes.length) return [3, 1];
                        i.label = 5;
                    case 5:
                        n = e.filter(Boolean), k(n), A.fixIssues(D.acceptedFixes, !1), N = !0, i.label = 6;
                    case 6:
                        return [2]
                }
            })
        })
    }

    function c() {
        var e = function(e, t, r) {
                void 0 === e && (e = 4.5);
                var n = 0;
                return n = r ? (e + .05) * (t + .05) - .05 : (t + .05) / e - .05, n < 0 ? 0 : n > 1 ? 1 : n
            },
            t = function(t, r, n, i) {
                void 0 === i && (i = !1);
                var o = new j,
                    a = new F(t),
                    u = new F(r),
                    l = function() {
                        var e = a.isLight(),
                            t = u.isLight();
                        if (e && t || !e && !t) {
                            if (a.luminance === u.luminance) {
                                var r = 0 === a.luminance,
                                    n = 1 === a.luminance;
                                return !(!r || !i) || (!n || !i) && e
                            }
                            return a.luminance > u.luminance
                        }
                        return e
                    }(),
                    c = e(n, u.luminance, l),
                    s = t.slice(0, 3).map(Number),
                    d = o.rgbToXyz(s),
                    f = __read(o.xyzToLab(d), 3),
                    p = (f[0], f[1]),
                    m = f[2],
                    h = o.findL(c) + (l ? 1 : -1);
                return "rgb(" + o.labToRgb([h, p, m]).join(",") + ")"
            },
            r = [];
        (function(e, t) {
            var r = function(e) {
                    return e[t]
                },
                n = t.split(".");
            return n.length > 1 && (r = function(e) {
                return n.reduce(function(e, t) {
                    return e[t]
                }, e)
            }), e.reduce(function(e, t) {
                var n = r(t),
                    i = e.get(n) || [];
                return e.set(n, __spreadArray(__spreadArray([], __read(i), !1), [t], !1)), e
            }, new Map)
        })(D.contrastIssues, "contrastData.backgroundColorParentElement").forEach(function(e, t) {
            var n = __read(e),
                i = n[0],
                o = n.slice(1);
            !o.length || o.every(function(e) {
                return e.contrastData.foreground[4] === i.contrastData.foreground[4]
            }) ? r.push(__assign(__assign({}, i), {
                tagName: t.tagName,
                xpath: w.xpath(t),
                childrenIssues: e.map(function(e) {
                    return e.xpath
                })
            })) : r = r.concat(e)
        }), D.contrastIssues = r.map(function(e) {
            var r, n = e.expectedRatio,
                i = e.contrastData,
                o = i.foreground,
                a = i.background,
                u = a[4],
                l = new F(a);
            r = t(o, a, n);
            var c = f(r);
            return new F(c).contrast(l).ratio < n && (u = t(a, c, n, !0)), __assign(__assign({}, e), {
                suggestion: {
                    foreground: r,
                    background: u
                }
            })
        })
    }

    function s(e) {
        var t = !1;
        return !!e && (Array.from(e.childNodes).some(function(e) {
            var r = e.nodeType,
                n = e.nodeValue;
            return 3 === r && n.length > 0 && -1 === n.search(/^\s+$/i) && (t = !0)
        }), (e instanceof HTMLInputElement && e.value.length > 0 || e instanceof HTMLSelectElement && e.options.length > 0) && (t = !0), t)
    }

    function d(e) {
        return __awaiter(this, void 0, void 0, function() {
            var t, r, n, i;
            return __generator(this, function(o) {
                switch (o.label) {
                    case 0:
                        return t = p(e), [4, m(e)];
                    case 1:
                        return r = o.sent(), (n = r.backgroundColor, i = r.targetElement, t.join("") === n.join("")) ? [2] : ("0" === n[3] && (n = ["255", "255", "255", "1", "rgb(255, 255, 255)"]), C(i) && (i = e), 1 === parseFloat(n[3]) && y(e, t, n, i), [2])
                }
            })
        })
    }

    function f(e) {
        if (!e) return ["0", "0", "0", "0", "rgba(0,0,0,0)"];
        var t = e.replace(/[^\d,.]/g, "").split(",");
        return t[3] || (t[3] = "1"), t[4] = e, t
    }

    function p(e) {
        return f(getComputedStyle(e).color)
    }

    function m(e) {
        return __awaiter(this, void 0, void 0, function() {
            var t, r, n, i, o, a, u, l, c, s, d, p;
            return __generator(this, function(y) {
                switch (y.label) {
                    case 0:
                        if (t = getComputedStyle(e), r = document.body === e, n = t.background.indexOf("linear-gradient") > -1, i = t.backgroundImage.indexOf("url") > -1 || t.background.indexOf("url") > -1, o = new RegExp(/rgba?\(((25[0-5]|2[0-4]\d|1\d{1,2}|\d\d?)\s*,\s*?){2}(25[0-5]|2[0-4]\d|1\d{1,2}|\d\d?)\s*,?\s*([01]\.?\d*?)?\)/g), a = function(e) {
                                return "rgba(0, 0, 0, 0)" === e || "transparent" === e
                            }, !r && a(t.backgroundColor) && !n && !i) return [2, m(e.parentElement)];
                        if (n && a(t.backgroundColor) && (u = (t.background.match(o) || []).find(function(e) {
                                return !a(e)
                            })), !i || !a(t.backgroundColor)) return [3, 6];
                        if (l = [".svg"], c = l.some(function(e) {
                                return -1 !== t.backgroundImage.indexOf(e) || -1 !== t.background.indexOf(e)
                            })) return [2, m(e.parentElement)];
                        s = t.backgroundImage.indexOf("url") > -1 ? t.backgroundImage.slice(4, -1).replace(/['"]/g, "") : t.background.match(/url\(["']?([^"']*)["']?\)/)[1], y.label = 1;
                    case 1:
                        return y.trys.push([1, 3, , 5]), [4, h(s)];
                    case 2:
                        return u = y.sent(), [3, 5];
                    case 3:
                        return d = y.sent(), [4, m(e.parentElement)];
                    case 4:
                        return [2, y.sent()];
                    case 5:
                        if ("rgb(0,0,0)" === u) return [2, m(e.parentElement)];
                        y.label = 6;
                    case 6:
                        return p = f(u || t.backgroundColor), (+t.opacity < 1 || "none" !== t.filter) && (p[3] = ".1"), [2, {
                            backgroundColor: p,
                            targetElement: e
                        }]
                }
            })
        })
    }

    function h(e) {
        return new Promise(function(t, r) {
            var n = document.createElement("canvas").getContext("2d"),
                i = new Image,
                o = function(e) {
                    return "rgb(" + e.join(",") + ")"
                };
            i.setAttribute("crossOrigin", ""), i.src = e, i.addEventListener("load", function() {
                var e;
                n.imageSmoothingEnabled = !0, n.drawImage(i, 0, 0), e = n.getImageData(0, 0, 1, 1).data.slice(0, 3), t(o(e))
            }), i.addEventListener("error", function(t) {
                console.warn("Image color recognition error:", e), r(t)
            })
        })
    }

    function y(e, t, r, n) {
        var i = {
                ratio: null,
                contrastRatio: null
            },
            o = new F(t),
            a = new F(r),
            u = o.contrast(a),
            l = u.ratio;
        if (l) {
            i.ratio = Number(l), i.contrastRatio = l + ":1";
            var c = window.getComputedStyle(e),
                s = c.getPropertyValue("font-size"),
                d = c.getPropertyValue("font-weight"),
                f = 72 * Number(s.substring(0, s.length - 2)) / 96,
                p = f >= 18 || f >= 14 && ("bold" === d || parseInt(d) >= 700),
                m = function(e) {
                    if (L) {
                        if (e && l < 4.5) return 4.5;
                        if (l < 7) return 7
                    }
                    return e && l < 3 ? 3 : l < 4.5 ? 4.5 : null
                }(p);
            if (!m) return;
            D.contrastIssues.push({
                contrastData: {
                    passRatio: m,
                    ratio: b(i.ratio),
                    foreground: t,
                    background: r,
                    backgroundColorParentElement: n
                },
                isLightFg: o.isLight(),
                isLightBg: a.isLight(),
                expectedRatio: m,
                tagName: e.tagName,
                xpath: w.xpath(e),
                fontSize: f
            })
        }
    }

    function g(e) {
        var t = e.background,
            r = e.foreground,
            n = e.xpath;
        return __awaiter(this, void 0, void 0, function() {
            var e, i, o, a, u, l, c, s, d, f, h;
            return __generator(this, function(y) {
                switch (y.label) {
                    case 0:
                        return (e = S.recursiveXpathSearch(n)) && "boolean" != typeof e ? (i = p(e), [4, m(e)]) : [2];
                    case 1:
                        return o = y.sent(), a = o.backgroundColor, u = o.targetElement, C(u) && (u = e), l = window.getComputedStyle(e), c = l.getPropertyValue("font-size"), s = l.getPropertyValue("font-weight"), d = 72 * Number(c.substring(0, c.length - 2)) / 96, f = d >= 18 || d >= 14 && ("bold" === s || parseInt(s) >= 700), h = f ? 3 : 4.5, [2, {
                            contrastData: {
                                passRatio: h,
                                ratio: h,
                                foreground: i,
                                background: a,
                                backgroundColorParentElement: u
                            },
                            suggestion: {
                                foreground: r,
                                background: t
                            },
                            expectedRatio: h,
                            tagName: e.tagName,
                            xpath: n,
                            fontSize: d
                        }]
                }
            })
        })
    }

    function b(e) {
        if (-1 !== (e = String(e)).indexOf(".")) {
            var t = e.split(".");
            return 1 === t.length ? Number(e) : Number(t[0] + "." + t[1].charAt(0) + t[1].charAt(1))
        }
        return Number(e)
    }
    var v = "REMEDIATION_COLOR_CONTRAST",
        A = UserWayWidgetApp.addLib(v),
        _ = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        E = UserWayWidgetApp.getLib("remediationConfig").contrast,
        w = UserWayWidgetApp.getLib("util"),
        x = UserWayWidgetApp.getLib("inlineStyling"),
        S = UserWayWidgetApp.getLib("xpath_search"),
        I = "data-uw-rm-color-contrast",
        O = {
            SMART_CONTRAST: "smc",
            AUTOFIX: "afix",
            PARSED: "prs",
            SET: "set"
        },
        R = {
            color: "",
            background: ""
        },
        W = !1,
        N = !1,
        L = !1,
        C = function(e) {
            var t = getComputedStyle(e);
            return t.backgroundImage.indexOf("url") > -1 || t.background.indexOf("url") > -1
        },
        T = {},
        k = function(e) {
            e.forEach(function(e) {
                T[e.xpath] = e
            })
        },
        U = function(e) {
            return Object.keys(T).filter(function(t) {
                return !e || e.includes(t)
            }).map(function(e) {
                return T[e]
            })
        },
        P = function() {
            T = {}
        },
        D = {
            foundedIssues: [],
            contrastIssues: [],
            acceptedFixes: []
        },
        H = function() {
            return D.acceptedFixes.map(function(e) {
                return e.xpath
            })
        },
        M = function(e) {
            return e.hasAttribute(I) && [O.AUTOFIX, O.SET].includes(e.getAttribute(I))
        };
    A.isSmartContrastEnabled = function() {
        return !!L
    }, A.isEnabled = function() {
        return W
    }, A.enable = function() {
        W = !0
    }, A.disable = function() {
        W = !1
    }, A.enableSmartContrast = function() {
        n(), L = !0, A.enable()
    }, A.disableSmartContrast = function() {
        n(), L = !1, A.disable()
    }, A.filter = function(e, r) {
        return E.enabled && (W || E.config.autofix) ? (r.reset && !A.isSmartContrastEnabled() && i(), t()) : []
    }, A.awaitForResources = function(t, r) {
        return new Promise(function(n, i) {
            e({
                resolve: n,
                reject: i,
                params: r,
                filteredElements: t
            })
        })
    }, A.doRemediation = function(e, t) {
        return new Promise(function(r, n) {
            if (!t.length) return r(null);
            setTimeout(function() {
                return a({
                    callbackAggregator: e,
                    items: t,
                    resolve: r,
                    reject: n
                })
            }, w.DELAYS.LONG)
        })
    }, A.fixIssues = function(e, t) {
        void 0 === t && (t = !0);
        var r = [];
        if (e.forEach(function(e) {
                var t = e.xpath && S.recursiveXpathSearch(e.xpath);
                if (t && "boolean" != typeof t) {
                    var n = e.childrenIssues,
                        i = void 0 === n ? [] : n,
                        o = __rest(e, ["childrenIssues"]),
                        a = i.map(function(e) {
                            return S.recursiveXpathSearch(e)
                        }).filter(function(e) {
                            return !!e && "boolean" != typeof e
                        });
                    if (a.length) x.applyInlineStyles(t, I, {
                        background: e.background
                    }), t.setAttribute(I, O.SET), a.forEach(function(t, n) {
                        x.applyInlineStyles(t, I, {
                            color: e.foreground
                        }), t.setAttribute(I, O.SET), r.push(__assign(__assign({}, o), {
                            xpath: e.childrenIssues[n]
                        }))
                    });
                    else {
                        var u = {
                            color: e.foreground,
                            background: e.background
                        };
                        x.applyInlineStyles(t, I, u), t.setAttribute(I, O.SET), r.push(e)
                    }
                }
            }), t) {
            D.acceptedFixes = D.acceptedFixes.concat(r);
            var n = H(),
                i = D.foundedIssues.filter(function(e) {
                    var t = e.xpath;
                    return n.includes(t)
                });
            k(i), D.foundedIssues = D.foundedIssues.filter(function(e) {
                var t = e.xpath;
                return !n.includes(t)
            })
        }
    }, A.autofixAllIssues = function() {
        o().forEach(function(e) {
            var t = e.xpath && S.recursiveXpathSearch(e.xpath);
            if (t) {
                var r = e.childrenIssues,
                    n = void 0 === r ? [] : r,
                    i = n.map(function(e) {
                        return S.recursiveXpathSearch(e)
                    }).filter(Boolean);
                if (!M(t))
                    if (i.length) x.applyInlineStyles(t, I, {
                        background: e.suggestion.background
                    }), t.setAttribute(I, O.AUTOFIX), i.forEach(function(t, r) {
                        x.applyInlineStyles(t, I, {
                            color: e.suggestion.foreground
                        }), t.setAttribute(I, O.AUTOFIX)
                    });
                    else {
                        var o = {
                            color: e.suggestion.foreground,
                            background: e.suggestion.background
                        };
                        x.applyInlineStyles(t, I, o), t.setAttribute(I, O.AUTOFIX)
                    }
            }
        }), A.isSmartContrastEnabled() || (E.config.autofix = !0)
    }, A.resetAutofixed = r, A.resetIssuesFixes = function() {
        i(), D.acceptedFixes = [], D.foundedIssues = D.foundedIssues.concat(U()), P()
    }, A.run = u;
    var F = function() {
            function e(e) {
                if (this.rgba = null, "transparent" === e) this.rgba = [0, 0, 0, 0];
                else if ("string" == typeof e) {
                    var t = e.match(/rgba?\(([\d.]+), ([\d.]+), ([\d.]+)(?:, ([\d.]+))?\)/);
                    if (!t) throw new Error("Invalid string: " + e);
                    t.shift()
                }
                0 === e[3] && (e[3] = 1), this.rgba = e.map(function(e) {
                    return q(e, 3)
                })
            }
            return Object.defineProperty(e.prototype, "rgb", {
                get: function() {
                    return this.rgba.slice(0, 3)
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "alpha", {
                get: function() {
                    return this.rgba[3]
                },
                set: function(e) {
                    this.rgba[3] = e
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "luminance", {
                get: function() {
                    for (var e = this.rgba.slice(), t = 0; t < 3; t++) {
                        var r = e[t];
                        r = (r /= 255) < .03928 ? r / 12.92 : Math.pow((r + .055) / 1.055, 2.4), e[t] = r
                    }
                    return .2126 * e[0] + .7152 * e[1] + .0722 * e[2]
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.clone = function() {
                return new e(this.rgba)
            }, e.prototype.isLight = function() {
                var e = (this.luminance + .05) / .05;
                return 1.05 / (this.luminance + .05) < e
            }, e.prototype.overlayOn = function(e) {
                var t = this.clone(),
                    r = this.alpha;
                if (r >= 1) return t;
                for (var n = 0; n < 3; n++) t.rgba[n] = t.rgba[n] * r + e.rgba[n] * e.rgba[3] * (1 - r);
                return t.rgba[3] = r + e.rgba[3] * (1 - r), t
            }, e.prototype.contrast = function(e) {
                var t = {
                    ratio: null
                };
                if (this.alpha < 1) return t;
                e.alpha < 1 && (e = e.overlayOn(this));
                var r = this.luminance + .05,
                    n = e.luminance + .05,
                    i = r / n;
                return t.ratio = n > r ? 1 / i : i, t
            }, e
        }(),
        q = function(e, t) {
            var r = Math.pow(10, t || 0);
            return Math.round(e * r) / r
        },
        j = function() {
            function e() {
                this.D65 = [95.047, 100, 108.883]
            }
            return e.prototype.rgbToXyz = function(e) {
                var t = __read(e.map(function(e) {
                        return e / 255
                    }).map(this.sRGBtoLinearRGB), 3),
                    r = t[0],
                    n = t[1],
                    i = t[2];
                return [.4124 * r + .3576 * n + .1805 * i, .2126 * r + .7152 * n + .0722 * i, .0193 * r + .1192 * n + .9505 * i].map(function(e) {
                    return 100 * e
                })
            }, e.prototype.sRGBtoLinearRGB = function(e) {
                return e <= .04045 ? e / 12.92 : Math.pow((e + .055) / 1.055, 2.4)
            }, e.prototype.xyzToLab = function(e) {
                var t, r = this,
                    n = __read(e, 3),
                    i = n[0],
                    o = n[1],
                    a = n[2];
                return t = __read([i, o, a].map(function(e, t) {
                    return e /= r.D65[t], e > .008856 ? Math.pow(e, 1 / 3) : 7.787 * e + 16 / 116
                }), 3), i = t[0], o = t[1], a = t[2], [116 * o - 16, 500 * (i - o), 200 * (o - a)]
            }, e.prototype.findL = function(e) {
                return 116 * Math.pow(e, 1 / 3) - 16
            }, e.prototype.labToRgb = function(e) {
                var t, r, n, i = (e[0] + 16) / 116,
                    o = e[1] / 500 + i,
                    a = i - e[2] / 200;
                return o = .95047 * (o * o * o > .008856 ? o * o * o : (o - 16 / 116) / 7.787), i = 1 * (i * i * i > .008856 ? i * i * i : (i - 16 / 116) / 7.787), a = 1.08883 * (a * a * a > .008856 ? a * a * a : (a - 16 / 116) / 7.787), t = 3.2406 * o + -1.5372 * i + -.4986 * a, r = -.9689 * o + 1.8758 * i + .0415 * a, n = .0557 * o + -.204 * i + 1.057 * a, t = t > .0031308 ? 1.055 * Math.pow(t, 1 / 2.4) - .055 : 12.92 * t, r = r > .0031308 ? 1.055 * Math.pow(r, 1 / 2.4) - .055 : 12.92 * r, n = n > .0031308 ? 1.055 * Math.pow(n, 1 / 2.4) - .055 : 12.92 * n, [255 * Math.max(0, Math.min(1, t)), 255 * Math.max(0, Math.min(1, r)), 255 * Math.max(0, Math.min(1, n))].map(function(e) {
                    return q(e)
                })
            }, e
        }()
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e, r) {
        var n;
        return (null === (n = UserWayWidgetApp.ContextHolder.remediationResources) || void 0 === n ? void 0 : n.ExternalLink) && t(UserWayWidgetApp.ContextHolder.remediationResources.ExternalLink), e()
    }

    function t(e) {
        e.forEach(function(e) {
            g[r(e.href, e.term)] = e
        })
    }

    function r(e, t) {
        return (e + "$" + t).toLowerCase().replace(/ /g, "")
    }

    function n() {
        [].slice.call(document.querySelectorAll("[" + y + "]")).forEach(function(e) {
            e.removeAttribute(y)
        })
    }

    function i(e) {
        return e.filter(function(e) {
            var t = e.href;
            return !(!t || !/^http/.test(t)) && (!(!e.hasAttribute("target") || "_self" === e.getAttribute("target") || !e.getAttribute("target")) && !e.hasAttribute(y))
        })
    }

    function o(e, t, n, i) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_EXTERNAL_LINK_TARGETS");
            for (var o = [], u = 0; u < i.length; u++) {
                var l = i[u],
                    c = a(l),
                    d = void 0;
                if (c)
                    if (-1 === c.indexOf("new window") && -1 === c.indexOf("new tab")) {
                        var p = r(l.href, c),
                            b = void 0;
                        if (g[p]) d = g[p].correction, b = g[p].approved, o.push(Object.assign(g[p], {
                            id: p
                        }));
                        else if (!d) {
                            b = !1;
                            var v = " - " + m(h.language, "widget.new_tab"),
                                A = void 0;
                            A = l.hasAttribute("aria-label") ? l.getAttribute("aria-label") : c, d = A + v, o.push({
                                href: l.href,
                                term: c,
                                correction: d,
                                approved: b,
                                id: p
                            })
                        }(b || s) && l.setAttribute("aria-label", d), l.setAttribute(y, ""), l.setAttribute("uw-rm-external-link-id", p)
                    } else l.setAttribute(y, "na");
                else l.setAttribute(y, "na")
            }
            e.onHelperRemediationCompleted(f.of("REMEDIATION_EXTERNAL_LINK_TARGETS", {
                items: o
            }, null, o.length, o.length)), t()
        } catch (e) {
            n(e)
        }
    }

    function a(e) {
        var t = e.hasAttribute("aria-label") ? e.getAttribute("aria-label") : null,
            r = e.hasAttribute("aria-labelledby") ? e.getAttribute("aria-labelledby") : null;
        return t || (r ? d.getLabelledByElements(r) : d.composeElementTextRepresentation(e))
    }
    var u, l = UserWayWidgetApp.addLib("REMEDIATION_EXTERNAL_LINK_TARGETS"),
        c = UserWayWidgetApp.getLib("remediationConfig"),
        s = !c.strategy || "AUTO" === c.strategy,
        d = UserWayWidgetApp.getLib("util"),
        f = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        p = UserWayWidgetApp.getLib("localization_manager"),
        m = p.translate,
        h = UserWayWidgetApp.ContextHolder.config,
        y = "data-uw-rm-ext-link",
        g = {};
    (null === (u = null === c || void 0 === c ? void 0 : c.externalLinks) || void 0 === u ? void 0 : u.enabled) && (l.filter = function(e, t) {
        return t.reset && n(), i([].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(e.querySelectorAll("a[href]"))
        })), !1)))
    }, l.awaitForResources = function(t, r) {
        return r.reset ? new Promise(function(t, r) {
            e(t, r)
        }) : Promise.resolve()
    }, l.doRemediation = function(e, t, r) {
        return new Promise(function(r, n) {
            o(e, r, n, t)
        })
    })
}(),
function() {
    function e() {
        var e = UserWayWidgetApp.ContextHolder.config,
            t = e._userway_config.hasOwnProperty("ai_custom_focus_style_enabled");
        return t ? t && (!0 === e._userway_config.ai_custom_focus_style_enabled || "true" === e._userway_config.ai_custom_focus_style_enabled) : l.enabled
    }

    function t(e) {
        var t = {
            outline: l.outlineWidth + " " + l.outlineStyle + " " + l.outlineColor
        };
        return t["outline-offset"] = "-" + l.outlineWidth, t
    }

    function r(e) {
        if ("function" == typeof e.hasAttribute && e.hasAttribute(d)) {
            var r = window.getComputedStyle(e),
                n = t(r);
            c.resetInlineStyles(e, d, n), e.removeAttribute(d)
        }
    }

    function n(e) {
        e.target && p && u.addStyles(e.target)
    }

    function i(e) {
        var t = e ? "addEventListener" : "removeEventListener";
        document[t]("mousedown", o), document[t]("keydown", a), document[t]("focusin", n), document[t]("focusout", m)
    }

    function o() {
        p = !1
    }

    function a() {
        p = !0
    }
    var u = UserWayWidgetApp.addLib("REMEDIATION_FOCUS_STYLE"),
        l = UserWayWidgetApp.getLib("remediationConfig").customFocus,
        c = UserWayWidgetApp.getLib("inlineStyling"),
        s = UserWayWidgetApp.getLib("remediation_utils"),
        d = "data-uw-rm-outline",
        f = {
            width: "2px",
            color: " #0018FF",
            style: "solid"
        },
        p = !1;
    u.apply = function() {
        var t, r, n, o;
        if (e()) {
            var a = null === (n = null === (r = null === (t = UserWayWidgetApp.ContextHolder) || void 0 === t ? void 0 : t.config) || void 0 === r ? void 0 : r.tunings) || void 0 === n ? void 0 : n.widget_color,
                u = (null === (o = UserWayWidgetApp.getLib("remediationConfig").customFocus.config) || void 0 === o ? void 0 : o.style) ? JSON.parse(UserWayWidgetApp.getLib("remediationConfig").customFocus.config.style) : f;
            l.outlineWidth = u.width, l.outlineColor = u.color || a, l.outlineStyle = u.style, setTimeout(function() {
                i(!0)
            }, 500)
        }
    }, u.getFocusStyle = function() {
        return {
            enabled: e(),
            outlineWidth: l.outlineWidth || f.width,
            outlineColor: l.outlineColor || f.color,
            outlineStyle: l.outlineStyle || f.style
        }
    }, u.updateOutlineStyle = function(e) {
        if (e.data && (e.data.update || null != e.data.enabled)) {
            var t = e.data.update,
                n = e.data.enabled;
            l.outlineWidth = t.width, l.outlineStyle = t.style, l.outlineColor = t.color, l.enabled !== n && (i(l.enabled), [].slice.call(document.querySelectorAll("[" + d + "]")).forEach(function(e) {
                r(e)
            }), l.enabled = n)
        }
    }, u.addStyles = function(e) {
        if (!e.hasAttribute(s.ignoreElementFromHelperProcessingAttr)) {
            var r = window.getComputedStyle(e),
                n = t(r);
            c.applyInlineStyles(e, d, n), e.setAttribute(d, "")
        }
    };
    var m = function(e) {
        e.target && r(e.target)
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    function e(e) {
        for (var t, r, n = e, i = !1; n && "BODY" !== n.tagName.toUpperCase();) {
            if ("FORM" === n.tagName.toUpperCase()) {
                try {
                    for (var o = (t = void 0, __values(f)), a = o.next(); !a.done; a = o.next()) {
                        var u = a.value;
                        if (n.action.indexOf(u) > -1) {
                            i = !0;
                            break
                        }
                    }
                } catch (e) {
                    t = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (r = o.return) && r.call(o)
                    } finally {
                        if (t) throw t.error
                    }
                }
                if (i) break
            }
            n = n.parentElement
        }
        return i
    }

    function t() {
        p = {}, [].slice.call(document.querySelectorAll("[" + d + "]")).forEach(function(e) {
            e.removeAttribute(d)
        })
    }

    function r(e, t, r) {
        return r.reset ? UserWayWidgetApp.ContextHolder.remediationResources ? (UserWayWidgetApp.ContextHolder.remediationResources.Forms.forEach(function(e) {
            p[e.xpath] = e
        }), e()) : void(l.enabled ? e() : t()) : e()
    }

    function n(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }

    function i(e) {
        if (l.enabled) {
            Array.from(document.querySelectorAll("form")).filter(function(e) {
                return n(e) && Array.from(e.querySelectorAll("input, textarea, select")).length
            }).forEach(function(t) {
                e && o(t);
                var r = t.querySelector('button[type="submit"], input[type="submit"]');
                r && !r.hasAttribute(d) && (r.addEventListener("click", function(e) {
                    o(t)
                }), r.setAttribute(d, "submit"))
            })
        }
    }

    function o(e) {
        function t(t) {
            for (var r = [], n = t.parentElement; n && n !== e;) r.push(n), n = n.parentElement;
            return {
                element: t,
                parents: r
            }
        }
        var r = Array.from(e.querySelectorAll('[class*="error" i], [class*="message" i]')).filter(function(e) {
            if (-1 !== ["DIV", "SPAN", "UL", "LI", "LABEL"].indexOf(e.nodeName) && !e.querySelector(c.focusableElementsSelector) && n(e) && e.textContent) return !0
        });
        if (r.length) {
            var i = Array.from(e.querySelectorAll("input, textarea, select")).filter(function(e) {
                    return n(e)
                }),
                o = [];
            i.forEach(function(e) {
                o.push(t(e))
            }), r.forEach(function(e) {
                var r, n, i, a, u = t(e).parents,
                    l = null,
                    c = u.length;
                try {
                    for (var s = __values(o), f = s.next(); !f.done; f = s.next())
                        for (var p = f.value, m = p.element, h = p.parents, y = 0; y < u.length; y++) {
                            var g = u[y];
                            try {
                                for (var b = (i = void 0, __values(h)), v = b.next(); !v.done; v = b.next()) {
                                    var A = v.value;
                                    g === A && y < c && (c = y, l = m)
                                }
                            } catch (e) {
                                i = {
                                    error: e
                                }
                            } finally {
                                try {
                                    v && !v.done && (a = b.return) && a.call(b)
                                } finally {
                                    if (i) throw i.error
                                }
                            }
                        }
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        f && !f.done && (n = s.return) && n.call(s)
                    } finally {
                        if (r) throw r.error
                    }
                }
                if (l && !l.hasAttribute("aria-describedby")) {
                    var _ = e.id;
                    _ || (_ = "uwRmForms_" + (new Date).getTime(), e.id = _, e.setAttribute(d, "in-validation")), l.setAttribute("aria-describedby", "" + _)
                }
            })
        }
    }
    var a = UserWayWidgetApp.addLib("REMEDIATION_FORM_LABEL"),
        u = UserWayWidgetApp.getLib("remediationConfig"),
        l = u.forms || {},
        c = UserWayWidgetApp.getLib("remediation_util"),
        s = UserWayWidgetApp.getLib("xpath_search"),
        d = "data-uw-rm-form",
        f = ["facebook", "google"],
        p = {};
    a.filter = function(r, n) {
        n.reset && t();
        var i = ["INPUT", "TEXTAREA", "SELECT"],
            o = [].concat.apply([], __spreadArray([], __read(r.map(function(e) {
                return [].slice.call(e.querySelectorAll(i.join().toLowerCase()))
            })), !1)),
            a = [];
        return o.forEach(function(t) {
            e(t) && t.setAttribute(d, "excluded"), t.hasAttribute(d) || t.type && -1 === ["text", "password", "search", "email", "tel", "number", "textarea", "select-one", "checkbox", "radio"].indexOf(t.type) || a.push(t)
        }), a
    }, a.awaitForResources = function(e, t) {
        return new Promise(function(e, n) {
            r(e, n, t)
        })
    }, a.doRemediation = function(e, t, r) {
        return new Promise(function(e, t) {
            try {
                i(r.reset), e()
            } catch (e) {
                t()
            }
        })
    }, a.updateLabelInDom = function(e) {
        var t = e.xpath && s.recursiveXpathSearch(e.xpath);
        "boolean" != typeof t && (t.setAttribute("aria-label", e.correction), "boolean" != typeof t && e.required ? (t.setAttribute("required", "true"), t.setAttribute("aria-required", "true")) : (t.removeAttribute("required"), t.removeAttribute("aria-required")), t.setAttribute(d, "adm"))
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    var e = UserWayWidgetApp.addLib("REMEDIATION_HAMBURGER_MENU"),
        t = UserWayWidgetApp.getLib("remediation_util"),
        r = UserWayWidgetApp.getLib("event_emitter");
    e.apply = function() {
        r.on("UW_CER_HAMBURGER_IN", function(e) {
            var r = __read(e, 2),
                n = r[0],
                i = r[1];
            n.setAttribute("tabindex", "0"), n.addEventListener("keydown", function(e) {
                t.keys.isEnter(e) && (setTimeout(function() {
                    var e, r, n, o, a = i.filter(function(e) {
                        return t.isElementVisible(e, {
                            skipParentCheck: !0
                        })
                    });
                    try {
                        for (var u = __values(a), l = u.next(); !l.done; l = u.next()) {
                            var c = l.value,
                                s = c.querySelectorAll("a");
                            try {
                                for (var d = (n = void 0, __values(s)), f = d.next(); !f.done; f = d.next()) {
                                    f.value.setAttribute("tabindex", "0")
                                }
                            } catch (e) {
                                n = {
                                    error: e
                                }
                            } finally {
                                try {
                                    f && !f.done && (o = d.return) && o.call(d)
                                } finally {
                                    if (n) throw n.error
                                }
                            }
                        }
                    } catch (t) {
                        e = {
                            error: t
                        }
                    } finally {
                        try {
                            l && !l.done && (r = u.return) && r.call(u)
                        } finally {
                            if (e) throw e.error
                        }
                    }
                    a.length && a[0].querySelector("a").focus()
                }, 800), e.preventDefault(), n.click())
            })
        })
    }
}(),
function() {
    function e() {
        var e = document.querySelector("[" + u + "]");
        null === e || void 0 === e || e.removeAttribute(u)
    }

    function t() {
        var e, t = document.querySelector("title");
        return !t || !(null === (e = t.innerHTML) || void 0 === e ? void 0 : e.trim()) && !t.hasAttribute(u)
    }

    function r() {
        var e = function(e) {
                return e.length > 1 ? e.slice(0, -1) : e
            },
            t = window.location,
            r = t.hostname,
            n = t.href,
            i = t.host,
            o = r.replace("www.", "").split("."),
            a = e(o).join("-"),
            u = n.split(i).pop().split("/").join(" "),
            l = u.split("?"),
            c = e(l).join(" ").replace(/^\d+|\s\d+/g, "").trim();
        return (c + (c ? " - " : " ") + a).trim()
    }

    function n(e) {
        var t = e.callbackAggregator,
            n = e.resolve,
            o = e.reject,
            c = e.items;
        try {
            t.onHelperRemediationStarted(i), c.forEach(function(e) {
                var t = r(),
                    n = e.querySelector("title");
                if (n) n.innerHTML = t;
                else {
                    var i = e.createElement("title");
                    i.innerHTML = t, e.head.appendChild(i)
                }
                e.querySelector("title").setAttribute(u, t ? l.GENERIC : l.UNKNOWN)
            }), t.onHelperRemediationCompleted(a.of(i, null, null, c.length, 0)), n()
        } catch (e) {
            o(e)
        }
    }
    var i = "REMEDIATION_HEADER_TITLE",
        o = UserWayWidgetApp.addLib(i),
        a = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        u = "data-uw-rm-title",
        l = {
            UNKNOWN: "un",
            GENERIC: "gn"
        };
    o.filter = function(r, n) {
        return n.reset && e(), t() ? [document] : []
    }, o.awaitForResources = function() {
        return Promise.resolve()
    }, o.doRemediation = function(e, t) {
        return new Promise(function(r, i) {
            n({
                callbackAggregator: e,
                items: t,
                resolve: r,
                reject: i
            })
        })
    }
}();
var __read = this && this.__read || function(e, t) {
    var r = "function" == typeof Symbol && e[Symbol.iterator];
    if (!r) return e;
    var n, i, o = r.call(e),
        a = [];
    try {
        for (;
            (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
    } catch (e) {
        i = {
            error: e
        }
    } finally {
        try {
            n && !n.done && (r = o.return) && r.call(o)
        } finally {
            if (i) throw i.error
        }
    }
    return a
};
! function() {
    function e(e) {
        e.forEach(function(e) {
            var t = null != e.page ? e.page : "$all";
            h[e.type] = h[e.type] || {}, h[e.type][t] = h[e.type][t] || {}, e.xpath ? h[e.type][t][e.xpath] = e : h[e.type][t] = e
        })
    }

    function t(t, r, n) {
        return s ? (UserWayWidgetApp.ContextHolder.remediationResources && e(UserWayWidgetApp.ContextHolder.remediationResources.Headings), t()) : t()
    }

    function r() {
        var e = document.querySelector("[" + d + '="h1"]');
        e && e.parentElement.removeChild(e), [].slice.call(document.querySelectorAll("[" + d + '="level"]')).forEach(function(e) {
            e.removeAttribute(d), e.removeAttribute("aria-level"), e.removeAttribute("role")
        });
        var t = [].slice.call(document.querySelectorAll("[" + d + '="hide"]'));
        t.length && t.forEach(function(e) {
            e.removeAttribute(d), e.removeAttribute("aria-hidden"), e.removeAttribute("role");
            var t = e.querySelector(".uw-ai-autofix-hide");
            t && e.removeChild(t)
        })
    }

    function n(e, t) {
        e.setAttribute("role", "heading"), e.setAttribute("aria-level", "" + t), e.setAttribute(d, "level")
    }

    function i(e) {
        var t = document.createElement("h1"),
            r = document.querySelector("main"),
            i = document.querySelector("[role=main]"),
            o = r || i;
        if (o) {
            var a = h["ADD-H1"] && h["ADD-H1"].$all,
                u = h["ADD-H1"] && h["ADD-H1"][e],
                l = !!u,
                c = u || a,
                s = c && c.correction ? c.correction : document.title;
            return n(t, 1), t.setAttribute("style", "clip: rect(1px, 1px, 1px, 1px)!important;height:1px!important;width:1px!important;overflow:hidden!important;position:absolute!important;top:0!important;left:0!important;z-index:-1!important;opacity:0!important"), t.setAttribute(d, "h1"), t.setAttribute("id", "userway-h1-heading"), t.setAttribute("data-uw-rm-ignore", ""), t.innerText = s, o.prepend(t), m.push({
                type: "ADD-H1",
                level: 1,
                previousLevel: 0,
                content: s,
                autofix: !0,
                approved: l,
                xpath: p.xpath(t)
            }), [t, !!c]
        }
        return [null, !1]
    }

    function o(e) {
        return /(h\d)/i.test(e.nodeName) ? +e.nodeName.slice(1) : +e.getAttribute("aria-level")
    }

    function a(e, t, r, a) {
        if (e.onHelperRemediationStarted("REMEDIATION_HEADING"), m = [], s) {
            var u = location.pathname;
            if (a.length || i(u), a.length) {
                if (!("H1" === a[0].nodeName || a[0].hasAttribute("aria-level") && "1" === a[0].getAttribute("aria-level"))) {
                    var l = __read(i(u), 1),
                        c = l[0];
                    c && a.unshift(c)
                }
                for (var y = void 0, g = 0, b = void 0, v = 0, A = a.length; v < A; v++) {
                    var _ = p.xpath(a[v]);
                    y = o(a[v]);
                    var E = p.composeElementTextRepresentation(a[v]);
                    if (1 === y && a[v].hasAttribute(d)) g = 1;
                    else if (b = {
                            type: "CONTENT",
                            level: y,
                            content: E,
                            approved: !0,
                            xpath: _,
                            autofix: !0
                        }, E && 1 === y && 0 !== v && (a[v].setAttribute("role", "heading"), a[v].setAttribute("aria-level", "2"), a[v].setAttribute(d, "level"), b.previousLevel = 1, b.approved = !1, b.type = "LEVEL", y = 2, b.level = 2), E && E.trim())
                        if (y > g + 1) {
                            var w = h.LEVEL && h.LEVEL[u] && h.LEVEL[u][_] && h.LEVEL[u][_].correction,
                                x = !!w && h.LEVEL[u][_].approved;
                            b.previousLevel = y, b.approved = !1;
                            var S = g + 1;
                            b.type = "LEVEL", a[v].setAttribute(d, "level"), b.level = S, n(a[v], S), g++, b.approved = x, m.push(b)
                        } else g = y, m.push(b);
                    else {
                        a[v].setAttribute("role", "presentation"), a[v].setAttribute("aria-hidden", !0), p.addScreenRearedElement(a[v], "Empty heading", "data-uw-rm-autofix-hide"), b.type = "HIDE", a[v].setAttribute(d, "hide");
                        var I = h.HIDE && h.HIDE.$all && h.HIDE.$all[_],
                            O = h.HIDE && h.HIDE[u] && h.HIDE[u][_],
                            R = O || I;
                        b.approved = !!R && R.approved, m.push(b)
                    }
                }
            }
        }
        e.onHelperRemediationCompleted(f.of("REMEDIATION_HEADING", {
            items: m
        }, null, s ? 0 : [].slice.call(document.querySelectorAll("[" + d + "]")).length, 0)), t()
    }
    var u = UserWayWidgetApp.addLib("REMEDIATION_HEADING"),
        l = UserWayWidgetApp.ContextHolder.config,
        c = UserWayWidgetApp.getLib("remediationConfig").headings || {},
        s = c.enabled && l.partner !== atob("c2hvcnRwb2ludA=="),
        d = "data-uw-rm-heading",
        f = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        p = UserWayWidgetApp.getLib("util"),
        m = [],
        h = {};
    u.filter = function(e) {
        return s ? (r(), [].slice.call(document.querySelectorAll('h1, h2, h3, h4, h5, h6, [role="heading"]:not([data-uw-rm-aria])'))) : []
    }, u.awaitForResources = function(e, r) {
        return new Promise(function(e, n) {
            t(e, n, r)
        })
    }, u.doRemediation = function(e, t) {
        return new Promise(function(r, n) {
            a(e, r, n, t)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e() {
        [].slice.call(document.querySelectorAll("[" + f + "]")).forEach(function(e) {
            e.removeAttribute(f)
        })
    }

    function t(e) {
        var t = [],
            n = e.filter(function(e) {
                return !e.hasAttribute(f) && e.hasAttribute("title")
            });
        return r(n).length > 0 && (t = r(n)), t.concat(e.filter(function(e) {
            return !e.hasAttribute(f) && !e.hasAttribute("title")
        }))
    }

    function r(e) {
        var t = {},
            r = [],
            i = [];
        return e.forEach(function(e, r) {
            var n = e.getAttribute("src");
            t[n] ? t[n].push(r) : t[n] = [r]
        }), Object.keys(t).filter(function(e) {
            return t[e].length > 1
        }).forEach(function(r) {
            i.push({
                src: r,
                elements: n(e, t[r])
            })
        }), i.forEach(function(e) {
            e.elements.sort(function(e, t) {
                return e.title.length - t.title.length
            });
            var t = e.elements[e.elements.length - 1].title;
            e.elements.pop(), e.elements.forEach(function(e) {
                e.setAttribute(p, t)
            }), r = r.length ? r.concat(e.elements) : e.elements
        }), r
    }

    function n(e, t) {
        var r = [];
        return t.forEach(function(t) {
            r.push(e[t])
        }), r
    }

    function i(e) {
        var t = "";
        try {
            t = new URL(e).hostname.replace("www.", "").split(".").slice(0, -1).join("-")
        } catch (e) {}
        return t
    }

    function o(e) {
        var t = {
                SRC: "src",
                CLASSNAME: "class",
                ID: "id"
            },
            r = e.getAttribute(t.SRC) || "",
            n = e.getAttribute(t.CLASSNAME) || "",
            o = e.getAttribute(t.ID) || "",
            a = i(r) || u(n) || o;
        a ? (e.setAttribute("title", a), e.setAttribute(f, m.GENERIC)) : e.setAttribute(f, m.UNKNOWN)
    }

    function a(e) {
        var t = e.getAttribute(p);
        e.setAttribute("title", t), e.setAttribute(f, m.GENERIC), e.removeAttribute(p)
    }

    function u(e) {
        return e.replace(/\./g, "").split(" ").join("___")
    }

    function l(e) {
        var t = e.callbackAggregator,
            r = e.resolve,
            n = e.reject,
            i = e.items;
        try {
            t.onHelperRemediationStarted(c), i.forEach(function(e) {
                e.hasAttribute(p) ? a(e) : o(e)
            }), t.onHelperRemediationCompleted(d.of(c, null, null, i.length, 0)), r()
        } catch (e) {
            n(e)
        }
    }
    var c = "REMEDIATION_IFRAME_TITLE",
        s = UserWayWidgetApp.addLib(c),
        d = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        f = "data-uw-rm-iframe",
        p = "data-correct-title",
        m = {
            UPDATED_BY_ADMIN: "adm",
            UNKNOWN: "un",
            GENERIC: "gn"
        };
    s.filter = function(r, n) {
        return n.reset && e(), t(__spreadArray([], __read(r), !1).reduce(function(e, t) {
            return __spreadArray(__spreadArray([], __read(e), !1), __read([].slice.call(t.querySelectorAll("iframe"))), !1)
        }, []))
    }, s.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, s.doRemediation = function(e, t) {
        return new Promise(function(r, n) {
            l({
                callbackAggregator: e,
                items: t,
                resolve: r,
                reject: n
            })
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    function e(e) {
        var t = __spreadArray(__spreadArray(["a"], __read(c), !1), __read(c.map(function(e) {
            return '[role="' + e + '"]'
        })), !1).join(",");
        return e.querySelectorAll(t).length > 0
    }

    function t(t) {
        return t.filter(function(t) {
            var r, n, i, a, m, h, y, g;
            if ("function" == typeof t.hasAttribute && t.hasAttribute(u) || e(t)) return !1;
            if (t.classList && t.classList.contains("betterbot_botInfoText")) return t.setAttribute(u, l.BETTERBOT_CHAT), !0;
            if ("function" == typeof t.getAttribute && c.indexOf(t.getAttribute("role")) > -1 && !t.hasAttribute("tabindex")) return t.setAttribute(u, l.HAS_ROLE_NO_TABINDEX), !0;
            var b = !1,
                v = !1;
            if ("function" == typeof t.hasAttribute) try {
                for (var A = __values(s), _ = A.next(); !_.done; _ = A.next()) {
                    var E = _.value;
                    if (t.hasAttribute(E) && !o.isElementEditable(t)) {
                        v = !1, b = !0;
                        try {
                            for (var w = (i = void 0, __values(d)), x = w.next(); !x.done; x = w.next()) {
                                var S = x.value;
                                t.hasAttribute(S) && (v = !0)
                            }
                        } catch (e) {
                            i = {
                                error: e
                            }
                        } finally {
                            try {
                                x && !x.done && (a = w.return) && a.call(w)
                            } finally {
                                if (i) throw i.error
                            }
                        }
                    }
                }
            } catch (e) {
                r = {
                    error: e
                }
            } finally {
                try {
                    _ && !_.done && (n = A.return) && n.call(A)
                } finally {
                    if (r) throw r.error
                }
            }
            if (b && !v) return t.setAttribute(u, l.HAS_ONCLICK_NO_ONKEYPRESS), !0;
            var I = !1,
                O = !1,
                R = !1,
                W = ["drag-and-drop"];
            if ("function" == typeof t.hasAttribute) {
                R = t.hasAttribute("tabindex");
                try {
                    for (var N = __values(f), L = N.next(); !L.done; L = N.next()) {
                        var E = L.value;
                        if (W.indexOf(t.nodeName.toLowerCase()) < 0 && t.hasAttribute(E) && !o.isElementEditable(t)) {
                            O = !1, I = !0;
                            try {
                                for (var C = (y = void 0, __values(p)), T = C.next(); !T.done; T = C.next()) {
                                    var S = T.value;
                                    t.hasAttribute(S) && (O = !0)
                                }
                            } catch (e) {
                                y = {
                                    error: e
                                }
                            } finally {
                                try {
                                    T && !T.done && (g = C.return) && g.call(C)
                                } finally {
                                    if (y) throw y.error
                                }
                            }
                        }
                    }
                } catch (e) {
                    m = {
                        error: e
                    }
                } finally {
                    try {
                        L && !L.done && (h = N.return) && h.call(N)
                    } finally {
                        if (m) throw m.error
                    }
                }
            }
            return !I || O || R ? !("A" !== t.tagName || t.href || t.hasAttribute("tabindex") || t.hasAttribute("role")) && (t.setAttribute(u, l.ANCHOR_NO_HREF), !0) : (t.setAttribute(u, l.HAS_NGCLICK_NO_NGKEYPRESS), !0)
        })
    }

    function r(e, t, r, n, a) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_KEYBOARD_NAVIGATION");
            var c = 0;
            n.forEach(function(e) {
                var t = e.getAttribute(u);
                if (t) return c++, t === l.BETTERBOT_CHAT ? (e.setAttribute("tabindex", "0"), e.setAttribute("role", "button"), e.setAttribute("aria-label", "Start chat with us"), void o.clickOnEnter(e)) : t === l.HAS_ROLE_NO_TABINDEX ? (e.setAttribute("tabindex", "0"), void o.clickOnEnter(e)) : t === l.OVERFLOW_HELPER ? void e.setAttribute("tabindex", "0") : t === l.HAS_ONCLICK_NO_ONKEYPRESS ? void o.clickOnEnter(e) : t && e.getAttribute(u) === l.HAS_NGCLICK_NO_NGKEYPRESS ? (e.setAttribute("role", "button"), e.setAttribute("tabindex", "0"), void o.clickOnEnter(e)) : t === l.ANCHOR_NO_HREF ? (e.setAttribute("tabindex", "0"), void("pointer" === window.getComputedStyle(e).cursor && o.clickOnEnter(e))) : void 0
            }), e.onHelperRemediationCompleted(i.of("REMEDIATION_KEYBOARD_NAVIGATION", null, null, c, 0)), t()
        } catch (e) {
            r(e)
        }
    }
    var n = UserWayWidgetApp.addLib("REMEDIATION_KEYBOARD_NAVIGATION"),
        i = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        o = UserWayWidgetApp.getLib("remediation_util"),
        a = UserWayWidgetApp.getLib("util"),
        u = "data-uw-rm-kbnav",
        l = {
            BETTERBOT_CHAT: "betterbot",
            HAS_ROLE_NO_TABINDEX: "role",
            HAS_ONCLICK_NO_ONKEYPRESS: "click",
            HAS_NGCLICK_NO_NGKEYPRESS: "ngclick",
            OVERFLOW_HELPER: "scrollTabIndex",
            ANCHOR_NO_HREF: "anohref"
        },
        c = ["link", "button", "menuitem", "checkbox"],
        s = ["onclick"],
        d = ["onkeydown", "onkeyup", "onkeypress"],
        f = ["ng-click"],
        p = ["ng-keypress", "ng-keyup", "ng-keydown"];
    n.filter = function(e, r) {
        return r.reset, t([].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(a.findAllElements(e))
        })), !1)))
    }, n.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, n.doRemediation = function(e, t, n) {
        return new Promise(function(i, o) {
            r(e, i, o, t, n)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e, t) {
        if (!a.enabled) return e();
        UserWayWidgetApp.ContextHolder.remediationResources && (s = UserWayWidgetApp.ContextHolder.remediationResources.Language), e()
    }

    function t() {
        [].slice.call(document.querySelectorAll("[" + c + "]")).forEach(function(e) {
            e.removeAttribute(c)
        })
    }

    function r(e, t, r, i) {
        var o = 0,
            a = "" + u.hashString(window.location.pathname),
            d = s.find(function(e) {
                return e.page === a
            });
        try {
            r.onHelperRemediationStarted("REMEDIATION_SITE_LANGUAGE"), d && document.documentElement.setAttribute("lang", d.correction), i.forEach(function(e) {
                var t = e.getAttribute("lang"),
                    r = e.getAttribute("xml:lang"),
                    i = !1;
                if (r && !n(r) && (e.removeAttribute("xml:lang"), r = null, i = !0), t && !n(t) && (e.removeAttribute("lang"), t = null, i = !0), e === document.documentElement && !t) {
                    var a = UserWayWidgetApp.ContextHolder.config;
                    t = a && a.language || "en", e.setAttribute("lang", t), i = !0
                }
                t && r && t !== r && (i = !0, e.setAttribute("xml:lang", t)), e.setAttribute(c, "" + i), i && o++
            }), r.onHelperRemediationCompleted(l.of("REMEDIATION_SITE_LANGUAGE", {
                items: [{
                    count: o,
                    lang: d
                }]
            }, null, o, 0)), e()
        } catch (e) {
            t(e)
        }
    }

    function n(e) {
        return !(!e || e.length > e.trim().length) && (e.indexOf("-") > -1 && (e = e.split("-")[0]), e.indexOf("_") > -1 && (e = e.split("_")[0]), d.includes(e.toLowerCase()))
    }

    function i(e) {
        return e.filter(function(e) {
            if (!e || !e.getAttribute) return !1;
            var t = e.getAttribute("lang");
            return !(!e.getAttribute("xml:lang") && !t && e !== document.documentElement || e.hasAttribute(c))
        })
    }
    var o = UserWayWidgetApp.addLib("REMEDIATION_SITE_LANGUAGE"),
        a = UserWayWidgetApp.getLib("remediationConfig").language || {},
        u = UserWayWidgetApp.getLib("util"),
        l = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        c = "data-uw-rm-lang",
        s = [],
        d = ["aa", "ab", "af", "am", "ar", "as", "ay", "az", "ba", "be", "bg", "bh", "bi", "bn", "bo", "br", "ca", "ceb", "co", "cs", "cy", "da", "de", "div", "dz", "el", "en", "eo", "es", "et", "eu", "fa", "fi", "fj", "fo", "fr", "fy", "ga", "gd", "gl", "gn", "gu", "ha", "haw", "he", "hi", "hr", "hu", "hy", "ia", "id", "ie", "ik", "id", "is", "it", "iw", "ja", "ji", "jw", "ka", "kk", "kl", "km", "kn", "ko", "kok", "ks", "ku", "ky", "kz", "la", "ln", "lo", "ls", "lt", "lv", "mg", "mi", "mk", "ml", "mn", "mo", "mr", "ms", "mt", "my", "na", "nb-no", "ne", "nl", "nn-no", "no", "oc", "om", "or", "pa", "pl", "ps", "pt", "qu", "rm", "rn", "ro", "ru", "rw", "sa", "sb", "sd", "sg", "sh", "si", "sk", "sl", "sm", "sn", "so", "sq", "sr", "sr-Latn", "ss", "st", "su", "sv", "sw", "sx", "syr", "ta", "te", "tg", "th", "ti", "tk", "tl", "tn", "to", "tr", "ts", "tt", "tw", "uk", "ur", "us", "uz", "vi", "vo", "wo", "xh", "yi", "yo", "zh", "zu"];
    o.filter = function(e, r) {
        if (!a.enabled) return [];
        r.reset && t();
        var n = [].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(u.findAllElements(e))
        })), !1));
        return document.documentElement && n.push(document.documentElement), i(n)
    }, o.awaitForResources = function(t, r) {
        return r.reset ? new Promise(function(t, r) {
            e(t, r)
        }) : Promise.resolve()
    }, o.doRemediation = function(e, t, n) {
        return new Promise(function(n, i) {
            r(n, i, e, t)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e() {
        [].slice.call(document.querySelectorAll("[" + i + "]")).forEach(function(e) {
            e.removeAttribute(i)
        })
    }

    function t(e) {
        return e.filter(function(e) {
            return !e.hasAttribute(i)
        })
    }
    var r = UserWayWidgetApp.addLib("REMEDIATION_MARQUEE"),
        n = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        i = "data-uw-rm-mrq";
    r.filter = function(r, n) {
        return n.reset && e(), t([].concat.apply([], __spreadArray([], __read(r.map(function(e) {
            return [].slice.call(e.querySelectorAll("marquee"))
        })), !1)))
    }, r.awaitForResources = function() {
        return Promise.resolve()
    }, r.doRemediation = function(e, t, r) {
        return new Promise(function(r, o) {
            try {
                e.onHelperRemediationStarted("REMEDIATION_MARQUEE"), t.forEach(function(e) {
                    e.setAttribute(i, "")
                }), e.onHelperRemediationCompleted(n.of("REMEDIATION_MARQUEE", null, null, t.length, 0)), r(!0)
            } catch (e) {
                o(e)
            }
        })
    }
}(),
function() {
    function e() {
        document.querySelectorAll("[" + u + "]").forEach(function(e) {
            e.removeAttribute(u)
        })
    }

    function t(e) {
        return e.filter(function(e) {
            return !e.hasAttribute(u)
        })
    }

    function r(e) {
        var t = e.callbackAggregator,
            r = e.resolve,
            n = e.reject,
            o = e.items;
        try {
            t.onHelperRemediationStarted(i), o.forEach(function(e) {
                m(e), e.setAttribute(u, l)
            }), t.onHelperRemediationCompleted(a.of(i, null, null, o.length, 0)), r()
        } catch (e) {
            n(e)
        }
    }
    var n, i = "REMEDIATION_META_VIEWPORT",
        o = UserWayWidgetApp.addLib(i),
        a = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        u = "uw-rm-meta-viewport",
        l = "",
        c = null === (n = UserWayWidgetApp.getLib("remediationConfig")) || void 0 === n ? void 0 : n.metaViewport;
    if (null === c || void 0 === c ? void 0 : c.enabled) {
        o.filter = function(r, n) {
            return n.reset && e(), t(Array.from(document.querySelectorAll('meta[name="viewport"][content*="maximum-scale"], meta[name="viewport"][content*="user-scalable=0"], meta[name="viewport"][content*="user-scalable=no"]')))
        }, o.awaitForResources = function() {
            return Promise.resolve()
        }, o.doRemediation = function(e, t) {
            return new Promise(function(n, i) {
                r({
                    callbackAggregator: e,
                    items: t,
                    resolve: n,
                    reject: i
                })
            })
        };
        var s = function(e) {
                var t = e.match(/maximum-scale=([.0-9]+)/);
                if (t) {
                    if (parseFloat(t[1]) < 5) return e.replace(t[0], "maximum-scale=5.0")
                }
                return e
            },
            d = function(e) {
                var t = e.match(/user-scalable=(0|no)/);
                return t ? e.replace(t[0], "") : e
            },
            f = function(e) {
                return e.replace(/\s/g, "").replace(/,+|;+/g, ", ").replace(/\s+$/g, "").replace(/^(,\s*)/, "").replace(/(,\s*)$/, "")
            },
            p = function(e) {
                return f(d(s(e)))
            },
            m = function(e) {
                var t = e.getAttribute("content"),
                    r = p(t);
                e.setAttribute("content", r)
            }
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e() {
        [].slice.call(document.querySelectorAll("[" + i + "]")).forEach(function(e) {
            e.removeAttribute(i)
        })
    }

    function t(e, t, n, i, a) {
        function u(e, t) {
            return ("label" === (null === t || void 0 === t ? void 0 : t.nodeName) ? [t] : []).concat(e === t ? u(t.parentElement) : [])
        }
        try {
            var l = [],
                c = document.body;
            i.forEach(function(e) {
                if (e && "function" == typeof e.hasAttribute) {
                    var t = e.hasAttribute("id") && e.getAttribute("id"),
                        r = e.hasAttribute("aria-labelledby") && e.getAttribute("aria-labelledby"),
                        n = t ? [].slice.call(c.querySelectorAll('label[for="' + t + '"]')) : [],
                        i = r ? [].slice.call(c.querySelectorAll('label[id="' + r + '"]')) : [],
                        o = u(c, e);
                    if (!(n.length + i.length + o.length <= 1)) {
                        if (n.length <= 1 && i.length <= 1 && o.length <= 1) {
                            var a = [n, i, o].filter(function(e) {
                                return e
                            });
                            if (2 === a.length && a[0] === a[1] || 3 === a.length && a[0] === a[1] === a[2]) return
                        }
                        var s = {
                            el: e
                        };
                        n.length && (s.forId = t, s.labelsForId = n), i.length && (s.labelledBy = r, s.labelsLabelledBy = i), o.length && (s.perentLabels = o), l.push(s)
                    }
                }
            }), l.forEach(function(e) {
                if (!e.forId && !e.labelledBy || e.perentLabels.length, !e.forId && !e.perentLabels) {
                    var t = [].slice.call(document.querySelectorAll(o)).filter(function(t) {
                        return t.hasAttribute("aria-labelledby") && t.getAttribute("aria-labelledby") === e.labelledBy
                    }).forEach(function(t, n) {
                        var i = r();
                        t.setAttribute("aria-labelledby", i), e.labelsLabelledBy[n] && e.labelsLabelledBy[n].setAttribute("id", i)
                    });
                    e.labelsLabelledBy.slice(t.length).forEach(function(e) {
                        return e.removeAttribute("id")
                    })
                }
                if (!e.labelledBy && !e.perentLabels) {
                    var t = [].slice.call(document.querySelectorAll(o)).filter(function(t) {
                        return t.hasAttribute("id") && t.getAttribute("id") === e.forId
                    }).slice(1).forEach(function(t, n) {
                        var i = r();
                        t.setAttribute("aria-labelledby", i), e.labelsForId[n] && e.labelsForId[n].removeAttribute("for") || e.labelsForId[n].setAttribute("id", i)
                    });
                    e.labelsForId.slice(t.length).forEach(function(e) {
                        return e.removeAttribute("for")
                    })
                }
            }), t()
        } catch (e) {
            n(e)
        }
    }

    function r() {
        return ("userway_id_" + Math.random()).slice(2)
    }
    var n = UserWayWidgetApp.addLib("REMEDIATION_MULTIPLE_FORM_LABEL"),
        i = "uw-rm-mform",
        o = "input:not([type=image]):not([type=submit]):not([type=reset]):not([type=button]):not([type=hidden]), select, textarea";
    n.filter = function(t, r) {
        return r.reset && e(), [].concat.apply([], __spreadArray([], __read(t.map(function(e) {
            return [].slice.call(e.querySelectorAll("input:not([type=image]):not([type=submit]):not([type=reset]):not([type=button]):not([type=hidden]), select, textarea"))
        })), !1))
    }, n.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, n.doRemediation = function(e, r, n) {
        return new Promise(function(i, o) {
            t(e, i, o, r, n)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    function e(e) {
        e.forEach(function(e) {
            g[e.pdf_hash] = e
        })
    }

    function t() {
        [].slice.call(document.querySelectorAll("[" + d + "]")).forEach(function(e) {
            e.removeAttribute(d)
        })
    }

    function r(e) {
        return o(e)
    }

    function n(e, t, r, n) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_PDF_DOCUMENTS");
            var o = [],
                a = [],
                l = [];
            n.forEach(function(e, t) {
                var r = e.href.split("?")[0],
                    n = u.hashString(r),
                    c = i(e.href),
                    s = e.hasAttribute(f);
                if (g[n]) {
                    var h = g[n].rem_url;
                    h && !s && (e.setAttribute(p, e.href), e.href = y + h), l.indexOf(r) < 0 && (a.push(Object.assign({}, g[n], {
                        name: c,
                        pdf_url: r,
                        pdf_link: e.innerText,
                        pdf_isDone: !!h || s
                    })), l.push(r))
                } else {
                    var b = e.hasAttribute(m) && "1" === e.getAttribute(m),
                        v = e.hasAttribute(m) && "0" === e.getAttribute(m);
                    b && !s && o.push({
                        hash: n,
                        url: r
                    }), l.indexOf(r.toLowerCase()) < 0 && (a.push({
                        pdf_url: e.href,
                        pdf_hash: n,
                        pdf_link: e.innerText,
                        name: c,
                        status: s ? "DONE" : null,
                        validityCheckFailed: v,
                        id: "not_created-" + t,
                        pdf_isDone: s
                    }), l.push(r.toLowerCase()))
                }
                e.setAttribute(d, "")
            }), e.onHelperRemediationCompleted(s.of("REMEDIATION_PDF_DOCUMENTS", {
                items: a
            }, {
                items: o,
                path: h,
                props: {
                    page: location.pathname
                }
            }, a.length, a.length)), t()
        } catch (e) {
            r(e)
        }
    }

    function i(e) {
        return e.substring(e.lastIndexOf("/") + 1)
    }

    function o(e) {
        return e.filter(function(e) {
            if (!e || e.nodeType !== Node.ELEMENT_NODE || "A" !== e.nodeName) return !1;
            if (e.hasAttribute(d)) return !1;
            if (e.hasAttribute(p)) return !1;
            var t = e.href ? e.href.split("?")[0] : null,
                r = null === t || void 0 === t ? void 0 : t.match(/\.pdf($|\?)/);
            return !(!t || !r)
        })
    }
    var a = UserWayWidgetApp.addLib("REMEDIATION_PDF_DOCUMENTS"),
        u = UserWayWidgetApp.getLib("util"),
        l = UserWayWidgetApp.getLib("remediationConfig").pdf || {},
        c = UserWayWidgetApp.getLib("remediation_utils"),
        s = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        d = "data-uw-pdf-doc",
        f = "data-uw-pdf-rem",
        p = "data-uw-pdf-doc-original",
        m = "data-uw-pdf-br",
        h = "pdf",
        y = "https://cdn.userway.org/",
        g = {};
    a.filter = function(e, n) {
        return l.enabled ? (n.reset && t(), r([].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(e.querySelectorAll("a[href]"))
        })), !1)))) : []
    }, a.awaitForResources = function(t, r) {
        return new Promise(function(r, n) {
            var i, o;
            if (!l.enabled) return r(!0);
            UserWayWidgetApp.ContextHolder.remediationResources && UserWayWidgetApp.ContextHolder.remediationResources.Pdfs && e(UserWayWidgetApp.ContextHolder.remediationResources.Pdfs);
            var a = [];
            try {
                for (var u = __values(t), s = u.next(); !s.done; s = u.next()) {
                    var d = s.value;
                    !d.hasAttribute(m) && a.indexOf(d) < 0 && a.push(d)
                }
            } catch (e) {
                i = {
                    error: e
                }
            } finally {
                try {
                    s && !s.done && (o = u.return) && o.call(u)
                } finally {
                    if (i) throw i.error
                }
            }
            return a.length ? l.config.quotaExceeded ? (a.forEach(function(e) {
                e.setAttribute(m, "2")
            }), r(!0)) : void c.sendBackEnd("/br-links/v0/pdf-links", null, {
                page: location.pathname,
                fullPage: location.href,
                links: a.map(function(e) {
                    return e.href ? e.href.split("?")[0] : null
                })
            }).then(function(e) {
                var t = e && e.response && JSON.parse(e.response);
                a.forEach(function(e, r) {
                    var n = t.statuses[r];
                    [0, 1, 2].indexOf(n) > -1 && e.setAttribute(m, "" + n)
                }), r(!0)
            }).catch(function(e) {
                return n(e)
            }) : r(!0)
        })
    }, a.doRemediation = function(e, t, r) {
        return new Promise(function(r, i) {
            n(e, r, i, t)
        })
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("REMEDIATION_PER_SITE"),
        t = UserWayWidgetApp.getLib("remediationConfig"),
        r = UserWayWidgetApp.getLib("util");
    e.apply = function() {
        t.perSiteRemediation && t.perSiteRemediation.enabled && t.perSiteRemediation.resources && r.execJs(t.perSiteRemediation.resources).finally(function() {
            r.fireUserWayLifeCycleEvent(r.LIFE_CYCLE_EVENT.REMEDIATION_CSR_LOADED)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    var e = UserWayWidgetApp.addLib("REMEDIATION_POPUP"),
        t = UserWayWidgetApp.getLib("remediation_util"),
        r = UserWayWidgetApp.getLib("event_emitter"),
        n = UserWayWidgetApp.getLib("util");
    e.apply = function() {
        r.on("UW_CER_POPUP_ON", function(e) {
            var r = __read(e, 2),
                i = r[0],
                o = r[1];
            ! function(e, r) {
                setTimeout(function() {
                    var i, o;
                    t.clickOnEnter(r);
                    var a = Array.from(e.querySelectorAll(t.focusableElementsSelector)).filter(function(e) {
                        return r !== e && t.isElementVisible(e, {
                            skipParentCheck: !0
                        }) && !e.hasAttribute("data-uw-rm-ignore")
                    });
                    try {
                        for (var u = __values(a), l = u.next(); !l.done; l = u.next()) {
                            var c = l.value;
                            c.setAttribute("tabindex", "0"), t.clickOnEnter(c)
                        }
                    } catch (e) {
                        i = {
                            error: e
                        }
                    } finally {
                        try {
                            l && !l.done && (o = u.return) && o.call(u)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                    if (a.length ? t.trapFocusBetweenElements(r || a[0], a[a.length - 1], e) : r && (r.addEventListener("keydown", function(e) {
                            t.keys.isTab(e) && e.preventDefault()
                        }), r.focus()), e.addEventListener("keydown", function(e) {
                            t.keys.isEsc(e) && r.click()
                        }), r) {
                        n.customTrim(r.textContent).length < 3 && !r.hasAttribute("aria-label") && !r.hasAttribute("aria-labelledby") && r.setAttribute("aria-label", "Close dialog"), -1 !== ["INPUT", "BUTTON", "A"].indexOf(r.tagName) || r.hasAttribute("role") || (r.setAttribute("role", "button"),
                            r.setAttribute("tabindex", "0"))
                    }
                }, 1e3)
            }(i, o)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    function e(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }

    function t(e) {
        var t = Array.from(e.children),
            r = t.filter(function(e) {
                return "LI" === e.tagName && !e.hasAttribute("role")
            });
        if (r.length) return r;
        var n = t.filter(function(e) {
            return !e.hasAttribute("role") && (["A", "BUTTON"].includes(e.tagName) || e.hasAttribute("tabindex"))
        });
        return n.length ? n : []
    }

    function r() {
        var r, n, i = 0,
            o = Array.from(document.querySelectorAll('*[role="menu"], *[role="menubar"]'));
        try {
            for (var a = __values(o), u = a.next(); !u.done; u = a.next()) {
                var l = u.value;
                ! function(r) {
                    var n, o;
                    if (!r.hasAttribute(y)) {
                        r.setAttribute(y, "");
                        if (!Array.from(r.querySelectorAll('*[role="menuitem"], *[role="menuitemcheckbox"], *[role="menuitemradio"]')).length) {
                            i++;
                            var a = t(r);
                            try {
                                for (var u = (n = void 0, __values(a)), l = u.next(); !l.done; l = u.next()) {
                                    var c = l.value;
                                    c.setAttribute("role", "menuitem"), c.setAttribute(y, "menuitem")
                                }
                            } catch (e) {
                                n = {
                                    error: e
                                }
                            } finally {
                                try {
                                    l && !l.done && (o = u.return) && o.call(u)
                                } finally {
                                    if (n) throw n.error
                                }
                            }
                            if (!a.length && !e(r)) {
                                var s = r.getAttribute("role");
                                r.setAttribute(y + "-role", s), r.removeAttribute("role"), m.onElementVisible(r, function() {
                                    if (r.hasAttribute(y + "-role")) {
                                        var e = r.getAttribute(y + "-role");
                                        r.removeAttribute(y + "-role"), r.setAttribute("role", e)
                                    }
                                })
                            }
                        }
                    }
                }(l)
            }
        } catch (e) {
            r = {
                error: e
            }
        } finally {
            try {
                u && !u.done && (n = a.return) && n.call(a)
            } finally {
                if (r) throw r.error
            }
        }
        return i
    }

    function n() {
        i("aria-labelledby"), i("aria-describedby")
    }

    function i(e) {
        Array.from(document.querySelectorAll("*[" + y + "-" + e + "]")).forEach(function(t) {
            var r = t.getAttribute(y + "-" + e).split(" "),
                n = [],
                i = [];
            r.forEach(function(e) {
                document.getElementById(e) ? n.push(e) : i.push(e)
            }), n.length && t.setAttribute(e, n.join(" ")), i.length ? i.length !== r.length && t.setAttribute(y + "-" + e, i.join(" ")) : t.removeAttribute(y + "-" + e)
        })
    }

    function o() {
        var e = 0;
        return e += a("aria-labelledby"), e += a("aria-describedby")
    }

    function a(e) {
        var t = 0;
        return Array.from(document.querySelectorAll("*[" + e + "]")).forEach(function(r) {
            if (!r.hasAttribute(y)) {
                var n = r.getAttribute(e).split(" "),
                    i = [],
                    o = [];
                n.forEach(function(e) {
                    document.getElementById(e) ? i.push(e) : o.push(e)
                }), o.length && (r.setAttribute(y + "-" + e, o.join(" ")), i.length ? r.setAttribute(e, i.join(" ")) : r.removeAttribute(e)), t += o.length
            }
        }), t
    }

    function u(e) {
        var t = e.tagName.toLowerCase();
        if ("s" === t || "strike" === t || "del" === t) return !0;
        var r = window.getComputedStyle(e);
        if (!!r.getPropertyValue("text-decoration") && r.getPropertyValue("text-decoration").indexOf("line-through") > -1) return !0;
        var n = e.parentElement;
        return !(!n || "BODY" === n.tagName.toUpperCase()) && u(n)
    }

    function l() {
        var e, t, r = 0,
            n = h.ElementsWithText.getElementsWithText(document, !1);
        try {
            for (var i = __values(n), o = i.next(); !o.done; o = i.next()) {
                var a = o.value;
                if (!a.hasAttribute(y)) {
                    var l = m.customTrim(a.innerText),
                        c = l.match(/(?:[\$\xA2-\xA5\u058F\u060B\u09F2\u09F3\u09FB\u0AF1\u0BF9\u0E3F\u17DB\u20A0-\u20BD\uA838\uFDFC\uFE69\uFF04\uFFE0\uFFE1\uFFE5\uFFE6])(?:[^0-9.]*)([\d,.]+)/);
                    l && c && c.length && (a.setAttribute(y, ""), u(a) && (a.setAttribute("aria-label", "Previous price was " + c[0]), a.setAttribute(y, "price"), r++))
                }
            }
        } catch (t) {
            e = {
                error: t
            }
        } finally {
            try {
                o && !o.done && (t = i.return) && t.call(i)
            } finally {
                if (e) throw e.error
            }
        }
        return r
    }

    function c() {
        [].slice.call(document.querySelectorAll("[" + y + "]")).forEach(function(e) {
            e.removeAttribute(y)
        })
    }

    function s(e) {
        for (var t = e, r = !1; t && "BODY" !== t.tagName.toUpperCase();) {
            if (t.hasAttribute("contenteditable")) {
                r = !0;
                break
            }
            t = t.parentElement
        }
        return r
    }

    function d(e) {
        return e.filter(function(e) {
            return !e.hasAttribute("role") && (!s(e) && !e.hasAttribute(y))
        })
    }
    var f = UserWayWidgetApp.addLib("REMEDIATION_SCREEN_READER_BASIC"),
        p = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        m = UserWayWidgetApp.getLib("util"),
        h = UserWayWidgetApp.getLib("helpers"),
        y = "data-uw-rm-sr";
    f.filter = function(e, t) {
        return t.reset && c(), d([].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(e.querySelectorAll("br,hr"))
        })), !1)))
    }, f.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, f.doRemediation = function(e, t, i) {
        return new Promise(function(i, a) {
            try {
                e.onHelperRemediationStarted("REMEDIATION_SCREEN_READER_BASIC"), t.forEach(function(e) {
                    e.setAttribute("role", "presentation"), e.setAttribute(y, "")
                });
                var u = l();
                n();
                var c = o(),
                    s = r();
                e.onHelperRemediationCompleted(p.of("REMEDIATION_SCREEN_READER_BASIC", null, null, t.length + u + c + s, 0)), i(!0)
            } catch (e) {
                a(e)
            }
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
    if (r) return r.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && n >= e.length && (e = void 0), {
                value: e && e[n++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        return !!["A", "INPUT", "BUTTON", "SELECT", "TEXTAREA"].includes(e.tagName) || !!e.hasAttribute("tabindex")
    }

    function t(e) {
        var t = e.getAttribute("aria-label") || e.textContent;
        return t && t.trim() ? t.trim().toLowerCase() : null
    }

    function r() {
        var r, n, i = document.querySelector("main"),
            o = document.querySelector('[role="main"]'),
            a = document.querySelector("h1"),
            u = [].slice.call(document.querySelectorAll("h2, h3, h4, h5, h6")),
            l = u.length ? u[0] : null,
            c = i || o || a || l;
        if (!c) return !0;
        var s = [].slice.call(document.querySelectorAll("body *")),
            d = 0;
        try {
            for (var f = __values(s), p = f.next(); !p.done; p = f.next()) {
                var m = p.value;
                if (m === c) break;
                if (!m.id || "userwayAccessibilityIcon" !== m.id) {
                    if (e(m) && ++d < 3) {
                        var h = t(m);
                        if (h && "uw-skip-to-main" !== m.id && (h.toLowerCase().indexOf("skip") > -1 || h.toLowerCase().indexOf("pass") > -1 || h.toLowerCase().indexOf("jump") > -1)) return !0
                    }
                    if (d > 5) break
                }
            }
        } catch (e) {
            r = {
                error: e
            }
        } finally {
            try {
                p && !p.done && (n = f.return) && n.call(f)
            } finally {
                if (r) throw r.error
            }
        }
        return d > 0 && d <= 5
    }

    function n(e, t, n, i) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_SKIP_NAVIGATION_LINK");
            var o = location.pathname,
                c = 0; - 1 !== a.indexOf(o) || r() || (a.push(o), document.body.setAttribute(l, ""), c = 1), e.onHelperRemediationCompleted(u.of("REMEDIATION_SKIP_NAVIGATION_LINK", null, null, c, 0)), t()
        } catch (e) {
            n(e)
        }
    }
    var i = UserWayWidgetApp.addLib("REMEDIATION_SKIP_NAVIGATION_LINK"),
        o = UserWayWidgetApp.getLib("remediationConfig").skipLinks,
        a = [],
        u = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        l = "data-uw-rm-skl";
    i.filter = function(e) {
        return []
    }, i.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, i.doRemediation = function(e, t, r) {
        return new Promise(function(r, i) {
            n(e, r, i, t)
        })
    }, i.getSkipLinksConfig = function() {
        var e, t;
        return {
            enabled: null === o || void 0 === o ? void 0 : o.enabled,
            selector: null !== (t = null === (e = null === o || void 0 === o ? void 0 : o.config) || void 0 === e ? void 0 : e.anchorSelector) && void 0 !== t ? t : null
        }
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e, t) {
        var r = c.config.resources + UserWayWidgetApp.ContextHolder.config.services.siteId + "/" + d.hashString(p);
        d.request({
            method: "GET",
            url: r
        }).then(function(t) {
            if (t && t.response && 404 !== JSON.parse(t.response).code) {
                var r = JSON.parse(t.response);
                h = r.Dictionary, g = r.ContentModeration
            }
            e()
        }, function(e) {
            t(e)
        })
    }

    function t() {
        h = {}, g = [], [].slice.call(document.querySelectorAll("[" + m + "]")).forEach(function(e) {
            e.removeAttribute(m)
        })
    }

    function r(e) {
        return new RegExp("([^A-Za-z0-9_-]|^)" + e.replace(/(\s)/g, "\\s+") + "([^A-Za-z0-9_-]|$)", "gi")
    }

    function n(e) {
        for (var t = Object.keys(h).length; t--;) {
            var r = Object.keys(h)[t],
                n = h[r],
                i = n.t;
            if (e.trim().toLowerCase() === i.trim().toLowerCase()) return r
        }
        throw "Unexpected term: " + e
    }

    function i(e, t, r) {
        for (var n = g.length; n--;) {
            var i = g[n];
            if (i.phraseId + "" === e && i.type === t && i.xpath === r && !i.ignored) return i.correction
        }
        return null
    }

    function o(e, t, r) {
        for (var n = g.length; n--;) {
            var i = g[n];
            if (i.phraseId + "" === e && i.type === t && i.xpath === r && i.ignored) return !0
        }
        return !1
    }

    function a(e, t, a, l, c) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_SOCIAL_SENSITIVITY"), l = l.filter(function(e) {
                var t = e.parentNode;
                return t && "function" != typeof t.hasAttribute || !t.hasAttribute(m)
            });
            var f = 0,
                p = [],
                g = Object.keys(h).map(function(e) {
                    return h[e].t
                });
            l.forEach(function(e) {
                var t = " " + d.customTrim(e.textContent) + " ",
                    a = "INNER_TEXT",
                    l = [];
                if (g.forEach(function(e) {
                        var n = t.match(r(e));
                        n && l.push.apply(l, __spreadArray([], __read(new Array(n.length).fill(e)), !1))
                    }), l && l.length) {
                    f += l.length;
                    for (var c = d.xpath(e.parentElement), s = 0; s < l.length; s++) {
                        for (var h = l[s], b = 0, v = 0; v < s; v++) {
                            l[v].toLowerCase() === h.toLowerCase() && b++
                        }
                        var A = d.hashString(c + h + b) + "",
                            _ = n(h),
                            E = o(_, a, A),
                            w = i(_, a, A),
                            x = !!w || E;
                        x && y++, w && !E && u(e, h, w), e.parentElement.setAttribute(m, ""), p.push({
                            xpath: c,
                            xpathHash: A,
                            type: a,
                            term: h,
                            approved: x,
                            ignored: E,
                            phraseId: _,
                            correction: x ? w : null
                        })
                    }
                }
            }), e.onHelperRemediationCompleted(s.of("REMEDIATION_SOCIAL_SENSITIVITY", {
                items: p
            }, null, f, p.filter(function(e) {
                return !e.correction
            }).length)), t()
        } catch (e) {
            a(e)
        }
    }

    function u(e, t, r) {
        var n = new RegExp(t, "gi"),
            i = e.textContent;
        e.textContent = i.replace(n, r)
    }
    var l = UserWayWidgetApp.addLib("REMEDIATION_SOCIAL_SENSITIVITY"),
        c = UserWayWidgetApp.getLib("remediationConfig").moderator,
        s = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        d = UserWayWidgetApp.getLib("util"),
        f = UserWayWidgetApp.getLib("helpers"),
        p = location.pathname,
        m = "data-uw-rm-mod",
        h = {},
        y = 0,
        g = [];
    l.filter = function(e, r) {
        return c.enabled ? (r.reset && t(), f.ElementsWithText.getTextNodes(document, !1)) : []
    }, l.awaitForResources = function(t, r) {
        return c.enabled && c.config.resources && t.length && r.reset ? new Promise(function(t, r) {
            e(t, r)
        }) : Promise.resolve()
    }, l.doRemediation = function(e, t, r) {
        return new Promise(function(n, i) {
            a(e, n, i, t, r)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
    if (r) return r.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && n >= e.length && (e = void 0), {
                value: e && e[n++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var t = e.checked,
            r = e.readOnly,
            n = e.required,
            i = e.disabled,
            o = e.hidden,
            a = e.getAttribute("aria-checked"),
            u = e.getAttribute("aria-readonly"),
            l = e.getAttribute("aria-required"),
            c = e.getAttribute("aria-disabled"),
            s = e.getAttribute("aria-hidden");
        t && "true" !== a && (e.ariaChecked = !0), t || "false" === a || (e.ariaChecked = !1), r && "true" !== u && (e.ariaReadOnly = !0), r || "false" === u || (e.ariaReadOnly = !1), n && "true" !== l && (e.ariaRequired = !0), n || "false" === l || (e.ariaRequired = !1), i && "true" !== c && (e.ariaDisabled = !0), i || "false" === c || (e.ariaDisabled = !1), o && "true" !== s && (e.ariaHidden = !0), o || "false" === s || (e.ariaHidden = !1)
    }

    function t(t) {
        var r = function(r) {
                var n, i;
                try {
                    for (var o = __values(r), a = o.next(); !a.done; a = o.next()) {
                        "attributes" === a.value.type && e(t)
                    }
                } catch (e) {
                    n = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (i = o.return) && i.call(o)
                    } finally {
                        if (n) throw n.error
                    }
                }
            },
            n = new MutationObserver(r),
            i = {
                attributes: !0,
                childList: !1,
                subtree: !1
            };
        n.observe(t, i)
    }
    var r = UserWayWidgetApp.addLib("REMEDIATION_ANGULAR_JS_ARIA");
    r.filter = function(e, t) {
        return []
    }, r.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, r.doRemediation = function(r, n, i) {
        var o = document.querySelectorAll("[ng-show], [ng-hide], [ng-value], [ng-checked], [ng-readonly], [ng-required], [ng-model], [ng-disabled]");
        return new Promise(function(r) {
            var n, i;
            try {
                for (var a = __values(Array.from(o)), u = a.next(); !u.done; u = a.next()) {
                    var l = u.value;
                    e(l), t(l)
                }
            } catch (e) {
                n = {
                    error: e
                }
            } finally {
                try {
                    u && !u.done && (i = a.return) && i.call(a)
                } finally {
                    if (n) throw n.error
                }
            }
            r(!0)
        })
    }
}();
var __assign = this && this.__assign || function() {
        return __assign = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) {
                t = arguments[r];
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }
            return e
        }, __assign.apply(this, arguments)
    },
    __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e, t) {
        return (e + "$" + t).toLowerCase()
    }

    function t(t) {
        t.forEach(function(t) {
            m[e(t.href, t.term)] = t
        })
    }

    function r(e, r) {
        if (UserWayWidgetApp.ContextHolder.remediationResources) return t(UserWayWidgetApp.ContextHolder.remediationResources.VagueLinks), e();
        c.enabled ? e() : r()
    }

    function n(e) {
        return e.filter(function(e) {
            if (!e || e.nodeType !== Node.ELEMENT_NODE || "A" !== e.nodeName) return !1;
            var t = e.href;
            if (!t || !/(^http|^tel:|^mailto:)/.test(t)) return !1;
            var r = e.hasAttribute("aria-label") ? e.getAttribute("aria-label") : null;
            if (r && r.trim()) return !1;
            var n = e.hasAttribute("aria-labelledby") ? e.getAttribute("aria-labelledby") : null;
            return (!n || !n.trim()) && !e.hasAttribute(p)
        })
    }

    function i(t, r, n, i) {
        try {
            t.onHelperRemediationStarted("REMEDIATION_VAGUE_LINK");
            var u = [];
            i.forEach(function(t) {
                var r, n = o(t);
                if (n) {
                    if (/^tel:|^mailto:/.test(t.getAttribute("href"))) r = n;
                    else if (-1 === ["here", "click here", "download", "download now", "click", "click this", "this", "link", "more", "read more", "please click here", "continue reading", "learn more →", "learn more", "more details"].indexOf(n)) return;
                    var i = e(t.href, n),
                        l = !1,
                        c = {};
                    m[i] ? (r = m[i].correction, l = m[i].approved, c = Object.assign(m[i], {
                        id: i
                    }), u.push(c), h[i] = __assign(__assign({}, c), {
                        el: t
                    })) : r || (r = a(t), c = {
                        href: t.href,
                        term: n,
                        correction: r,
                        approved: l,
                        id: i
                    }, u.push(c), h[i] = __assign(__assign({}, c), {
                        el: t
                    })), (l || s) && t.setAttribute("aria-label", r), t.setAttribute("uw-rm-vague-link-id", i), t.setAttribute(p, "")
                }
            }), t.onHelperRemediationCompleted(f.of("REMEDIATION_VAGUE_LINK", {
                items: u
            }, null, u.length, u.filter(function(e) {
                return !e.approved
            }).length)), r()
        } catch (e) {
            n(e)
        }
    }

    function o(e) {
        var t = e.textContent ? e.textContent : null,
            r = /tel:(.+)/,
            n = /mailto:(.+)/,
            i = e.hasAttribute("href") ? e.getAttribute("href") : null;
        return r.test(i) ? i.replace(r, "call $1") : n.test(i) ? i.replace(n, "send an email to $1") : t && t.trim() ? d.customTrim(t).replace(/[^A-Za-z0-9\s]/g, "").replace(/\s{2,}/g, " ").toLowerCase() : null
    }

    function a(e) {
        function t(e) {
            if (!e) return null;
            if (-1 !== ["h1", "h2", "h3", "h4", "h5", "h6"].indexOf(e.nodeName.toLowerCase())) return e.textContent;
            var t = [].slice.call(e.querySelectorAll("h1,h2,h3,h4,h5,h6"));
            return t.length ? t[0].textContent : null
        }
        for (var r = e.parentElement, n = e; d.customTrim(d.customTextContent(r)) === d.customTrim(e.textContent);) n = r, r = r.parentElement;
        for (var i = n.previousElementSibling, o = t(i); i && i.parentElement === r && !o;) i = i.previousElementSibling, o = i ? t(i) : null;
        if (o) return [e.textContent, o].join(" ");
        var a = function(e, t) {
                for (var r, n = [], i = d.instantiateTreeWalker(e); r = i.nextNode();) n.push({
                    node: r,
                    target: r.parentElement === t
                });
                return n
            }(r, e).map(function(e) {
                return {
                    text: d.customTrim(e.node.textContent),
                    target: e.target
                }
            }).filter(function(e) {
                return !!e.text
            }),
            u = "",
            l = "",
            c = "",
            s = a.find(function(e) {
                return e.target
            }),
            f = a.indexOf(s);
        l = s ? s.text : "";
        var p = [];
        if (f && a[f - 1] && (p = a[f - 1].text.split(/[.!?]+/), u = p.pop(), u = u ? u.trim() : ""), f + 1 < a.length) {
            c = a[f + 1].text.split(/[.!?]+/).shift(), c = c ? c.trim() : ""
        }
        return u || c || (u = p.length ? p.pop() : ""), [u, l, c].filter(function(e) {
            return !!e
        }).join(" ")
    }
    var u = UserWayWidgetApp.addLib("REMEDIATION_VAGUE_LINK"),
        l = UserWayWidgetApp.getLib("remediationConfig"),
        c = l.vagueLinks || {},
        s = !l.strategy || "AUTO" === l.strategy,
        d = UserWayWidgetApp.getLib("util"),
        f = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        p = "data-uw-rm-vglnk",
        m = {},
        h = {};
    u.filter = function(e, t) {
        if (t.reset) {
            [].slice.call(document.querySelectorAll("[" + p + "]")).forEach(function(e) {
                e.removeAttribute(p)
            })
        }
        return n([].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(e.querySelectorAll("a[href]"))
        })), !1)))
    }, u.awaitForResources = function(e, t) {
        return t.reset ? new Promise(function(e, t) {
            r(e, t)
        }) : Promise.resolve()
    }, u.doRemediation = function(e, t, r) {
        return new Promise(function(r, n) {
            i(e, r, n, t)
        })
    }, u.updateElement = function(e) {
        var t = h[e.id];
        t && t.el && "function" == typeof t.el.setAttribute && t.el.setAttribute("aria-label", e.correction)
    }
}();
var __assign = this && this.__assign || function() {
        return __assign = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) {
                t = arguments[r];
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }
            return e
        }, __assign.apply(this, arguments)
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    var e = UserWayWidgetApp.addLib("remediation_util"),
        t = UserWayWidgetApp.getLib("util");
    e.focusableElementsSelector = "\n    a[href]:not([tabindex='-1']), \n    area[href]:not([tabindex='-1']), \n    audio[controls]:not([tabindex='-1']), \n    button:not([disabled], [tabindex='-1']), \n    details:not([tabindex='-1']) summary:not([tabindex='-1']), \n    input:not([disabled], [type=hidden], [tabindex='-1']), \n    iframe:not([tabindex='-1']), \n    select:not([disabled], [tabindex='-1']), \n    textarea:not([disabled], [tabindex='-1']), \n    video[controls]:not([tabindex='-1']), \n    [tabindex]:not([disabled], [tabindex='-1']), \n    [contenteditable='']:not([disabled], [tabindex='-1']),\n    [contenteditable='true']:not([disabled], [tabindex='-1'])\n  ", e.keys = {
        isRightShift: function(e) {
            return 16 === e.keyCode || "Shift" === e.key || "ShiftRight" === e.code
        },
        isLeftShift: function(e) {
            return 16 === e.keyCode || "Shift" === e.key || "ShiftLeft" === e.code
        },
        isSpace: function(e) {
            return 32 === e.keyCode || " " === e.key || "Space" === e.code
        },
        isEnter: function(e) {
            return 13 === e.keyCode || "Enter" === e.key || "Enter" === e.code
        },
        isEsc: function(e) {
            return 27 === e.keyCode || "Escape" === e.key || "Escape" === e.code
        },
        isTab: function(e) {
            return 9 === e.keyCode || "Tab" === e.key || "Tab" === e.code
        },
        isHome: function(e) {
            return 36 === e.keyCode || "Home" === e.key || "Home" === e.code
        },
        isEnd: function(e) {
            return 35 === e.keyCode || "End" === e.key || "End" === e.code
        },
        isPageUp: function(e) {
            return 33 === e.keyCode || "PageUp" === e.key || "PageUp" === e.code
        },
        isPageDown: function(e) {
            return 34 === e.keyCode || "PageDown" === e.key || "PageDown" === e.code
        },
        isArrowLeft: function(e) {
            return 37 === e.keyCode || "ArrowLeft" === e.key || "ArrowLeft" === e.code
        },
        isArrowUp: function(e) {
            return 38 === e.keyCode || "ArrowUp" === e.key || "ArrowUp" === e.code
        },
        isArrowRight: function(e) {
            return 39 === e.keyCode || "ArrowRight" === e.key || "ArrowRight" === e.code
        },
        isArrowDown: function(e) {
            return 40 === e.keyCode || "ArrowDown" === e.key || "ArrowDown" === e.code
        },
        isPrintableChar: function(e) {
            return 1 === e.key.length && e.key.match(/\S/)
        }
    }, e.log = function(e, t, r) {
        console.warn("UserWay remediation " + e + " - " + t + ": " + r)
    }, e.generateRandomId = t.generateRandomId, e.isElementEditable = function(e) {
        function t(e) {
            var t = e.nodeName.toLowerCase();
            return !!e.hasAttribute("contenteditable") || 1 === e.nodeType && ("textarea" === t || "input" === t && /^(?:text|email|number|search|tel|url|password)$/i.test(e.type))
        }
        var r, n, i = t(e);
        if (i) return !0;
        try {
            for (var o = __values(Array.from(e.querySelectorAll("*"))), a = o.next(); !a.done; a = o.next()) {
                if (i = t(a.value)) break
            }
        } catch (e) {
            r = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (n = o.return) && n.call(o)
            } finally {
                if (r) throw r.error
            }
        }
        return i
    }, e.waitUntil = function(e, t, r, n) {
        void 0 === r && (r = null), void 0 === n && (n = null), r = __assign({
            timeout: 8e3,
            frequency: 1e3
        }, r || {});
        var i = Date.now();
        ! function o() {
            var a = e();
            if (a) return t(a);
            setTimeout(function() {
                if (r.timeout && Date.now() - i > r.timeout) return void(n && n());
                o()
            }, r.frequency)
        }()
    }, e.trapFocusBetweenElements = function(t, r, n) {
        void 0 === n && (n = null);
        var i = !1;
        window.addEventListener("keydown", function(t) {
            e.keys.isLeftShift(t) && (i = !0)
        }), window.addEventListener("keyup", function(t) {
            e.keys.isLeftShift(t) && (i = !1)
        }), t.setAttribute("tabindex", "0"), document.activeElement && n.contains(document.activeElement) || t.focus(), t.addEventListener("keydown", function(t) {
            e.keys.isTab(t) && i && (t.preventDefault(), r.focus())
        }), r.setAttribute("tabindex", "0"), r.addEventListener("keydown", function(r) {
            e.keys.isTab(r) && (i || (r.preventDefault(), t.focus()))
        })
    }, e.trapFocusBetween = function(e) {
        function t(e, t, n) {
            if (9 === n.keyCode) return r ? t && t.focus() : e && e.focus(), n.preventDefault();
            16 === n.keyCode && (r = !0)
        }
        for (var r = !1, n = [], i = 0; i < e.length; i++) {
            var o = document.querySelector(e[i]);
            if (o) {
                o.setAttribute("tabindex", 0);
                var a = document.querySelector(e[i + 1]) || document.querySelector(e[0]),
                    u = document.querySelector(e[i - 1]) || document.querySelector(e[e.length - 1]),
                    l = t.bind(event, a, u);
                n.push(l), o.addEventListener("keydown", l, !1), o.addEventListener("keyup", function(e) {
                    16 === e.keyCode && (r = !1)
                })
            }
        }
        return setTimeout(function() {
            var t = document.querySelector(e[0]);
            t && t.focus()
        }, 100), {
            terminate: function() {
                for (var t = 0; t < e.length; t++) {
                    document.querySelector(e[t]).removeEventListener("keydown", n[t])
                }
            }
        }
    }, e.waitForDocumentReady = function(e) {
        var t = setInterval(function() {
            "complete" === document.readyState && (clearInterval(t), e())
        }, 10)
    }, e.injectStylesheet = function(e) {
        var t = document.createElement("style");
        return t.innerHTML = e, document.head.appendChild(t), t
    }, e.setSrOnly = function(e) {
        if (e.style) {
            var t = {
                overflow: "hidden",
                position: "absolute",
                margin: "0",
                padding: "0",
                width: "1px",
                height: "1px",
                border: "0",
                clip: "rect(1px, 1px, 1px, 1px)",
                "-webkit-clip-path": "inset(50%)",
                "clip-path": "inset(50%)",
                "white-space": "nowrap"
            };
            for (var r in t) e.style.setProperty(r, t[r], "important")
        }
    }, e.createSrOnlyElement = function(t, r) {
        void 0 === t && (t = ""), void 0 === r && (r = "span");
        var n = document.createElement(r);
        return n.textContent = t, e.setSrOnly(n), n
    }, e.isElementVisible = function(e, t) {
        t = t || {}, t.hasOwnProperty("skipParentCheck") || (t.skipParentCheck = !1), t.hasOwnProperty("shouldBeInViewport") || (t.shouldBeInViewport = !0);
        var r = function(e, t) {
                if (!e) return !1;
                if (e === document) return !0;
                var r = getComputedStyle(e),
                    n = e.getBoundingClientRect(),
                    i = n.top >= 0 && n.left >= 0 && n.bottom <= (window.innerHeight || document.documentElement.clientHeight) && n.right <= (window.innerWidth || document.documentElement.clientWidth),
                    o = 0 === n.width || 0 === n.height;
                return (e.offsetWidth > 0 || e.offsetHeight > 0 || e.getClientRects().length > 0) && (!t.shouldBeInViewport || i) && !o && "0" !== r.opacity && "hidden" !== r.visibility && "collapse" !== r.visibility
            },
            n = r(e, t);
        if (!t.skipParentCheck)
            for (; n && e.parentNode && e.parentNode !== document;) r(e.parentNode, {
                shouldBeInViewport: !1
            }) ? e = e.parentNode : n = !1;
        return n
    }, e.fireEvent = function(e, t) {
        if (e.fireEvent) e.fireEvent("on" + t);
        else {
            var r = document.createEvent("Events");
            r.initEvent(t, !0, !1), e.dispatchEvent(r)
        }
    }, e.clickOnEnter = function(t) {
        t && "function" == typeof t.click && !e.isElementEditable(t) && t.addEventListener("keydown", function(r) {
            e.keys.isEnter(r) && (r.preventDefault(), t.click())
        })
    }, e.clickOnSpace = function(t) {
        t && "function" == typeof t.click && !e.isElementEditable(t) && t.addEventListener("keydown", function(r) {
            e.keys.isSpace(r) && (r.preventDefault(), t.click())
        })
    }, e.execOnPage = function(e, t) {
        var r, n, i;
        if (Array.isArray(e)) try {
            for (var o = __values(e), a = o.next(); !a.done; a = o.next()) {
                var u = a.value;
                if (i = new RegExp(u).test(window.location.href)) {
                    t();
                    break
                }
            }
        } catch (e) {
            r = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (n = o.return) && n.call(o)
            } finally {
                if (r) throw r.error
            }
        } else(i = new RegExp(e).test(window.location.href)) && t();
        return i
    }, e.getFocusableElement = function(t, r, n) {
        t = t || "next", n = n || {}, n.childrenOnly = n.childrenOnly || !1, n.canBeHidden = n.canBeHidden || !1;
        var i = Array.from((n.childrenOnly ? r : document).querySelectorAll(e.focusableElementsSelector + (r ? "," + e.getCssPath(r) : "")));
        n.canBeHidden || (i = i.filter(function(e) {
            return !!e.offsetParent
        }));
        var o = i.findIndex(function(e) {
            return !(!r || e !== r) || e === document.activeElement
        });
        return "next" === t ? i[o + 1] || i[0] : "prev" === t ? i[o - 1] || i[i.length - 1] : void 0
    }, e.getCssPath = function(e) {
        for (var t = []; e.parentNode;) {
            if (e.id) {
                t.unshift("#" + e.id);
                break
            }
            if (e == e.ownerDocument.documentElement) t.unshift(e.tagName);
            else {
                for (var r = 1, n = e; n.previousElementSibling; n = n.previousElementSibling, r++);
                t.unshift(e.tagName + ":nth-child(" + r + ")")
            }
            e = e.parentNode
        }
        return t.join(" > ")
    }, e.getElementPosition = function(e) {
        for (var t = 0, r = 0; e;) {
            if ("BODY" == e.tagName) {
                var n = e.scrollLeft || document.documentElement.scrollLeft,
                    i = e.scrollTop || document.documentElement.scrollTop;
                t += e.offsetLeft - n + e.clientLeft, r += e.offsetTop - i + e.clientTop
            } else t += e.offsetLeft - e.scrollLeft + e.clientLeft, r += e.offsetTop - e.scrollTop + e.clientTop;
            e = e.offsetParent
        }
        return {
            x: t,
            y: r
        }
    };
    var r = [];
    e.onHistoryPushState = function(e, t) {
        if (void 0 === t && (t = {}), t = __assign({
                delay: 300
            }, t), r.push(e), 1 === r.length) {
            if (window.history) {
                var n = window.history.pushState;
                window.history.pushState = function(e) {
                    return "function" == typeof window.history.onpushstate && window.history.onpushstate({
                        state: e
                    }), n.apply(window.history, arguments)
                }
            }
            var i;
            window.onpopstate = window.history.onpushstate = function() {
                clearTimeout(i), i = setTimeout(function() {
                    return r.forEach(function(e) {
                        return e()
                    })
                }, t.delay)
            }
        }
    }, e.announce = function(e) {
        var t = document.createElement("div");
        t.setAttribute("aria-live", "assertive"), t.style.width = "0", t.style.height = "0", t.style.overflow = "hidden", document.body.insertAdjacentElement("afterbegin", t), setTimeout(function() {
            t.innerHTML = e
        }, 1e3), setTimeout(function() {
            t.remove()
        }, 1e4)
    }, e.queryXPath = function(e, t) {
        var r;
        void 0 === t && (t = null);
        var n = document.evaluate(e, t || document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return (null === n || void 0 === n ? void 0 : n.singleNodeValue) && (null === (r = null === n || void 0 === n ? void 0 : n.singleNodeValue) || void 0 === r ? void 0 : r.nodeType) === Node.ELEMENT_NODE ? n.singleNodeValue : null
    }, e.queryXPathAll = function(e, t) {
        void 0 === t && (t = null);
        for (var r = document.evaluate(e, t || document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null), n = [], i = 0, o = r.snapshotLength; i < o; ++i) n.push(r.snapshotItem(i));
        return n
    }, e.loopThroughElements = function(t, r, n, i) {
        void 0 === n && (n = null), void 0 === i && (i = null), n = __assign({
            ancestor: document,
            useForEach: !0
        }, n || {}), e.waitUntil(function() {
            if (n.ancestor) {
                var r = [];
                try {
                    r = n.ancestor.querySelectorAll(t)
                } catch (i) {
                    try {
                        r = e.queryXPathAll(t, n.ancestor)
                    } catch (e) {
                        throw new Error(t + " is invalid CSS and XPath selector")
                    }
                }
                return (null === r || void 0 === r ? void 0 : r.length) ? r : void 0
            }
        }, function(e) {
            n.useForEach ? e.forEach(r) : r(e)
        }, n, i)
    }, e.waitForElement = function(t, r, n, i) {
        void 0 === n && (n = null), void 0 === i && (i = null), n = __assign({
            ancestor: document
        }, n || {}), e.waitUntil(function() {
            if (n.ancestor) try {
                return n.ancestor.querySelector(t)
            } catch (r) {
                try {
                    return e.queryXPath(t, n.ancestor)
                } catch (e) {
                    throw new Error(t + " is invalid CSS and XPath selector")
                }
            }
        }, r, n, i)
    }
}(),
function() {
    function e(e, t, n, i) {
        -1 === u.indexOf(e) && (u.push(e), r.execJs(o + t, n).then(function() {
            i && window.postMessage({
                isUserWay: !0,
                action: "remediation",
                type: "add-dynamically",
                remediationHelperName: i
            }, "*")
        }))
    }
    var t = UserWayWidgetApp.addLib("cpr_patterns_observer"),
        r = UserWayWidgetApp.getLib("util"),
        n = UserWayWidgetApp.getLib("remediation_util"),
        i = UserWayWidgetApp.getLib("remediationConfig"),
        o = (i && i.complex && i.complex, "https://cdn.userway.org/"),
        a = "widgetapp/2023-12-20-16-19-19/remediation/nav_menu_helper_1703089159263.js",
        u = [];
    t.apply = function(e) {
        l.filter(function(e) {
            return e.onPageLoad
        }).forEach(function(e) {
            return e.observe()
        })
    }, t.tick = function(e) {
        l.filter(function(e) {
            return e.onDomChanged
        }).forEach(function(e) {
            return e.observe()
        })
    };
    var l = [{
        name: "PayoneerAccountSitesCommon",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/payoneer_account_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this;
            "m8nhTkGuMw" === UserWayWidgetApp.ContextHolder.config.account && function() {
                e(t.name, t.path, "sha256-NJHPNbXQL8/yvJDyo23NXe1W44QtML+W756pkztQpYM=", t.remediationHelperName)
            }()
        }
    }, {
        name: "SimplexAccountSitesCommon",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/simplex_account_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this;
            "DBnq3tIKbX" === UserWayWidgetApp.ContextHolder.config.account && function() {
                e(t.name, t.path, "sha256-7a+7Xg3vciW+Mne1lJuwv2A4CANleNvKOmGD12pHInM=", t.remediationHelperName)
            }()
        }
    }, {
        name: "JQueryUiDatepicker",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/jqueryui_datepicker_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            [].slice.call(document.querySelectorAll(".hasDatepicker")).filter(function(e) {
                return !e.getAttribute("data-uw-rm-cpr-jqdp")
            }).length && jQuery && jQuery.ui && jQuery.ui.datepicker && e(this.name, this.path, "sha256-fzY74JVqYIY5N5yNkPCLVyawerLdVlcB7cdjZRcRfKs=", this.remediationHelperName)
        }
    }, {
        name: "AngularJsAria",
        remediationHelperName: "ANGULAR_JS_ARIA",
        path: "widgetapp/2023-12-20-16-19-19/remediation/uw_aria_helper_1703089159263.ts",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this,
                r = function() {
                    e(t.name, t.path, "sha256-skUcGYwV4ch6x37u65wVQrTZMuCIAUdYJOqbNwN54j0=", t.remediationHelperName)
                };
            n.waitUntil(function() {
                return !!document.querySelector("[ng-app]")
            }, r, {
                timeout: 6e4
            })
        }
    }, {
        name: "slickSlider",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/slick_slider_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".slick-slider") && e(this.name, this.path, "sha256-5uSn3jdgXAqy+UE7rQxryrCvtXRqlCRNUktYFPWbHDM=", this.remediationHelperName)
        }
    }, {
        name: "NavMenu",
        remediationHelperName: "",
        path: "//",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = function() {
                window.jQuery && window.jQuery.ui && window.jQuery.ui.version ? (n.waitUntil(function() {
                    return !!(window.jQuery && window.jQuery.ui && window.jQuery.ui.version && window.jQuery.ui.menu) && !!document.querySelector(".navigation .ui-menu-item")
                }, function() {
                    setTimeout(function() {
                        e("JQueryUiMenu", "widgetapp/2023-12-20-16-19-19/remediation/jqueryui_menu_helper_1703089159263.js", "sha256-vvjYbKhSaii5P+3Ctik4H+LTSHLvHDnybHBFwUSL1uQ=", "")
                    }, 4e3)
                }, {
                    timeout: 1e4
                }), setTimeout(function() {
                    -1 === u.indexOf("JQueryUiMenu") && e("NavMenu", a, "sha256-N/hVBAa+v4AD7HYMTIH76GHj04pbu9Bprp1gNYcQ8Dg=", "")
                }, 14100)) : -1 === u.indexOf("JQueryUiMenu") && e("NavMenu", a, "sha256-N/hVBAa+v4AD7HYMTIH76GHj04pbu9Bprp1gNYcQ8Dg=", "")
            };
            "complete" === document.readyState ? t() : window.addEventListener("load", t, !1)
        }
    }, {
        name: "OwlCarousel",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/owl_carousel_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".owl-carousel") && e(this.name, this.path, "sha256-uURQpSwG3FAwlOtP33/NYxsGef08DBKWfqJwwNcAdU0=", this.remediationHelperName)
        }
    }, {
        name: "yotpoWidget",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/yotpo_widget_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".yotpo") && e(this.name, this.path, "sha256-GIuAq4nuA4gneXSAeZ/QDQug8Z/6Xbz2E9fOLGZV5Eg=", this.remediationHelperName)
        }
    }, {
        name: "judgeMe",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/judgeme_widget_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".jdgm-star") && e(this.name, this.path, "sha256-UbU25H+TzYB73LKY1BZpGepuOcR3Zq40WFZ/6Bf9s3s=", this.remediationHelperName)
        }
    }, {
        name: "cycleSliderHelper",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/cycle_slider_helper_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".cycle-slide") && e(this.name, this.path, "sha256-7d6M1UDXQDlMngKZI+asQoUOXwa4BMyeRqUCiDYsxas=", this.remediationHelperName)
        }
    }, {
        name: "muiElementsRemediation",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/mui_elements_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !0,
        observe: function() {
            ["mat-expansion-panel.mat-expansion-panel", ".mat-option-text", ".mat-option-ripple", ".mat-form-field-label-wrapper", ".mat-expansion-panel-header-title", ".mat-expansion-indicator", ".mat-autocomplete-panel", ".mat-expansion-panel-header"].some(function(e) {
                return document.querySelector(e)
            }) && e(this.name, this.path, "sha256-yXI4CdhFr5OhbD13f+WFeyHuPTtGa1K47eJRnqTztlI=", this.remediationHelperName)
        }
    }, {
        name: "shortPointHelper",
        remediationHelperName: "",
        path: "widgetapp/2023-12-20-16-19-19/remediation/s_p_1703089159263.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            ['[data-shortpoint-type="row"]'].some(function(e) {
                return document.querySelector(e)
            }) && e(this.name, this.path, "sha256-wEsvu9mmG0N5053GtFHN4cn5qmr27+xhS3MMUa3MVBM=", this.remediationHelperName)
        }
    }]
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
    if (r) return r.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && n >= e.length && (e = void 0), {
                value: e && e[n++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var r = e.alt;
        if (r && r.trim()) return r.trim();
        var n = e.getAttribute("aria-label");
        if (n && n.trim()) return n.trim();
        var i = e.getAttribute("aria-describedby");
        if (i) {
            var o = t(i);
            if (o) return o
        }
        var a = e.getAttribute("aria-labelledby");
        if (a) {
            var o = t(a);
            if (o) return o
        }
        return null
    }

    function t(e) {
        var t = e.split(" "),
            r = "";
        return t.forEach(function(e) {
            e = e.trim();
            var t = document.getElementById(e);
            r += t && t.textContent ? t.textContent : ""
        }), r
    }
    var r, n = UserWayWidgetApp.addLib("remediation_utils");
    n.ignoreElementFromHelperProcessingAttr = "data-uw-rm-ignore";
    var i = UserWayWidgetApp.getLib("util"),
        o = UserWayWidgetApp.getLib("inlineStyling"),
        a = UserWayWidgetApp.getLib("xpath_search");
    n.PROCESS_ATTRIBUTES = {
        CER: {
            popup: {
                wrapper: "data-uw-cer-popup-wrapper",
                close: "data-uw-cer-popup-close"
            },
            hamburger: {
                button: "data-uw-cer-hamburger-btn"
            }
        }
    };
    var u = {
        attrMarker: "uw-remediation",
        className: "uw-remediation-highlighting",
        styles: (r = {
            border: "dashed 2px #c00"
        }, r["border-radius"] = "3px", r["box-shadow"] = "0 0 0 4px yellow, inset 0 0 0 4px yellow", r)
    };
    n.sendBackEnd = function(e, t, r) {
        var n = {
            method: "POST",
            url: "https://api.userway.org/api" + e,
            header: {
                "Content-Type": "application/json"
            },
            body: {
                userId: UserWayWidgetApp.ContextHolder.config.services.userId,
                siteId: UserWayWidgetApp.ContextHolder.config.services.siteId
            }
        };
        return t && (n.body.elements = t), "object" == typeof r && Object.keys(r).map(function(e) {
            n.body[e] = r[e]
        }), i.request(n)
    }, n.highlightElements = function(e, t, r) {
        var n, i, l, c, s = document.querySelectorAll("." + u.className);
        s.length && s.forEach(function(e) {
            o.resetInlineStyles(e, u.attrMarker, u.styles), e.classList.remove(u.className)
        });
        var d = [];
        switch (e) {
            case "xpath":
                var f = a.recursiveXpathSearch(t);
                d = "boolean" != typeof f ? [f] : [];
                break;
            case "href":
                var p = Array.prototype.slice.call(document.querySelectorAll("[href]"));
                try {
                    for (var m = __values(p), h = m.next(); !h.done; h = m.next()) {
                        var y = h.value;
                        y.href.toLowerCase().indexOf(t) > -1 && d.push(y)
                    }
                } catch (e) {
                    n = {
                        error: e
                    }
                } finally {
                    try {
                        h && !h.done && (i = m.return) && i.call(m)
                    } finally {
                        if (n) throw n.error
                    }
                }
                break;
            case "src":
                var g = Array.prototype.slice.call(document.querySelectorAll("[src]"));
                try {
                    for (var b = __values(g), v = b.next(); !v.done; v = b.next()) {
                        var A = v.value;
                        A.src.toLowerCase().indexOf(t) > -1 && d.push(A)
                    }
                } catch (e) {
                    l = {
                        error: e
                    }
                } finally {
                    try {
                        v && !v.done && (c = b.return) && c.call(b)
                    } finally {
                        if (l) throw l.error
                    }
                }
                break;
            case "attr":
                if (r.attrName) {
                    var _ = document.querySelectorAll("[" + r.attrName + '="' + t + '"]');
                    d = Array.prototype.slice.call(_)
                }
        }
        for (var E = 0; E < d.length; E++) {
            var w = d[E];
            if (w && "function" == typeof w.setAttribute && (w.classList.add(u.className), o.applyInlineStyles(w, u.attrMarker, u.styles), !E && r.scroll)) {
                var x = w.getBoundingClientRect(),
                    S = x.top + window.pageYOffset - document.documentElement.clientTop - window.innerHeight / 2 + x.height;
                window.scrollTo({
                    top: S,
                    behavior: "smooth"
                })
            }
        }
    }, n.getElementAccessibleName = function(r) {
        var n = r.getAttribute("aria-label"),
            i = r.getAttribute("aria-describedby");
        if (i && (n += t(i)), n && n.trim()) return n.trim().toLowerCase();
        var o = r.getAttribute("aria-labelledby");
        if (o && (n += t(o)), n && n.trim()) return n.trim().toLowerCase();
        if ((n = r.textContent ? r.textContent : null) && n.trim()) return n.trim().toLowerCase();
        if ((n = r.value || "") && n.trim() && "INPUT" === r.tagName.toUpperCase() && r.type && -1 !== ["button", "submit", "reset"].indexOf(r.type.toLowerCase())) return n.trim().toLowerCase();
        var a = r.querySelector('img, *[role="img"]');
        return a && (n = e(a)) && n.trim() ? n.trim().toLowerCase() : null
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("remediation_helper_outcome"),
        t = UserWayWidgetApp.getLib("util");
    e.of = function(e, r, n, i, o) {
        return r = r || {
            items: []
        }, n = n || {
            items: [],
            path: null
        }, {
            helperName: e,
            postMessageAppData: r,
            backEndData: n,
            countFixed: i,
            countTodo: o,
            hash: t.hashString(e + JSON.stringify(r) + i + o)
        }
    }
}();
var __assign = this && this.__assign || function() {
    return __assign = Object.assign || function(e) {
        for (var t, r = 1, n = arguments.length; r < n; r++) {
            t = arguments[r];
            for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
        }
        return e
    }, __assign.apply(this, arguments)
};
! function() {
    var e = UserWayWidgetApp.addLib("remediation_results_holder"),
        t = UserWayWidgetApp.getLib("util"),
        r = ["REMEDIATION_HEADING", "REMEDIATION_COLOR_CONTRAST"];
    e.instance = new function() {
        var e = this,
            n = {};
        e.reset = function() {
            n = {}
        }, e.get = function() {
            return n
        }, e.mergeHelperOutcomes = function(e, n) {
            if (e.helperName !== n.helperName) throw "Inconsistent helpers! Unable to merge " + e.helperName + " with " + n.helperName;
            var i = e.postMessageAppData && -1 === r.indexOf(e.helperName),
                o = -1 === r.indexOf(e.helperName);
            return e.postMessageAppData = i ? {
                items: e.postMessageAppData.items.concat(n.postMessageAppData.items)
            } : __assign({}, n.postMessageAppData), e.backEndData.items = n.backEndData.items, e.countFixed = o ? e.countFixed + n.countFixed : n.countFixed, e.countTodo = e.countTodo + n.countTodo, e.hash = t.hashString(n.hash), e
        }, e.put = function(t) {
            var r = t.helperName,
                i = n[r] ? e.mergeHelperOutcomes(n[r], t) : t;
            n[r] = i
        }, e.getCurrentHash = function() {
            var e = "";
            return Object.keys(n).length ? (Object.keys(n).forEach(function(t) {
                e += n[t].hash
            }), e) : e
        }, e.getHelperPostMessagePayload = function(e) {
            var t = n[e];
            return t ? t.postMessageAppData : {
                items: []
            }
        }, e.getHelpersOutcomeCounters = function() {
            var e = {};
            return Object.keys(n).forEach(function(t) {
                e[t] = n[t].countFixed
            }), e
        }, e.getHelpersTodoOutcomeCounters = function() {
            var e = {};
            return Object.keys(n).forEach(function(t) {
                e[t] = n[t].countTodo
            }), e
        }, e.toString = function() {
            return JSON.stringify(n)
        }
    }
}(),
function() {
    UserWayWidgetApp.addLib("remediation_changes_detector").instance = new function() {
        function e() {
            if (n.length !== r) return !1;
            var e = n.every(function(e) {
                return e === n[0]
            });
            return t.reset(), e
        }
        var t = this,
            r = 2,
            n = [];
        t.reset = function() {
            n = []
        }, t.anyChange = function(t) {
            return n.length < r && n.push(t), n.length > r && (n = [t]), !e()
        }, t.anyChangeOnIterationComplete = function(e) {
            return t.anyChange(e)
        }
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("remediation_stopwatch"),
        t = {};
    e.checkPointHelperStart = function(e, r) {
        r.debugMode && (t.hasOwnProperty(e) || (t[e] = {
            start: [],
            "f-start": [],
            "f-end": [],
            "a-start": [],
            "a-end": [],
            "r-start": [],
            "r-end": [],
            end: []
        }), t[e].start.push(performance.now()))
    }, e.checkPointHelperEnd = function(e, r) {
        r.debugMode && t[e].end.push(performance.now())
    }, e.checkPointHelperFilterStart = function(e, r) {
        r.debugMode && t[e]["f-start"].push(performance.now())
    }, e.checkPointHelperFilterEnd = function(e, r) {
        r.debugMode && t[e]["f-end"].push(performance.now())
    }, e.checkPointHelperAwaitForResourcesStart = function(e, r) {
        r.debugMode && t[e]["a-start"].push(performance.now())
    }, e.checkPointHelperAwaitForResourcesEnd = function(e, r) {
        r.debugMode && t[e]["a-end"].push(performance.now())
    }, e.checkPointHelperDoRemediationStart = function(e, r) {
        r.debugMode && t[e]["r-start"].push(performance.now())
    }, e.checkPointHelperDoRemediationEnd = function(e, r) {
        r.debugMode && t[e]["r-end"].push(performance.now())
    }, UserWayWidgetApp.getHelpersPerformance = function() {
        var e = {};
        return Object.keys(t).forEach(function(r) {
            var n = t[r];
            e[r] = {
                "1_filter": [],
                "2_resources": [],
                "3_remediation": [],
                "4_total": []
            };
            for (var i = 0; i < n.start.length; i++) e[r]["1_filter"].push(n["f-end"][i] - n["f-start"][i]), e[r]["2_resources"].push(n["a-end"][i] - n["a-start"][i]), e[r]["3_remediation"].push(n["r-end"][i] - n["r-start"][i]), e[r]["4_total"].push(n.end[i] - n.start[i])
        }), t._aggregated = e, t
    }
}(),
function() {
    function e(e, t, n, i) {
        return new Promise(function(o, a) {
            var u = UserWayWidgetApp.getLib(e);
            r.checkPointHelperStart(u.name, i);
            var l = [];
            r.checkPointHelperFilterStart(u.name, i);
            try {
                l = u.filter ? u.filter(t, i) : null, r.checkPointHelperFilterEnd(u.name, i)
            } catch (e) {
                return r.checkPointHelperFilterEnd(u.name, i), r.checkPointHelperEnd(u.name, i), i.debugMode && console.error(e), o()
            }
            r.checkPointHelperAwaitForResourcesStart(u.name, i), u.awaitForResources(l, i).then(function() {
                r.checkPointHelperAwaitForResourcesEnd(u.name, i), r.checkPointHelperDoRemediationStart(u.name, i), u.doRemediation(n, l, i).then(function() {
                    r.checkPointHelperDoRemediationEnd(u.name, i), r.checkPointHelperEnd(u.name, i), o()
                }).catch(function(e) {
                    r.checkPointHelperDoRemediationEnd(u.name, i), r.checkPointHelperEnd(u.name, i), i.debugMode && console.error(e), o()
                })
            }).catch(function(e) {
                r.checkPointHelperAwaitForResourcesEnd(u.name, i), r.checkPointHelperEnd(u.name, i), i.debugMode && console.error(e), o()
            })
        })
    }
    var t = UserWayWidgetApp.addLib("remediation_processor"),
        r = UserWayWidgetApp.getLib("remediation_stopwatch");
    UserWayWidgetApp.getLib("remediation_utils");
    t.runHelper = function(t, r, n, i) {
        return t.then ? t : e(t, r, n, i)
    }, t.parallel = function(e, t) {
        return Promise.all(e.map(function(e) {
            return t(e)
        }))
    }, t.sequence = function(e, t) {
        return e.reduce(function(e, r) {
            return e.then(function() {
                return t(r)
            })
        }, Promise.resolve())
    }, t.series = function(e, r, n, i) {
        return t.sequence(e, function(e) {
            return t.parallel(e, function(e) {
                return t.runHelper(e, r, n, i)
            })
        }).catch(function(e) {
            i.debugMode && console.error(e)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
    if (r) return r.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && n >= e.length && (e = void 0), {
                value: e && e[n++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var t, r, n = [].slice.call(m.findAllElements(e)),
            i = n.filter(function(e) {
                var t, r, n = Array.from(e.attributes),
                    i = !1;
                try {
                    for (var o = __values(n), a = o.next(); !a.done; a = o.next()) {
                        var u = a.value,
                            l = u.value.toLowerCase();
                        if (-1 !== l.indexOf("close") || -1 !== l.indexOf("dismiss")) {
                            i = !0;
                            break
                        }
                    }
                } catch (e) {
                    t = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (r = o.return) && r.call(o)
                    } finally {
                        if (t) throw t.error
                    }
                }
                return i
            }),
            o = null,
            a = l().vw,
            u = Math.round(a / 20);
        try {
            for (var c = __values(i), s = c.next(); !s.done; s = c.next()) {
                var d = s.value,
                    f = d.offsetWidth,
                    p = d.offsetHeight;
                if (f && p && f <= 5 * u) {
                    o = d;
                    break
                }
            }
        } catch (e) {
            t = {
                error: e
            }
        } finally {
            try {
                s && !s.done && (r = c.return) && r.call(c)
            } finally {
                if (t) throw t.error
            }
        }
        return o
    }

    function t(e, t) {
        var r, n, i = null;
        try {
            for (var o = __values(e[0]), a = o.next(); !a.done; a = o.next()) {
                var l = a.value,
                    c = new Array(e.length).fill(0);
                c[0] = 1;
                for (var s = 1; s < e.length; s++) {
                    e[s].indexOf(l) > -1 && (c[s] = 1)
                }
                if (c.every(function(e) {
                        return !!e
                    })) {
                    i = l;
                    break
                }
            }
        } catch (e) {
            r = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (n = o.return) && n.call(o)
            } finally {
                if (r) throw r.error
            }
        }
        return i && 0 === e[0].indexOf(i) && u(i.offsetWidth, t) < 5 && (i = null), i
    }

    function r(e, t) {
        return e.classList.contains("tt-dropdown-menu") || /datepicker/.test(e.getAttribute("class")) || !!e.id && "klevuSearchingArea" === e.id || e.hasAttribute("data-uw-rm-ignore") || !!Array.from(document.querySelectorAll("nav")).find(function(t) {
            return e.contains(t)
        }) || !!e.querySelector("[class*='search']")
    }

    function n(e) {
        var t = window.getComputedStyle(e),
            n = "none" === t.display,
            i = "fixed" === t.position,
            o = parseFloat(t.width),
            a = parseFloat(t.height);
        return i && !n && o && a && !r(e, t)
    }

    function i(e) {
        var t = null;
        if (!e) return t;
        for (; e && "BODY" !== e.tagName;) {
            if (n(e)) {
                t = e;
                break
            }
            e = e.parentElement
        }
        return t
    }

    function o() {
        return /^([^.]+\.)?manage\..*userway\.(dev|org)$/.test(window.location.host)
    }

    function a() {
        if (114355 === f.services.siteId || 990479 === f.services.siteId || o()) return null;
        var e = l(),
            r = e.vw,
            n = e.vh,
            a = Math.round(r / 2),
            u = Math.round(n / 2),
            c = Math.round(3 * r / 4),
            s = Math.round(n / 4),
            d = u + Math.round(n / 4),
            p = Math.round(r / 20),
            m = Math.round(n / 20),
            h = [{
                x: a,
                y: u - m
            }, {
                x: a + p,
                y: u
            }, {
                x: a,
                y: u + m
            }, {
                x: a - p,
                y: u
            }],
            y = [{
                x: c,
                y: u - m
            }, {
                x: c + p,
                y: u
            }, {
                x: c,
                y: u + m
            }, {
                x: c - p,
                y: u
            }],
            g = [{
                x: a,
                y: s
            }, {
                x: a - p,
                y: s + m
            }, {
                x: a + p,
                y: s + m
            }],
            b = [{
                x: a,
                y: d
            }, {
                x: a - p,
                y: d - m
            }, {
                x: a + p,
                y: d - m
            }],
            v = document.elementsFromPoint(h[0].x, h[0].y),
            A = document.elementsFromPoint(h[1].x, h[1].y),
            _ = document.elementsFromPoint(h[2].x, h[2].y),
            E = document.elementsFromPoint(h[3].x, h[3].y),
            w = i(t([v, A, _, E], r));
        if (w) return w;
        var x = document.elementsFromPoint(g[0].x, g[0].y),
            S = document.elementsFromPoint(g[1].x, g[1].y),
            I = document.elementsFromPoint(g[2].x, g[2].y),
            O = i(t([x, S, I], r));
        if (O) return O;
        var R = document.elementsFromPoint(b[0].x, b[0].y),
            W = document.elementsFromPoint(b[1].x, b[1].y),
            N = document.elementsFromPoint(b[2].x, b[2].y),
            L = i(t([R, W, N], r));
        if (L) return L;
        var C = document.elementsFromPoint(y[0].x, y[0].y),
            T = document.elementsFromPoint(y[1].x, y[1].y),
            k = document.elementsFromPoint(y[2].x, y[2].y),
            U = document.elementsFromPoint(y[3].x, y[3].y),
            P = i(t([C, T, k, U], r));
        return P || null
    }

    function u(e, t) {
        return Math.abs(e - t) / ((e + t) / 2) * 100
    }

    function l() {
        return {
            vw: Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0),
            vh: Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0)
        }
    }
    var c = UserWayWidgetApp.addLib("cer_observer"),
        s = UserWayWidgetApp.getLib("event_emitter"),
        d = UserWayWidgetApp.getLib("remediation_utils"),
        f = UserWayWidgetApp.ContextHolder.config,
        p = UserWayWidgetApp.getLib("remediationConfig").popups,
        m = UserWayWidgetApp.getLib("util"),
        h = [];
    c.apply = function(e) {}, c.tick = function(t) {
        var r = t.processParameters;
        r.debugMode && console.log("CER observer: tick");
        var n, i = null;
        if (r.debugMode && (n = performance.now()), p.enabled) {
            var o = null;
            try {
                o = a()
            } catch (e) {
                r.debugMode && console.error(e)
            }
            if (o) {
                o.setAttribute(d.PROCESS_ATTRIBUTES.CER.popup.wrapper, "");
                if (-1 === h.indexOf(o)) {
                    s.emitEvent("UW_CER_POPUP_FOUND", [o]), h.push(o);
                    var u = null;
                    try {
                        u = e(o)
                    } catch (e) {
                        r.debugMode && console.error(e)
                    }
                    u && u.setAttribute(d.PROCESS_ATTRIBUTES.CER.popup.close, ""), s.emitEvent("UW_CER_POPUP_ON", [
                        [o, u]
                    ]), r.debugMode && console.log("CER observer: POPUP found", o, u)
                }
            } else h.forEach(function(e) {
                s.emitEvent("UW_CER_POPUP_OFF", [e]), r.debugMode && console.log("CER observer: POPUP closed", e)
            }), h = []
        }
        r.debugMode && (i = performance.now(), console.log("CER observer tick: execution took " + (i - n) + " milliseconds."))
    }
}();
var __read = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, i, o = r.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(n = o.next()).done;) a.push(n.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                n && !n.done && (r = o.return) && r.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length)
            for (var n, i = 0, o = t.length; i < o; i++) !n && i in t || (n || (n = Array.prototype.slice.call(t, 0, i)), n[i] = t[i]);
        return e.concat(n || Array.prototype.slice.call(t))
    };
! function() {
    function e(e) {
        P && P.time(e)
    }

    function t(e) {
        P && P.timeEnd(e)
    }

    function r() {
        N.getMeasurements && N.getMeasurements("Remediation")
    }

    function n(e) {
        return e ? __spreadArray([q, j, B], __read(G.map(function(e) {
            return [e]
        })), !1) : __spreadArray([
            ["REMEDIATION_FORM_LABEL", "REMEDIATION_KEYBOARD_NAVIGATION"]
        ], __read(G.map(function(e) {
            return [e]
        })), !1)
    }

    function i() {
        return U.hasAttribute("data-uw-w-kb")
    }

    function o() {
        F.completedEventFired || (F.completedEventFired = !0, w.fireUserWayRemediationCompletedEvent({
            enabled: !0,
            counters: W.getHelpersOutcomeCounters()
        }))
    }

    function a() {
        var e;
        if (!F.iterationInProgress) {
            if (O.consolidated && !UserWayWidgetApp.ContextHolder.remediationResources || D()) return;
            var t = n(!F.domChangesEnqueued.length);
            F.iterationInProgress = !0, F.domChangesEnqueued = [], F.debugMode && console.log("UserWay Remediation: tick started"), H && i() && (S.tick({
                processParameters: F
            }), null === (e = null === I || void 0 === I ? void 0 : I.tick) || void 0 === e || e.call(I, {
                processParameters: F
            })), x.series(t, [document.body], v.HelperCallbackAggregator, {
                reset: F.locationChanged,
                debugMode: M
            }).catch(function(e) {
                console.error(e)
            }).finally(function() {
                F.debugMode && console.log("UserWay Remediation: tick ended"), o(), setTimeout(function() {
                    r(), d(), f(), F.iterationInProgress = !1, F.domChangesEnqueued.length && a()
                }, 1e3)
            }), F.locationChanged && p(), F.locationChanged = !1
        }
    }

    function u() {
        var r;
        V.forEach(function(r) {
            var n;
            e(r);
            var i = UserWayWidgetApp.getLib(r);
            F.debugMode && console.log("UserWay Remediation: One-time helper applied %c" + r, "color:Red"), null === (n = null === i || void 0 === i ? void 0 : i.apply) || void 0 === n || n.call(i, F), t(r)
        }), null === (r = null === I || void 0 === I ? void 0 : I.apply) || void 0 === r || r.call(I, {
            processParameters: F
        })
    }

    function l() {
        setTimeout(function() {
            a(), H && u(), F.debugMode && console.log("UserWay Remediation: process started"), A.on(L, function(e, t) {
                if (t && (!t || t.length)) {
                    if (T) return void(F.debugMode && console.log("UserWay Remediation: SKIP_DOM_CHANGES_REMEDIATION"));
                    F.debugMode && console.log("UserWay Remediation: tick resumed; initiator: DOM change"), D() || (F.domChangesEnqueued = F.domChangesEnqueued.concat(t), F.iterationInProgress || a())
                }
            })
        }, C)
    }

    function c(e) {
        var t = e.data.remediationHelperName;
        t && (B.push("REMEDIATION_" + t), K.push("REMEDIATION_" + t), a())
    }

    function s(e) {
        var t = UserWayWidgetApp.getLib("REMEDIATION_NAVIGATION_MENU");
        t && "function" == typeof t.apply && t.apply(F), k && l()
    }

    function d() {
        m("remediation-count", W.getHelpersOutcomeCounters())
    }

    function f() {
        m("all-data", W.get())
    }

    function p() {
        m("get-site-info", {
            origin: location.origin,
            path: location.pathname
        })
    }

    function m(e, t) {
        F.debugMode && (console.log("UserWay Remediation PostMessage: %c[TYPE]: %c" + e, "color:Blue", "color:Red"), console.group("%c[PAYLOAD]:", "color:Blue"), console.log(t), console.groupEnd()), w.postMessage({
            action: "remediation",
            type: e,
            data: t
        })
    }
    var h, y, g, b, v = UserWayWidgetApp.addLib("remediation_manager"),
        A = UserWayWidgetApp.getLib("event_emitter"),
        _ = UserWayWidgetApp.getLib("dom_observer"),
        E = UserWayWidgetApp.getLib("remediation_utils"),
        w = UserWayWidgetApp.getLib("util"),
        x = UserWayWidgetApp.getLib("remediation_processor"),
        S = UserWayWidgetApp.getLib("cer_observer"),
        I = UserWayWidgetApp.getLib("cpr_patterns_observer"),
        O = UserWayWidgetApp.getLib("remediationConfig"),
        R = UserWayWidgetApp.ContextHolder.config,
        W = UserWayWidgetApp.getLib("remediation_results_holder").instance,
        N = UserWayWidgetApp.getLib("performance_logger");
    v.ResultsHolder = W;
    var L = _.DOM_OBSERVER_DOM_CHANGED_EVENT,
        C = (null === (h = null === R || void 0 === R ? void 0 : R.tunings) || void 0 === h ? void 0 : h.tech_rem_in_throttle_ms) ? Number(null === (y = null === R || void 0 === R ? void 0 : R.tunings) || void 0 === y ? void 0 : y.tech_rem_in_throttle_ms) : 1e3,
        T = null === (g = null === R || void 0 === R ? void 0 : R.tunings) || void 0 === g ? void 0 : g.tech_rem_dom,
        k = null === (b = null === R || void 0 === R ? void 0 : R.tunings) || void 0 === b ? void 0 : b.tech_rem_on_tab,
        U = document.querySelector("html"),
        P = N.getInstance ? N.getInstance("Remediation") : null,
        D = function() {
            if (location.pathname && location.pathname.indexOf("wp-admin") > -1) return !0;
            var e = O.commonSettings,
                t = e.enabled,
                r = e.config,
                n = r.mobile,
                i = r.disabledPages;
            return !t || (!(!UserWayWidgetApp.ContextHolder.config.isMobile || !n || n.enabled) || !(null === i || void 0 === i || !i.some(function(e) {
                var t;
                return (null === (t = window.location) || void 0 === t ? void 0 : t.href.indexOf(e)) > -1
            })))
        },
        H = !!R.remediation && !D(),
        M = !1;
    try {
        UserWayWidgetApp.setDebugMode = function(e) {
            e ? (window.localStorage.setItem("userway-rm-debug", "1"), console.log("UserWay Remediation: Debug mode enabled")) : window.localStorage.removeItem("userway-rm-debug")
        }, M = window.localStorage.getItem("userway-rm-debug")
    } catch (e) {}
    var F = {
            iterationInProgress: !1,
            locationChanged: !0,
            domChangesEnqueued: [],
            completedEventFired: !1,
            debugMode: M
        },
        q = H ? ["REMEDIATION_AUTO_PLAY_VIDEO", "REMEDIATION_FORM_LABEL", "REMEDIATION_SITE_LANGUAGE", "REMEDIATION_MARQUEE", "REMEDIATION_SCREEN_READER_BASIC", "REMEDIATION_SKIP_NAVIGATION_LINK", "REMEDIATION_META_VIEWPORT"] : [],
        j = H ? ["REMEDIATION_EXTERNAL_LINK_TARGETS", "REMEDIATION_KEYBOARD_NAVIGATION", "REMEDIATION_VAGUE_LINK", "REMEDIATION_IFRAME_TITLE", "REMEDIATION_PDF_DOCUMENTS"] : [],
        B = H ? ["REMEDIATION_HEADING"] : [],
        G = ["REMEDIATION_COLOR_CONTRAST"],
        V = H ? ["REMEDIATION_FOCUS_STYLE", "REMEDIATION_PER_SITE", "REMEDIATION_POPUP"] : [];
    (function() {
        return [932691].includes(UserWayWidgetApp.ContextHolder.config.services.siteId)
    })() && B.push("REMEDIATION_SOCIAL_SENSITIVITY");
    var K = [].concat(q, j, B, G),
        Y = function() {
            function r() {}
            return r.prototype.onHelperRemediationStarted = function(t) {
                e(t)
            }, r.prototype.onHelperRemediationCompleted = function(e) {
                e.backEndData && e.backEndData.items.length && E.sendBackEnd("/remediation/" + e.backEndData.path, e.backEndData.items, e.backEndData.props), W.put(e), m(e.helperName, W.getHelperPostMessagePayload(e.helperName)), t(e.helperName)
            }, r
        }();
    v.HelperCallbackAggregator = new Y, (!k || i() || UserWayWidgetApp.ContextHolder.config.isMobile) && l();
    var X = {
            "get-site-info": p,
            "remediation-count": d,
            "all-data": f,
            "element-is-visible": function(e) {
                var t = JSON.parse(e.data.data),
                    r = t.elements.map(function(e) {
                        return [e, E.isElementVisible(e)]
                    });
                m("element-is-visible", {
                    key: t.key,
                    elements: r
                })
            },
            "element-highlight": function(e) {
                var t = e.data.data.type,
                    r = e.data.data.value ? e.data.data.value.toLowerCase() : "",
                    n = Object.assign({
                        scroll: !0
                    }, e.data.data.options || {});
                E.highlightElements(t, r, n)
            },
            "app-key-nav-enabled": function(e) {
                s(e)
            },
            remediation: function(e) {
                var t = e.data.type;
                W.get()[t] && m(t, W.getHelperPostMessagePayload(t))
            },
            "remediation-check": function() {
                a()
            },
            "add-dynamically": c
        },
        Q = UserWayWidgetApp.getLib("REMEDIATION_FOCUS_STYLE"),
        z = {
            "custom-focus-get": function(e) {
                m("custom-focus-get", Q.getFocusStyle())
            },
            "custom-focus-update": function(e) {
                e.data && e.data.data && Q.updateOutlineStyle(e.data)
            }
        },
        J = UserWayWidgetApp.getLib("REMEDIATION_SKIP_NAVIGATION_LINK"),
        $ = {
            "skip-links-get": function(e) {
                m("skip-links-get", J.getSkipLinksConfig())
            },
            "skip-links-update": function(e) {}
        },
        Z = UserWayWidgetApp.getLib("REMEDIATION_COLOR_CONTRAST"),
        ee = {
            "enable-color-contrast": function() {
                Z.isSmartContrastEnabled() && Z.disableSmartContrast(), Z.isEnabled() || (Z.enable(), a())
            },
            "fix-color-contrast": function(e) {
                e.data && e.data.data && (Z.fixIssues(e.data.data), a())
            },
            "fix-all-color-contrast": function() {
                Z.autofixAllIssues(), a()
            },
            "reset-all": function() {
                Z.resetIssuesFixes(), a()
            },
            "reset-autofixed": function() {
                Z.resetAutofixed(), a()
            }
        },
        te = UserWayWidgetApp.getLib("REMEDIATION_VAGUE_LINK"),
        re = {
            "vague-link-update": function(e) {
                e.data && e.data.data && te.updateElement(e.data.data)
            }
        },
        ne = Object.assign({}, X, z, $, ee, re),
        ie = function(t) {
            var r = t.data || {};
            if (r.isUserWay && ("remediation" === r.action || "aria-editor" === r.action)) {
                var n = t.data.type;
                if (-1 !== Object.keys(ne).indexOf(n)) {
                    e(n);
                    (0, ne[n])(t), e(n)
                } else ne.remediation(t)
            }
        };
    w.registerPostMessageListener(ie)
}();